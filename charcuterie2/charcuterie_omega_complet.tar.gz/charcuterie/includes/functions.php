<?php
function uploadImage($file, $prefix = 'prod') {
    if (!isset($file['tmp_name']) || empty($file['tmp_name'])) return null;
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $allowed = ['jpg','jpeg','png','gif','webp'];
    if (!in_array($ext, $allowed)) return null;
    if ($file['size'] > 5 * 1024 * 1024) return null;
    $name = $prefix . '_' . uniqid() . '.' . $ext;
    $dest = UPLOAD_DIR . $name;
    if (!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR, 0755, true);
    if (move_uploaded_file($file['tmp_name'], $dest)) return $name;
    return null;
}

function imgTag($img, $alt = '', $class = '') {
    $default = ADMIN_URL . '../assets/images/no-image.png';
    $src = $img ? BASE_URL . UPLOAD_URL . htmlspecialchars($img) : $default;
    return '<img src="'.$src.'" alt="'.htmlspecialchars($alt).'" class="'.$class.'" onerror="this.src=\''.BASE_URL.'assets/images/no-image.png\'">';
}

function formatMoney($n) {
    return number_format((float)$n, 0, ',', ' ') . ' FCFA';
}

function alertStock($pdo) {
    $st = $pdo->query("SELECT COUNT(*) as c FROM produits WHERE stock_actuel <= stock_min AND stock_min > 0")->fetch();
    return (int)$st['c'];
}

function flash($msg, $type = 'success') {
    $_SESSION['flash'] = ['msg' => $msg, 'type' => $type];
}

function getFlash() {
    if (isset($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $f;
    }
    return null;
}

function showFlash() {
    $f = getFlash();
    if ($f) {
        $cls = $f['type'] === 'success' ? 'alert-success' : ($f['type'] === 'error' ? 'alert-danger' : 'alert-warning');
        echo '<div class="alert '.$cls.' alert-dismissible fade show" role="alert">'
            .htmlspecialchars($f['msg'])
            .'<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
    }
}

function secureRedirect($url) {
    header('Location: ' . $url);
    exit;
}

function sanitize($v) {
    return htmlspecialchars(trim($v), ENT_QUOTES, 'UTF-8');
}
