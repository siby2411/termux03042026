<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'charcuterie');
define('SITE_NAME', 'OMEGA INFORMATIQUE CONSULTING');
define('SITE_SUBTITLE', 'GESTION CHARCUTERIE');
define('UPLOAD_DIR', __DIR__ . '/../assets/uploads/');
define('UPLOAD_URL', 'assets/uploads/');
define('BASE_URL', '/apachewsl2026/charcuterie/');
define('ADMIN_URL', '/apachewsl2026/charcuterie/admin/');

$pdo = null;
function getPDO() {
    global $pdo;
    if ($pdo === null) {
        try {
            $pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4", DB_USER, DB_PASS);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            die('<div style="color:#c0392b;padding:20px;font-family:monospace;background:#fdf2f2;border:1px solid #e74c3c;border-radius:8px;margin:20px">❌ Erreur DB: '.$e->getMessage().'</div>');
        }
    }
    return $pdo;
}
