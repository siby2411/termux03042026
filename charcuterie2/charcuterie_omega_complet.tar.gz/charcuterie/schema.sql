-- ============================================================
--  OMEGA INFORMATIQUE CONSULTING - GESTION CHARCUTERIE
--  Schéma complet MariaDB
-- ============================================================

USE charcuterie;

-- Utilisateurs admin
CREATE TABLE IF NOT EXISTS utilisateurs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin','gestionnaire','caissier') DEFAULT 'caissier',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Catégories produits
CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    icone VARCHAR(10) DEFAULT '🥩',
    couleur VARCHAR(20) DEFAULT '#e74c3c',
    description TEXT
);

-- Produits
CREATE TABLE IF NOT EXISTS produits (
    id INT AUTO_INCREMENT PRIMARY KEY,
    categorie_id INT,
    nom VARCHAR(150) NOT NULL,
    description TEXT,
    prix_vente DECIMAL(10,2) NOT NULL DEFAULT 0,
    prix_achat DECIMAL(10,2) NOT NULL DEFAULT 0,
    stock_actuel DECIMAL(10,3) DEFAULT 0,
    stock_min DECIMAL(10,3) DEFAULT 1,
    unite VARCHAR(20) DEFAULT 'kg',
    image VARCHAR(255),
    actif TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (categorie_id) REFERENCES categories(id) ON DELETE SET NULL
);

-- Clients
CREATE TABLE IF NOT EXISTS clients (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    prenom VARCHAR(100),
    telephone VARCHAR(20),
    email VARCHAR(150),
    adresse TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Fournisseurs
CREATE TABLE IF NOT EXISTS fournisseurs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(150) NOT NULL,
    contact VARCHAR(100),
    telephone VARCHAR(20),
    email VARCHAR(150),
    adresse TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Factures
CREATE TABLE IF NOT EXISTS factures (
    id INT AUTO_INCREMENT PRIMARY KEY,
    client_id INT,
    numero VARCHAR(30) UNIQUE NOT NULL,
    date_facture DATE NOT NULL,
    total_ht DECIMAL(12,2) DEFAULT 0,
    tva DECIMAL(5,2) DEFAULT 18,
    total_ttc DECIMAL(12,2) DEFAULT 0,
    statut ENUM('brouillon','emise','payee','annulee') DEFAULT 'emise',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE SET NULL
);

-- Lignes de facture
CREATE TABLE IF NOT EXISTS facture_lignes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    facture_id INT NOT NULL,
    produit_id INT,
    designation VARCHAR(200) NOT NULL,
    quantite DECIMAL(10,3) NOT NULL,
    unite VARCHAR(20) DEFAULT 'kg',
    prix_unitaire DECIMAL(10,2) NOT NULL,
    total_ligne DECIMAL(12,2) NOT NULL,
    FOREIGN KEY (facture_id) REFERENCES factures(id) ON DELETE CASCADE,
    FOREIGN KEY (produit_id) REFERENCES produits(id) ON DELETE SET NULL
);

-- Ventes directes (caisse)
CREATE TABLE IF NOT EXISTS ventes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    facture_id INT,
    produit_id INT,
    client_id INT,
    quantite DECIMAL(10,3) NOT NULL,
    prix_unitaire DECIMAL(10,2) NOT NULL,
    total DECIMAL(12,2) NOT NULL,
    date_vente DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (facture_id) REFERENCES factures(id) ON DELETE SET NULL,
    FOREIGN KEY (produit_id) REFERENCES produits(id) ON DELETE SET NULL,
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE SET NULL
);

-- Approvisionnements
CREATE TABLE IF NOT EXISTS approvisionnements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fournisseur_id INT,
    produit_id INT NOT NULL,
    quantite DECIMAL(10,3) NOT NULL,
    prix_unitaire DECIMAL(10,2) NOT NULL,
    total DECIMAL(12,2) NOT NULL,
    date_appro DATE NOT NULL,
    reference VARCHAR(50),
    notes TEXT,
    FOREIGN KEY (fournisseur_id) REFERENCES fournisseurs(id) ON DELETE SET NULL,
    FOREIGN KEY (produit_id) REFERENCES produits(id) ON DELETE CASCADE
);

-- Dépenses
CREATE TABLE IF NOT EXISTS depenses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    libelle VARCHAR(200) NOT NULL,
    montant DECIMAL(12,2) NOT NULL,
    categorie ENUM('salaire','loyer','electricite','eau','transport','emballage','maintenance','publicite','divers') DEFAULT 'divers',
    date_depense DATE NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ===== DONNÉES DE BASE =====

INSERT INTO utilisateurs (nom, email, password, role) VALUES
('Administrateur', 'admin@omega.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');
-- password: password

INSERT INTO categories (nom, icone, couleur, description) VALUES
('Charcuterie Sèche',  '🥩','#c0392b','Jambon sec, saucisson, salami, chorizo...'),
('Charcuterie Cuite',  '🍖','#e67e22','Jambon cuit, mortadelle, pâtés, rillettes...'),
('Volaille',           '🐓','#f39c12','Poulet, dinde, pintade, canard, caille...'),
('Fromages',           '🧀','#d4ac0d','Fromages divers - frais, affinés, fondus...'),
('Œufs & Laitiers',   '🥚','#f1c40f','Œufs de poule, caille, lait, crème, beurre...'),
('Viandes Rouges',     '🥩','#922b21','Bœuf, mouton, chèvre, agneau...'),
('Poissons & Mer',     '🐟','#1a5276','Poissons fumés, sardines, thon, crevettes...'),
('Épicerie Fine',      '🫙','#27ae60','Condiments, sauces, épices, conserves...'),
('Emballages',         '📦','#7f8c8d','Sacs, barquettes, film alimentaire...'),
('Boissons',           '🧃','#2980b9','Jus, sodas, eau minérale...');

INSERT INTO produits (categorie_id,nom,description,prix_vente,prix_achat,stock_actuel,stock_min,unite) VALUES
(1,'Saucisson Sec Artisanal','Saucisson sec pur porc, séchage naturel 45 jours',3500,2200,15,3,'kg'),
(1,'Chorizo Doux','Chorizo doux au paprika fumé, spécialité espagnole',4200,2800,10,2,'kg'),
(1,'Salami Milano','Salami Milano finement tranché, goût délicat',5500,3600,8,2,'kg'),
(1,'Jambon Sec 24 mois','Jambon sec affiné 24 mois, sel de Guérande',12000,8000,5,1,'kg'),
(1,'Coppa Artisanale','Coppa italienne, épaule de porc marinée',6500,4200,6,1,'kg'),
(2,'Jambon Cuit Supérieur','Jambon cuit supérieur, sans polyphosphates',4800,3000,20,5,'kg'),
(2,'Mortadelle Pistaches','Mortadelle à la pistache, spécialité bolognaise',3200,2000,12,3,'kg'),
(2,'Pâté de Campagne','Pâté de campagne maison, recette traditionnelle',2800,1600,8,2,'kg'),
(2,'Rillettes du Mans','Rillettes de porc cuites lentement, pot 500g',2500,1400,15,4,'pot'),
(2,'Boudin Blanc Truffé','Boudin blanc aux truffes, spécialité festive',7500,5000,4,1,'kg'),
(3,'Poulet Fermier Entier','Poulet fermier Label Rouge, élevé en plein air',3500,2200,30,10,'kg'),
(3,'Blanc de Dinde','Escalopes de dinde fraîches, tranche fine',3800,2400,15,5,'kg'),
(3,'Cuisses de Canard','Cuisses de canard confites, recette du Sud-Ouest',5500,3500,10,3,'kg'),
(3,'Pintade Fermière','Pintade fermière entière, chair savoureuse',4500,2900,8,2,'pièce'),
(3,'Filet de Poulet Bio','Filet de poulet certifié bio, sans antibiotiques',5200,3400,12,4,'kg'),
(3,'Cailles Prêtes à Cuire','Cailles vidées prêtes à cuisiner',1800,1100,20,6,'pièce'),
(4,'Emmental Français','Emmental français, fruité et fondant',3200,1900,8,2,'kg'),
(4,'Camembert Normand','Camembert AOP de Normandie, au lait cru',2500,1500,15,5,'pièce'),
(4,'Fromage Fondu Portions','Fromage fondu en portions, idéal sandwich',1800,1000,20,6,'boite'),
(4,'Mozzarella Fraîche','Mozzarella fraîche di bufala, importée',3500,2200,10,3,'pièce'),
(4,'Gruyère Suisse','Gruyère AOP suisse, cave affinée 12 mois',5800,3800,5,1,'kg'),
(5,'Œufs Fermiers x12','Œufs frais de poules élevées en plein air',2000,1200,50,20,'boite'),
(5,'Œufs de Caille x24','Œufs de caille frais, pack de 24 unités',1500,900,30,10,'boite'),
(5,'Crème Fraîche 500g','Crème fraîche épaisse 30% MG',1200,700,25,8,'pot'),
(5,'Beurre Doux 250g','Beurre doux de qualité supérieure',1000,600,30,10,'plaquette'),
(6,'Bœuf Haché Pur','Bœuf haché pur, 15% MG, fraîcheur garantie',4500,2800,20,5,'kg'),
(6,'Côtes d\'Agneau','Côtes d\'agneau fraîches, herbes et épices',6800,4500,8,2,'kg'),
(6,'Gigot de Mouton','Gigot de mouton entier, désossé sur demande',5500,3500,10,3,'kg'),
(6,'Merguez Artisanales','Merguez maison, mélange bœuf-agneau épicé',3800,2400,15,5,'kg'),
(7,'Sardines à l\'Huile x5','Sardines portugaises à l\'huile d\'olive',800,500,40,15,'boite'),
(7,'Thon en Boite Naturel','Thon albacore au naturel, sans sel ajouté',1200,750,35,12,'boite'),
(8,'Moutarde de Dijon','Moutarde forte de Dijon, bocal 200g',900,500,30,10,'bocal'),
(8,'Cornichons Extra Fins','Cornichons extra fins au vinaigre, bocal 400g',1100,650,25,8,'bocal'),
(9,'Barquettes Alimentaires x50','Barquettes plastique alimentaire, 50 pièces',1500,1000,100,30,'pack'),
(9,'Film Alimentaire 30m','Film étirable transparent alimentaire',800,500,50,15,'rouleau'),
(10,'Jus d\'Orange 1L','Pur jus d\'orange pressé, 100% naturel',1500,900,40,15,'bouteille'),
(10,'Eau Minérale 1,5L','Eau minérale naturelle, pack 6 bouteilles',1800,1100,60,20,'pack');

INSERT INTO clients (nom,prenom,telephone,email,adresse) VALUES
('Dupont','Jean','77 123 45 67','jean.dupont@email.com','12 Rue des Fleurs, Dakar'),
('Mbaye','Aminata','78 456 78 90','aminata.mbaye@gmail.com','45 Avenue Cheikh Anta Diop, Dakar'),
('Restaurant Le Gourmet',NULL,'33 821 00 00','contact@legourmet.sn','Place de l\'Indépendance, Dakar'),
('Hôtel Teranga',NULL,'33 889 22 00','commandes@teranga.sn','Route de la Corniche, Dakar'),
('Fall','Ousmane','76 234 56 78','ousmane.fall@email.com','Parcelles Assainies, Dakar');

INSERT INTO fournisseurs (nom,contact,telephone,email,adresse) VALUES
('Abattoir National du Sénégal','M. Diallo','33 832 00 00','contact@ans.sn','Zone Industrielle, Dakar'),
('Ferme Avicole du Sahel','Mme Sow','77 890 12 34','ferme.sahel@gmail.com','Thiès, Sénégal'),
('Importations Européennes SA','M. Bernard','33 821 55 66','import@euroalim.sn','Port de Dakar'),
('Fromagerie Artisanale','M. Touré','78 567 89 01','fromagerie@artisan.sn','Plateau, Dakar'),
('Grossiste Épicerie Fine','Mme Konaté','76 345 67 89','epicerie@fine.sn','Sandaga, Dakar');

INSERT INTO depenses (libelle,montant,categorie,date_depense,description) VALUES
('Loyer local commercial',250000,'loyer',DATE_SUB(CURDATE(),INTERVAL 1 MONTH),'Loyer mensuel du local'),
('Salaire vendeur',180000,'salaire',DATE_SUB(CURDATE(),INTERVAL 1 MONTH),'Salaire M. Ndiaye'),
('Facture SENELEC',45000,'electricite',DATE_SUB(CURDATE(),INTERVAL 1 MONTH),'Électricité mensuelle'),
('Facture SDE eau',12000,'eau',DATE_SUB(CURDATE(),INTERVAL 1 MONTH),'Eau mensuelle'),
('Carburant livraisons',35000,'transport',DATE_SUB(CURDATE(),INTERVAL 15 DAY),'Livraisons clients'),
('Emballages sous-vide',28000,'emballage',DATE_SUB(CURDATE(),INTERVAL 10 DAY),'Achat sacs sous-vide'),
('Publicité Facebook',15000,'publicite',DATE_SUB(CURDATE(),INTERVAL 5 DAY),'Campagne réseaux sociaux');
