/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: ecole
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `affectation_matieres`
--

DROP TABLE IF EXISTS `affectation_matieres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `affectation_matieres` (
  `id_affectation` int(11) NOT NULL AUTO_INCREMENT,
  `id_prof` int(11) DEFAULT NULL,
  `id_matiere` int(11) DEFAULT NULL,
  `id_classe` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_affectation`),
  KEY `id_prof` (`id_prof`),
  KEY `id_matiere` (`id_matiere`),
  KEY `id_classe` (`id_classe`),
  CONSTRAINT `affectation_matieres_ibfk_1` FOREIGN KEY (`id_prof`) REFERENCES `professeurs` (`id_prof`) ON DELETE CASCADE,
  CONSTRAINT `affectation_matieres_ibfk_2` FOREIGN KEY (`id_matiere`) REFERENCES `matieres` (`id`) ON DELETE CASCADE,
  CONSTRAINT `affectation_matieres_ibfk_3` FOREIGN KEY (`id_classe`) REFERENCES `classes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `affectation_matieres`
--

LOCK TABLES `affectation_matieres` WRITE;
/*!40000 ALTER TABLE `affectation_matieres` DISABLE KEYS */;
/*!40000 ALTER TABLE `affectation_matieres` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `archives_notes`
--

DROP TABLE IF EXISTS `archives_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `archives_notes` (
  `id_archive` int(11) NOT NULL AUTO_INCREMENT,
  `note_id` int(11) DEFAULT NULL,
  `code_etudiant` varchar(50) DEFAULT NULL,
  `id_matiere` int(11) DEFAULT NULL,
  `ancienne_moyenne` decimal(5,2) DEFAULT NULL,
  `nouvelle_moyenne` decimal(5,2) DEFAULT NULL,
  `date_modification` timestamp NULL DEFAULT current_timestamp(),
  `utilisateur` varchar(50) DEFAULT 'Admin',
  PRIMARY KEY (`id_archive`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `archives_notes`
--

LOCK TABLES `archives_notes` WRITE;
/*!40000 ALTER TABLE `archives_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `archives_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bulletins`
--

DROP TABLE IF EXISTS `bulletins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bulletins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code_etudiant` varchar(50) DEFAULT NULL,
  `annee_academique` varchar(20) DEFAULT NULL,
  `moyenne_semestre1` decimal(4,2) DEFAULT NULL,
  `moyenne_semestre2` decimal(4,2) DEFAULT NULL,
  `moyenne_annuelle` decimal(4,2) DEFAULT NULL,
  `decision` varchar(50) DEFAULT NULL,
  `date_generation` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bulletins`
--

LOCK TABLES `bulletins` WRITE;
/*!40000 ALTER TABLE `bulletins` DISABLE KEYS */;
INSERT INTO `bulletins` VALUES
(2,'ETU-2026-100','2025-2026',14.40,15.47,14.94,NULL,'2026-06-14 13:02:25'),
(3,'ETU-2026-101','2025-2026',8.20,NULL,NULL,NULL,'2026-06-14 13:02:25');
/*!40000 ALTER TABLE `bulletins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cartes_etudiants`
--

DROP TABLE IF EXISTS `cartes_etudiants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cartes_etudiants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `etudiant_id` int(11) NOT NULL,
  `photo_path` varchar(255) DEFAULT NULL,
  `date_emission` date DEFAULT NULL,
  `statut` varchar(20) DEFAULT 'ACTIVE',
  PRIMARY KEY (`id`),
  UNIQUE KEY `etudiant_id` (`etudiant_id`),
  CONSTRAINT `cartes_etudiants_ibfk_1` FOREIGN KEY (`etudiant_id`) REFERENCES `etudiants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cartes_etudiants`
--

LOCK TABLES `cartes_etudiants` WRITE;
/*!40000 ALTER TABLE `cartes_etudiants` DISABLE KEYS */;
INSERT INTO `cartes_etudiants` VALUES
(6,1,'uploads/photos/stu_1.jpg','2026-06-16','ACTIVE');
/*!40000 ALTER TABLE `cartes_etudiants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classes`
--

DROP TABLE IF EXISTS `classes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `classes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom_class` varchar(50) NOT NULL,
  `filiere_id` int(11) DEFAULT NULL,
  `annee_academique` varchar(20) DEFAULT '2025-2026',
  `montant_scolarite` decimal(10,2) NOT NULL DEFAULT 0.00,
  `montant_inscription` decimal(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`),
  KEY `filiere_id` (`filiere_id`),
  CONSTRAINT `classes_ibfk_1` FOREIGN KEY (`filiere_id`) REFERENCES `filieres` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classes`
--

LOCK TABLES `classes` WRITE;
/*!40000 ALTER TABLE `classes` DISABLE KEYS */;
INSERT INTO `classes` VALUES
(1,'L1-Compta',1,'2025-2026',100000.00,20000.00),
(2,'L1-Info',2,'2025-2026',90000.00,15000.00),
(3,'L1-Mark',3,'2025-2026',90000.00,15000.00),
(4,'Licence 1 Banque',1,'2025-2026',100000.00,20000.00),
(5,'Master 1 Marketing',2,'2025-2026',80000.00,20000.00);
/*!40000 ALTER TABLE `classes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clotures_validees`
--

DROP TABLE IF EXISTS `clotures_validees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clotures_validees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_cloture` date DEFAULT NULL,
  `signe_par` varchar(100) DEFAULT NULL,
  `date_signature` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `date_cloture` (`date_cloture`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clotures_validees`
--

LOCK TABLES `clotures_validees` WRITE;
/*!40000 ALTER TABLE `clotures_validees` DISABLE KEYS */;
/*!40000 ALTER TABLE `clotures_validees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `compteurs`
--

DROP TABLE IF EXISTS `compteurs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `compteurs` (
  `type_code` varchar(20) NOT NULL,
  `dernier_numero` int(11) DEFAULT 0,
  PRIMARY KEY (`type_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compteurs`
--

LOCK TABLES `compteurs` WRITE;
/*!40000 ALTER TABLE `compteurs` DISABLE KEYS */;
INSERT INTO `compteurs` VALUES
('ETUDIANT',0),
('PROFESSEUR',0);
/*!40000 ALTER TABLE `compteurs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cycles`
--

DROP TABLE IF EXISTS `cycles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cycles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom_cycle` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cycles`
--

LOCK TABLES `cycles` WRITE;
/*!40000 ALTER TABLE `cycles` DISABLE KEYS */;
INSERT INTO `cycles` VALUES
(1,'Licence'),
(2,'Master');
/*!40000 ALTER TABLE `cycles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `etudiants`
--

DROP TABLE IF EXISTS `etudiants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `etudiants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code_etudiant` varchar(50) DEFAULT NULL,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `date_naissance` date DEFAULT NULL,
  `adresse` varchar(255) DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `classe_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code_etudiant` (`code_etudiant`),
  KEY `classe_id` (`classe_id`),
  CONSTRAINT `etudiants_ibfk_1` FOREIGN KEY (`classe_id`) REFERENCES `classes` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `etudiants`
--

LOCK TABLES `etudiants` WRITE;
/*!40000 ALTER TABLE `etudiants` DISABLE KEYS */;
INSERT INTO `etudiants` VALUES
(1,'ETU-2026-100','DIOP','Fatou',NULL,NULL,NULL,NULL,1);
/*!40000 ALTER TABLE `etudiants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `filieres`
--

DROP TABLE IF EXISTS `filieres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `filieres` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom_filiere` varchar(100) NOT NULL,
  `cycle_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cycle_id` (`cycle_id`),
  CONSTRAINT `filieres_ibfk_1` FOREIGN KEY (`cycle_id`) REFERENCES `cycles` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filieres`
--

LOCK TABLES `filieres` WRITE;
/*!40000 ALTER TABLE `filieres` DISABLE KEYS */;
INSERT INTO `filieres` VALUES
(1,'Comptabilité',NULL),
(2,'Informatique-Gestion',NULL),
(3,'Marketing-Communication',NULL);
/*!40000 ALTER TABLE `filieres` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matiere_uv`
--

DROP TABLE IF EXISTS `matiere_uv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `matiere_uv` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uv_id` int(11) DEFAULT NULL,
  `matiere_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_mat_uv` (`matiere_id`,`uv_id`),
  KEY `uv_id` (`uv_id`),
  CONSTRAINT `matiere_uv_ibfk_1` FOREIGN KEY (`uv_id`) REFERENCES `unites_valeur` (`id`),
  CONSTRAINT `matiere_uv_ibfk_2` FOREIGN KEY (`matiere_id`) REFERENCES `matieres` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matiere_uv`
--

LOCK TABLES `matiere_uv` WRITE;
/*!40000 ALTER TABLE `matiere_uv` DISABLE KEYS */;
INSERT INTO `matiere_uv` VALUES
(1,1,1),
(2,1,2),
(3,2,3),
(4,2,4);
/*!40000 ALTER TABLE `matiere_uv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matieres`
--

DROP TABLE IF EXISTS `matieres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `matieres` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code_matiere` varchar(20) DEFAULT NULL,
  `nom_matiere` varchar(100) NOT NULL,
  `semestre` varchar(2) DEFAULT 'S1',
  `coefficient` float DEFAULT 1,
  `nom_uv` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code_matiere` (`code_matiere`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matieres`
--

LOCK TABLES `matieres` WRITE;
/*!40000 ALTER TABLE `matieres` DISABLE KEYS */;
INSERT INTO `matieres` VALUES
(1,NULL,'Compta Générale','S1',1,NULL),
(2,NULL,'Algorithmique','S1',1,NULL),
(3,NULL,'Marketing Digital','S1',1,NULL),
(4,NULL,'Statistiques','S1',1,NULL),
(5,NULL,'Droit des Affaires','S1',1,NULL),
(6,NULL,'Anglais','S1',1,NULL),
(7,NULL,'Macroéconomie','S1',1,NULL);
/*!40000 ALTER TABLE `matieres` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notes`
--

DROP TABLE IF EXISTS `notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code_etudiant` varchar(50) DEFAULT NULL,
  `id_matiere` int(11) DEFAULT NULL,
  `annee_academique` varchar(20) DEFAULT NULL,
  `semestre` int(11) NOT NULL,
  `note_cc1` decimal(4,2) DEFAULT NULL,
  `note_cc2` decimal(4,2) DEFAULT NULL,
  `note_exam` decimal(4,2) DEFAULT NULL,
  `moyenne_matiere` decimal(5,2) DEFAULT NULL,
  `est_valide` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_note` (`code_etudiant`,`id_matiere`,`semestre`),
  KEY `id_matiere` (`id_matiere`),
  CONSTRAINT `notes_ibfk_1` FOREIGN KEY (`id_matiere`) REFERENCES `matieres` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notes`
--

LOCK TABLES `notes` WRITE;
/*!40000 ALTER TABLE `notes` DISABLE KEYS */;
INSERT INTO `notes` VALUES
(5,'ETU-2026-101',2,NULL,1,8.00,NULL,9.00,8.60,1),
(6,'ETU-2026-101',4,NULL,1,9.00,NULL,7.00,7.80,1),
(7,'ETU-2026-100',1,NULL,1,16.00,16.00,15.00,15.40,1),
(8,'ETU-2026-100',3,NULL,1,15.00,15.00,14.00,14.40,1),
(9,'ETU-2026-100',5,NULL,1,14.00,14.00,13.00,13.40,1),
(10,'ETU-2026-100',1,NULL,2,17.00,18.00,16.00,16.60,1),
(11,'ETU-2026-100',3,NULL,2,16.00,16.00,15.00,15.40,1),
(12,'ETU-2026-100',5,NULL,2,15.00,15.00,14.00,14.40,1);
/*!40000 ALTER TABLE `notes` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER before_note_save BEFORE INSERT ON notes
FOR EACH ROW
SET NEW.moyenne_matiere = (((COALESCE(NEW.note_cc1, 0) + COALESCE(NEW.note_cc2, 0)) / 2) * 0.4) + (COALESCE(NEW.note_exam, 0) * 0.6) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER before_note_update BEFORE UPDATE ON notes
FOR EACH ROW
SET NEW.moyenne_matiere = (((COALESCE(NEW.note_cc1, 0) + COALESCE(NEW.note_cc2, 0)) / 2) * 0.4) + (COALESCE(NEW.note_exam, 0) * 0.6) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` enum('Finance','Stock','Cours','Système') NOT NULL,
  `message` text NOT NULL,
  `est_lu` tinyint(1) DEFAULT 0,
  `date_creation` timestamp NULL DEFAULT current_timestamp(),
  `lien_action` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paiements`
--

DROP TABLE IF EXISTS `paiements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `paiements` (
  `id_paiement` int(11) NOT NULL AUTO_INCREMENT,
  `code_etudiant` varchar(50) DEFAULT NULL,
  `annee_academique` varchar(20) DEFAULT NULL,
  `type_paiement` enum('Scolarite','Inscription') DEFAULT 'Scolarite',
  `montant_paye` decimal(15,2) DEFAULT NULL,
  `date_paiement` date DEFAULT NULL,
  `mode_paiement` varchar(50) DEFAULT NULL,
  `code_transaction` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_paiement`),
  UNIQUE KEY `code_transaction` (`code_transaction`),
  KEY `code_etudiant` (`code_etudiant`),
  CONSTRAINT `paiements_ibfk_1` FOREIGN KEY (`code_etudiant`) REFERENCES `etudiants` (`code_etudiant`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paiements`
--

LOCK TABLES `paiements` WRITE;
/*!40000 ALTER TABLE `paiements` DISABLE KEYS */;
/*!40000 ALTER TABLE `paiements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paiements_inscription`
--

DROP TABLE IF EXISTS `paiements_inscription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `paiements_inscription` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code_etudiant` varchar(20) DEFAULT NULL,
  `annee_academique` varchar(10) DEFAULT NULL,
  `montant_verse` decimal(10,2) DEFAULT NULL,
  `date_paiement` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `code_etudiant` (`code_etudiant`),
  CONSTRAINT `paiements_inscription_ibfk_1` FOREIGN KEY (`code_etudiant`) REFERENCES `etudiants` (`code_etudiant`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paiements_inscription`
--

LOCK TABLES `paiements_inscription` WRITE;
/*!40000 ALTER TABLE `paiements_inscription` DISABLE KEYS */;
INSERT INTO `paiements_inscription` VALUES
(1,'ETU-2026-100',NULL,25000.00,'2026-06-16');
/*!40000 ALTER TABLE `paiements_inscription` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paiements_scolarite`
--

DROP TABLE IF EXISTS `paiements_scolarite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `paiements_scolarite` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `etudiant_id` int(11) DEFAULT NULL,
  `montant_verse` decimal(10,2) DEFAULT NULL,
  `date_paiement` timestamp NULL DEFAULT current_timestamp(),
  `mode_paiement` enum('Espèces','Chèque','Virement','Mobile Money') DEFAULT NULL,
  `recu_numero` varchar(50) DEFAULT NULL,
  `mois_paye` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paiements_scolarite`
--

LOCK TABLES `paiements_scolarite` WRITE;
/*!40000 ALTER TABLE `paiements_scolarite` DISABLE KEYS */;
INSERT INTO `paiements_scolarite` VALUES
(1,1,25000.00,'2026-06-16 03:39:53','Espèces','Er','Octobre');
/*!40000 ALTER TABLE `paiements_scolarite` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `presences`
--

DROP TABLE IF EXISTS `presences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `presences` (
  `id_presence` int(11) NOT NULL AUTO_INCREMENT,
  `code_etudiant` varchar(50) DEFAULT NULL,
  `id_classe` int(11) DEFAULT NULL,
  `date_presence` date DEFAULT NULL,
  `statut` enum('Present','Absent','Retard') DEFAULT 'Present',
  `justifie` tinyint(1) DEFAULT 0,
  `commentaire` text DEFAULT NULL,
  PRIMARY KEY (`id_presence`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `presences`
--

LOCK TABLES `presences` WRITE;
/*!40000 ALTER TABLE `presences` DISABLE KEYS */;
/*!40000 ALTER TABLE `presences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `professeurs`
--

DROP TABLE IF EXISTS `professeurs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `professeurs` (
  `id_prof` int(11) NOT NULL AUTO_INCREMENT,
  `id_prof_code` varchar(50) DEFAULT NULL,
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `specialite` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_prof`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `id_prof_code` (`id_prof_code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `professeurs`
--

LOCK TABLES `professeurs` WRITE;
/*!40000 ALTER TABLE `professeurs` DISABLE KEYS */;
INSERT INTO `professeurs` VALUES
(1,'PROF-1-2026','Mohamed ','Siby','Math ','sibymohamed24@gmail.com','77');
/*!40000 ALTER TABLE `professeurs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `programmes`
--

DROP TABLE IF EXISTS `programmes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `programmes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `classe_id` int(11) DEFAULT NULL,
  `uv_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_prog` (`classe_id`,`uv_id`),
  KEY `uv_id` (`uv_id`),
  CONSTRAINT `programmes_ibfk_1` FOREIGN KEY (`classe_id`) REFERENCES `classes` (`id`),
  CONSTRAINT `programmes_ibfk_2` FOREIGN KEY (`uv_id`) REFERENCES `unites_valeur` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `programmes`
--

LOCK TABLES `programmes` WRITE;
/*!40000 ALTER TABLE `programmes` DISABLE KEYS */;
INSERT INTO `programmes` VALUES
(1,1,1),
(2,2,1),
(3,3,2);
/*!40000 ALTER TABLE `programmes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock`
--

DROP TABLE IF EXISTS `stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom_item` varchar(100) DEFAULT NULL,
  `article` varchar(100) DEFAULT NULL,
  `categorie` enum('Papeterie','Informatique','Maintenance') DEFAULT NULL,
  `quantite` int(11) DEFAULT NULL,
  `seuil_alerte` int(11) DEFAULT 5,
  `dernier_reappro` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock`
--

LOCK TABLES `stock` WRITE;
/*!40000 ALTER TABLE `stock` DISABLE KEYS */;
/*!40000 ALTER TABLE `stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tarifs`
--

DROP TABLE IF EXISTS `tarifs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tarifs` (
  `id_tarif` int(11) NOT NULL AUTO_INCREMENT,
  `classe_id` int(11) DEFAULT NULL,
  `montant_scolarite` decimal(15,2) DEFAULT NULL,
  `droit_inscription` decimal(15,2) DEFAULT NULL,
  `annee_academique` varchar(20) DEFAULT '2025-2026',
  PRIMARY KEY (`id_tarif`),
  KEY `classe_id` (`classe_id`),
  CONSTRAINT `tarifs_ibfk_1` FOREIGN KEY (`classe_id`) REFERENCES `classes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tarifs`
--

LOCK TABLES `tarifs` WRITE;
/*!40000 ALTER TABLE `tarifs` DISABLE KEYS */;
/*!40000 ALTER TABLE `tarifs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unites_valeur`
--

DROP TABLE IF EXISTS `unites_valeur`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `unites_valeur` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom_uv` varchar(100) NOT NULL,
  `code_uv` varchar(20) DEFAULT NULL,
  `semestre` int(11) DEFAULT NULL COMMENT '1 ou 2',
  `coefficient` decimal(4,2) DEFAULT 1.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unites_valeur`
--

LOCK TABLES `unites_valeur` WRITE;
/*!40000 ALTER TABLE `unites_valeur` DISABLE KEYS */;
INSERT INTO `unites_valeur` VALUES
(1,'UV Fondamentale',NULL,NULL,1.00),
(2,'UV Spécialité',NULL,NULL,1.00),
(3,'UV Management',NULL,NULL,1.00),
(4,'UV Langues',NULL,NULL,1.00);
/*!40000 ALTER TABLE `unites_valeur` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `utilisateurs_ecole`
--

DROP TABLE IF EXISTS `utilisateurs_ecole`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `utilisateurs_ecole` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','professeur','comptable','etudiant') DEFAULT 'admin',
  `id_entite_associe` int(11) DEFAULT NULL,
  `entite_type` varchar(50) DEFAULT NULL,
  `nom_complet` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `utilisateurs_ecole`
--

LOCK TABLES `utilisateurs_ecole` WRITE;
/*!40000 ALTER TABLE `utilisateurs_ecole` DISABLE KEYS */;
INSERT INTO `utilisateurs_ecole` VALUES
(1,'admin','$2y$10$h5QOkt.aaHye8pXjL0N1iOeeuGlKrdJ.LBALVVtUpzV7oNg8aCy9G','admin',NULL,'ADMIN','MOHAMED SIBY'),
(2,'prof.diop','$2y$10$h5QOkt.aaHye8pXjL0N1iOeeuGlKrdJ.LBALVVtUpzV7oNg8aCy9G','professeur',NULL,'PROFESSEUR','M. DIOP'),
(3,'ETU-2025-0001','$2y$10$h5QOkt.aaHye8pXjL0N1iOeeuGlKrdJ.LBALVVtUpzV7oNg8aCy9G','etudiant',NULL,'ETUDIANT','Etudiant Test');
/*!40000 ALTER TABLE `utilisateurs_ecole` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-16 21:54:09
