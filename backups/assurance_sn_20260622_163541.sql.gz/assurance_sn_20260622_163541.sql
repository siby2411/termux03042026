/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: assurance_sn
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_client` enum('particulier','entreprise') DEFAULT 'particulier',
  `numero_client` varchar(20) NOT NULL,
  `nom` varchar(100) DEFAULT NULL,
  `prenom` varchar(100) DEFAULT NULL,
  `raison_sociale` varchar(200) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `telephone` varchar(20) NOT NULL,
  `adresse` text DEFAULT NULL,
  `ville` varchar(100) DEFAULT NULL,
  `date_naissance` date DEFAULT NULL,
  `statut` enum('actif','inactif') DEFAULT 'actif',
  `date_creation` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `numero_client` (`numero_client`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` VALUES
(1,'particulier','CLT20260001','DIOP','Ibrahima',NULL,NULL,'771691527',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(2,'particulier','CLT20260002','GUEYE','Amadou',NULL,NULL,'779974616',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(3,'particulier','CLT20260003','DIOP','Ousmane',NULL,NULL,'773668310',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(4,'particulier','CLT20260004','NDIAYE','Ibrahima',NULL,NULL,'777610951',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(5,'particulier','CLT20260005','SOW','Ibrahima',NULL,NULL,'772904103',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(6,'particulier','CLT20260006','GUEYE','Amadou',NULL,NULL,'779541868',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(7,'particulier','CLT20260007','FALL','Mariama',NULL,NULL,'777548233',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(8,'particulier','CLT20260008','SOW','Ousmane',NULL,NULL,'774599034',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(9,'particulier','CLT20260009','NDIAYE','Ousmane',NULL,NULL,'776614821',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(10,'particulier','CLT20260010','FALL','Mariama',NULL,NULL,'771167626',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(11,'particulier','CLT20260011','SOW','Ibrahima',NULL,NULL,'771754720',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(12,'particulier','CLT20260012','GUEYE','Mariama',NULL,NULL,'779631239',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(13,'particulier','CLT20260013','GUEYE','Fatou',NULL,NULL,'779616472',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(14,'particulier','CLT20260014','DIOP','Mariama',NULL,NULL,'771288831',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(15,'particulier','CLT20260015','NDIAYE','Amadou',NULL,NULL,'779452820',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(16,'particulier','CLT20260016','DIOP','Amadou',NULL,NULL,'773522254',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(17,'particulier','CLT20260017','NDIAYE','Ousmane',NULL,NULL,'772939126',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(18,'particulier','CLT20260018','DIOP','Amadou',NULL,NULL,'777590575',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(19,'particulier','CLT20260019','FALL','Mariama',NULL,NULL,'772901448',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(20,'particulier','CLT20260020','FALL','Amadou',NULL,NULL,'778285667',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(21,'particulier','CLT20260021','NDIAYE','Ibrahima',NULL,NULL,'771730783',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(22,'particulier','CLT20260022','SOW','Fatou',NULL,NULL,'771568889',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(23,'particulier','CLT20260023','GUEYE','Mariama',NULL,NULL,'771152497',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(24,'particulier','CLT20260024','BA','Fatou',NULL,NULL,'771421890',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(25,'particulier','CLT20260025','DIOP','Mariama',NULL,NULL,'771844591',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(26,'particulier','CLT20260026','FALL','Amadou',NULL,NULL,'777922796',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(27,'particulier','CLT20260027','FALL','Amadou',NULL,NULL,'773671480',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(28,'particulier','CLT20260028','BA','Mariama',NULL,NULL,'772760664',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(29,'particulier','CLT20260029','GUEYE','Ibrahima',NULL,NULL,'778231331',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(30,'particulier','CLT20260030','DIOP','Ibrahima',NULL,NULL,'775896445',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(31,'particulier','CLT20260031','DIOP','Amadou',NULL,NULL,'775088077',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(32,'particulier','CLT20260032','SOW','Amadou',NULL,NULL,'774501694',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(33,'particulier','CLT20260033','BA','Mariama',NULL,NULL,'776867314',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(34,'particulier','CLT20260034','GUEYE','Ousmane',NULL,NULL,'775043296',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(35,'particulier','CLT20260035','FALL','Ibrahima',NULL,NULL,'772263872',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(36,'particulier','CLT20260036','SOW','Ousmane',NULL,NULL,'772477459',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(37,'particulier','CLT20260037','DIOP','Fatou',NULL,NULL,'773742513',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(38,'particulier','CLT20260038','SOW','Ibrahima',NULL,NULL,'777402012',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(39,'particulier','CLT20260039','DIOP','Amadou',NULL,NULL,'774026006',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(40,'particulier','CLT20260040','GUEYE','Mariama',NULL,NULL,'774981149',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(41,'particulier','CLT20260041','DIOP','Ibrahima',NULL,NULL,'779072755',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(42,'particulier','CLT20260042','DIOP','Ousmane',NULL,NULL,'772609609',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(43,'particulier','CLT20260043','BA','Ibrahima',NULL,NULL,'772301890',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(44,'particulier','CLT20260044','DIOP','Ousmane',NULL,NULL,'774360808',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(45,'particulier','CLT20260045','FALL','Amadou',NULL,NULL,'772351739',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(46,'particulier','CLT20260046','DIOP','Mariama',NULL,NULL,'778859808',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(47,'particulier','CLT20260047','BA','Fatou',NULL,NULL,'776086306',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(48,'particulier','CLT20260048','GUEYE','Ousmane',NULL,NULL,'772264496',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(49,'particulier','CLT20260049','DIOP','Ousmane',NULL,NULL,'771421855',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(50,'particulier','CLT20260050','BA','Ibrahima',NULL,NULL,'778100478',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(51,'entreprise','ENT20260001',NULL,NULL,'AFRIQUE LOGISTIC 7',NULL,'33969201',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(52,'entreprise','ENT20260002',NULL,NULL,'DAKAR TRANS 14',NULL,'33994068',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(53,'entreprise','ENT20260003',NULL,NULL,'SENEXPRESS 24',NULL,'33877058',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(54,'entreprise','ENT20260004',NULL,NULL,'DAKAR TRANS 29',NULL,'33853813',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(55,'entreprise','ENT20260005',NULL,NULL,'OMEGA SARL 21',NULL,'33854756',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(56,'entreprise','ENT20260006',NULL,NULL,'OMEGA SARL 42',NULL,'33873422',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(57,'entreprise','ENT20260007',NULL,NULL,'DAKAR TRANS 39',NULL,'33986125',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(58,'entreprise','ENT20260008',NULL,NULL,'DAKAR TRANS 21',NULL,'33990950',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(59,'entreprise','ENT20260009',NULL,NULL,'SENEXPRESS 45',NULL,'33845271',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(60,'entreprise','ENT20260010',NULL,NULL,'AFRIQUE LOGISTIC 8',NULL,'33940066',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(61,'entreprise','ENT20260011',NULL,NULL,'DAKAR TRANS 41',NULL,'33915207',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(62,'entreprise','ENT20260012',NULL,NULL,'SENEXPRESS 18',NULL,'33939619',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(63,'entreprise','ENT20260013',NULL,NULL,'AFRIQUE LOGISTIC 8',NULL,'33996668',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(64,'entreprise','ENT20260014',NULL,NULL,'SUNU GROUPE 50',NULL,'33938078',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(65,'entreprise','ENT20260015',NULL,NULL,'AFRIQUE LOGISTIC 44',NULL,'33887597',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(66,'entreprise','ENT20260016',NULL,NULL,'AFRIQUE LOGISTIC 27',NULL,'33913021',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(67,'entreprise','ENT20260017',NULL,NULL,'SUNU GROUPE 36',NULL,'33914826',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(68,'entreprise','ENT20260018',NULL,NULL,'SENEXPRESS 36',NULL,'33800744',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(69,'entreprise','ENT20260019',NULL,NULL,'DAKAR TRANS 8',NULL,'33885411',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28'),
(70,'entreprise','ENT20260020',NULL,NULL,'SUNU GROUPE 3',NULL,'33908376',NULL,'Dakar',NULL,'actif','2026-04-14 18:55:28');
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contrats`
--

DROP TABLE IF EXISTS `contrats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `contrats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numero_contrat` varchar(50) NOT NULL,
  `client_id` int(11) NOT NULL,
  `vehicule_id` int(11) DEFAULT NULL,
  `formule` enum('Tiers','Tiers_Plus','Tous_Risques','Premium') DEFAULT 'Tiers',
  `prime_nette` decimal(15,2) NOT NULL,
  `taxe` decimal(15,2) DEFAULT 0.00,
  `prime_ttc` decimal(15,2) NOT NULL,
  `mode_paiement` enum('Annuel','Semestriel','Trimestriel','Mensuel') DEFAULT 'Annuel',
  `date_effet` date NOT NULL,
  `date_echeance` date NOT NULL,
  `statut` enum('actif','expire','resilie') DEFAULT 'actif',
  `date_creation` timestamp NULL DEFAULT current_timestamp(),
  `type_contrat` varchar(50) DEFAULT 'Auto',
  PRIMARY KEY (`id`),
  UNIQUE KEY `numero_contrat` (`numero_contrat`),
  KEY `client_id` (`client_id`),
  KEY `vehicule_id` (`vehicule_id`),
  CONSTRAINT `contrats_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`),
  CONSTRAINT `contrats_ibfk_2` FOREIGN KEY (`vehicule_id`) REFERENCES `vehicules` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contrats`
--

LOCK TABLES `contrats` WRITE;
/*!40000 ALTER TABLE `contrats` DISABLE KEYS */;
INSERT INTO `contrats` VALUES
(1,'CON-202600001',35,48,'Tous_Risques',400000.00,40000.00,440000.00,'Trimestriel','2025-12-20','2026-12-20','actif','2025-12-20 00:00:00','Auto'),
(2,'CON-202600002',57,84,'Tiers',180000.00,18000.00,198000.00,'Annuel','2026-01-03','2027-01-03','expire','2026-01-03 00:00:00','Auto'),
(3,'CON-202600003',16,23,'Premium',700000.00,70000.00,770000.00,'Trimestriel','2025-11-16','2026-11-16','actif','2025-11-16 00:00:00','Auto'),
(4,'CON-202600004',52,59,'Tiers_Plus',300000.00,30000.00,330000.00,'Semestriel','2025-12-01','2026-12-01','actif','2025-12-01 00:00:00','Auto'),
(5,'CON-202600005',42,98,'Premium',600000.00,60000.00,660000.00,'Trimestriel','2025-09-12','2026-09-12','actif','2025-09-12 00:00:00','Auto'),
(6,'CON-202600006',17,46,'Tiers_Plus',300000.00,30000.00,330000.00,'Annuel','2025-08-23','2026-08-23','expire','2025-08-23 00:00:00','Auto'),
(7,'CON-202600007',51,59,'Premium',1000000.00,100000.00,1100000.00,'Annuel','2026-01-23','2027-01-23','actif','2026-01-23 00:00:00','Auto'),
(8,'CON-202600008',41,17,'Tiers',150000.00,15000.00,165000.00,'Trimestriel','2026-03-18','2027-03-18','expire','2026-03-18 00:00:00','Auto'),
(9,'CON-202600009',12,31,'Tiers_Plus',400000.00,40000.00,440000.00,'Annuel','2026-03-28','2027-03-28','actif','2026-03-28 00:00:00','Auto'),
(10,'CON-202600010',62,64,'Tiers',220000.00,22000.00,242000.00,'Trimestriel','2025-09-04','2026-09-04','actif','2025-09-04 00:00:00','Auto'),
(11,'CON-202600011',5,53,'Premium',900000.00,90000.00,990000.00,'Trimestriel','2026-03-26','2027-03-26','actif','2026-03-26 00:00:00','Auto'),
(12,'CON-202600012',47,50,'Tous_Risques',450000.00,45000.00,495000.00,'Annuel','2025-10-25','2026-10-25','expire','2025-10-25 00:00:00','Auto'),
(13,'CON-202600013',4,37,'Tiers_Plus',300000.00,30000.00,330000.00,'Trimestriel','2025-06-30','2026-06-30','actif','2025-06-30 00:00:00','Auto'),
(14,'CON-202600014',34,36,'Premium',900000.00,90000.00,990000.00,'Trimestriel','2025-10-03','2026-10-03','expire','2025-10-03 00:00:00','Auto'),
(15,'CON-202600015',64,25,'Tiers_Plus',350000.00,35000.00,385000.00,'Annuel','2026-01-22','2027-01-22','expire','2026-01-22 00:00:00','Auto'),
(16,'CON-202600016',14,9,'Tiers',150000.00,15000.00,165000.00,'Annuel','2025-07-05','2026-07-05','expire','2025-07-05 00:00:00','Auto'),
(17,'CON-202600017',24,54,'Tiers_Plus',250000.00,25000.00,275000.00,'Trimestriel','2025-07-01','2026-07-01','actif','2025-07-01 00:00:00','Auto'),
(18,'CON-202600018',18,19,'Tous_Risques',400000.00,40000.00,440000.00,'Semestriel','2025-09-30','2026-09-30','actif','2025-09-30 00:00:00','Auto'),
(19,'CON-202600019',6,20,'Premium',800000.00,80000.00,880000.00,'Semestriel','2026-02-03','2027-02-03','expire','2026-02-03 00:00:00','Auto'),
(20,'CON-202600020',35,79,'Tiers_Plus',300000.00,30000.00,330000.00,'Semestriel','2025-12-06','2026-12-06','expire','2025-12-06 00:00:00','Auto'),
(21,'CON-202600021',22,75,'Tiers_Plus',300000.00,30000.00,330000.00,'Annuel','2026-04-14','2027-04-14','expire','2026-04-14 00:00:00','Auto'),
(22,'CON-202600022',17,4,'Premium',600000.00,60000.00,660000.00,'Trimestriel','2025-11-25','2026-11-25','actif','2025-11-25 00:00:00','Auto'),
(23,'CON-202600023',68,75,'Tous_Risques',400000.00,40000.00,440000.00,'Annuel','2026-04-10','2027-04-10','actif','2026-04-10 00:00:00','Auto'),
(24,'CON-202600024',29,56,'Tiers',220000.00,22000.00,242000.00,'Annuel','2025-07-17','2026-07-17','actif','2025-07-17 00:00:00','Auto'),
(25,'CON-202600025',46,30,'Premium',900000.00,90000.00,990000.00,'Trimestriel','2026-03-07','2027-03-07','expire','2026-03-07 00:00:00','Auto'),
(26,'CON-202600026',13,109,'Tiers',220000.00,22000.00,242000.00,'Annuel','2025-12-10','2026-12-10','actif','2025-12-10 00:00:00','Auto'),
(27,'CON-202600027',58,15,'Tous_Risques',450000.00,45000.00,495000.00,'Semestriel','2025-09-10','2026-09-10','actif','2025-09-10 00:00:00','Auto'),
(28,'CON-202600028',35,88,'Tous_Risques',500000.00,50000.00,550000.00,'Trimestriel','2025-06-26','2026-06-26','actif','2025-06-26 00:00:00','Auto'),
(29,'CON-202600029',7,76,'Tiers',250000.00,25000.00,275000.00,'Trimestriel','2026-02-01','2027-02-01','actif','2026-02-01 00:00:00','Auto'),
(30,'CON-202600030',34,59,'Tiers',250000.00,25000.00,275000.00,'Semestriel','2025-08-31','2026-08-31','actif','2025-08-31 00:00:00','Auto'),
(31,'CON-202600031',29,25,'Tiers_Plus',250000.00,25000.00,275000.00,'Trimestriel','2026-02-12','2027-02-12','actif','2026-02-12 00:00:00','Auto'),
(32,'CON-202600032',58,14,'Tous_Risques',600000.00,60000.00,660000.00,'Trimestriel','2026-01-09','2027-01-09','actif','2026-01-09 00:00:00','Auto'),
(33,'CON-202600033',3,38,'Premium',900000.00,90000.00,990000.00,'Semestriel','2025-06-21','2026-06-21','actif','2025-06-21 00:00:00','Auto'),
(34,'CON-202600034',61,52,'Tiers_Plus',280000.00,28000.00,308000.00,'Semestriel','2025-12-26','2026-12-26','expire','2025-12-26 00:00:00','Auto'),
(35,'CON-202600035',23,18,'Tiers_Plus',250000.00,25000.00,275000.00,'Semestriel','2026-02-22','2027-02-22','expire','2026-02-22 00:00:00','Auto'),
(36,'CON-202600036',37,98,'Tous_Risques',550000.00,55000.00,605000.00,'Trimestriel','2026-02-02','2027-02-02','actif','2026-02-02 00:00:00','Auto'),
(37,'CON-202600037',56,107,'Tiers',200000.00,20000.00,220000.00,'Trimestriel','2025-07-14','2026-07-14','expire','2025-07-14 00:00:00','Auto'),
(38,'CON-202600038',13,66,'Tous_Risques',550000.00,55000.00,605000.00,'Semestriel','2026-03-17','2027-03-17','actif','2026-03-17 00:00:00','Auto'),
(39,'CON-202600039',4,44,'Tiers',150000.00,15000.00,165000.00,'Annuel','2026-03-01','2027-03-01','actif','2026-03-01 00:00:00','Auto'),
(40,'CON-202600040',34,66,'Tiers',180000.00,18000.00,198000.00,'Semestriel','2025-07-07','2026-07-07','actif','2025-07-07 00:00:00','Auto'),
(41,'CON-202600041',21,85,'Tiers',150000.00,15000.00,165000.00,'Trimestriel','2026-02-23','2027-02-23','actif','2026-02-23 00:00:00','Auto'),
(42,'CON-202600042',25,83,'Premium',700000.00,70000.00,770000.00,'Annuel','2026-04-06','2027-04-06','expire','2026-04-06 00:00:00','Auto'),
(43,'CON-202600043',10,20,'Premium',600000.00,60000.00,660000.00,'Semestriel','2026-03-26','2027-03-26','expire','2026-03-26 00:00:00','Auto'),
(44,'CON-202600044',69,4,'Tous_Risques',500000.00,50000.00,550000.00,'Trimestriel','2025-09-15','2026-09-15','expire','2025-09-15 00:00:00','Auto'),
(45,'CON-202600045',32,105,'Tous_Risques',450000.00,45000.00,495000.00,'Semestriel','2025-09-04','2026-09-04','actif','2025-09-04 00:00:00','Auto'),
(46,'CON-202600046',62,42,'Tiers',220000.00,22000.00,242000.00,'Trimestriel','2026-03-21','2027-03-21','actif','2026-03-21 00:00:00','Auto'),
(47,'CON-202600047',39,31,'Premium',600000.00,60000.00,660000.00,'Semestriel','2025-08-19','2026-08-19','expire','2025-08-19 00:00:00','Auto'),
(48,'CON-202600048',25,72,'Tiers_Plus',350000.00,35000.00,385000.00,'Trimestriel','2025-12-25','2026-12-25','actif','2025-12-25 00:00:00','Auto'),
(49,'CON-202600049',65,65,'Tiers',250000.00,25000.00,275000.00,'Annuel','2025-09-30','2026-09-30','actif','2025-09-30 00:00:00','Auto'),
(50,'CON-202600050',18,69,'Tiers_Plus',300000.00,30000.00,330000.00,'Trimestriel','2025-09-15','2026-09-15','actif','2025-09-15 00:00:00','Auto'),
(51,'CON-202600051',23,65,'Tous_Risques',450000.00,45000.00,495000.00,'Trimestriel','2025-10-20','2026-10-20','actif','2025-10-20 00:00:00','Auto'),
(52,'CON-202600052',39,40,'Premium',800000.00,80000.00,880000.00,'Trimestriel','2026-03-06','2027-03-06','actif','2026-03-06 00:00:00','Auto'),
(53,'CON-202600053',19,107,'Tous_Risques',600000.00,60000.00,660000.00,'Semestriel','2025-11-20','2026-11-20','actif','2025-11-20 00:00:00','Auto'),
(54,'CON-202600054',24,3,'Tous_Risques',600000.00,60000.00,660000.00,'Trimestriel','2025-06-29','2026-06-29','expire','2025-06-29 00:00:00','Auto'),
(55,'CON-202600055',23,89,'Tous_Risques',600000.00,60000.00,660000.00,'Trimestriel','2025-08-21','2026-08-21','expire','2025-08-21 00:00:00','Auto'),
(56,'CON-202600056',59,11,'Tiers_Plus',280000.00,28000.00,308000.00,'Semestriel','2026-01-31','2027-01-31','actif','2026-01-31 00:00:00','Auto'),
(57,'CON-202600057',42,1,'Tiers_Plus',300000.00,30000.00,330000.00,'Annuel','2026-01-26','2027-01-26','actif','2026-01-26 00:00:00','Auto'),
(58,'CON-202600058',48,96,'Tiers_Plus',350000.00,35000.00,385000.00,'Annuel','2025-11-07','2026-11-07','actif','2025-11-07 00:00:00','Auto'),
(59,'CON-202600059',25,77,'Premium',800000.00,80000.00,880000.00,'Semestriel','2026-03-30','2027-03-30','expire','2026-03-30 00:00:00','Auto'),
(60,'CON-202600060',67,34,'Tiers_Plus',300000.00,30000.00,330000.00,'Trimestriel','2025-08-13','2026-08-13','actif','2025-08-13 00:00:00','Auto'),
(61,'CON-202600061',69,18,'Tous_Risques',550000.00,55000.00,605000.00,'Semestriel','2026-01-17','2027-01-17','expire','2026-01-17 00:00:00','Auto'),
(62,'CON-202600062',8,74,'Tous_Risques',600000.00,60000.00,660000.00,'Annuel','2025-11-11','2026-11-11','actif','2025-11-11 00:00:00','Auto'),
(63,'CON-202600063',23,86,'Tiers',180000.00,18000.00,198000.00,'Semestriel','2025-09-27','2026-09-27','actif','2025-09-27 00:00:00','Auto'),
(64,'CON-202600064',69,57,'Tous_Risques',550000.00,55000.00,605000.00,'Semestriel','2026-04-01','2027-04-01','expire','2026-04-01 00:00:00','Auto'),
(65,'CON-202600065',5,7,'Tous_Risques',600000.00,60000.00,660000.00,'Semestriel','2025-06-18','2026-06-18','expire','2025-06-18 00:00:00','Auto'),
(66,'CON-202600066',58,96,'Tous_Risques',500000.00,50000.00,550000.00,'Annuel','2026-02-27','2027-02-27','actif','2026-02-27 00:00:00','Auto'),
(67,'CON-202600067',30,37,'Tiers_Plus',250000.00,25000.00,275000.00,'Semestriel','2025-08-16','2026-08-16','actif','2025-08-16 00:00:00','Auto'),
(68,'CON-202600068',39,32,'Premium',900000.00,90000.00,990000.00,'Trimestriel','2026-03-20','2027-03-20','actif','2026-03-20 00:00:00','Auto'),
(69,'CON-202600069',47,96,'Tiers',220000.00,22000.00,242000.00,'Annuel','2025-06-21','2026-06-21','actif','2025-06-21 00:00:00','Auto'),
(70,'CON-202600070',27,10,'Premium',700000.00,70000.00,770000.00,'Annuel','2025-10-02','2026-10-02','actif','2025-10-02 00:00:00','Auto'),
(71,'CON-202600071',61,75,'Premium',600000.00,60000.00,660000.00,'Annuel','2026-02-22','2027-02-22','expire','2026-02-22 00:00:00','Auto'),
(72,'CON-202600072',41,28,'Tous_Risques',600000.00,60000.00,660000.00,'Trimestriel','2025-11-04','2026-11-04','actif','2025-11-04 00:00:00','Auto'),
(73,'CON-202600073',14,76,'Tiers_Plus',250000.00,25000.00,275000.00,'Trimestriel','2025-06-20','2026-06-20','actif','2025-06-20 00:00:00','Auto'),
(74,'CON-202600074',55,5,'Tiers_Plus',250000.00,25000.00,275000.00,'Trimestriel','2025-11-09','2026-11-09','actif','2025-11-09 00:00:00','Auto'),
(75,'CON-202600075',13,4,'Tous_Risques',400000.00,40000.00,440000.00,'Annuel','2025-09-16','2026-09-16','actif','2025-09-16 00:00:00','Auto'),
(76,'CON-202600076',19,45,'Tous_Risques',550000.00,55000.00,605000.00,'Trimestriel','2025-07-12','2026-07-12','actif','2025-07-12 00:00:00','Auto'),
(77,'CON-202600077',64,28,'Tous_Risques',550000.00,55000.00,605000.00,'Semestriel','2025-06-20','2026-06-20','actif','2025-06-20 00:00:00','Auto'),
(78,'CON-202600078',48,49,'Tiers',220000.00,22000.00,242000.00,'Trimestriel','2025-12-02','2026-12-02','actif','2025-12-02 00:00:00','Auto'),
(79,'CON-202600079',40,5,'Premium',600000.00,60000.00,660000.00,'Semestriel','2025-08-28','2026-08-28','actif','2025-08-28 00:00:00','Auto'),
(80,'CON-202600080',18,90,'Tiers',200000.00,20000.00,220000.00,'Semestriel','2026-04-03','2027-04-03','expire','2026-04-03 00:00:00','Auto'),
(81,'CON-202600081',70,22,'Tiers',200000.00,20000.00,220000.00,'Annuel','2026-03-16','2027-03-16','actif','2026-03-16 00:00:00','Auto'),
(82,'CON-202600082',3,86,'Tiers',220000.00,22000.00,242000.00,'Annuel','2026-01-15','2027-01-15','actif','2026-01-15 00:00:00','Auto'),
(83,'CON-202600083',57,28,'Tiers_Plus',400000.00,40000.00,440000.00,'Annuel','2025-09-20','2026-09-20','expire','2025-09-20 00:00:00','Auto'),
(84,'CON-202600084',33,12,'Tous_Risques',600000.00,60000.00,660000.00,'Semestriel','2026-01-06','2027-01-06','actif','2026-01-06 00:00:00','Auto'),
(85,'CON-202600085',49,90,'Tiers_Plus',280000.00,28000.00,308000.00,'Trimestriel','2026-02-13','2027-02-13','actif','2026-02-13 00:00:00','Auto'),
(86,'CON-202600086',63,50,'Tous_Risques',450000.00,45000.00,495000.00,'Semestriel','2025-11-23','2026-11-23','expire','2025-11-23 00:00:00','Auto'),
(87,'CON-202600087',68,43,'Tiers_Plus',350000.00,35000.00,385000.00,'Annuel','2025-08-31','2026-08-31','actif','2025-08-31 00:00:00','Auto'),
(88,'CON-202600088',69,74,'Tiers',180000.00,18000.00,198000.00,'Semestriel','2026-02-28','2027-02-28','actif','2026-02-28 00:00:00','Auto'),
(89,'CON-202600089',43,90,'Tous_Risques',450000.00,45000.00,495000.00,'Trimestriel','2025-11-03','2026-11-03','expire','2025-11-03 00:00:00','Auto'),
(90,'CON-202600090',13,71,'Tiers_Plus',350000.00,35000.00,385000.00,'Trimestriel','2026-02-15','2027-02-15','actif','2026-02-15 00:00:00','Auto'),
(91,'CON-202600091',51,106,'Tiers',150000.00,15000.00,165000.00,'Trimestriel','2026-03-11','2027-03-11','actif','2026-03-11 00:00:00','Auto'),
(92,'CON-202600092',60,80,'Tous_Risques',400000.00,40000.00,440000.00,'Annuel','2025-08-26','2026-08-26','expire','2025-08-26 00:00:00','Auto'),
(93,'CON-202600093',65,66,'Premium',600000.00,60000.00,660000.00,'Semestriel','2025-12-19','2026-12-19','expire','2025-12-19 00:00:00','Auto'),
(94,'CON-202600094',25,100,'Tiers',250000.00,25000.00,275000.00,'Trimestriel','2025-09-19','2026-09-19','actif','2025-09-19 00:00:00','Auto'),
(95,'CON-202600095',11,103,'Premium',800000.00,80000.00,880000.00,'Semestriel','2026-01-04','2027-01-04','actif','2026-01-04 00:00:00','Auto'),
(96,'CON-202600096',21,31,'Premium',900000.00,90000.00,990000.00,'Semestriel','2025-09-26','2026-09-26','expire','2025-09-26 00:00:00','Auto'),
(97,'CON-202600097',21,33,'Tiers_Plus',400000.00,40000.00,440000.00,'Trimestriel','2026-03-07','2027-03-07','actif','2026-03-07 00:00:00','Auto'),
(98,'CON-202600098',61,32,'Tiers',220000.00,22000.00,242000.00,'Annuel','2025-11-25','2026-11-25','actif','2025-11-25 00:00:00','Auto'),
(99,'CON-202600099',68,85,'Premium',900000.00,90000.00,990000.00,'Annuel','2025-07-13','2026-07-13','expire','2025-07-13 00:00:00','Auto'),
(100,'CON-202600100',68,94,'Premium',800000.00,80000.00,880000.00,'Annuel','2025-10-24','2026-10-24','expire','2025-10-24 00:00:00','Auto');
/*!40000 ALTER TABLE `contrats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paiements`
--

DROP TABLE IF EXISTS `paiements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `paiements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contrat_id` int(11) NOT NULL,
  `numero_quittance` varchar(50) NOT NULL,
  `date_paiement` date NOT NULL,
  `montant` decimal(15,2) NOT NULL,
  `mode_reglement` enum('Especes','Virement','Cheque','Orange_Money','Wave') DEFAULT 'Especes',
  `statut` enum('valide','annule') DEFAULT 'valide',
  PRIMARY KEY (`id`),
  UNIQUE KEY `numero_quittance` (`numero_quittance`),
  KEY `contrat_id` (`contrat_id`),
  CONSTRAINT `paiements_ibfk_1` FOREIGN KEY (`contrat_id`) REFERENCES `contrats` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paiements`
--

LOCK TABLES `paiements` WRITE;
/*!40000 ALTER TABLE `paiements` DISABLE KEYS */;
INSERT INTO `paiements` VALUES
(1,1,'Q-20260414-1985','2025-12-20',440000.00,'Especes','valide'),
(2,2,'Q-20260414-2300','2026-01-03',198000.00,'Wave','valide'),
(3,3,'Q-20260414-3954','2025-11-16',770000.00,'Wave','valide'),
(4,4,'Q-20260414-4664','2025-12-01',330000.00,'Wave','valide'),
(5,5,'Q-20260414-5967','2025-09-12',660000.00,'Virement','valide'),
(6,6,'Q-20260414-6667','2025-08-23',330000.00,'Orange_Money','valide'),
(7,7,'Q-20260414-7685','2026-01-23',1100000.00,'Wave','valide'),
(8,8,'Q-20260414-8570','2026-03-18',165000.00,'Virement','valide'),
(9,9,'Q-20260414-9331','2026-03-28',440000.00,'Virement','valide'),
(10,10,'Q-20260414-10541','2025-09-04',242000.00,'Orange_Money','valide'),
(11,11,'Q-20260414-11194','2026-03-26',990000.00,'Orange_Money','valide'),
(12,12,'Q-20260414-12131','2025-10-25',495000.00,'Virement','valide'),
(13,13,'Q-20260414-13809','2025-06-30',330000.00,'Orange_Money','valide'),
(14,14,'Q-20260414-14970','2025-10-03',990000.00,'Virement','valide'),
(15,15,'Q-20260414-15605','2026-01-22',385000.00,'Virement','valide'),
(16,16,'Q-20260414-16485','2025-07-05',165000.00,'Orange_Money','valide'),
(17,17,'Q-20260414-17133','2025-07-01',275000.00,'Especes','valide'),
(18,18,'Q-20260414-18296','2025-09-30',440000.00,'Wave','valide'),
(19,19,'Q-20260414-19367','2026-02-03',880000.00,'Virement','valide'),
(20,20,'Q-20260414-20873','2025-12-06',330000.00,'Virement','valide'),
(21,21,'Q-20260414-21202','2026-04-14',330000.00,'Virement','valide'),
(22,22,'Q-20260414-22186','2025-11-25',660000.00,'Wave','valide'),
(23,23,'Q-20260414-23562','2026-04-10',440000.00,'Wave','valide'),
(24,24,'Q-20260414-24680','2025-07-17',242000.00,'Wave','valide'),
(25,25,'Q-20260414-25711','2026-03-07',990000.00,'Orange_Money','valide'),
(26,26,'Q-20260414-26296','2025-12-10',242000.00,'Virement','valide'),
(27,27,'Q-20260414-27777','2025-09-10',495000.00,'Virement','valide'),
(28,28,'Q-20260414-28770','2025-06-26',550000.00,'Wave','valide'),
(29,29,'Q-20260414-29322','2026-02-01',275000.00,'Virement','valide'),
(30,30,'Q-20260414-30229','2025-08-31',275000.00,'Orange_Money','valide'),
(31,31,'Q-20260414-31280','2026-02-12',275000.00,'Virement','valide'),
(32,32,'Q-20260414-32627','2026-01-09',660000.00,'Virement','valide'),
(33,33,'Q-20260414-33252','2025-06-21',990000.00,'Wave','valide'),
(34,34,'Q-20260414-34192','2025-12-26',308000.00,'Especes','valide'),
(35,35,'Q-20260414-35257','2026-02-22',275000.00,'Wave','valide'),
(36,36,'Q-20260414-36765','2026-02-02',605000.00,'Wave','valide'),
(37,37,'Q-20260414-37119','2025-07-14',220000.00,'Virement','valide'),
(38,38,'Q-20260414-38295','2026-03-17',605000.00,'Orange_Money','valide'),
(39,39,'Q-20260414-39361','2026-03-01',165000.00,'Virement','valide'),
(40,40,'Q-20260414-40906','2025-07-07',198000.00,'Wave','valide'),
(41,41,'Q-20260414-41824','2026-02-23',165000.00,'Orange_Money','valide'),
(42,42,'Q-20260414-42973','2026-04-06',770000.00,'Wave','valide'),
(43,43,'Q-20260414-43526','2026-03-26',660000.00,'Orange_Money','valide'),
(44,44,'Q-20260414-44815','2025-09-15',550000.00,'Especes','valide'),
(45,45,'Q-20260414-45681','2025-09-04',495000.00,'Especes','valide'),
(46,46,'Q-20260414-46987','2026-03-21',242000.00,'Virement','valide'),
(47,47,'Q-20260414-47623','2025-08-19',660000.00,'Orange_Money','valide'),
(48,48,'Q-20260414-48947','2025-12-25',385000.00,'Virement','valide'),
(49,49,'Q-20260414-49486','2025-09-30',275000.00,'Especes','valide'),
(50,50,'Q-20260414-50588','2025-09-15',330000.00,'Wave','valide'),
(51,51,'Q-20260414-51804','2025-10-20',495000.00,'Wave','valide'),
(52,52,'Q-20260414-52232','2026-03-06',880000.00,'Orange_Money','valide'),
(53,53,'Q-20260414-53985','2025-11-20',660000.00,'Orange_Money','valide'),
(54,54,'Q-20260414-54965','2025-06-29',660000.00,'Orange_Money','valide'),
(55,55,'Q-20260414-55287','2025-08-21',660000.00,'Virement','valide'),
(56,56,'Q-20260414-56868','2026-01-31',308000.00,'Orange_Money','valide'),
(57,57,'Q-20260414-57470','2026-01-26',330000.00,'Wave','valide'),
(58,58,'Q-20260414-58527','2025-11-07',385000.00,'Wave','valide'),
(59,59,'Q-20260414-59294','2026-03-30',880000.00,'Virement','valide'),
(60,60,'Q-20260414-60575','2025-08-13',330000.00,'Orange_Money','valide'),
(61,61,'Q-20260414-61314','2026-01-17',605000.00,'Wave','valide'),
(62,62,'Q-20260414-62754','2025-11-11',660000.00,'Virement','valide'),
(63,63,'Q-20260414-63945','2025-09-27',198000.00,'Especes','valide'),
(64,64,'Q-20260414-64642','2026-04-01',605000.00,'Virement','valide'),
(65,65,'Q-20260414-65634','2025-06-18',660000.00,'Orange_Money','valide'),
(66,66,'Q-20260414-66795','2026-02-27',550000.00,'Orange_Money','valide'),
(67,67,'Q-20260414-67773','2025-08-16',275000.00,'Especes','valide'),
(68,68,'Q-20260414-68948','2026-03-20',990000.00,'Orange_Money','valide'),
(69,69,'Q-20260414-69177','2025-06-21',242000.00,'Orange_Money','valide'),
(70,70,'Q-20260414-70865','2025-10-02',770000.00,'Wave','valide'),
(71,71,'Q-20260414-71484','2026-02-22',660000.00,'Especes','valide'),
(72,72,'Q-20260414-72238','2025-11-04',660000.00,'Especes','valide'),
(73,73,'Q-20260414-73161','2025-06-20',275000.00,'Especes','valide'),
(74,74,'Q-20260414-74540','2025-11-09',275000.00,'Orange_Money','valide'),
(75,75,'Q-20260414-75686','2025-09-16',440000.00,'Virement','valide'),
(76,76,'Q-20260414-76257','2025-07-12',605000.00,'Especes','valide'),
(77,77,'Q-20260414-77311','2025-06-20',605000.00,'Virement','valide'),
(78,78,'Q-20260414-78653','2025-12-02',242000.00,'Orange_Money','valide'),
(79,79,'Q-20260414-79551','2025-08-28',660000.00,'Wave','valide'),
(80,80,'Q-20260414-80644','2026-04-03',220000.00,'Especes','valide'),
(81,81,'Q-20260414-81548','2026-03-16',220000.00,'Orange_Money','valide'),
(82,82,'Q-20260414-82338','2026-01-15',242000.00,'Orange_Money','valide'),
(83,83,'Q-20260414-83730','2025-09-20',440000.00,'Orange_Money','valide'),
(84,84,'Q-20260414-84159','2026-01-06',660000.00,'Wave','valide'),
(85,85,'Q-20260414-85349','2026-02-13',308000.00,'Wave','valide'),
(86,86,'Q-20260414-86388','2025-11-23',495000.00,'Wave','valide'),
(87,87,'Q-20260414-87998','2025-08-31',385000.00,'Especes','valide'),
(88,88,'Q-20260414-88315','2026-02-28',198000.00,'Orange_Money','valide'),
(89,89,'Q-20260414-89188','2025-11-03',495000.00,'Wave','valide'),
(90,90,'Q-20260414-90853','2026-02-15',385000.00,'Wave','valide'),
(91,91,'Q-20260414-91406','2026-03-11',165000.00,'Virement','valide'),
(92,92,'Q-20260414-92591','2025-08-26',440000.00,'Especes','valide'),
(93,93,'Q-20260414-93909','2025-12-19',660000.00,'Orange_Money','valide'),
(94,94,'Q-20260414-94925','2025-09-19',275000.00,'Virement','valide'),
(95,95,'Q-20260414-95606','2026-01-04',880000.00,'Virement','valide'),
(96,96,'Q-20260414-96229','2025-09-26',990000.00,'Virement','valide'),
(97,97,'Q-20260414-97396','2026-03-07',440000.00,'Wave','valide'),
(98,98,'Q-20260414-98141','2025-11-25',242000.00,'Virement','valide'),
(99,99,'Q-20260414-99909','2025-07-13',990000.00,'Especes','valide'),
(100,100,'Q-20260414-100196','2025-10-24',880000.00,'Especes','valide');
/*!40000 ALTER TABLE `paiements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sinistres`
--

DROP TABLE IF EXISTS `sinistres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sinistres` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numero_sinistre` varchar(50) NOT NULL,
  `contrat_id` int(11) NOT NULL,
  `date_survenance` date NOT NULL,
  `date_declaration` date NOT NULL,
  `type_sinistre` enum('Accident','Vol','Incendie','Bris_de_glace') DEFAULT 'Accident',
  `montant_estime` decimal(15,2) DEFAULT NULL,
  `montant_indemnise` decimal(15,2) DEFAULT NULL,
  `statut` enum('declare','expertise','indemnise','cloture') DEFAULT 'declare',
  PRIMARY KEY (`id`),
  UNIQUE KEY `numero_sinistre` (`numero_sinistre`),
  KEY `contrat_id` (`contrat_id`),
  CONSTRAINT `sinistres_ibfk_1` FOREIGN KEY (`contrat_id`) REFERENCES `contrats` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sinistres`
--

LOCK TABLES `sinistres` WRITE;
/*!40000 ALTER TABLE `sinistres` DISABLE KEYS */;
INSERT INTO `sinistres` VALUES
(1,'SIN-202600001',45,'2025-11-14','2025-11-14','Vol',2505870.00,1779167.70,'indemnise'),
(2,'SIN-202600002',27,'2026-02-10','2026-02-10','Incendie',2375798.00,0.00,'expertise'),
(3,'SIN-202600003',14,'2026-03-05','2026-03-05','Accident',949770.00,0.00,'declare'),
(4,'SIN-202600004',27,'2025-10-08','2025-10-08','Bris_de_glace',519615.00,405299.70,'indemnise'),
(5,'SIN-202600005',39,'2025-11-05','2025-11-05','Incendie',1326546.00,0.00,'expertise'),
(6,'SIN-202600006',66,'2025-12-03','2025-12-03','Vol',1127374.00,800435.54,'cloture'),
(7,'SIN-202600007',17,'2025-12-03','2025-12-03','Vol',2321944.00,2275505.12,'indemnise'),
(8,'SIN-202600008',77,'2025-10-01','2025-10-01','Bris_de_glace',592365.00,491662.95,'indemnise'),
(9,'SIN-202600009',55,'2026-02-20','2026-02-20','Vol',711997.00,640797.30,'indemnise'),
(10,'SIN-202600010',20,'2025-12-31','2025-12-31','Vol',970954.00,0.00,'declare'),
(11,'SIN-202600011',38,'2025-12-17','2025-12-17','Bris_de_glace',1017625.00,0.00,'expertise'),
(12,'SIN-202600012',86,'2026-03-31','2026-03-31','Bris_de_glace',309608.00,219821.68,'indemnise'),
(13,'SIN-202600013',84,'2026-01-07','2026-01-07','Accident',2841975.00,2387259.00,'cloture'),
(14,'SIN-202600014',82,'2026-01-11','2026-01-11','Bris_de_glace',1528203.00,1207280.37,'indemnise'),
(15,'SIN-202600015',95,'2026-02-13','2026-02-13','Vol',2139503.00,0.00,'declare'),
(16,'SIN-202600016',83,'2025-09-27','2025-09-27','Bris_de_glace',1831788.00,1502066.16,'indemnise'),
(17,'SIN-202600017',1,'2025-12-02','2025-12-02','Incendie',693520.00,485464.00,'indemnise'),
(18,'SIN-202600018',39,'2026-01-07','2026-01-07','Vol',2015745.00,0.00,'declare'),
(19,'SIN-202600019',82,'2025-12-20','2025-12-20','Accident',994682.00,875320.16,'cloture'),
(20,'SIN-202600020',95,'2026-01-10','2026-01-10','Bris_de_glace',918349.00,872431.55,'indemnise'),
(21,'SIN-202600021',45,'2026-02-28','2026-02-28','Bris_de_glace',2912697.00,2475792.45,'indemnise'),
(22,'SIN-202600022',65,'2025-11-03','2025-11-03','Vol',1078308.00,0.00,'expertise'),
(23,'SIN-202600023',16,'2026-01-29','2026-01-29','Vol',1133945.00,0.00,'expertise'),
(24,'SIN-202600024',4,'2026-01-28','2026-01-28','Incendie',979258.00,744236.08,'cloture'),
(25,'SIN-202600025',90,'2025-10-29','2025-10-29','Incendie',1721416.00,1222205.36,'indemnise'),
(26,'SIN-202600026',24,'2025-10-24','2025-10-24','Bris_de_glace',1738093.00,0.00,'expertise'),
(27,'SIN-202600027',89,'2026-01-27','2026-01-27','Bris_de_glace',1093145.00,983830.50,'cloture'),
(28,'SIN-202600028',8,'2026-03-05','2026-03-05','Incendie',2987118.00,0.00,'declare'),
(29,'SIN-202600029',97,'2025-12-03','2025-12-03','Incendie',1966111.00,1710516.57,'cloture'),
(30,'SIN-202600030',57,'2025-12-02','2025-12-02','Incendie',469815.00,0.00,'expertise'),
(31,'SIN-202600031',4,'2025-10-03','2025-10-03','Bris_de_glace',1437288.00,1221694.80,'cloture'),
(32,'SIN-202600032',82,'2026-01-09','2026-01-09','Incendie',2520502.00,0.00,'declare'),
(33,'SIN-202600033',22,'2025-12-13','2025-12-13','Incendie',2512011.00,2461770.78,'indemnise'),
(34,'SIN-202600034',72,'2025-11-05','2025-11-05','Accident',1880330.00,1316231.00,'cloture'),
(35,'SIN-202600035',1,'2025-10-02','2025-10-02','Vol',2104090.00,0.00,'declare'),
(36,'SIN-202600036',35,'2025-10-31','2025-10-31','Incendie',2592895.00,0.00,'expertise'),
(37,'SIN-202600037',50,'2026-03-31','2026-03-31','Bris_de_glace',1653073.00,1636542.27,'cloture'),
(38,'SIN-202600038',20,'2026-01-13','2026-01-13','Accident',2270332.00,0.00,'expertise'),
(39,'SIN-202600039',40,'2026-02-21','2026-02-21','Accident',680313.00,639494.22,'indemnise'),
(40,'SIN-202600040',33,'2026-03-23','2026-03-23','Incendie',2749997.00,2172497.63,'cloture'),
(41,'SIN-202600041',69,'2026-04-10','2026-04-10','Incendie',799660.00,0.00,'declare'),
(42,'SIN-202600042',52,'2026-01-07','2026-01-07','Vol',778893.00,701003.70,'cloture'),
(43,'SIN-202600043',88,'2026-01-06','2026-01-06','Incendie',1745965.00,1641207.10,'indemnise'),
(44,'SIN-202600044',48,'2025-10-30','2025-10-30','Vol',2024082.00,0.00,'declare'),
(45,'SIN-202600045',87,'2026-01-24','2026-01-24','Accident',356142.00,249299.40,'indemnise'),
(46,'SIN-202600046',56,'2025-12-30','2025-12-30','Accident',1982248.00,0.00,'declare'),
(47,'SIN-202600047',66,'2025-12-29','2025-12-29','Accident',2282446.00,2191148.16,'indemnise'),
(48,'SIN-202600048',99,'2025-10-26','2025-10-26','Vol',2519771.00,2015816.80,'cloture'),
(49,'SIN-202600049',31,'2025-10-07','2025-10-07','Bris_de_glace',2143201.00,0.00,'expertise'),
(50,'SIN-202600050',100,'2026-03-28','2026-03-28','Incendie',2645446.00,2486719.24,'indemnise');
/*!40000 ALTER TABLE `sinistres` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `stats_contrats_actifs`
--

DROP TABLE IF EXISTS `stats_contrats_actifs`;
/*!50001 DROP VIEW IF EXISTS `stats_contrats_actifs`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `stats_contrats_actifs` AS SELECT
 1 AS `total_contrats`,
  1 AS `total_primes`,
  1 AS `mois` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `stats_sinistres_mensuels`
--

DROP TABLE IF EXISTS `stats_sinistres_mensuels`;
/*!50001 DROP VIEW IF EXISTS `stats_sinistres_mensuels`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `stats_sinistres_mensuels` AS SELECT
 1 AS `nombre_sinistres`,
  1 AS `total_indemnites`,
  1 AS `mois` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `utilisateurs`
--

DROP TABLE IF EXISTS `utilisateurs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `utilisateurs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom_utilisateur` varchar(50) NOT NULL,
  `mot_de_passe` varchar(255) NOT NULL,
  `nom` varchar(100) DEFAULT NULL,
  `prenom` varchar(100) DEFAULT NULL,
  `role` enum('admin','agent','comptable') DEFAULT 'agent',
  `actif` tinyint(1) DEFAULT 1,
  `dernier_connexion` timestamp NULL DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nom_utilisateur` (`nom_utilisateur`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `utilisateurs`
--

LOCK TABLES `utilisateurs` WRITE;
/*!40000 ALTER TABLE `utilisateurs` DISABLE KEYS */;
INSERT INTO `utilisateurs` VALUES
(1,'admin','$2y$10$9YtvB0U8HSKttad5GKqwSeeVOpSwTphaypfkKl6bMcmSvm85AG4qG','Administrateur','Système','admin',1,'2026-06-07 18:15:27',NULL);
/*!40000 ALTER TABLE `utilisateurs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vehicules`
--

DROP TABLE IF EXISTS `vehicules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `vehicules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `immatriculation` varchar(20) NOT NULL,
  `marque` varchar(50) NOT NULL,
  `modele` varchar(50) NOT NULL,
  `annee_fabrication` int(11) DEFAULT NULL,
  `valeur_venale` decimal(15,2) DEFAULT NULL,
  `proprietaire_id` int(11) DEFAULT NULL,
  `statut` enum('actif','assure','sinistre') DEFAULT 'actif',
  PRIMARY KEY (`id`),
  UNIQUE KEY `immatriculation` (`immatriculation`),
  KEY `proprietaire_id` (`proprietaire_id`),
  CONSTRAINT `vehicules_ibfk_1` FOREIGN KEY (`proprietaire_id`) REFERENCES `clients` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=110 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vehicules`
--

LOCK TABLES `vehicules` WRITE;
/*!40000 ALTER TABLE `vehicules` DISABLE KEYS */;
INSERT INTO `vehicules` VALUES
(1,'IF-284-SN','PEUGEOT','Civic',2025,19338937.00,1,'actif'),
(2,'GK-558-SN','TOYOTA','Picanto',2022,19128559.00,2,'actif'),
(3,'QI-445-SN','HYUNDAI','Clio',2023,21920937.00,3,'actif'),
(4,'ZY-147-SN','KIA','Clio',2023,15276437.00,3,'actif'),
(5,'SA-278-SN','HYUNDAI','Picanto',2021,22923662.00,4,'actif'),
(6,'AN-283-SN','HYUNDAI','i10',2025,23389176.00,5,'actif'),
(7,'AG-171-SN','KIA','Corolla',2024,8387908.00,5,'actif'),
(8,'RD-909-SN','NISSAN','i10',2022,21972786.00,6,'actif'),
(9,'OG-585-SN','KIA','208',2025,13791409.00,6,'actif'),
(10,'ZR-960-SN','HYUNDAI','Clio',2017,18923202.00,7,'actif'),
(11,'TO-710-SN','TOYOTA','208',2021,15867084.00,7,'actif'),
(12,'IM-283-SN','TOYOTA','208',2021,6394914.00,8,'actif'),
(13,'YT-872-SN','RENAULT','Micra',2023,22268873.00,9,'actif'),
(14,'IR-682-SN','TOYOTA','Micra',2023,5870804.00,9,'actif'),
(15,'FZ-425-SN','KIA','Clio',2021,20494473.00,10,'actif'),
(16,'BJ-338-SN','HONDA','208',2017,8472286.00,11,'actif'),
(17,'UV-325-SN','PEUGEOT','208',2017,20493901.00,12,'actif'),
(18,'MJ-993-SN','PEUGEOT','208',2022,20695440.00,12,'actif'),
(19,'WZ-485-SN','KIA','208',2018,19608383.00,13,'actif'),
(20,'DZ-731-SN','KIA','i10',2023,7616901.00,13,'actif'),
(21,'VT-611-SN','KIA','Micra',2022,5164386.00,14,'actif'),
(22,'AP-999-SN','PEUGEOT','Picanto',2025,7467761.00,15,'actif'),
(23,'WO-817-SN','TOYOTA','208',2019,9957012.00,16,'actif'),
(24,'UO-369-SN','NISSAN','208',2015,5007138.00,16,'actif'),
(25,'LH-477-SN','KIA','Corolla',2018,5704699.00,17,'actif'),
(26,'CZ-246-SN','KIA','Corolla',2019,18093139.00,17,'actif'),
(27,'HH-439-SN','HYUNDAI','208',2016,5294116.00,18,'actif'),
(28,'FD-683-SN','HONDA','Clio',2023,14914044.00,18,'actif'),
(29,'AX-925-SN','KIA','Clio',2015,14171271.00,19,'actif'),
(30,'EQ-557-SN','KIA','Corolla',2016,5758975.00,19,'actif'),
(31,'ND-121-SN','NISSAN','i10',2019,8614742.00,20,'actif'),
(32,'FD-555-SN','NISSAN','i10',2018,12531482.00,20,'actif'),
(33,'HK-586-SN','HONDA','Civic',2018,13287386.00,21,'actif'),
(34,'PV-667-SN','HYUNDAI','Micra',2015,11434303.00,22,'actif'),
(35,'YZ-418-SN','TOYOTA','208',2022,7692674.00,23,'actif'),
(36,'TW-936-SN','RENAULT','Corolla',2024,13124521.00,24,'actif'),
(37,'HU-860-SN','HONDA','Micra',2023,14097233.00,25,'actif'),
(38,'FK-909-SN','KIA','Clio',2025,12345259.00,25,'actif'),
(39,'NF-644-SN','NISSAN','Corolla',2024,24856739.00,26,'actif'),
(40,'NR-177-SN','PEUGEOT','Clio',2016,9443356.00,27,'actif'),
(41,'UD-953-SN','NISSAN','Corolla',2018,10424185.00,27,'actif'),
(42,'JV-891-SN','KIA','i10',2017,11659405.00,28,'actif'),
(43,'DT-849-SN','KIA','Micra',2018,6334075.00,29,'actif'),
(44,'JP-119-SN','NISSAN','Corolla',2025,8737073.00,29,'actif'),
(45,'HU-532-SN','HYUNDAI','Micra',2024,20496167.00,30,'actif'),
(46,'JC-967-SN','RENAULT','Corolla',2015,14436001.00,31,'actif'),
(47,'AF-878-SN','RENAULT','Civic',2017,6212520.00,31,'actif'),
(48,'PF-474-SN','KIA','208',2024,20610433.00,32,'actif'),
(49,'LB-286-SN','PEUGEOT','Micra',2016,23048564.00,32,'actif'),
(50,'HB-305-SN','HONDA','208',2022,7293982.00,33,'actif'),
(51,'GL-553-SN','TOYOTA','Civic',2015,5087335.00,34,'actif'),
(52,'FO-769-SN','NISSAN','i10',2021,20223624.00,34,'actif'),
(53,'LW-579-SN','KIA','208',2022,23422251.00,35,'actif'),
(54,'CU-289-SN','RENAULT','Civic',2022,15862469.00,35,'actif'),
(55,'OF-213-SN','HYUNDAI','208',2015,18688408.00,36,'actif'),
(56,'DI-848-SN','PEUGEOT','Micra',2017,8514489.00,37,'actif'),
(57,'SN-416-SN','RENAULT','Corolla',2015,15259148.00,37,'actif'),
(58,'RE-284-SN','HONDA','208',2024,15822089.00,38,'actif'),
(59,'WJ-825-SN','HONDA','208',2025,10934772.00,38,'actif'),
(60,'UH-303-SN','HYUNDAI','208',2017,7179975.00,39,'actif'),
(61,'HS-390-SN','HONDA','Corolla',2015,14023114.00,40,'actif'),
(62,'HO-815-SN','TOYOTA','Clio',2022,17681959.00,41,'actif'),
(63,'AP-238-SN','NISSAN','208',2020,15781115.00,42,'actif'),
(64,'AN-441-SN','HYUNDAI','i10',2023,22904778.00,42,'actif'),
(65,'QR-323-SN','HONDA','Civic',2022,7983688.00,43,'actif'),
(66,'GI-472-SN','PEUGEOT','Picanto',2025,15762588.00,43,'actif'),
(67,'XD-612-SN','PEUGEOT','208',2020,8088612.00,44,'actif'),
(68,'XS-669-SN','RENAULT','208',2016,22376062.00,44,'actif'),
(69,'NL-541-SN','TOYOTA','Micra',2021,23609245.00,45,'actif'),
(70,'IW-991-SN','HYUNDAI','Corolla',2023,9186498.00,46,'actif'),
(71,'GX-765-SN','NISSAN','Corolla',2024,8222237.00,47,'actif'),
(72,'YE-899-SN','HYUNDAI','Corolla',2019,20383047.00,47,'actif'),
(73,'EI-252-SN','TOYOTA','Picanto',2023,7919753.00,48,'actif'),
(74,'HM-922-SN','RENAULT','208',2020,14101543.00,48,'actif'),
(75,'SS-617-SN','PEUGEOT','i10',2018,24706156.00,49,'actif'),
(76,'UJ-568-SN','PEUGEOT','Civic',2025,21052007.00,49,'actif'),
(77,'HM-675-SN','HYUNDAI','Picanto',2018,24606476.00,50,'actif'),
(78,'OE-574-SN','NISSAN','i10',2016,17798480.00,51,'actif'),
(79,'GT-435-SN','NISSAN','208',2016,13747826.00,51,'actif'),
(80,'JR-709-SN','KIA','Corolla',2017,12333372.00,52,'actif'),
(81,'NY-843-SN','KIA','i10',2021,21926974.00,52,'actif'),
(82,'UC-761-SN','HONDA','Civic',2015,5809640.00,53,'actif'),
(83,'MX-822-SN','HONDA','Picanto',2025,6252350.00,53,'actif'),
(84,'RS-734-SN','HYUNDAI','Clio',2019,21784207.00,54,'actif'),
(85,'KF-344-SN','TOYOTA','Clio',2024,16059174.00,54,'actif'),
(86,'SG-767-SN','HYUNDAI','Corolla',2021,20588185.00,55,'actif'),
(87,'XD-548-SN','TOYOTA','Clio',2018,11883663.00,55,'actif'),
(88,'YV-612-SN','PEUGEOT','Picanto',2015,11875546.00,56,'actif'),
(89,'FH-319-SN','RENAULT','Corolla',2022,24089349.00,57,'actif'),
(90,'FX-593-SN','KIA','Picanto',2020,6432286.00,58,'actif'),
(91,'WN-142-SN','RENAULT','Micra',2020,14854618.00,58,'actif'),
(92,'MQ-791-SN','KIA','Corolla',2020,11253123.00,59,'actif'),
(93,'AB-688-SN','HYUNDAI','Corolla',2019,10885599.00,60,'actif'),
(94,'HN-279-SN','TOYOTA','208',2018,9529075.00,60,'actif'),
(95,'QM-956-SN','PEUGEOT','Picanto',2023,5273229.00,61,'actif'),
(96,'SM-534-SN','TOYOTA','Clio',2024,5313711.00,62,'actif'),
(97,'ZO-993-SN','TOYOTA','i10',2024,12661846.00,63,'actif'),
(98,'NM-675-SN','RENAULT','i10',2021,21709156.00,63,'actif'),
(99,'QB-236-SN','PEUGEOT','Corolla',2024,22985403.00,64,'actif'),
(100,'GU-601-SN','HYUNDAI','Picanto',2021,19148993.00,64,'actif'),
(101,'JU-526-SN','HYUNDAI','Corolla',2024,24634650.00,65,'actif'),
(102,'OB-919-SN','RENAULT','Corolla',2021,7591740.00,65,'actif'),
(103,'WU-855-SN','HYUNDAI','Corolla',2018,23988690.00,66,'actif'),
(104,'GP-551-SN','KIA','Micra',2018,22677555.00,66,'actif'),
(105,'SO-581-SN','TOYOTA','Picanto',2016,17849507.00,67,'actif'),
(106,'UU-378-SN','RENAULT','Civic',2018,18300848.00,68,'actif'),
(107,'JR-452-SN','HONDA','i10',2020,5966296.00,69,'actif'),
(108,'KD-329-SN','TOYOTA','i10',2019,14298580.00,70,'actif'),
(109,'CP-236-SN','HYUNDAI','208',2016,10708307.00,70,'actif');
/*!40000 ALTER TABLE `vehicules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `stats_contrats_actifs`
--

/*!50001 DROP VIEW IF EXISTS `stats_contrats_actifs`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `stats_contrats_actifs` AS select count(0) AS `total_contrats`,sum(`contrats`.`prime_ttc`) AS `total_primes`,date_format(`contrats`.`date_effet`,'%Y-%m') AS `mois` from `contrats` where `contrats`.`statut` = 'actif' group by date_format(`contrats`.`date_effet`,'%Y-%m') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `stats_sinistres_mensuels`
--

/*!50001 DROP VIEW IF EXISTS `stats_sinistres_mensuels`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `stats_sinistres_mensuels` AS select count(0) AS `nombre_sinistres`,sum(`sinistres`.`montant_indemnise`) AS `total_indemnites`,date_format(`sinistres`.`date_survenance`,'%Y-%m') AS `mois` from `sinistres` where `sinistres`.`statut` in ('indemnise','cloture') group by date_format(`sinistres`.`date_survenance`,'%Y-%m') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-22 16:35:42
