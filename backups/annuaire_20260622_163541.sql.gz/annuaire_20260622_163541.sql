/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: annuaire
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `annuaire_medical`
--

DROP TABLE IF EXISTS `annuaire_medical`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `annuaire_medical` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) NOT NULL,
  `specialite` varchar(255) DEFAULT NULL,
  `adresse` text DEFAULT NULL,
  `telephone` varchar(100) DEFAULT NULL,
  `zone_geographique` varchar(100) DEFAULT NULL,
  `categorie` enum('URGENCE','CLINIQUE','DENTAIRE','PHARMACIE','AGENCE_VOYAGE','ANNUAIRE','ASSURANCE','AUTO','BANQUE','CHARCUTERIE','COUTURE','ECOMMERCE','FITNESS','FOOT','GENIE_CIVIL','GESTION_AUTO','GESTION_COMMERCIALE','GESTION_ECOLE','GESTION_ECOMMERCIALE','GESTION_IMMOBILIERE','GESTION_POINTAGE','GESTION_PREVISIONNELLE','GP','HOTEL','OFFRE_EMPLOI','O_GARAGE','PARFUMERIE','PIECE_AUTO','PIZZERIA','PME','PORTAIL','PRESSING','REPORT','RESTAU','SCOOTER') NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `annuaire_medical`
--

LOCK TABLES `annuaire_medical` WRITE;
/*!40000 ALTER TABLE `annuaire_medical` DISABLE KEYS */;
INSERT INTO `annuaire_medical` VALUES
(1,'SOS Médecin','Soins médicaux d\'urgence','Rue 64 Baie de Soumbédioune','33 889 15 15','MEDINA','URGENCE','2026-03-29 15:37:05'),
(2,'REMED 24','Soins médicaux d\'urgence','No 22, SIPRES Al AZHAR','33 860 83 33','MERMOZ','URGENCE','2026-03-29 15:37:05'),
(3,'Urgences Cardio','Cardiologie','Sotrac Mermoz N°133','33 825 04 04','SACRE COEUR','URGENCE','2026-03-29 15:37:05'),
(4,'Clinique du CAP','Médecine générale et spécialités','Avenue Pasteur','33 889 02 02','PLATEAU','CLINIQUE','2026-03-29 15:37:05'),
(5,'Clinique de la Madeleine','Médecine générale et spécialités','Avenue des Diambars','33 889 94 70','PLATEAU','CLINIQUE','2026-03-29 15:37:05'),
(6,'Clinique MEDIC\'KANE','Médecine générale et spécialités','Sacré cœur 3','33 859 49 49','SACRE COEUR','CLINIQUE','2026-03-29 15:37:05'),
(7,'Clinique NEST','Gynécologie et Pédiatrie','64, Liberté 6 Nord VDN','33 835 33 33','LIBERTE 6','CLINIQUE','2026-03-29 15:37:05'),
(8,'Cabinet PREMIUM (Prof. NGOM)','Orthodontie et Chirurgie','Cité Keur Gorgui','33 825 82 00','SACRE COEUR','DENTAIRE','2026-03-29 15:37:05'),
(9,'Cabinet Dr. AKONDÉ','Soins dentaires','Sicap rue 10 x Bd Dial DIOP','33 824 60 34','GRAND DAKAR','DENTAIRE','2026-03-29 15:37:05'),
(10,'PHARMACIE GUIGON','Pharmacie de référence','101 av Président Lamine Guèye','33 823 43 63','PLATEAU','PHARMACIE','2026-03-29 15:37:05'),
(11,'PHARMACIE AIME CESAIRE','Pharmacie 24h/24','Fann résidence','33 825 44 23','FANN','PHARMACIE','2026-03-29 15:37:05'),
(12,'PHARMACIE DEMBA KOÏTA','Pharmacie 24h/24','Sicap Keur Gorgui','33 825 79 79','SACRE COEUR','PHARMACIE','2026-03-29 15:37:05'),
(13,'SOS Médecin','Soins médicaux d\'urgence','Rue 64 Baie de Soumbédioune','33 889 15 15','MEDINA','URGENCE','2026-03-29 15:40:13'),
(14,'REMED 24','Soins médicaux d\'urgence','No 22, SIPRES Al AZHAR','33 860 83 33','MERMOZ','URGENCE','2026-03-29 15:40:13'),
(15,'Urgences & Solutions Médicales','Soins médicaux d\'urgence','4319 Allees Seydou Nourou Tall','33 869 98 97','SICAP KARAK','URGENCE','2026-03-29 15:40:13'),
(16,'Urgences Cardio','Cardiologie','Sotrac Mermoz N°133','33 825 04 04','SACRE COEUR','URGENCE','2026-03-29 15:40:13'),
(17,'Pédiatrie 24','Pédiatrie','11 Mermoz VDN Dakar','33 864 44 33','SICAP AMITIE','URGENCE','2026-03-29 15:40:13'),
(18,'Clinique du CAP','Médecine générale','Avenue Pasteur','33 889 02 02','PLATEAU','CLINIQUE','2026-03-29 15:40:13'),
(19,'Clinique Fann Hock','Médecine générale','Rue 70 x 55','33 821 03 46','PLATEAU','CLINIQUE','2026-03-29 15:40:13'),
(20,'Clinique Pasteur','Médecine générale','50, Rue Carnot','33 849 28 10','PLATEAU','CLINIQUE','2026-03-29 15:40:13'),
(21,'Clinique de la Madeleine','Médecine générale','Avenue des Diambars','33 889 94 70','PLATEAU','CLINIQUE','2026-03-29 15:40:13'),
(22,'SGH (ex Clinique NIANG)','Médecine générale','Boulevard Général De GAULLE','33 849 04 46','PLATEAU','CLINIQUE','2026-03-29 15:40:13'),
(23,'Clinique du Plateau','Médecine générale','69, Rue Félix Faure','33 822 70 70','PLATEAU','CLINIQUE','2026-03-29 15:40:13'),
(24,'Clinique Hospitalière ASSIYA','Médecine générale','10 Av. Nelson Mandela','33 889 05 05','PLATEAU','CLINIQUE','2026-03-29 15:40:13'),
(25,'Clinique MEDIC\'KANE','Médecine générale','Sacré cœur 3','33 859 49 49','SACRE COEUR','CLINIQUE','2026-03-29 15:40:13'),
(26,'Clinique de l’Amitié','Médecine générale','HLM Grand Yoff n° 525/527','33 869 64 90','GRAND YOFF','CLINIQUE','2026-03-29 15:40:13'),
(27,'Clinique Almadies','Médecine générale','Almadies Rte de Ngor','33 859 05 99','ALMADIES','CLINIQUE','2026-03-29 15:40:13'),
(28,'Clinique de la Famille','Médecine générale','Almadies face station Shell Ngor','33 869 28 27','ALMADIES','CLINIQUE','2026-03-29 15:40:13'),
(29,'Clinique du GOLF','Médecine générale','Rue CF 03, Dakar','33 835 81 81','CAMBERENE','CLINIQUE','2026-03-29 15:40:13'),
(30,'Clinique de la Croix Bleue','Médecine générale','Rue 13 x P Castors','33 824 51 82','CASTORS','CLINIQUE','2026-03-29 15:40:13'),
(31,'Clinique Raby','Médecine générale','Rue 13 Castors','33 676 18 18','CASTORS','CLINIQUE','2026-03-29 15:40:13'),
(32,'CLINIQUE YA Salam','Médecine générale','Corniche Sicap Fann Hock n°2','33 823 67 63','CORNICHE','CLINIQUE','2026-03-29 15:40:13'),
(33,'Clinique Khalifa Ababacar SY','Médecine générale','Villa 82, Derklé','33 825 75 79','DERKLE','CLINIQUE','2026-03-29 15:40:13'),
(34,'Clinique Cheikh Anta Diop','Médecine générale','Km 4,5 Avenue Cheikh Anta DIOP','33 824 20 72','FANN','CLINIQUE','2026-03-29 15:40:13'),
(35,'Clinique Internationale','Médecine générale','Avenue Dial DIOP','33 824 44 21','GRAND DAKAR','CLINIQUE','2026-03-29 15:40:13'),
(36,'Clinique les Maristes','Médecine générale','Hann Maristes 2','33 832 09 89','HANN MARISTES','CLINIQUE','2026-03-29 15:40:13'),
(37,'Clinique NEST','Gynécologie et Pédiatrie','64, Liberté 6 Nord VDN','33 835 33 33','LIBERTE 6','CLINIQUE','2026-03-29 15:40:13'),
(38,'Clinique des Mamelles','Médecine générale','Route de Ngor','33 869 13 13','MAMELLES','CLINIQUE','2026-03-29 15:40:13'),
(39,'Clinique YASIN','Médecine générale','Parcelles Assainies U17','33 851 82 33','PARCELLES','CLINIQUE','2026-03-29 15:40:13'),
(40,'Clinique Al NOOR','Médecine générale','Petit Mbao','33 836 70 63','PETIT MBAO','CLINIQUE','2026-03-29 15:40:13'),
(41,'Clinique Lansar','Médecine générale','Pikine Route des Niayes','33 837 56 83','PIKINE','CLINIQUE','2026-03-29 15:40:13'),
(42,'Clinique Maïmouna','Médecine générale','Rufisque Route des HLM','33 836 05 33','RUFISQUE','CLINIQUE','2026-03-29 15:40:13'),
(43,'Cabinet Dr ABOU KHALIL','Chirurgie dentaire','16, Rue COLBERT','33 822 92 52','PLATEAU','DENTAIRE','2026-03-29 15:40:13'),
(44,'Cabinet Dr DIOP Anta Marie','Orthodontie','27, Rue Mohamed V','33 821 52 03','PLATEAU','DENTAIRE','2026-03-29 15:40:13'),
(45,'Cabinet Dr FAYE Joseph','Chirurgie dentaire','74, rue CARNOT','33 821 83 60','PLATEAU','DENTAIRE','2026-03-29 15:40:13'),
(46,'Cabinet PREMIUM (NGOM/DIÈYE)','Orthodontie','Cité Keur Gorgui','33 825 82 00','SACRE COEUR','DENTAIRE','2026-03-29 15:40:13'),
(47,'Cabinet Dr NIANG SARR','Soins dentaires','Rond-point Sacré Cœur 3','33 867 37 21','SACRE COEUR','DENTAIRE','2026-03-29 15:40:13'),
(48,'Cabinet Dr AKONDÉ Noël','Chirurgie dentaire','Sicap rue 10 x Bd Dial DIOP','33 824 60 34','GRAND DAKAR','DENTAIRE','2026-03-29 15:40:13'),
(49,'PHARMACIE BOISSON','Pharmacie','3 Rue Parent, Place Kermel','33 821 17 14','PLATEAU','PHARMACIE','2026-03-29 15:40:13'),
(50,'PHARMACIE GUIGON','Pharmacie','101 av Président Lamine Guèye','33 823 43 63','PLATEAU','PHARMACIE','2026-03-29 15:40:13'),
(51,'PHARMACIE DE LA REPUBLIQUE','Pharmacie','15 Boulevard de la République','33 821 16 63','PLATEAU','PHARMACIE','2026-03-29 15:40:13'),
(52,'PHARMACIE AIME CESAIRE','Pharmacie 24h/24','Fann résidence','33 825 44 23','FANN','PHARMACIE','2026-03-29 15:40:13'),
(53,'PHARMACIE DEMBA KOÏTA','Pharmacie 24h/24','Sicap Keur Gorgui','33 825 79 79','SACRE COEUR','PHARMACIE','2026-03-29 15:40:13'),
(54,'PHARMACIE VDN','Pharmacie','Sacré Cœur 3','33 827 56 83','SACRE COEUR','PHARMACIE','2026-03-29 15:40:13'),
(55,'PHARMACIE BOURGUIBA','Pharmacie','Avenue BOURGUIBA','33 824 59 92','BOURGUIBA','PHARMACIE','2026-03-29 15:40:13'),
(56,'PHARMACIE MOTA','Pharmacie','Route de l\'Aéroport','33 820 64 64','NORD FOIRE','PHARMACIE','2026-03-29 15:40:13'),
(57,'PHARMACIE ADJA MARIETOU DIAGNE','Pharmacie','RUFISQUE OUEST N°78','33 897 91 28','RUFISQUE','PHARMACIE','2026-03-29 15:40:13'),
(58,'Agence air Sénégal','Agence de voyage','Dakar','775692362','Dakar','AGENCE_VOYAGE','2026-06-21 12:59:54'),
(59,'AVIATION HANDLING SERVICES VOYAGES','Voyages organisés','Aéroport L.S. Senghor, Bureau n°1, Dakar','+221 33 869 87 13','Dakar','AGENCE_VOYAGE','2026-06-21 13:06:12'),
(60,'AL AZHAR MAYOMBA TRAVEL','Voyages','Liberté 6 Extension VDN, Immeuble Ibrahima Touré, Dakar','+221 33 820 83 70','Dakar','AGENCE_VOYAGE','2026-06-21 13:06:12'),
(61,'MERCURE VOYAGES','Tourisme','1er étage Immeuble Cbao, route de Ngor, Dakar','+221 33 820 83 70','Dakar','AGENCE_VOYAGE','2026-06-21 13:06:12');
/*!40000 ALTER TABLE `annuaire_medical` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `historique_offres`
--

DROP TABLE IF EXISTS `historique_offres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `historique_offres` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom_client` varchar(255) DEFAULT NULL,
  `telephone_client` varchar(100) DEFAULT NULL,
  `categorie_client` varchar(50) DEFAULT NULL,
  `date_generation` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `historique_offres`
--

LOCK TABLES `historique_offres` WRITE;
/*!40000 ALTER TABLE `historique_offres` DISABLE KEYS */;
INSERT INTO `historique_offres` VALUES
(1,'Cabinet Dr ABOU KHALIL','33 822 92 52','DENTAIRE','2026-03-29 16:08:19'),
(2,'Cabinet Dr ABOU KHALIL','33 822 92 52','DENTAIRE','2026-06-21 11:58:10');
/*!40000 ALTER TABLE `historique_offres` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-22 16:35:42
