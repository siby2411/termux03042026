/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: librairie
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `date_creation` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES
(1,'Mathématiques','Livres de mathématiques pures et appliquées',NULL,'2026-03-20 22:47:20'),
(2,'Physique','Ouvrages de physique générale et spécialisée',NULL,'2026-03-20 22:47:20'),
(3,'Informatique','Programmation, algorithmes, systèmes',NULL,'2026-03-20 22:47:20'),
(4,'Chimie','Chimie générale, organique, inorganique',NULL,'2026-03-20 22:47:20'),
(5,'Géographie','Géographie physique, humaine, cartographie',NULL,'2026-03-20 22:47:20'),
(6,'Électricité','Électricité, circuits, électronique',NULL,'2026-03-20 22:47:20'),
(7,'Électronique','Composants électroniques, microcontrôleurs',NULL,'2026-03-20 22:47:20'),
(8,'Littérature africaine','Romans, essais, poésie des auteurs africains',NULL,'2026-03-21 09:49:34');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `adresse` text DEFAULT NULL,
  `date_inscription` datetime DEFAULT current_timestamp(),
  `points_fidelite` int(11) DEFAULT 0,
  `statut` enum('actif','inactif','blacklist') DEFAULT 'actif',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` VALUES
(1,'Diop','Amadou','amadou.diop@email.com','771234567','Dakar, Sénégal','2026-03-20 22:47:20',0,'actif'),
(2,'Fall','Fatou','fatou.fall@email.com','772345678','Thiès, Sénégal','2026-03-20 22:47:20',0,'actif'),
(3,'Ndiaye','Mamadou','mamadou.ndiaye@email.com','773456789','Saint-Louis, Sénégal','2026-03-20 22:47:20',0,'actif');
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fournisseurs`
--

DROP TABLE IF EXISTS `fournisseurs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fournisseurs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `contact` varchar(100) DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `adresse` text DEFAULT NULL,
  `date_ajout` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fournisseurs`
--

LOCK TABLES `fournisseurs` WRITE;
/*!40000 ALTER TABLE `fournisseurs` DISABLE KEYS */;
/*!40000 ALTER TABLE `fournisseurs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `livres`
--

DROP TABLE IF EXISTS `livres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `livres` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `isbn` varchar(20) DEFAULT NULL,
  `titre` varchar(255) NOT NULL,
  `auteur` varchar(150) NOT NULL,
  `editeur` varchar(100) DEFAULT NULL,
  `annee_publication` int(11) DEFAULT NULL,
  `categorie_id` int(11) DEFAULT NULL,
  `prix_achat` decimal(10,2) NOT NULL,
  `prix_vente` decimal(10,2) NOT NULL,
  `quantite_stock` int(11) DEFAULT 0,
  `quantite_min` int(11) DEFAULT 5,
  `emplacement` varchar(50) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `couverture` varchar(255) DEFAULT NULL,
  `statut` enum('disponible','epuise','commande') DEFAULT 'disponible',
  `date_ajout` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `isbn` (`isbn`),
  KEY `categorie_id` (`categorie_id`),
  CONSTRAINT `livres_ibfk_1` FOREIGN KEY (`categorie_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `livres`
--

LOCK TABLES `livres` WRITE;
/*!40000 ALTER TABLE `livres` DISABLE KEYS */;
INSERT INTO `livres` VALUES
(1,NULL,'Mathématiques Supérieures','Jean Dupont','Hachette',2023,1,5000.00,7500.00,15,5,NULL,'Manuel complet de mathématiques',NULL,'disponible','2026-03-20 22:47:20'),
(2,NULL,'Physique Moderne','Marie Curie','Nathan',2022,2,6000.00,9000.00,10,5,NULL,'Introduction à la physique quantique',NULL,'disponible','2026-03-20 22:47:20'),
(3,NULL,'Programmation PHP','Larry Wall','O\'Reilly',2023,3,8000.00,12000.00,8,5,NULL,'Guide complet du développement PHP',NULL,'disponible','2026-03-20 22:47:20'),
(4,NULL,'Chimie Organique','Lavoisier','Dunod',2021,4,7000.00,10500.00,12,5,NULL,'Chimie organique avancée',NULL,'disponible','2026-03-20 22:47:20'),
(5,NULL,'Géographie Mondiale','Vidal de la Blache','Armand Colin',2022,5,4500.00,6800.00,19,5,NULL,'Géographie physique et humaine',NULL,'disponible','2026-03-20 22:47:20'),
(6,NULL,'Physique Générale','Richard Feynman','Dunod',2023,2,10000.00,15000.00,10,5,NULL,NULL,NULL,'disponible','2026-03-21 00:01:05'),
(7,NULL,'Programmation Python','Guido van Rossum','O\'Reilly',2024,3,6000.00,9500.00,20,5,NULL,NULL,NULL,'disponible','2026-03-21 00:01:05'),
(8,NULL,'Géographie Universelle','Elisée Reclus','Armand Colin',2022,5,5000.00,7800.00,8,5,NULL,NULL,NULL,'disponible','2026-03-21 00:01:05'),
(9,NULL,'Algèbre Linéaire','Serge Lang','Dunod',2023,1,7000.00,11000.00,12,5,NULL,NULL,NULL,'disponible','2026-03-21 00:11:38'),
(10,NULL,'Mécanique Quantique','Albert Messiah','Dunod',2022,2,9000.00,13500.00,8,5,NULL,NULL,NULL,'disponible','2026-03-21 00:11:38'),
(11,NULL,'Base de Données SQL','Joe Celko','O\'Reilly',2024,3,8500.00,12800.00,15,5,NULL,NULL,NULL,'disponible','2026-03-21 00:11:38'),
(12,NULL,'Chimie Organique Avancée','Clayden','De Boeck',2023,4,9500.00,14200.00,10,5,NULL,NULL,NULL,'disponible','2026-03-21 00:11:38'),
(13,NULL,'Géopolitique Mondiale','Yves Lacoste','Larousse',2022,5,6000.00,9000.00,7,5,NULL,NULL,NULL,'disponible','2026-03-21 00:11:38'),
(14,NULL,'Circuits Électroniques','Paul Horowitz','Cambridge',2023,7,11000.00,16500.00,5,5,NULL,NULL,NULL,'disponible','2026-03-21 00:11:38'),
(15,NULL,'Nations nègres et culture','Cheikh Anta Diop','Présence Africaine',1954,8,8000.00,12000.00,19,5,NULL,'Essai fondamental sur l\'histoire et la culture africaine',NULL,'disponible','2026-03-21 09:52:28'),
(16,NULL,'Civilisation ou barbarie','Cheikh Anta Diop','Présence Africaine',1981,8,7500.00,11500.00,15,5,NULL,'Anthropologie et histoire de l\'Afrique',NULL,'disponible','2026-03-21 09:52:28'),
(17,NULL,'L\'Afrique noire pré-coloniale','Cheikh Anta Diop','Présence Africaine',1960,8,7000.00,11000.00,12,5,NULL,'Étude des structures politiques et sociales',NULL,'disponible','2026-03-21 09:52:28'),
(18,NULL,'Things Fall Apart','Chinua Achebe','Heinemann',1958,8,6500.00,9500.00,25,5,NULL,'Chef-d\'œuvre de la littérature nigériane',NULL,'disponible','2026-03-21 09:52:28'),
(19,NULL,'Arrow of God','Chinua Achebe','Heinemann',1964,8,6000.00,9000.00,18,5,NULL,'Roman sur les conflits culturels',NULL,'disponible','2026-03-21 09:52:28'),
(20,NULL,'No Longer at Ease','Chinua Achebe','Heinemann',1960,8,5500.00,8500.00,14,5,NULL,'Suite de Things Fall Apart',NULL,'disponible','2026-03-21 09:52:28'),
(21,NULL,'Les Soleils des indépendances','Ahmadou Kourouma','Seuil',1968,8,7000.00,10500.00,22,5,NULL,'Roman emblématique de la littérature ivoirienne',NULL,'disponible','2026-03-21 09:52:28'),
(22,NULL,'Allah n\'est pas obligé','Ahmadou Kourouma','Seuil',2000,8,7200.00,10800.00,16,5,NULL,'Roman sur la guerre civile en Afrique',NULL,'disponible','2026-03-21 09:52:28'),
(23,NULL,'Une si longue lettre','Mariama Bâ','NEA',1979,8,5000.00,7800.00,30,5,NULL,'Roman épistolaire sénégalais',NULL,'disponible','2026-03-21 09:52:28'),
(24,NULL,'L\'enfant noir','Camara Laye','Plon',1953,8,5500.00,8200.00,24,5,NULL,'Récit autobiographique guinéen',NULL,'disponible','2026-03-21 09:52:28'),
(25,NULL,'Le devoir de violence','Yambo Ouologuem','Seuil',1968,8,6800.00,10200.00,10,5,NULL,'Roman malien primé',NULL,'disponible','2026-03-21 09:52:28'),
(26,NULL,'La grève des bàttu','Aminata Sow Fall','NEA',1979,8,4800.00,7200.00,20,5,NULL,'Roman sénégalais sur la condition des mendiants',NULL,'disponible','2026-03-21 09:52:28'),
(27,NULL,'L\'aventure ambiguë','Cheikh Hamidou Kane','Julliard',1961,8,6200.00,9300.00,18,5,NULL,'Roman sénégalais sur le choc des cultures',NULL,'disponible','2026-03-21 09:52:28'),
(28,NULL,'Le pauvre Christ de Bomba','Mongo Beti','Plon',1956,8,5800.00,8700.00,12,5,NULL,'Roman camerounais satirique',NULL,'disponible','2026-03-21 09:52:28'),
(29,NULL,'Ville cruelle','Eza Boto','Présence Africaine',1954,8,5200.00,7800.00,8,5,NULL,'Premier roman de Mongo Beti (sous pseudonyme)',NULL,'disponible','2026-03-21 09:52:28');
/*!40000 ALTER TABLE `livres` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logs`
--

DROP TABLE IF EXISTS `logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `utilisateur_id` int(11) DEFAULT NULL,
  `action` varchar(100) DEFAULT NULL,
  `details` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `date_creation` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `utilisateur_id` (`utilisateur_id`),
  CONSTRAINT `logs_ibfk_1` FOREIGN KEY (`utilisateur_id`) REFERENCES `utilisateurs` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs`
--

LOCK TABLES `logs` WRITE;
/*!40000 ALTER TABLE `logs` DISABLE KEYS */;
INSERT INTO `logs` VALUES
(1,3,'logout','Déconnexion de Utilisateur','127.0.0.1','2026-03-21 00:16:52'),
(2,3,'login','Connexion réussie','127.0.0.1','2026-03-21 00:23:31'),
(3,3,'login','Connexion réussie','127.0.0.1','2026-03-21 01:35:01'),
(4,3,'logout','Déconnexion de System Administrateur','127.0.0.1','2026-03-21 01:46:40'),
(5,3,'login','Connexion réussie','127.0.0.1','2026-03-21 02:01:58'),
(6,3,'logout','Déconnexion de System Administrateur','127.0.0.1','2026-03-21 09:28:54'),
(7,3,'login','Connexion réussie','127.0.0.1','2026-03-21 09:39:00'),
(8,3,'logout','Déconnexion de System Administrateur','127.0.0.1','2026-03-21 09:56:48'),
(9,3,'login','Connexion réussie','127.0.0.1','2026-03-21 09:57:17'),
(10,3,'logout','Déconnexion de System Administrateur','127.0.0.1','2026-03-21 09:58:32'),
(11,3,'login','Connexion réussie','127.0.0.1','2026-03-21 10:32:28'),
(12,3,'login','Connexion réussie','127.0.0.1','2026-03-21 10:48:17'),
(13,3,'login','Connexion réussie','127.0.0.1','2026-03-21 19:37:42'),
(14,3,'logout','Déconnexion de System Administrateur','127.0.0.1','2026-03-21 19:46:23'),
(15,3,'login','Connexion réussie','127.0.0.1','2026-03-21 19:46:40');
/*!40000 ALTER TABLE `logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender_id` int(11) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `is_read` tinyint(4) DEFAULT 0,
  `is_deleted_sender` tinyint(4) DEFAULT 0,
  `is_deleted_receiver` tinyint(4) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `sender_id` (`sender_id`),
  KEY `idx_receiver_read` (`receiver_id`,`is_read`),
  CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`sender_id`) REFERENCES `utilisateurs` (`id`),
  CONSTRAINT `messages_ibfk_2` FOREIGN KEY (`receiver_id`) REFERENCES `utilisateurs` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
INSERT INTO `messages` VALUES
(1,5,6,'Bonjour','Salut Fatou, comment ça va ?',0,0,0,'2026-03-21 01:36:16'),
(2,6,5,'Réponse','Ça va bien Amadou, merci !',0,0,0,'2026-03-21 01:36:16'),
(3,3,5,'Information','Réunion demain à 10h',0,0,0,'2026-03-21 01:36:16'),
(4,3,6,'Information','Réunion demain à 10h',0,0,0,'2026-03-21 01:36:16'),
(5,5,6,'Bonjour','Salut Fatou, comment ça va ?',0,0,0,'2026-03-21 01:40:42'),
(6,6,5,'Réponse','Ça va bien Amadou, merci !',0,0,0,'2026-03-21 01:40:42'),
(7,3,5,'Information','Réunion demain à 10h',0,0,0,'2026-03-21 01:40:42'),
(8,3,6,'Information','Réunion demain à 10h',0,0,0,'2026-03-21 01:40:42'),
(9,5,6,'Bonjour','Salut Fatou, comment ça va ?',0,0,0,'2026-03-21 01:41:25'),
(10,6,5,'Réponse','Ça va bien Amadou, merci !',0,0,0,'2026-03-21 01:41:25'),
(11,3,5,'Information','Réunion demain à 10h',0,0,0,'2026-03-21 01:41:25'),
(12,3,6,'Information','Réunion demain à 10h',0,0,0,'2026-03-21 01:41:25');
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `type` varchar(50) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `is_read` tinyint(4) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_read` (`user_id`,`is_read`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `utilisateurs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=141 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES
(1,3,'stock','Test notification','Ceci est une notification de test','dashboard.php',0,'2026-03-21 01:40:42'),
(2,3,'stock','Test notification','Ceci est une notification de test','dashboard.php',0,'2026-03-21 01:41:25'),
(3,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 09:28:37'),
(4,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 09:28:37'),
(5,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 09:28:39'),
(6,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 09:28:39'),
(7,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 09:39:00'),
(8,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 09:39:00'),
(9,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 09:56:44'),
(10,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 09:56:44'),
(11,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 09:56:48'),
(12,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 09:56:48'),
(13,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 09:57:17'),
(14,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 09:57:17'),
(15,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 09:58:27'),
(16,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 09:58:27'),
(17,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 09:58:27'),
(18,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 09:58:27'),
(19,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 09:58:29'),
(20,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 09:58:29'),
(21,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 09:58:32'),
(22,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 09:58:32'),
(23,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:32:29'),
(24,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:32:29'),
(25,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:32:59'),
(26,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:32:59'),
(27,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:33:20'),
(28,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:33:20'),
(29,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:34:33'),
(30,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:34:33'),
(31,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:35:07'),
(32,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:35:07'),
(33,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:35:43'),
(34,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:35:43'),
(35,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:35:43'),
(36,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:35:43'),
(37,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:36:15'),
(38,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:36:15'),
(39,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:36:26'),
(40,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:36:26'),
(41,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:48:17'),
(42,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:48:17'),
(43,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:48:48'),
(44,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:48:48'),
(45,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:49:22'),
(46,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:49:22'),
(47,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:50:02'),
(48,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:50:02'),
(49,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:50:12'),
(50,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:50:12'),
(51,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:52:00'),
(52,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:52:00'),
(53,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:52:23'),
(54,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:52:23'),
(55,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:52:31'),
(56,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:52:31'),
(57,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:52:34'),
(58,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:52:34'),
(59,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:53:18'),
(60,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:53:18'),
(61,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:53:48'),
(62,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:53:48'),
(63,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:54:01'),
(64,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:54:01'),
(65,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:54:54'),
(66,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:54:54'),
(67,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:55:04'),
(68,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:55:04'),
(69,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:55:24'),
(70,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:55:24'),
(71,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:56:10'),
(72,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:56:10'),
(73,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:56:13'),
(74,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:56:13'),
(75,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:57:21'),
(76,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:57:21'),
(77,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:57:38'),
(78,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 10:57:38'),
(79,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 19:37:42'),
(80,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 19:37:42'),
(81,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 19:37:58'),
(82,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 19:37:58'),
(83,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 19:45:57'),
(84,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 19:45:57'),
(85,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 19:45:59'),
(86,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 19:45:59'),
(87,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 19:46:20'),
(88,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 19:46:20'),
(89,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 19:46:23'),
(90,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 19:46:23'),
(91,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 19:46:40'),
(92,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 19:46:40'),
(93,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 19:46:53'),
(94,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 19:46:53'),
(95,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 19:46:59'),
(96,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 19:46:59'),
(97,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 19:47:03'),
(98,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 19:47:03'),
(99,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 19:47:09'),
(100,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 19:47:09'),
(101,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 19:47:17'),
(102,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 19:47:17'),
(103,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 19:47:27'),
(104,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 19:47:27'),
(105,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 19:49:23'),
(106,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 19:49:23'),
(107,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 19:49:30'),
(108,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 19:49:30'),
(109,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 19:54:42'),
(110,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 19:54:42'),
(111,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 19:54:43'),
(112,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 19:54:43'),
(113,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 19:54:54'),
(114,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 19:54:54'),
(115,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 19:55:01'),
(116,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-03-21 19:55:01'),
(117,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-06-09 18:55:18'),
(118,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-06-09 18:55:18'),
(119,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-06-09 18:55:18'),
(120,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-06-09 18:55:18'),
(121,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-06-09 18:55:31'),
(122,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-06-09 18:55:31'),
(123,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-06-09 18:56:03'),
(124,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-06-09 18:56:03'),
(125,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-06-09 19:15:40'),
(126,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-06-09 19:15:40'),
(127,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-06-09 19:15:42'),
(128,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-06-09 19:15:42'),
(129,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-06-09 19:16:13'),
(130,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-06-09 19:16:13'),
(131,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-06-09 19:16:58'),
(132,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-06-09 19:16:58'),
(133,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-06-09 19:24:52'),
(134,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-06-09 19:24:52'),
(135,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-06-09 19:24:52'),
(136,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-06-09 19:24:52'),
(137,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-06-09 19:36:27'),
(138,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-06-09 19:36:27'),
(139,2,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-06-09 19:36:27'),
(140,3,'stock','Alerte stock faible','Le livre \'Circuits Électroniques\' n\'a plus que 5 exemplaire(s).','modules/livres/modifier.php?id=14',0,'2026-06-09 19:36:27');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `salle`
--

DROP TABLE IF EXISTS `salle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `salle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `capacite` int(11) DEFAULT NULL,
  `equipements` text DEFAULT NULL,
  `disponibilite` enum('libre','occupée') DEFAULT 'libre',
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salle`
--

LOCK TABLES `salle` WRITE;
/*!40000 ALTER TABLE `salle` DISABLE KEYS */;
INSERT INTO `salle` VALUES
(1,'Salle de conférence',50,'Vidéoprojecteur, tableau blanc','libre','2026-03-26 14:38:40'),
(2,'Salle de réunion',20,'Table, chaises, écran','occupée','2026-03-26 14:38:40');
/*!40000 ALTER TABLE `salle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `terrain`
--

DROP TABLE IF EXISTS `terrain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `terrain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `disponibilite` enum('libre','occupé') DEFAULT 'libre',
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `terrain`
--

LOCK TABLES `terrain` WRITE;
/*!40000 ALTER TABLE `terrain` DISABLE KEYS */;
INSERT INTO `terrain` VALUES
(1,'Terrain A','Terrain de football principal','libre','2026-03-26 14:38:40'),
(2,'Terrain B','Terrain d’entraînement','occupé','2026-03-26 14:38:40');
/*!40000 ALTER TABLE `terrain` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `utilisateurs`
--

DROP TABLE IF EXISTS `utilisateurs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `utilisateurs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nom` varchar(100) DEFAULT NULL,
  `prenom` varchar(100) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `role` enum('admin','caissier','gestionnaire') DEFAULT 'caissier',
  `statut` enum('actif','inactif') DEFAULT 'actif',
  `dernier_acces` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `utilisateurs`
--

LOCK TABLES `utilisateurs` WRITE;
/*!40000 ALTER TABLE `utilisateurs` DISABLE KEYS */;
INSERT INTO `utilisateurs` VALUES
(2,'admin2','$2y$10$Ew.Y/iV0C0b7gM6rM1C.J.8XjPqV6s1lG7fL/fNf2Ff2Ff2Ff2Ff2','Administrateur','System',NULL,'admin','actif',NULL,'2026-03-21 00:08:04'),
(3,'admin','$2y$10$Ew.Y/iV0C0b7gM6rM1C.J.8XjPqV6s1lG7fL/fNf2Ff2Ff2Ff2Ff2','Administrateur','System',NULL,'admin','actif','2026-03-21 19:46:40','2026-03-21 00:09:07'),
(5,'caissier1','$2y$10$Ew.Y/iV0C0b7gM6rM1C.J.8XjPqV6s1lG7fL/fNf2Ff2Ff2Ff2Ff2','Diop','Amadou','amadou.diop@omega.com','caissier','actif',NULL,'2026-03-21 00:33:14'),
(6,'caissier2','$2y$10$Ew.Y/iV0C0b7gM6rM1C.J.8XjPqV6s1lG7fL/fNf2Ff2Ff2Ff2Ff2','Fall','Fatou','fatou.fall@omega.com','caissier','actif',NULL,'2026-03-21 00:33:14');
/*!40000 ALTER TABLE `utilisateurs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ventes`
--

DROP TABLE IF EXISTS `ventes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ventes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numero_facture` varchar(50) NOT NULL,
  `client_id` int(11) DEFAULT NULL,
  `utilisateur_id` int(11) NOT NULL,
  `date_vente` datetime DEFAULT current_timestamp(),
  `montant_total` decimal(10,2) NOT NULL,
  `montant_paye` decimal(10,2) NOT NULL,
  `monnaie` decimal(10,2) DEFAULT 0.00,
  `mode_paiement` enum('especes','carte','cheque','virement') DEFAULT 'especes',
  `statut` enum('validee','annulee','rembourse') DEFAULT 'validee',
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `numero_facture` (`numero_facture`),
  KEY `client_id` (`client_id`),
  KEY `utilisateur_id` (`utilisateur_id`),
  CONSTRAINT `ventes_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE SET NULL,
  CONSTRAINT `ventes_ibfk_2` FOREIGN KEY (`utilisateur_id`) REFERENCES `utilisateurs` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ventes`
--

LOCK TABLES `ventes` WRITE;
/*!40000 ALTER TABLE `ventes` DISABLE KEYS */;
INSERT INTO `ventes` VALUES
(6,'FACT001',NULL,5,'2026-03-19 00:35:55',12500.00,12500.00,0.00,'especes','validee',NULL),
(7,'FACT002',NULL,5,'2026-03-20 00:35:55',8900.00,10000.00,0.00,'carte','validee',NULL),
(8,'FACT003',NULL,6,'2026-03-21 00:35:55',15000.00,15000.00,0.00,'especes','validee',NULL),
(9,'FACT004',NULL,6,'2026-03-21 00:35:55',6700.00,6700.00,0.00,'cheque','validee',NULL),
(10,'FACT005',NULL,5,'2026-03-18 00:35:55',21000.00,21000.00,0.00,'carte','validee',NULL),
(11,'FACT006',NULL,5,'2026-03-17 00:35:55',4500.00,5000.00,0.00,'especes','validee',NULL),
(12,'FACT007',NULL,6,'2026-03-20 00:35:55',32000.00,32000.00,0.00,'carte','validee',NULL),
(13,'FACT008',NULL,5,'2026-03-21 00:35:55',8700.00,8700.00,0.00,'especes','validee',NULL),
(14,'FACT009',NULL,6,'2026-03-19 00:35:55',12500.00,13000.00,0.00,'carte','validee',NULL),
(15,'FACT010',NULL,5,'2026-03-21 00:41:11',23500.00,23500.00,0.00,'especes','validee',NULL),
(16,'FACT011',NULL,5,'2026-03-21 00:41:11',18900.00,20000.00,0.00,'carte','validee',NULL),
(17,'FACT012',NULL,5,'2026-03-20 00:41:11',42000.00,42000.00,0.00,'virement','validee',NULL),
(18,'FACT013',NULL,6,'2026-03-21 00:41:11',15700.00,15700.00,0.00,'especes','validee',NULL),
(19,'FACT014',NULL,6,'2026-03-20 00:41:11',28400.00,28400.00,0.00,'carte','validee',NULL),
(20,'FACT015',NULL,6,'2026-03-19 00:41:11',9300.00,10000.00,0.00,'cheque','validee',NULL),
(21,'FACT-20260321-3214',NULL,3,'2026-03-21 19:54:42',18800.00,18800.00,0.00,'especes','validee',NULL);
/*!40000 ALTER TABLE `ventes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ventes_lignes`
--

DROP TABLE IF EXISTS `ventes_lignes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ventes_lignes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vente_id` int(11) NOT NULL,
  `livre_id` int(11) NOT NULL,
  `quantite` int(11) NOT NULL,
  `prix_unitaire` decimal(10,2) NOT NULL,
  `remise` decimal(5,2) DEFAULT 0.00,
  `sous_total` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `vente_id` (`vente_id`),
  KEY `livre_id` (`livre_id`),
  CONSTRAINT `ventes_lignes_ibfk_1` FOREIGN KEY (`vente_id`) REFERENCES `ventes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ventes_lignes_ibfk_2` FOREIGN KEY (`livre_id`) REFERENCES `livres` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ventes_lignes`
--

LOCK TABLES `ventes_lignes` WRITE;
/*!40000 ALTER TABLE `ventes_lignes` DISABLE KEYS */;
INSERT INTO `ventes_lignes` VALUES
(10,10,1,2,11750.00,0.00,23500.00),
(11,11,2,2,9450.00,0.00,18900.00),
(12,12,3,3,14000.00,0.00,42000.00),
(13,13,4,2,7850.00,0.00,15700.00),
(14,14,5,2,14200.00,0.00,28400.00),
(15,15,1,1,9300.00,0.00,9300.00),
(16,21,5,1,6800.00,0.00,6800.00),
(17,21,15,1,12000.00,0.00,12000.00);
/*!40000 ALTER TABLE `ventes_lignes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-22 16:43:48
