/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: cabinet_radiologie
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `comptes_rendus`
--

DROP TABLE IF EXISTS `comptes_rendus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `comptes_rendus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rendezvous_id` int(11) NOT NULL,
  `radiologue_id` int(11) NOT NULL,
  `date_redaction` datetime DEFAULT current_timestamp(),
  `date_modification` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `indication` text NOT NULL,
  `technique` text NOT NULL,
  `comparaison` text DEFAULT NULL,
  `resultats` text NOT NULL,
  `conclusion` text NOT NULL,
  `recommandations` text DEFAULT NULL,
  `document_pdf` varchar(200) DEFAULT NULL,
  `images` varchar(200) DEFAULT NULL,
  `signe` tinyint(1) DEFAULT 0,
  `date_signature` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `rendezvous_id` (`rendezvous_id`),
  KEY `radiologue_id` (`radiologue_id`),
  CONSTRAINT `comptes_rendus_ibfk_1` FOREIGN KEY (`rendezvous_id`) REFERENCES `rendezvous` (`id`) ON DELETE CASCADE,
  CONSTRAINT `comptes_rendus_ibfk_2` FOREIGN KEY (`radiologue_id`) REFERENCES `radiologues` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comptes_rendus`
--

LOCK TABLES `comptes_rendus` WRITE;
/*!40000 ALTER TABLE `comptes_rendus` DISABLE KEYS */;
/*!40000 ALTER TABLE `comptes_rendus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipements`
--

DROP TABLE IF EXISTS `equipements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `equipements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `type` enum('IRM','SCANNER','RADIO','MAMMO','ECHO','DENSITO') NOT NULL,
  `marque` varchar(100) NOT NULL,
  `modele` varchar(100) NOT NULL,
  `numero_serie` varchar(50) NOT NULL,
  `date_acquisition` date NOT NULL,
  `date_derniere_maintenance` date DEFAULT NULL,
  `prochaine_maintenance` date DEFAULT NULL,
  `statut` enum('OPERATIONNEL','MAINTENANCE','PANNE','HS') DEFAULT 'OPERATIONNEL',
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `numero_serie` (`numero_serie`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipements`
--

LOCK TABLES `equipements` WRITE;
/*!40000 ALTER TABLE `equipements` DISABLE KEYS */;
INSERT INTO `equipements` VALUES
(1,'IRM 1.5T','IRM','Siemens','Symphony','IRM001','2020-01-01',NULL,NULL,'OPERATIONNEL',NULL),
(2,'Scanner 128 coupes','SCANNER','GE','Revolution','SCAN001','2021-03-15',NULL,NULL,'OPERATIONNEL',NULL),
(3,'Radiologie numérique','RADIO','Philips','DigitalDiagnost','RAD001','2019-06-20',NULL,NULL,'OPERATIONNEL',NULL);
/*!40000 ALTER TABLE `equipements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `examens`
--

DROP TABLE IF EXISTS `examens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `examens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `categorie` enum('IRM_CEREBRALE','IRM_RACHIS','IRM_ARTICULAIRE','SCANNER_THORAX','SCANNER_ABDOMEN','SCANNER_CRANE','RADIO_THORAX','RADIO_OS','MAMMOGRAPHIE','ECHO_ABDOMEN','ECHO_PELVIS','DENSITOMETRIE') NOT NULL,
  `description` text DEFAULT NULL,
  `duree_estimee` int(11) NOT NULL COMMENT 'minutes',
  `tarif` decimal(10,2) NOT NULL,
  `preparation` text DEFAULT NULL,
  `contre_indications` text DEFAULT NULL,
  `actif` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nom` (`nom`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `examens`
--

LOCK TABLES `examens` WRITE;
/*!40000 ALTER TABLE `examens` DISABLE KEYS */;
INSERT INTO `examens` VALUES
(1,'IRM Cérébrale','IRM_CEREBRALE','IRM du cerveau sans injection',30,85000.00,'Aucune',NULL,1),
(2,'Scanner Thorax','SCANNER_THORAX','Scanner du thorax avec ou sans contraste',15,65000.00,'Jeûne 4h',NULL,1),
(3,'Radiographie Thorax','RADIO_THORAX','Radio pulmonaire face et profil',5,15000.00,'Aucune',NULL,1),
(4,'Mammographie','MAMMOGRAPHIE','Mammographie bilatérale',10,25000.00,'Éviter les déodorants',NULL,1),
(5,'Échographie Abdominale','ECHO_ABDOMEN','Échographie de l\'abdomen',20,30000.00,'Jeûne 6h',NULL,1);
/*!40000 ALTER TABLE `examens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `factures`
--

DROP TABLE IF EXISTS `factures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `factures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numero_facture` varchar(20) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `rendezvous_id` int(11) DEFAULT NULL,
  `date_emission` date DEFAULT curdate(),
  `total_ht` decimal(10,2) NOT NULL,
  `tva` decimal(10,2) DEFAULT 0.00,
  `total_ttc` decimal(10,2) NOT NULL,
  `remise` decimal(10,2) DEFAULT 0.00,
  `montant_assurance` decimal(10,2) DEFAULT 0.00,
  `montant_patient` decimal(10,2) DEFAULT 0.00,
  `reglee` tinyint(1) DEFAULT 0,
  `prise_en_charge_assurance` tinyint(1) DEFAULT 0,
  `assurance` varchar(100) DEFAULT NULL,
  `date_reglement` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `numero_facture` (`numero_facture`),
  KEY `patient_id` (`patient_id`),
  KEY `rendezvous_id` (`rendezvous_id`),
  CONSTRAINT `factures_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `factures_ibfk_2` FOREIGN KEY (`rendezvous_id`) REFERENCES `rendezvous` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `factures`
--

LOCK TABLES `factures` WRITE;
/*!40000 ALTER TABLE `factures` DISABLE KEYS */;
/*!40000 ALTER TABLE `factures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manipulateurs`
--

DROP TABLE IF EXISTS `manipulateurs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `manipulateurs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `qualification` varchar(100) NOT NULL,
  `numero_licence` varchar(50) NOT NULL,
  `actif` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `manipulateurs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manipulateurs`
--

LOCK TABLES `manipulateurs` WRITE;
/*!40000 ALTER TABLE `manipulateurs` DISABLE KEYS */;
INSERT INTO `manipulateurs` VALUES
(1,5,'Technicien Supérieur','LIC-4782',1),
(2,6,'Manipulateur IRM','LIC-2364',1),
(3,7,'Manipulateur Scanner','LIC-1040',1);
/*!40000 ALTER TABLE `manipulateurs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paiements`
--

DROP TABLE IF EXISTS `paiements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `paiements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `facture_id` int(11) NOT NULL,
  `montant` decimal(10,2) NOT NULL,
  `mode` enum('especes','carte','cheque','virement','assurance') NOT NULL,
  `date_paiement` date DEFAULT curdate(),
  `reference` varchar(100) DEFAULT NULL,
  `commentaire` text DEFAULT NULL,
  `encaisse_par_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `facture_id` (`facture_id`),
  KEY `encaisse_par_id` (`encaisse_par_id`),
  CONSTRAINT `paiements_ibfk_1` FOREIGN KEY (`facture_id`) REFERENCES `factures` (`id`) ON DELETE CASCADE,
  CONSTRAINT `paiements_ibfk_2` FOREIGN KEY (`encaisse_par_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paiements`
--

LOCK TABLES `paiements` WRITE;
/*!40000 ALTER TABLE `paiements` DISABLE KEYS */;
/*!40000 ALTER TABLE `paiements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patients`
--

DROP TABLE IF EXISTS `patients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `patients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `code_patient` varchar(20) NOT NULL,
  `date_naissance` date NOT NULL,
  `groupe_sanguin` varchar(5) DEFAULT NULL,
  `allergies` text DEFAULT NULL,
  `antecedent_medicaux` text DEFAULT NULL,
  `medecin_traitant` varchar(100) DEFAULT NULL,
  `assurance` varchar(100) DEFAULT NULL,
  `numero_secu` varchar(50) DEFAULT NULL,
  `date_creation` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code_patient` (`code_patient`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `patients_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patients`
--

LOCK TABLES `patients` WRITE;
/*!40000 ALTER TABLE `patients` DISABLE KEYS */;
INSERT INTO `patients` VALUES
(1,8,'PAT-2026-0001','1985-03-15','A+',NULL,NULL,NULL,'IPM',NULL,'2026-03-28 13:42:11'),
(2,9,'PAT-2026-0002','1990-07-22','O+',NULL,NULL,NULL,'CSS',NULL,'2026-03-28 13:42:12'),
(3,10,'PAT-2026-0003','1978-11-05','A+',NULL,NULL,NULL,'SUNU',NULL,'2026-03-28 13:42:12'),
(4,11,'PAT-2026-0004','1982-09-18','O+',NULL,NULL,NULL,'Privée',NULL,'2026-03-28 13:42:12'),
(5,12,'PAT-2026-0005','1965-05-30','O+',NULL,NULL,NULL,'IPM',NULL,'2026-03-28 13:42:12');
/*!40000 ALTER TABLE `patients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `presences`
--

DROP TABLE IF EXISTS `presences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `presences` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `personnel_id` int(11) NOT NULL,
  `date` date DEFAULT curdate(),
  `heure_arrivee` time NOT NULL,
  `heure_depart` time DEFAULT NULL,
  `present` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_presence` (`personnel_id`,`date`),
  CONSTRAINT `presences_ibfk_1` FOREIGN KEY (`personnel_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `presences`
--

LOCK TABLES `presences` WRITE;
/*!40000 ALTER TABLE `presences` DISABLE KEYS */;
/*!40000 ALTER TABLE `presences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radiologues`
--

DROP TABLE IF EXISTS `radiologues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `radiologues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `specialite` varchar(100) NOT NULL,
  `numero_ordre` varchar(50) NOT NULL,
  `signature_electronique` varchar(200) DEFAULT NULL,
  `actif` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `radiologues_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radiologues`
--

LOCK TABLES `radiologues` WRITE;
/*!40000 ALTER TABLE `radiologues` DISABLE KEYS */;
INSERT INTO `radiologues` VALUES
(1,2,'Radiologie Générale','ORD-4897',NULL,1),
(2,3,'IRM & Scanner','ORD-9207',NULL,1),
(3,4,'Mammographie','ORD-4755',NULL,1);
/*!40000 ALTER TABLE `radiologues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rendezvous`
--

DROP TABLE IF EXISTS `rendezvous`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rendezvous` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_id` int(11) NOT NULL,
  `examen_id` int(11) NOT NULL,
  `radiologue_id` int(11) DEFAULT NULL,
  `manipulateur_id` int(11) NOT NULL,
  `equipement_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `heure_debut` time NOT NULL,
  `heure_fin` time NOT NULL,
  `statut` enum('programme','confirme','arrive','en_cours','termine','annule','reporte') DEFAULT 'programme',
  `motif` varchar(255) DEFAULT 'Consultation',
  `notes` text DEFAULT NULL,
  `besoin_specifique` text DEFAULT NULL,
  `cree_le` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `patient_id` (`patient_id`),
  KEY `examen_id` (`examen_id`),
  KEY `radiologue_id` (`radiologue_id`),
  KEY `manipulateur_id` (`manipulateur_id`),
  KEY `equipement_id` (`equipement_id`),
  CONSTRAINT `rendezvous_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `rendezvous_ibfk_2` FOREIGN KEY (`examen_id`) REFERENCES `examens` (`id`) ON DELETE CASCADE,
  CONSTRAINT `rendezvous_ibfk_3` FOREIGN KEY (`radiologue_id`) REFERENCES `radiologues` (`id`) ON DELETE SET NULL,
  CONSTRAINT `rendezvous_ibfk_4` FOREIGN KEY (`manipulateur_id`) REFERENCES `manipulateurs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `rendezvous_ibfk_5` FOREIGN KEY (`equipement_id`) REFERENCES `equipements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rendezvous`
--

LOCK TABLES `rendezvous` WRITE;
/*!40000 ALTER TABLE `rendezvous` DISABLE KEYS */;
INSERT INTO `rendezvous` VALUES
(1,3,3,2,1,1,'2026-03-22','11:30:00','12:30:00','termine','Consultation',NULL,NULL,'2026-03-28 13:42:12');
/*!40000 ALTER TABLE `rendezvous` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(150) NOT NULL,
  `password` varchar(128) NOT NULL,
  `email` varchar(254) DEFAULT NULL,
  `first_name` varchar(150) DEFAULT NULL,
  `last_name` varchar(150) DEFAULT NULL,
  `role` enum('radiologue','manipulateur','secretaire','admin','patient') NOT NULL DEFAULT 'patient',
  `phone` varchar(20) DEFAULT NULL,
  `adresse` text DEFAULT NULL,
  `matricule` varchar(20) DEFAULT NULL,
  `date_joined` datetime DEFAULT current_timestamp(),
  `is_active` tinyint(1) DEFAULT 1,
  `is_staff` tinyint(1) DEFAULT 0,
  `is_superuser` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `matricule` (`matricule`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'admin','$2y$10$yVNhvojtziCVZU4C9V2dpOnupVwGtZPdQmgvwaxGh9sWXJDsJT0fO','admin@cabinet.sn','Admin','System','admin',NULL,NULL,NULL,'2026-03-28 13:42:10',1,1,1),
(2,'mamadou.diop','$2y$10$yVNhvojtziCVZU4C9V2dpOnupVwGtZPdQmgvwaxGh9s...','mamadou.diop@cabinet.sn','Mamadou','Diop','radiologue','77 123 45 67',NULL,NULL,'2026-03-28 13:42:10',1,0,0),
(3,'aïcha.fall','$2y$10$yVNhvojtziCVZU4C9V2dpOnupVwGtZPdQmgvwaxGh9s...','aicha.fall@cabinet.sn','Aïcha','Fall','radiologue','78 234 56 78',NULL,NULL,'2026-03-28 13:42:11',1,0,0),
(4,'oumar.sow','$2y$10$yVNhvojtziCVZU4C9V2dpOnupVwGtZPdQmgvwaxGh9s...','oumar.sow@cabinet.sn','Oumar','Sow','radiologue','76 345 67 89',NULL,NULL,'2026-03-28 13:42:11',1,0,0),
(5,'papa.sarr','$2y$10$yVNhvojtziCVZU4C9V2dpOnupVwGtZPdQmgvwaxGh9s...','papa.sarr@cabinet.sn','Papa','Sarr','manipulateur','77 111 22 33',NULL,NULL,'2026-03-28 13:42:11',1,0,0),
(6,'mariama.gueye','$2y$10$yVNhvojtziCVZU4C9V2dpOnupVwGtZPdQmgvwaxGh9s...','mariama.gueye@cabinet.sn','Mariama','Gueye','manipulateur','78 222 33 44',NULL,NULL,'2026-03-28 13:42:11',1,0,0),
(7,'ibrahima.diouf','$2y$10$yVNhvojtziCVZU4C9V2dpOnupVwGtZPdQmgvwaxGh9s...','ibrahima.diouf@cabinet.sn','Ibrahima','Diouf','manipulateur','76 333 44 55',NULL,NULL,'2026-03-28 13:42:11',1,0,0),
(8,'abdoulaye.diallo','$2y$10$yVNhvojtziCVZU4C9V2dpOnupVwGtZPdQmgvwaxGh9s...','abdoulaye.diallo@email.sn','Abdoulaye','Diallo','patient','77 111 22 33',NULL,NULL,'2026-03-28 13:42:11',1,0,0),
(9,'maimouna.ndiaye','$2y$10$yVNhvojtziCVZU4C9V2dpOnupVwGtZPdQmgvwaxGh9s...','maimouna.ndiaye@email.sn','Maimouna','Ndiaye','patient','78 222 33 44',NULL,NULL,'2026-03-28 13:42:12',1,0,0),
(10,'serigne.fall','$2y$10$yVNhvojtziCVZU4C9V2dpOnupVwGtZPdQmgvwaxGh9s...','serigne.fall@email.sn','Serigne','Fall','patient','76 333 44 55',NULL,NULL,'2026-03-28 13:42:12',1,0,0),
(11,'awa.dieng','$2y$10$yVNhvojtziCVZU4C9V2dpOnupVwGtZPdQmgvwaxGh9s...','awa.dieng@email.sn','Awa','Dieng','patient','70 444 55 66',NULL,NULL,'2026-03-28 13:42:12',1,0,0),
(12,'bamba.sow','$2y$10$yVNhvojtziCVZU4C9V2dpOnupVwGtZPdQmgvwaxGh9s...','bamba.sow@email.sn','Bamba','Sow','patient','77 555 66 77',NULL,NULL,'2026-03-28 13:42:12',1,0,0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-22 16:35:44
