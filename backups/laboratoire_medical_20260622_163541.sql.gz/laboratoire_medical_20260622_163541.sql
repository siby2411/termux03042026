/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: laboratoire_medical
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `analyses`
--

DROP TABLE IF EXISTS `analyses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `analyses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code_analyse` varchar(20) NOT NULL,
  `nom` varchar(200) NOT NULL,
  `categorie_id` int(11) NOT NULL,
  `type_prelevement` enum('sang','urine','selle','salive','liquide_cephalique','biopsie','autre') NOT NULL,
  `description` text DEFAULT NULL,
  `prix` decimal(10,2) NOT NULL,
  `delai_resultat` int(11) NOT NULL COMMENT 'Délai en heures',
  `materiel_necessaire` text DEFAULT NULL,
  `conditions_specifiques` text DEFAULT NULL,
  `statut` enum('disponible','indisponible','externe') DEFAULT 'disponible',
  `actif` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code_analyse` (`code_analyse`),
  KEY `categorie_id` (`categorie_id`),
  CONSTRAINT `analyses_ibfk_1` FOREIGN KEY (`categorie_id`) REFERENCES `categories_analyse` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `analyses`
--

LOCK TABLES `analyses` WRITE;
/*!40000 ALTER TABLE `analyses` DISABLE KEYS */;
INSERT INTO `analyses` VALUES
(1,'NFS','Numération Formule Sanguine',1,'sang','Numération des globules rouges, blancs, plaquettes et formule leucocytaire',5000.00,4,NULL,NULL,'disponible',1),
(2,'GLY','Glycémie à jeun',2,'sang','Dosage du glucose sanguin',3000.00,2,NULL,NULL,'disponible',1),
(3,'CHOL','Cholestérol total',2,'sang','Dosage du cholestérol',3500.00,2,NULL,NULL,'disponible',1),
(4,'HDL','HDL-Cholestérol',2,'sang','Dosage du bon cholestérol',4000.00,2,NULL,NULL,'disponible',1),
(5,'LDL','LDL-Cholestérol',2,'sang','Dosage du mauvais cholestérol',4000.00,2,NULL,NULL,'disponible',1),
(6,'TSH','TSH us',5,'sang','Dosage de la thyréostimuline',6000.00,6,NULL,NULL,'disponible',1),
(7,'ECBU','Examen Cytobactériologique des Urines',8,'urine','Recherche d\'infection urinaire',4500.00,24,NULL,NULL,'disponible',1),
(8,'CRP','Protéine C réactive',2,'sang','Marqueur inflammatoire',5000.00,2,NULL,NULL,'disponible',1),
(9,'FIB','Fibrinogène',1,'sang','Facteur de coagulation',5500.00,4,NULL,NULL,'disponible',1),
(10,'ASAT','ASAT (SGOT)',2,'sang','Enzyme hépatique',3500.00,2,NULL,NULL,'disponible',1),
(11,'ALAT','ALAT (SGPT)',2,'sang','Enzyme hépatique',3500.00,2,NULL,NULL,'disponible',1);
/*!40000 ALTER TABLE `analyses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `analyses_realisees`
--

DROP TABLE IF EXISTS `analyses_realisees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `analyses_realisees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prelevement_id` int(11) NOT NULL,
  `analyse_id` int(11) NOT NULL,
  `technicien_id` int(11) DEFAULT NULL,
  `biologiste_validateur_id` int(11) DEFAULT NULL,
  `date_debut` datetime DEFAULT NULL,
  `date_fin` datetime DEFAULT NULL,
  `statut` enum('en_attente','en_cours','valide','rejete') DEFAULT 'en_attente',
  `notes` text DEFAULT NULL,
  `date_validation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `prelevement_id` (`prelevement_id`),
  KEY `analyse_id` (`analyse_id`),
  KEY `technicien_id` (`technicien_id`),
  KEY `biologiste_validateur_id` (`biologiste_validateur_id`),
  KEY `idx_analyses_realisees_statut` (`statut`),
  CONSTRAINT `analyses_realisees_ibfk_1` FOREIGN KEY (`prelevement_id`) REFERENCES `prelevements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `analyses_realisees_ibfk_2` FOREIGN KEY (`analyse_id`) REFERENCES `analyses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `analyses_realisees_ibfk_3` FOREIGN KEY (`technicien_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `analyses_realisees_ibfk_4` FOREIGN KEY (`biologiste_validateur_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `analyses_realisees`
--

LOCK TABLES `analyses_realisees` WRITE;
/*!40000 ALTER TABLE `analyses_realisees` DISABLE KEYS */;
/*!40000 ALTER TABLE `analyses_realisees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories_analyse`
--

DROP TABLE IF EXISTS `categories_analyse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories_analyse` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories_analyse`
--

LOCK TABLES `categories_analyse` WRITE;
/*!40000 ALTER TABLE `categories_analyse` DISABLE KEYS */;
INSERT INTO `categories_analyse` VALUES
(1,'Hématologie','Analyses du sang, numération formule sanguine, coagulation'),
(2,'Biochimie','Analyses biochimiques : glycémie, cholestérol, enzymes hépatiques'),
(3,'Microbiologie','Analyses bactériologiques, parasitologiques, mycologiques'),
(4,'Immunologie','Sérologie, marqueurs tumoraux, auto-immunité'),
(5,'Hormonologie','Dosages hormonaux : TSH, T3, T4, hormones sexuelles'),
(6,'Toxicologie','Recherche de toxiques, alcoolémie, stupéfiants'),
(7,'Anatomopathologie','Analyses cytologiques et histologiques'),
(8,'Urines','Analyses d\'urine : ECBU, protéinurie, etc.'),
(9,'Biologie moléculaire','PCR, séquençage, tests génétiques');
/*!40000 ALTER TABLE `categories_analyse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comptes_rendus`
--

DROP TABLE IF EXISTS `comptes_rendus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `comptes_rendus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `analyse_realisee_id` int(11) NOT NULL,
  `biologiste_id` int(11) DEFAULT NULL,
  `date_redaction` datetime DEFAULT current_timestamp(),
  `date_modification` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `conclusion` text NOT NULL,
  `recommandations` text DEFAULT NULL,
  `observations` text DEFAULT NULL,
  `document_pdf` varchar(200) DEFAULT NULL,
  `signe` tinyint(1) DEFAULT 0,
  `date_signature` datetime DEFAULT NULL,
  `signature_electronique` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `analyse_realisee_id` (`analyse_realisee_id`),
  KEY `biologiste_id` (`biologiste_id`),
  CONSTRAINT `comptes_rendus_ibfk_1` FOREIGN KEY (`analyse_realisee_id`) REFERENCES `analyses_realisees` (`id`) ON DELETE CASCADE,
  CONSTRAINT `comptes_rendus_ibfk_2` FOREIGN KEY (`biologiste_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comptes_rendus`
--

LOCK TABLES `comptes_rendus` WRITE;
/*!40000 ALTER TABLE `comptes_rendus` DISABLE KEYS */;
/*!40000 ALTER TABLE `comptes_rendus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contrats_personnel`
--

DROP TABLE IF EXISTS `contrats_personnel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `contrats_personnel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `personnel_id` int(11) NOT NULL,
  `type_contrat` enum('CDI','CDD','STAGE','PRESTATION') NOT NULL,
  `date_debut` date NOT NULL,
  `date_fin` date DEFAULT NULL,
  `salaire_base` decimal(12,2) NOT NULL,
  `taux_horaire` decimal(10,2) DEFAULT NULL,
  `avantages` text DEFAULT NULL,
  `actif` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personnel_id` (`personnel_id`),
  CONSTRAINT `contrats_personnel_ibfk_1` FOREIGN KEY (`personnel_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contrats_personnel`
--

LOCK TABLES `contrats_personnel` WRITE;
/*!40000 ALTER TABLE `contrats_personnel` DISABLE KEYS */;
/*!40000 ALTER TABLE `contrats_personnel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `controles_qualite`
--

DROP TABLE IF EXISTS `controles_qualite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `controles_qualite` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `analyse_id` int(11) NOT NULL,
  `type_controle` enum('interne','externe','calibration') NOT NULL,
  `date_controle` date NOT NULL,
  `technicien_id` int(11) DEFAULT NULL,
  `valeur_cible` varchar(100) NOT NULL,
  `valeur_obtenue` varchar(100) NOT NULL,
  `resultat` enum('conforme','non_conforme','a_revoir') NOT NULL,
  `observations` text DEFAULT NULL,
  `document` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `analyse_id` (`analyse_id`),
  KEY `technicien_id` (`technicien_id`),
  CONSTRAINT `controles_qualite_ibfk_1` FOREIGN KEY (`analyse_id`) REFERENCES `analyses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `controles_qualite_ibfk_2` FOREIGN KEY (`technicien_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `controles_qualite`
--

LOCK TABLES `controles_qualite` WRITE;
/*!40000 ALTER TABLE `controles_qualite` DISABLE KEYS */;
/*!40000 ALTER TABLE `controles_qualite` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipements`
--

DROP TABLE IF EXISTS `equipements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `equipements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `type` enum('analyseur','centrifugeuse','microscope','incubateur','frigo','autre') NOT NULL,
  `marque` varchar(100) NOT NULL,
  `modele` varchar(100) NOT NULL,
  `numero_serie` varchar(50) NOT NULL,
  `date_acquisition` date NOT NULL,
  `date_derniere_maintenance` date DEFAULT NULL,
  `prochaine_maintenance` date DEFAULT NULL,
  `statut` enum('operationnel','maintenance','panne','hors_service') DEFAULT 'operationnel',
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `numero_serie` (`numero_serie`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipements`
--

LOCK TABLES `equipements` WRITE;
/*!40000 ALTER TABLE `equipements` DISABLE KEYS */;
/*!40000 ALTER TABLE `equipements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `factures`
--

DROP TABLE IF EXISTS `factures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `factures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numero_facture` varchar(20) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `prelevement_id` int(11) DEFAULT NULL,
  `date_emission` date DEFAULT curdate(),
  `date_echeance` date DEFAULT NULL,
  `total_ht` decimal(12,2) NOT NULL,
  `tva` decimal(10,2) DEFAULT 0.00,
  `remise` decimal(10,2) DEFAULT 0.00,
  `total_ttc` decimal(12,2) NOT NULL,
  `montant_assurance` decimal(12,2) DEFAULT 0.00,
  `montant_patient` decimal(12,2) DEFAULT 0.00,
  `prise_en_charge_assurance` tinyint(1) DEFAULT 0,
  `assurance` varchar(100) DEFAULT NULL,
  `numero_bon_prise_en_charge` varchar(50) DEFAULT NULL,
  `reglee` tinyint(1) DEFAULT 0,
  `date_reglement` date DEFAULT NULL,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `numero_facture` (`numero_facture`),
  KEY `prelevement_id` (`prelevement_id`),
  KEY `idx_factures_patient` (`patient_id`),
  CONSTRAINT `factures_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `factures_ibfk_2` FOREIGN KEY (`prelevement_id`) REFERENCES `prelevements` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `factures`
--

LOCK TABLES `factures` WRITE;
/*!40000 ALTER TABLE `factures` DISABLE KEYS */;
/*!40000 ALTER TABLE `factures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feuilles_paie`
--

DROP TABLE IF EXISTS `feuilles_paie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `feuilles_paie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `personnel_id` int(11) NOT NULL,
  `mois` int(11) NOT NULL,
  `annee` int(11) NOT NULL,
  `salaire_base` decimal(12,2) NOT NULL,
  `heures_travaillees` decimal(6,2) DEFAULT 0.00,
  `heures_sup` decimal(6,2) DEFAULT 0.00,
  `prime_presence` decimal(10,2) DEFAULT 0.00,
  `prime_performance` decimal(10,2) DEFAULT 0.00,
  `avantages` decimal(10,2) DEFAULT 0.00,
  `total_brut` decimal(12,2) NOT NULL,
  `cotisations` decimal(10,2) NOT NULL,
  `total_net` decimal(12,2) NOT NULL,
  `statut` enum('brouillon','valide','paye') DEFAULT 'brouillon',
  `date_paiement` date DEFAULT NULL,
  `reference_paiement` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_feuille` (`personnel_id`,`mois`,`annee`),
  CONSTRAINT `feuilles_paie_ibfk_1` FOREIGN KEY (`personnel_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feuilles_paie`
--

LOCK TABLES `feuilles_paie` WRITE;
/*!40000 ALTER TABLE `feuilles_paie` DISABLE KEYS */;
/*!40000 ALTER TABLE `feuilles_paie` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fournisseurs`
--

DROP TABLE IF EXISTS `fournisseurs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fournisseurs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(200) NOT NULL,
  `adresse` text DEFAULT NULL,
  `telephone` varchar(20) NOT NULL,
  `email` varchar(254) DEFAULT NULL,
  `contact` varchar(100) DEFAULT NULL,
  `nina` varchar(50) DEFAULT NULL,
  `rc` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fournisseurs`
--

LOCK TABLES `fournisseurs` WRITE;
/*!40000 ALTER TABLE `fournisseurs` DISABLE KEYS */;
/*!40000 ALTER TABLE `fournisseurs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `indicateurs_performance`
--

DROP TABLE IF EXISTS `indicateurs_performance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `indicateurs_performance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `personnel_id` int(11) NOT NULL,
  `mois` int(11) NOT NULL,
  `annee` int(11) NOT NULL,
  `nb_analyses` int(11) DEFAULT 0,
  `nb_patients` int(11) DEFAULT 0,
  `ca_genere` decimal(12,2) DEFAULT 0.00,
  `taux_occupation` decimal(5,2) DEFAULT NULL,
  `qualite_notes` int(11) DEFAULT 0,
  `prime_performance` decimal(10,2) DEFAULT 0.00,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_indicateur` (`personnel_id`,`mois`,`annee`),
  CONSTRAINT `indicateurs_performance_ibfk_1` FOREIGN KEY (`personnel_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `indicateurs_performance`
--

LOCK TABLES `indicateurs_performance` WRITE;
/*!40000 ALTER TABLE `indicateurs_performance` DISABLE KEYS */;
/*!40000 ALTER TABLE `indicateurs_performance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medecins_prescripteurs`
--

DROP TABLE IF EXISTS `medecins_prescripteurs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `medecins_prescripteurs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `specialite` varchar(100) NOT NULL,
  `numero_ordre` varchar(50) NOT NULL,
  `telephone` varchar(20) NOT NULL,
  `email` varchar(254) DEFAULT NULL,
  `hopital` varchar(200) NOT NULL,
  `adresse` text DEFAULT NULL,
  `actif` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `medecins_prescripteurs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medecins_prescripteurs`
--

LOCK TABLES `medecins_prescripteurs` WRITE;
/*!40000 ALTER TABLE `medecins_prescripteurs` DISABLE KEYS */;
INSERT INTO `medecins_prescripteurs` VALUES
(1,NULL,'Momo','Siby','Orl','23','77 654 28 03','sibymohamed24@gmail.com','Chu','Dk',1),
(2,NULL,'Diop','Mamadou','Généraliste','ORD1001','771234567',NULL,'Hôpital Principal de Dakar',NULL,1),
(3,NULL,'Fall','Aminata','Pédiatre','ORD1002','772345678',NULL,'Hôpital pour Enfants Albert Royer',NULL,1),
(4,NULL,'Ndiaye','Oumar','Cardiologue','ORD1003','773456789',NULL,'Institut de Cardiologie',NULL,1);
/*!40000 ALTER TABLE `medecins_prescripteurs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mouvements_stock`
--

DROP TABLE IF EXISTS `mouvements_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mouvements_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reactif_id` int(11) NOT NULL,
  `type` enum('entree','sortie','peremption','ajustement') NOT NULL,
  `quantite` int(11) NOT NULL,
  `date` datetime DEFAULT current_timestamp(),
  `utilisateur_id` int(11) DEFAULT NULL,
  `motif` varchar(255) NOT NULL,
  `analyse_liee_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reactif_id` (`reactif_id`),
  KEY `utilisateur_id` (`utilisateur_id`),
  KEY `analyse_liee_id` (`analyse_liee_id`),
  CONSTRAINT `mouvements_stock_ibfk_1` FOREIGN KEY (`reactif_id`) REFERENCES `reactifs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `mouvements_stock_ibfk_2` FOREIGN KEY (`utilisateur_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `mouvements_stock_ibfk_3` FOREIGN KEY (`analyse_liee_id`) REFERENCES `analyses_realisees` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mouvements_stock`
--

LOCK TABLES `mouvements_stock` WRITE;
/*!40000 ALTER TABLE `mouvements_stock` DISABLE KEYS */;
/*!40000 ALTER TABLE `mouvements_stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paiements`
--

DROP TABLE IF EXISTS `paiements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `paiements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `facture_id` int(11) NOT NULL,
  `montant` decimal(12,2) NOT NULL,
  `mode` enum('especes','carte','cheque','virement','assurance','mobile_money') NOT NULL,
  `date_paiement` date DEFAULT curdate(),
  `reference` varchar(100) DEFAULT NULL,
  `commentaire` text DEFAULT NULL,
  `encaisse_par_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `facture_id` (`facture_id`),
  KEY `encaisse_par_id` (`encaisse_par_id`),
  CONSTRAINT `paiements_ibfk_1` FOREIGN KEY (`facture_id`) REFERENCES `factures` (`id`) ON DELETE CASCADE,
  CONSTRAINT `paiements_ibfk_2` FOREIGN KEY (`encaisse_par_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paiements`
--

LOCK TABLES `paiements` WRITE;
/*!40000 ALTER TABLE `paiements` DISABLE KEYS */;
/*!40000 ALTER TABLE `paiements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `parametres_analyse`
--

DROP TABLE IF EXISTS `parametres_analyse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `parametres_analyse` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `analyse_id` int(11) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `unite` varchar(20) DEFAULT NULL,
  `valeur_min` decimal(10,2) DEFAULT NULL,
  `valeur_max` decimal(10,2) DEFAULT NULL,
  `valeur_normale` varchar(100) DEFAULT NULL,
  `ordre` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `analyse_id` (`analyse_id`),
  CONSTRAINT `parametres_analyse_ibfk_1` FOREIGN KEY (`analyse_id`) REFERENCES `analyses` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parametres_analyse`
--

LOCK TABLES `parametres_analyse` WRITE;
/*!40000 ALTER TABLE `parametres_analyse` DISABLE KEYS */;
INSERT INTO `parametres_analyse` VALUES
(1,1,'Globules rouges','10^6/mm3',4.50,5.90,NULL,1),
(2,1,'Hémoglobine','g/dL',13.00,17.00,NULL,2),
(3,1,'Hématocrite','%',40.00,52.00,NULL,3),
(4,1,'Globules blancs','10^3/mm3',4.00,10.00,NULL,4),
(5,1,'Plaquettes','10^3/mm3',150.00,400.00,NULL,5);
/*!40000 ALTER TABLE `parametres_analyse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patients`
--

DROP TABLE IF EXISTS `patients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `patients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `code_patient` varchar(20) NOT NULL,
  `date_naissance` date NOT NULL,
  `lieu_naissance` varchar(100) DEFAULT NULL,
  `sexe` enum('M','F') NOT NULL,
  `groupe_sanguin` enum('A+','A-','B+','B-','O+','O-','AB+','AB-') DEFAULT NULL,
  `allergies` text DEFAULT NULL,
  `antecedent_medicaux` text DEFAULT NULL,
  `medecin_traitant` varchar(100) DEFAULT NULL,
  `assurance` varchar(100) DEFAULT NULL,
  `numero_secu` varchar(50) DEFAULT NULL,
  `profession` varchar(100) DEFAULT NULL,
  `date_creation` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code_patient` (`code_patient`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `patients_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patients`
--

LOCK TABLES `patients` WRITE;
/*!40000 ALTER TABLE `patients` DISABLE KEYS */;
INSERT INTO `patients` VALUES
(1,4,'PAT-2026-0001','1985-03-15',NULL,'M','O+',NULL,NULL,NULL,'IPM',NULL,NULL,'2026-03-28 10:57:42'),
(2,5,'PAT-2026-0002','1990-07-22',NULL,'F','A+',NULL,NULL,NULL,'CSS',NULL,NULL,'2026-03-28 10:57:42'),
(3,6,'PAT-2026-0003','1978-11-05',NULL,'M','B+',NULL,NULL,NULL,'SUNU',NULL,NULL,'2026-03-28 10:57:42'),
(4,7,'PAT-2026-0004','1982-09-18',NULL,'F','AB+',NULL,NULL,NULL,'Privée',NULL,NULL,'2026-03-28 10:57:42');
/*!40000 ALTER TABLE `patients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prelevement_analyses`
--

DROP TABLE IF EXISTS `prelevement_analyses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `prelevement_analyses` (
  `prelevement_id` int(11) NOT NULL,
  `analyse_id` int(11) NOT NULL,
  PRIMARY KEY (`prelevement_id`,`analyse_id`),
  KEY `analyse_id` (`analyse_id`),
  CONSTRAINT `prelevement_analyses_ibfk_1` FOREIGN KEY (`prelevement_id`) REFERENCES `prelevements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `prelevement_analyses_ibfk_2` FOREIGN KEY (`analyse_id`) REFERENCES `analyses` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prelevement_analyses`
--

LOCK TABLES `prelevement_analyses` WRITE;
/*!40000 ALTER TABLE `prelevement_analyses` DISABLE KEYS */;
/*!40000 ALTER TABLE `prelevement_analyses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prelevements`
--

DROP TABLE IF EXISTS `prelevements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `prelevements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_id` int(11) NOT NULL,
  `medecin_prescripteur_id` int(11) DEFAULT NULL,
  `date_prelevement` datetime NOT NULL,
  `technicien_id` int(11) DEFAULT NULL,
  `lieu_prelevement` varchar(200) DEFAULT 'Laboratoire',
  `statut` enum('programme','effectue','refuse','reporte') DEFAULT 'programme',
  `observations` text DEFAULT NULL,
  `code_barre` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code_barre` (`code_barre`),
  KEY `patient_id` (`patient_id`),
  KEY `medecin_prescripteur_id` (`medecin_prescripteur_id`),
  KEY `technicien_id` (`technicien_id`),
  KEY `idx_prelevements_date` (`date_prelevement`),
  CONSTRAINT `prelevements_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `prelevements_ibfk_2` FOREIGN KEY (`medecin_prescripteur_id`) REFERENCES `medecins_prescripteurs` (`id`) ON DELETE SET NULL,
  CONSTRAINT `prelevements_ibfk_3` FOREIGN KEY (`technicien_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prelevements`
--

LOCK TABLES `prelevements` WRITE;
/*!40000 ALTER TABLE `prelevements` DISABLE KEYS */;
/*!40000 ALTER TABLE `prelevements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `presences`
--

DROP TABLE IF EXISTS `presences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `presences` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `personnel_id` int(11) NOT NULL,
  `date` date DEFAULT curdate(),
  `heure_arrivee` time NOT NULL,
  `heure_depart` time DEFAULT NULL,
  `present` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_presence` (`personnel_id`,`date`),
  CONSTRAINT `presences_ibfk_1` FOREIGN KEY (`personnel_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `presences`
--

LOCK TABLES `presences` WRITE;
/*!40000 ALTER TABLE `presences` DISABLE KEYS */;
/*!40000 ALTER TABLE `presences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reactifs`
--

DROP TABLE IF EXISTS `reactifs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `reactifs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code_reactif` varchar(50) NOT NULL,
  `nom` varchar(200) NOT NULL,
  `categorie` enum('chimie','hematologie','immunologie','microbiologie','parasitologie','autre') NOT NULL,
  `fournisseur_id` int(11) DEFAULT NULL,
  `lot` varchar(50) NOT NULL,
  `date_expiration` date NOT NULL,
  `condition_conservation` enum('ambiant','frigo','congelateur','ultra_congelateur') NOT NULL,
  `stock_minimum` int(11) DEFAULT 5,
  `stock_actuel` int(11) DEFAULT 0,
  `prix_unitaire` decimal(10,2) NOT NULL,
  `emplacement` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code_reactif` (`code_reactif`),
  KEY `fournisseur_id` (`fournisseur_id`),
  CONSTRAINT `reactifs_ibfk_1` FOREIGN KEY (`fournisseur_id`) REFERENCES `fournisseurs` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reactifs`
--

LOCK TABLES `reactifs` WRITE;
/*!40000 ALTER TABLE `reactifs` DISABLE KEYS */;
/*!40000 ALTER TABLE `reactifs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rendezvous`
--

DROP TABLE IF EXISTS `rendezvous`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rendezvous` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_id` int(11) NOT NULL,
  `medecin_prescripteur_id` int(11) DEFAULT NULL,
  `date` date NOT NULL,
  `heure_debut` time NOT NULL,
  `heure_fin` time NOT NULL,
  `statut` enum('programme','confirme','arrive','prelevement','termine','annule','reporte') DEFAULT 'programme',
  `notes` text DEFAULT NULL,
  `besoin_specifique` text DEFAULT NULL,
  `cree_le` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `patient_id` (`patient_id`),
  KEY `medecin_prescripteur_id` (`medecin_prescripteur_id`),
  CONSTRAINT `rendezvous_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `rendezvous_ibfk_2` FOREIGN KEY (`medecin_prescripteur_id`) REFERENCES `medecins_prescripteurs` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rendezvous`
--

LOCK TABLES `rendezvous` WRITE;
/*!40000 ALTER TABLE `rendezvous` DISABLE KEYS */;
/*!40000 ALTER TABLE `rendezvous` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rendezvous_analyses`
--

DROP TABLE IF EXISTS `rendezvous_analyses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rendezvous_analyses` (
  `rendezvous_id` int(11) NOT NULL,
  `analyse_id` int(11) NOT NULL,
  PRIMARY KEY (`rendezvous_id`,`analyse_id`),
  KEY `analyse_id` (`analyse_id`),
  CONSTRAINT `rendezvous_analyses_ibfk_1` FOREIGN KEY (`rendezvous_id`) REFERENCES `rendezvous` (`id`) ON DELETE CASCADE,
  CONSTRAINT `rendezvous_analyses_ibfk_2` FOREIGN KEY (`analyse_id`) REFERENCES `analyses` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rendezvous_analyses`
--

LOCK TABLES `rendezvous_analyses` WRITE;
/*!40000 ALTER TABLE `rendezvous_analyses` DISABLE KEYS */;
/*!40000 ALTER TABLE `rendezvous_analyses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resultats_analyse`
--

DROP TABLE IF EXISTS `resultats_analyse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `resultats_analyse` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `analyse_realisee_id` int(11) NOT NULL,
  `parametre_id` int(11) NOT NULL,
  `valeur` varchar(100) NOT NULL,
  `interpretation` enum('normal','anormal','critique') DEFAULT NULL,
  `commentaire` text DEFAULT NULL,
  `date_saisie` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `analyse_realisee_id` (`analyse_realisee_id`),
  KEY `parametre_id` (`parametre_id`),
  CONSTRAINT `resultats_analyse_ibfk_1` FOREIGN KEY (`analyse_realisee_id`) REFERENCES `analyses_realisees` (`id`) ON DELETE CASCADE,
  CONSTRAINT `resultats_analyse_ibfk_2` FOREIGN KEY (`parametre_id`) REFERENCES `parametres_analyse` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resultats_analyse`
--

LOCK TABLES `resultats_analyse` WRITE;
/*!40000 ALTER TABLE `resultats_analyse` DISABLE KEYS */;
/*!40000 ALTER TABLE `resultats_analyse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `statistiques_mensuelles`
--

DROP TABLE IF EXISTS `statistiques_mensuelles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `statistiques_mensuelles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mois` int(11) NOT NULL,
  `annee` int(11) NOT NULL,
  `total_analyses` int(11) DEFAULT 0,
  `total_patients` int(11) DEFAULT 0,
  `total_rendezvous` int(11) DEFAULT 0,
  `ca_total` decimal(12,2) DEFAULT 0.00,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_stat` (`mois`,`annee`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `statistiques_mensuelles`
--

LOCK TABLES `statistiques_mensuelles` WRITE;
/*!40000 ALTER TABLE `statistiques_mensuelles` DISABLE KEYS */;
/*!40000 ALTER TABLE `statistiques_mensuelles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(150) NOT NULL,
  `password` varchar(128) NOT NULL,
  `email` varchar(254) DEFAULT NULL,
  `first_name` varchar(150) DEFAULT NULL,
  `last_name` varchar(150) DEFAULT NULL,
  `role` enum('biologiste','technicien','secretaire','admin','patient','medecin') NOT NULL DEFAULT 'patient',
  `phone` varchar(20) DEFAULT NULL,
  `adresse` text DEFAULT NULL,
  `matricule` varchar(20) DEFAULT NULL,
  `photo` varchar(200) DEFAULT '',
  `date_joined` datetime DEFAULT current_timestamp(),
  `is_active` tinyint(1) DEFAULT 1,
  `is_staff` tinyint(1) DEFAULT 0,
  `is_superuser` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `matricule` (`matricule`),
  KEY `idx_users_role` (`role`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'admin','$2y$10$Ew.Y/iV0C0b7gM6rM1C.J.8XjPqV6s1lG7fL/fNf2Ff2Ff2Ff2Ff2','admin@laboratoire.sn','Admin','System','admin',NULL,NULL,NULL,'','2026-03-28 02:18:09',1,1,1),
(4,'abdoulaye.diallo','$2y$10$Ew.Y/iV0C0b7gM6rM1C.J.8XjPqV6s1lG7fL/fNf2Ff2Ff2Ff2Ff2','abdoulaye.diallo@email.sn','Abdoulaye','Diallo','patient','771112233',NULL,NULL,'','2026-03-28 10:57:42',1,0,0),
(5,'maimouna.ndiaye','$2y$10$Ew.Y/iV0C0b7gM6rM1C.J.8XjPqV6s1lG7fL/fNf2Ff2Ff2Ff2Ff2','maimouna.ndiaye@email.sn','Maimouna','Ndiaye','patient','782223344',NULL,NULL,'','2026-03-28 10:57:42',1,0,0),
(6,'serigne.fall','$2y$10$Ew.Y/iV0C0b7gM6rM1C.J.8XjPqV6s1lG7fL/fNf2Ff2Ff2Ff2Ff2','serigne.fall@email.sn','Serigne','Fall','patient','763334455',NULL,NULL,'','2026-03-28 10:57:42',1,0,0),
(7,'awa.dieng','$2y$10$Ew.Y/iV0C0b7gM6rM1C.J.8XjPqV6s1lG7fL/fNf2Ff2Ff2Ff2Ff2','awa.dieng@email.sn','Awa','Dieng','patient','704445566',NULL,NULL,'','2026-03-28 10:57:42',1,0,0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-22 16:35:56
