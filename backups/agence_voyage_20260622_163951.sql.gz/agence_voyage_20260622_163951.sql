/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: agence_voyage
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `telephone` varchar(100) DEFAULT NULL,
  `passeport` varchar(100) DEFAULT NULL,
  `nationalite` varchar(100) DEFAULT 'Sénégalaise',
  `date_naissance` date DEFAULT NULL,
  `adresse` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` VALUES
(1,'Diallo','Mamadou','mamadou.diallo@gmail.com','+221 77 123 45 67',NULL,'Sénégalaise',NULL,NULL,'2026-04-03 03:01:56'),
(2,'Ndiaye','Fatou','fatou.ndiaye@gmail.com','+221 78 234 56 78',NULL,'Sénégalaise',NULL,NULL,'2026-04-03 03:01:56'),
(3,'Sow','Ibrahima','ibrahima.sow@yahoo.fr','+221 76 345 67 89',NULL,'Sénégalaise',NULL,NULL,'2026-04-03 03:01:56'),
(4,'Fall','Aissatou','aissatou.fall@hotmail.com','+221 70 456 78 90',NULL,'Sénégalaise',NULL,NULL,'2026-04-03 03:01:56'),
(5,'Ba','Oumar','oumar.ba@gmail.com','+221 77 567 89 01',NULL,'Sénégalaise',NULL,NULL,'2026-04-03 03:01:56'),
(6,'Mbaye','Seydou','seydou.mbaye@gmail.com','+221 77 678 90 12',NULL,'Sénégalaise',NULL,NULL,'2026-04-03 03:01:56'),
(7,'Sarr','Mariama','mariama.sarr@outlook.com','+221 78 789 01 23',NULL,'Sénégalaise',NULL,NULL,'2026-04-03 03:01:56');
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `compagnies_aeriennes`
--

DROP TABLE IF EXISTS `compagnies_aeriennes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `compagnies_aeriennes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code_iata` varchar(3) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `pays` varchar(100) DEFAULT NULL,
  `hub` varchar(100) DEFAULT NULL,
  `actif` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compagnies_aeriennes`
--

LOCK TABLES `compagnies_aeriennes` WRITE;
/*!40000 ALTER TABLE `compagnies_aeriennes` DISABLE KEYS */;
INSERT INTO `compagnies_aeriennes` VALUES
(1,'AF','Air France','France','Paris CDG',1,'2026-04-03 03:01:56'),
(2,'EK','Emirates','Émirats Arabes Unis','Dubai DXB',1,'2026-04-03 03:01:56'),
(3,'TK','Turkish Airlines','Turquie','Istanbul IST',1,'2026-04-03 03:01:56'),
(4,'AT','Royal Air Maroc','Maroc','Casablanca CMN',1,'2026-04-03 03:01:56'),
(5,'ET','Ethiopian Airlines','Éthiopie','Addis-Abeba ADD',1,'2026-04-03 03:01:56'),
(6,'LH','Lufthansa','Allemagne','Francfort FRA',1,'2026-04-03 03:01:56'),
(7,'HC','Air Sénégal','Sénégal','Dakar DSS',1,'2026-04-03 03:01:56'),
(8,'SN','Brussels Airlines','Belgique','Bruxelles BRU',1,'2026-04-03 03:01:56'),
(9,'IB','Iberia','Espagne','Madrid MAD',1,'2026-04-03 03:01:56');
/*!40000 ALTER TABLE `compagnies_aeriennes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `destinations`
--

DROP TABLE IF EXISTS `destinations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `destinations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code_iata` varchar(4) NOT NULL,
  `ville` varchar(255) NOT NULL,
  `pays` varchar(255) NOT NULL,
  `continent` varchar(100) DEFAULT NULL,
  `latitude` decimal(10,6) DEFAULT NULL,
  `longitude` decimal(10,6) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `populaire` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `destinations`
--

LOCK TABLES `destinations` WRITE;
/*!40000 ALTER TABLE `destinations` DISABLE KEYS */;
INSERT INTO `destinations` VALUES
(1,'DSS','Dakar','Sénégal','Afrique',14.739187,-17.490655,'Porte de l\'Afrique de l\'Ouest, ville lumineuse et vibrante',1),
(2,'CDG','Paris','France','Europe',48.856613,2.352222,'Ville Lumière, capitale culturelle du monde',1),
(3,'DXB','Dubaï','Émirats Arabes Unis','Asie',25.204849,55.270782,'Métropole de luxe et d\'innovation architecturale',1),
(4,'IST','Istanbul','Turquie','Europe',41.008240,28.978359,'Carrefour de l\'Orient et de l\'Occident',1),
(5,'JFK','New York','États-Unis','Amérique',40.712776,-74.005974,'La ville qui ne dort jamais, capitale du monde',1),
(6,'CMN','Casablanca','Maroc','Afrique',33.573110,-7.589843,'Capitale économique du Maghreb',1),
(7,'ADD','Addis-Abeba','Éthiopie','Afrique',9.145000,40.489673,'Hub stratégique d\'Afrique de l\'Est',0),
(8,'FRA','Francfort','Allemagne','Europe',50.110924,8.682127,'Premier hub aérien d\'Europe centrale',0),
(9,'LOS','Lagos','Nigeria','Afrique',6.524379,3.379206,'Capitale économique d\'Afrique de l\'Ouest',0),
(10,'ACC','Accra','Ghana','Afrique',5.603717,-0.186964,'Porte de l\'Afrique de l\'Ouest anglophone',0),
(11,'ABJ','Abidjan','Côte d\'Ivoire','Afrique',5.359952,-4.008257,'Capitale économique de la Côte d\'Ivoire',0),
(12,'BRU','Bruxelles','Belgique','Europe',50.846557,4.351697,'Capitale de l\'Europe',0),
(13,'MAD','Madrid','Espagne','Europe',40.416775,-3.703790,'Capitale culturelle de l\'Espagne',0);
/*!40000 ALTER TABLE `destinations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `offres_promotionnelles`
--

DROP TABLE IF EXISTS `offres_promotionnelles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `offres_promotionnelles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `destination_id` int(11) DEFAULT NULL,
  `prix_promo` decimal(10,2) DEFAULT NULL,
  `prix_original` decimal(10,2) DEFAULT NULL,
  `date_debut` date DEFAULT NULL,
  `date_fin` date DEFAULT NULL,
  `actif` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `destination_id` (`destination_id`),
  CONSTRAINT `offres_promotionnelles_ibfk_1` FOREIGN KEY (`destination_id`) REFERENCES `destinations` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offres_promotionnelles`
--

LOCK TABLES `offres_promotionnelles` WRITE;
/*!40000 ALTER TABLE `offres_promotionnelles` DISABLE KEYS */;
INSERT INTO `offres_promotionnelles` VALUES
(1,'Paris Printemps 2026','Aller-retour Dakar-Paris en classe Économique, tarif promotionnel limité',2,850000.00,1200000.00,'2026-04-03','2026-05-03',1),
(2,'Dubai Luxury Experience','Séjour premium Dakar-Dubai en classe Business, expérience 5 étoiles',3,1900000.00,2800000.00,'2026-04-03','2026-04-18',1),
(3,'Istanbul Découverte','Vol direct Dakar-Istanbul à prix réduit, découvrez le Bosphore',4,480000.00,680000.00,'2026-04-03','2026-04-28',1),
(4,'Casablanca Weekend','Escapade de 3 jours au Maroc, tarif imbattable',6,290000.00,420000.00,'2026-04-03','2026-04-23',1);
/*!40000 ALTER TABLE `offres_promotionnelles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paiements`
--

DROP TABLE IF EXISTS `paiements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `paiements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reservation_id` int(11) DEFAULT NULL,
  `montant` decimal(10,2) DEFAULT NULL,
  `methode` enum('CASH','VIREMENT','CARTE','MOBILE_MONEY','CHEQUE') DEFAULT 'CASH',
  `statut` enum('EN_ATTENTE','VALIDE','REJETE') DEFAULT 'EN_ATTENTE',
  `date_paiement` timestamp NULL DEFAULT current_timestamp(),
  `reference_paiement` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reservation_id` (`reservation_id`),
  CONSTRAINT `paiements_ibfk_1` FOREIGN KEY (`reservation_id`) REFERENCES `reservations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paiements`
--

LOCK TABLES `paiements` WRITE;
/*!40000 ALTER TABLE `paiements` DISABLE KEYS */;
/*!40000 ALTER TABLE `paiements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservations`
--

DROP TABLE IF EXISTS `reservations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `reservations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` varchar(20) NOT NULL,
  `vol_id` int(11) DEFAULT NULL,
  `client_id` int(11) DEFAULT NULL,
  `classe` enum('ECONOMIQUE','BUSINESS','PREMIERE') DEFAULT 'ECONOMIQUE',
  `nb_passagers` int(11) DEFAULT 1,
  `prix_total` decimal(10,2) DEFAULT NULL,
  `statut` enum('EN_ATTENTE','CONFIRMEE','PAYEE','ANNULEE') DEFAULT 'EN_ATTENTE',
  `date_reservation` timestamp NULL DEFAULT current_timestamp(),
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `reference` (`reference`),
  KEY `vol_id` (`vol_id`),
  KEY `client_id` (`client_id`),
  CONSTRAINT `reservations_ibfk_1` FOREIGN KEY (`vol_id`) REFERENCES `vols` (`id`),
  CONSTRAINT `reservations_ibfk_2` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservations`
--

LOCK TABLES `reservations` WRITE;
/*!40000 ALTER TABLE `reservations` DISABLE KEYS */;
INSERT INTO `reservations` VALUES
(1,'OMG-2026-0001',1,1,'ECONOMIQUE',2,1160000.00,'PAYEE','2026-04-03 03:01:56',NULL),
(2,'OMG-2026-0002',2,2,'BUSINESS',1,2200000.00,'CONFIRMEE','2026-04-03 03:01:56',NULL),
(3,'OMG-2026-0003',4,3,'ECONOMIQUE',1,185000.00,'EN_ATTENTE','2026-04-03 03:01:56',NULL),
(4,'OMG-2026-0004',6,4,'ECONOMIQUE',3,1860000.00,'CONFIRMEE','2026-04-03 03:01:56',NULL),
(5,'OMG-2026-0005',3,5,'BUSINESS',1,1300000.00,'PAYEE','2026-04-03 03:01:56',NULL),
(6,'OMG-2026-0006',7,6,'ECONOMIQUE',2,1220000.00,'EN_ATTENTE','2026-04-03 03:01:56',NULL),
(7,'OMG-2026-0007',5,7,'ECONOMIQUE',1,420000.00,'CONFIRMEE','2026-04-03 03:01:56',NULL);
/*!40000 ALTER TABLE `reservations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vols`
--

DROP TABLE IF EXISTS `vols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `vols` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numero_vol` varchar(20) NOT NULL,
  `compagnie_id` int(11) DEFAULT NULL,
  `origine_id` int(11) DEFAULT NULL,
  `destination_id` int(11) DEFAULT NULL,
  `date_depart` datetime NOT NULL,
  `date_arrivee` datetime NOT NULL,
  `type_appareil` varchar(100) DEFAULT 'Airbus A320',
  `places_eco` int(11) DEFAULT 150,
  `places_business` int(11) DEFAULT 20,
  `places_first` int(11) DEFAULT 0,
  `prix_eco` decimal(10,2) DEFAULT 0.00,
  `prix_business` decimal(10,2) DEFAULT 0.00,
  `prix_first` decimal(10,2) DEFAULT 0.00,
  `statut` enum('PROGRAMME','EN_COURS','ARRIVE','ANNULE','RETARDE') DEFAULT 'PROGRAMME',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `compagnie_id` (`compagnie_id`),
  KEY `origine_id` (`origine_id`),
  KEY `destination_id` (`destination_id`),
  CONSTRAINT `vols_ibfk_1` FOREIGN KEY (`compagnie_id`) REFERENCES `compagnies_aeriennes` (`id`),
  CONSTRAINT `vols_ibfk_2` FOREIGN KEY (`origine_id`) REFERENCES `destinations` (`id`),
  CONSTRAINT `vols_ibfk_3` FOREIGN KEY (`destination_id`) REFERENCES `destinations` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vols`
--

LOCK TABLES `vols` WRITE;
/*!40000 ALTER TABLE `vols` DISABLE KEYS */;
INSERT INTO `vols` VALUES
(1,'AF718',1,1,2,'2026-04-05 03:01:56','2026-04-05 10:01:56','Airbus A330-300',250,40,0,580000.00,1450000.00,0.00,'PROGRAMME','2026-04-03 03:01:56'),
(2,'EK762',2,1,3,'2026-04-04 03:01:56','2026-04-04 12:01:56','Boeing 777-300ER',304,42,8,750000.00,2200000.00,4500000.00,'PROGRAMME','2026-04-03 03:01:56'),
(3,'TK501',3,1,4,'2026-04-07 03:01:56','2026-04-07 11:01:56','Boeing 737 MAX 9',150,20,0,520000.00,1300000.00,0.00,'PROGRAMME','2026-04-03 03:01:56'),
(4,'HC100',7,1,6,'2026-04-04 03:01:56','2026-04-04 07:01:56','ATR 72-600',70,0,0,185000.00,0.00,0.00,'PROGRAMME','2026-04-03 03:01:56'),
(5,'ET551',5,1,7,'2026-04-03 03:01:56','2026-04-03 08:01:56','Boeing 787-9 Dreamliner',280,24,0,420000.00,980000.00,0.00,'EN_COURS','2026-04-03 03:01:56'),
(6,'AF719',1,2,1,'2026-04-06 03:01:56','2026-04-06 09:01:56','Airbus A330-200',250,40,0,620000.00,1550000.00,0.00,'PROGRAMME','2026-04-03 03:01:56'),
(7,'LH566',6,1,8,'2026-04-08 03:01:56','2026-04-08 12:01:56','Airbus A340-600',200,30,0,610000.00,1600000.00,0.00,'PROGRAMME','2026-04-03 03:01:56'),
(8,'HC200',7,1,9,'2026-04-05 03:01:56','2026-04-05 06:01:56','De Havilland Q400',78,0,0,145000.00,0.00,0.00,'RETARDE','2026-04-03 03:01:56');
/*!40000 ALTER TABLE `vols` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-22 16:39:52
