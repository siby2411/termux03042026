/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: banque
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `CLIENTS`
--

DROP TABLE IF EXISTS `CLIENTS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `CLIENTS` (
  `ClientID` int(11) NOT NULL AUTO_INCREMENT,
  `Nom` varchar(100) NOT NULL,
  `Prenoms` varchar(100) NOT NULL,
  `Email` varchar(150) DEFAULT NULL,
  `Telephone` varchar(20) DEFAULT NULL,
  `Adresse` text DEFAULT NULL,
  `DateNaissance` date DEFAULT NULL,
  `TypeIdentifiant` enum('CNI','Passeport','Permis') DEFAULT NULL,
  `NumeroIdentifiant` varchar(50) DEFAULT NULL,
  `Statut` enum('Actif','Inactif') DEFAULT 'Actif',
  `DateCreation` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`ClientID`),
  UNIQUE KEY `Email` (`Email`),
  UNIQUE KEY `NumeroIdentifiant` (`NumeroIdentifiant`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENTS`
--

LOCK TABLES `CLIENTS` WRITE;
/*!40000 ALTER TABLE `CLIENTS` DISABLE KEYS */;
INSERT INTO `CLIENTS` VALUES
(1,'SIBY','Mohamet',NULL,NULL,NULL,NULL,NULL,NULL,'Actif','2026-03-08 04:02:59'),
(2,'SARR','Ibrahima',NULL,NULL,NULL,NULL,NULL,NULL,'Actif','2026-03-08 04:02:59');
/*!40000 ALTER TABLE `CLIENTS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `COMPTES`
--

DROP TABLE IF EXISTS `COMPTES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `COMPTES` (
  `CompteID` int(11) NOT NULL AUTO_INCREMENT,
  `ClientID` int(11) NOT NULL,
  `CodeCompte` varchar(50) NOT NULL,
  `TypeCompte` enum('CompteCourant','Epargne','DepotATerme') NOT NULL,
  `Solde` decimal(15,2) DEFAULT 0.00,
  `TauxInteret` decimal(5,2) DEFAULT 0.00,
  `Statut` enum('Ouvert','Ferme','Bloque') DEFAULT 'Ouvert',
  `DateOuverture` date NOT NULL,
  PRIMARY KEY (`CompteID`),
  UNIQUE KEY `CodeCompte` (`CodeCompte`),
  KEY `ClientID` (`ClientID`),
  CONSTRAINT `COMPTES_ibfk_1` FOREIGN KEY (`ClientID`) REFERENCES `CLIENTS` (`ClientID`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `COMPTES`
--

LOCK TABLES `COMPTES` WRITE;
/*!40000 ALTER TABLE `COMPTES` DISABLE KEYS */;
INSERT INTO `COMPTES` VALUES
(1,1,'CPT-SIBY-001','CompteCourant',5000.00,0.00,'Ouvert','2026-03-08');
/*!40000 ALTER TABLE `COMPTES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CREDITS`
--

DROP TABLE IF EXISTS `CREDITS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `CREDITS` (
  `CreditID` int(11) NOT NULL AUTO_INCREMENT,
  `ClientID` int(11) NOT NULL,
  `CodeCredit` varchar(50) NOT NULL,
  `TypeCredit` varchar(100) DEFAULT NULL,
  `MontantPrincipal` decimal(15,2) NOT NULL,
  `TauxInteretAnnuel` decimal(5,2) NOT NULL,
  `DureeMois` int(11) NOT NULL,
  `DateDeblocage` date NOT NULL,
  `Statut` enum('EnAttente','Approuve','Rembourse','Defaut') DEFAULT 'Approuve',
  `DateCreation` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`CreditID`),
  UNIQUE KEY `CodeCredit` (`CodeCredit`),
  KEY `ClientID` (`ClientID`),
  CONSTRAINT `CREDITS_ibfk_1` FOREIGN KEY (`ClientID`) REFERENCES `CLIENTS` (`ClientID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CREDITS`
--

LOCK TABLES `CREDITS` WRITE;
/*!40000 ALTER TABLE `CREDITS` DISABLE KEYS */;
/*!40000 ALTER TABLE `CREDITS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PERSONNEL`
--

DROP TABLE IF EXISTS `PERSONNEL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `PERSONNEL` (
  `PersonnelID` int(11) NOT NULL AUTO_INCREMENT,
  `Nom` varchar(100) NOT NULL,
  `Prenoms` varchar(100) NOT NULL,
  `Email` varchar(150) NOT NULL,
  `MotDePasse` varchar(255) NOT NULL,
  `Role` enum('Admin','Comptable','Guichetier') DEFAULT 'Guichetier',
  `Statut` enum('Actif','Suspendu') DEFAULT 'Actif',
  `DerniereConnexion` datetime DEFAULT NULL,
  `DateCreation` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`PersonnelID`),
  UNIQUE KEY `Email` (`Email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PERSONNEL`
--

LOCK TABLES `PERSONNEL` WRITE;
/*!40000 ALTER TABLE `PERSONNEL` DISABLE KEYS */;
INSERT INTO `PERSONNEL` VALUES
(1,'SIBY','Mohamet','admin@omega.sn','$2y$10$h5QOkt.aaHye8pXjL0N1iOeeuGlKrdJ.LBALVVtUpzV7oNg8aCy9G','Admin','Actif',NULL,'2026-03-08 04:10:43');
/*!40000 ALTER TABLE `PERSONNEL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TRANSACTIONS`
--

DROP TABLE IF EXISTS `TRANSACTIONS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `TRANSACTIONS` (
  `TransactionID` int(11) NOT NULL AUTO_INCREMENT,
  `CompteID` int(11) DEFAULT NULL,
  `Montant` decimal(15,2) NOT NULL,
  `TypeTransaction` enum('Depot','Retrait','Virement','Interet_Crediteur','Frais') NOT NULL,
  `Description` text DEFAULT NULL,
  `DateTransaction` datetime NOT NULL,
  `PersonnelID` int(11) DEFAULT NULL,
  PRIMARY KEY (`TransactionID`),
  KEY `CompteID` (`CompteID`),
  CONSTRAINT `TRANSACTIONS_ibfk_1` FOREIGN KEY (`CompteID`) REFERENCES `COMPTES` (`CompteID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TRANSACTIONS`
--

LOCK TABLES `TRANSACTIONS` WRITE;
/*!40000 ALTER TABLE `TRANSACTIONS` DISABLE KEYS */;
/*!40000 ALTER TABLE `TRANSACTIONS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TRESORERIE`
--

DROP TABLE IF EXISTS `TRESORERIE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `TRESORERIE` (
  `TresorerieID` int(11) NOT NULL,
  `Nom_Caisse` varchar(100) DEFAULT NULL,
  `Montant` decimal(18,2) DEFAULT 0.00,
  `DerniereMiseAJour` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`TresorerieID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TRESORERIE`
--

LOCK TABLES `TRESORERIE` WRITE;
/*!40000 ALTER TABLE `TRESORERIE` DISABLE KEYS */;
INSERT INTO `TRESORERIE` VALUES
(1,'Caisse Centrale OMEGA',25000000.00,'2026-03-08 04:07:57');
/*!40000 ALTER TABLE `TRESORERIE` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-22 16:35:44
