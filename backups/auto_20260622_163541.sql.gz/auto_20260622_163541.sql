/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: auto
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `adresse` text DEFAULT NULL,
  `permis_conduire_num` varchar(50) DEFAULT NULL,
  `date_enregistrement` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` VALUES
(1,'Momo ','Siby ','sibymohamed24@gmail.com','77 654 28 03 ','Dk','34f','2026-03-08 23:51:55');
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `galerie`
--

DROP TABLE IF EXISTS `galerie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `galerie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `voiture_id` int(11) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `legende` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `voiture_id` (`voiture_id`),
  CONSTRAINT `galerie_ibfk_1` FOREIGN KEY (`voiture_id`) REFERENCES `voitures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `galerie`
--

LOCK TABLES `galerie` WRITE;
/*!40000 ALTER TABLE `galerie` DISABLE KEYS */;
INSERT INTO `galerie` VALUES
(3,3,'uploads/auto_1773009587_0.jpg','');
/*!40000 ALTER TABLE `galerie` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `images_voitures`
--

DROP TABLE IF EXISTS `images_voitures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `images_voitures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `voiture_id` int(11) NOT NULL,
  `chemin_image` varchar(255) NOT NULL,
  `est_principale` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `voiture_id` (`voiture_id`),
  CONSTRAINT `images_voitures_ibfk_1` FOREIGN KEY (`voiture_id`) REFERENCES `voitures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `images_voitures`
--

LOCK TABLES `images_voitures` WRITE;
/*!40000 ALTER TABLE `images_voitures` DISABLE KEYS */;
INSERT INTO `images_voitures` VALUES
(1,3,'uploads/galerie/3/slide_69adfd6ac33a2.jpg',0),
(2,3,'uploads/galerie/3/slide_69adfd6acc6c6.jpeg',0),
(3,3,'uploads/galerie/3/slide_69adfd6acdc62.jpeg',0),
(4,3,'uploads/galerie/3/slide_69ae0ada4719b.jpeg',0),
(5,3,'uploads/galerie/3/slide_69ae0ada4d873.jpeg',0);
/*!40000 ALTER TABLE `images_voitures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `locations`
--

DROP TABLE IF EXISTS `locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `locations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `voiture_id` int(11) NOT NULL,
  `date_debut` date NOT NULL,
  `date_fin` date NOT NULL,
  `cout_total` decimal(10,2) NOT NULL,
  `statut` varchar(50) DEFAULT 'En cours',
  `date_location` timestamp NULL DEFAULT current_timestamp(),
  `statut_paiement` enum('En attente','Payé') DEFAULT 'En attente',
  PRIMARY KEY (`id`),
  KEY `client_id` (`client_id`),
  KEY `voiture_id` (`voiture_id`),
  CONSTRAINT `locations_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`),
  CONSTRAINT `locations_ibfk_2` FOREIGN KEY (`voiture_id`) REFERENCES `voitures` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locations`
--

LOCK TABLES `locations` WRITE;
/*!40000 ALTER TABLE `locations` DISABLE KEYS */;
INSERT INTO `locations` VALUES
(1,1,3,'2026-03-08','2026-03-25',12500.00,'En cours','2026-03-08 23:52:28','En attente');
/*!40000 ALTER TABLE `locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `partenaires`
--

DROP TABLE IF EXISTS `partenaires`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `partenaires` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `contact` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `partenaires`
--

LOCK TABLES `partenaires` WRITE;
/*!40000 ALTER TABLE `partenaires` DISABLE KEYS */;
INSERT INTO `partenaires` VALUES
(1,'Auto Pro Dakar',NULL);
/*!40000 ALTER TABLE `partenaires` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nom_complet` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'admin','admin123','Administrateur Omega');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `voitures`
--

DROP TABLE IF EXISTS `voitures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `voitures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `marque` varchar(50) NOT NULL,
  `modele` varchar(50) NOT NULL,
  `annee` int(11) DEFAULT NULL,
  `prix_journalier` decimal(10,2) DEFAULT NULL,
  `statut` varchar(20) DEFAULT 'Disponible',
  `image_url` varchar(255) DEFAULT NULL,
  `partenaire_id` int(11) DEFAULT NULL,
  `date_ajout` timestamp NULL DEFAULT current_timestamp(),
  `type_usage` enum('Location','Vente') DEFAULT 'Location',
  `date_dernier_entretien` date DEFAULT NULL,
  `kilometrage` int(11) DEFAULT 0,
  `km_actuel` int(11) DEFAULT 0,
  `km_prochaine_vidange` int(11) DEFAULT 10000,
  `derniere_revision` date DEFAULT NULL,
  `immatriculation` varchar(20) DEFAULT NULL,
  `clics_whatsapp` int(11) DEFAULT 0,
  `boite_vitesse` enum('Manuelle','Automatique') DEFAULT 'Automatique',
  `nb_places` int(11) DEFAULT 5,
  `carburant` enum('Essence','Diesel','Hybride','Electrique') DEFAULT 'Diesel',
  PRIMARY KEY (`id`),
  KEY `partenaire_id` (`partenaire_id`),
  KEY `idx_usage` (`type_usage`),
  KEY `idx_statut` (`statut`),
  CONSTRAINT `voitures_ibfk_1` FOREIGN KEY (`partenaire_id`) REFERENCES `partenaires` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `voitures`
--

LOCK TABLES `voitures` WRITE;
/*!40000 ALTER TABLE `voitures` DISABLE KEYS */;
INSERT INTO `voitures` VALUES
(3,'Toyota ','Rav 4',NULL,15000.00,'Loué','uploads/principal_1773009512.jpeg',NULL,'2026-03-08 22:38:32','Location',NULL,0,0,10000,NULL,'Dk1',0,'Automatique',5,'Diesel');
/*!40000 ALTER TABLE `voitures` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-22 16:35:43
