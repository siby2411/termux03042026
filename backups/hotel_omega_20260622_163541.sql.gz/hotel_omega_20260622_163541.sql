/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: hotel_omega
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `chambres`
--

DROP TABLE IF EXISTS `chambres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chambres` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numero` varchar(10) NOT NULL,
  `type` enum('Simple','Double','Suite','Présidentielle') DEFAULT 'Simple',
  `etage` int(11) DEFAULT 1,
  `prix_nuit` decimal(10,2) NOT NULL,
  `capacite` int(11) DEFAULT 1,
  `statut` enum('Disponible','Occupée','Maintenance','Réservée') DEFAULT 'Disponible',
  `description` text DEFAULT NULL,
  `equipements` text DEFAULT NULL,
  `prix` decimal(10,2) DEFAULT 0.00,
  PRIMARY KEY (`id`),
  UNIQUE KEY `numero` (`numero`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chambres`
--

LOCK TABLES `chambres` WRITE;
/*!40000 ALTER TABLE `chambres` DISABLE KEYS */;
INSERT INTO `chambres` VALUES
(1,'101','Simple',1,25000.00,1,'Disponible','Chambre simple avec lit 140cm, salle de bain privative, clim','TV, Wi-Fi, Clim',0.00),
(2,'102','Simple',1,25000.00,1,'Disponible','Chambre simple avec lit 140cm, salle de bain privative, clim','TV, Wi-Fi, Clim',0.00),
(3,'103','Simple',1,25000.00,1,'Disponible','Chambre simple avec vue sur jardin','TV, Wi-Fi, Clim, Balcon',0.00),
(4,'201','Double',1,45000.00,2,'Disponible','Chambre double avec lit 160cm, salle de bain, balcon','TV, Wi-Fi, Clim, Mini-bar',0.00),
(5,'202','Double',1,45000.00,2,'Disponible','Chambre double avec vue sur piscine','TV, Wi-Fi, Clim, Mini-bar',0.00),
(6,'203','Double',1,45000.00,2,'Disponible','Chambre double familiale','TV, Wi-Fi, Clim, Canapé-lit',0.00),
(7,'301','Suite',1,85000.00,4,'Disponible','Suite familiale avec salon, deux chambres','TV, Wi-Fi, Clim, Salon, Cuisine',0.00),
(8,'302','Suite',1,85000.00,4,'Disponible','Suite avec jacuzzi, vue mer','TV, Wi-Fi, Clim, Jacuzzi, Terrasse',0.00),
(9,'401','Présidentielle',1,150000.00,6,'Disponible','Suite présidentielle avec terrasse, jacuzzi','TV, Wi-Fi, Clim, Jacuzzi, Salon, Salle à manger',0.00);
/*!40000 ALTER TABLE `chambres` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charges`
--

DROP TABLE IF EXISTS `charges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `charges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(255) DEFAULT NULL,
  `montant` decimal(10,2) DEFAULT NULL,
  `categorie` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `date_charge` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charges`
--

LOCK TABLES `charges` WRITE;
/*!40000 ALTER TABLE `charges` DISABLE KEYS */;
INSERT INTO `charges` VALUES
(1,'Électricité',125000.00,'Électricité',NULL,'2026-03-30 15:28:32','2026-01-05'),
(2,'Eau',45000.00,'Eau',NULL,'2026-03-30 15:28:32','2026-01-10'),
(3,'Internet',35000.00,'Internet',NULL,'2026-03-30 15:28:32','2026-01-15'),
(4,'Électricité',138000.00,'Électricité',NULL,'2026-03-30 15:28:32','2026-02-05'),
(5,'Eau',48000.00,'Eau',NULL,'2026-03-30 15:28:32','2026-02-10'),
(6,'Internet',35000.00,'Internet',NULL,'2026-03-30 15:28:32','2026-02-15'),
(7,'Électricité',142000.00,'Électricité',NULL,'2026-03-30 15:28:32','2026-03-05'),
(8,'Eau',52000.00,'Eau',NULL,'2026-03-30 15:28:32','2026-03-10'),
(9,'Internet',35000.00,'Internet',NULL,'2026-03-30 15:28:32','2026-03-15'),
(10,'Fournitures',28000.00,'Fournitures',NULL,'2026-03-30 15:28:32','2026-01-20'),
(11,'Fournitures',32000.00,'Fournitures',NULL,'2026-03-30 15:28:32','2026-02-20'),
(12,'Fournitures',35000.00,'Fournitures',NULL,'2026-03-30 15:28:32','2026-03-20'),
(13,'Entretien',75000.00,'Entretien',NULL,'2026-03-30 15:28:32','2026-01-25'),
(14,'Entretien',65000.00,'Entretien',NULL,'2026-03-30 15:28:32','2026-02-25'),
(15,'Entretien',85000.00,'Entretien',NULL,'2026-03-30 15:28:32','2026-03-25');
/*!40000 ALTER TABLE `charges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `adresse` text DEFAULT NULL,
  `ville` varchar(100) DEFAULT NULL,
  `pays` varchar(50) DEFAULT 'Sénégal',
  `nationalite` varchar(60) DEFAULT NULL,
  `num_piece` varchar(50) DEFAULT NULL,
  `date_inscription` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` VALUES
(1,'DIOP','Mamadou','mamadou.diop@email.sn','77 123 45 67',NULL,'Dakar','Sénégal',NULL,NULL,'2026-03-30 15:28:32'),
(2,'FALL','Aïcha','aicha.fall@email.sn','78 234 56 78',NULL,'Thiès','Sénégal',NULL,NULL,'2026-03-30 15:28:32'),
(3,'NDIAYE','Oumar','oumar.ndiaye@email.sn','76 345 67 89',NULL,'Saint-Louis','Sénégal',NULL,NULL,'2026-03-30 15:28:32'),
(4,'SOW','Fatou','fatou.sow@email.sn','77 456 78 90',NULL,'Dakar','Sénégal',NULL,NULL,'2026-03-30 15:28:32'),
(5,'GUEYE','Ibrahima','ibrahima.gueye@email.sn','78 567 89 01',NULL,'Touba','Sénégal',NULL,NULL,'2026-03-30 15:28:32'),
(6,'DIALLO','Aminata','aminata.diallo@email.sn','76 678 90 12',NULL,'Kaolack','Sénégal',NULL,NULL,'2026-03-30 15:28:32'),
(7,'BA','Cheikh','cheikh.ba@email.sn','77 789 01 23',NULL,'Ziguinchor','Sénégal',NULL,NULL,'2026-03-30 15:28:32'),
(8,'SARR','Ndeye','ndeye.sarr@email.sn','78 890 12 34',NULL,'Dakar','Sénégal',NULL,NULL,'2026-03-30 15:28:32'),
(9,'CISSÉ','Moussa','moussa.cisse@email.sn','76 901 23 45',NULL,'Thiès','Sénégal',NULL,NULL,'2026-03-30 15:28:32'),
(10,'KANE','Rokhaya','rokhaya.kane@email.sn','77 012 34 56',NULL,'Saint-Louis','Sénégal',NULL,NULL,'2026-03-30 15:28:32');
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paie`
--

DROP TABLE IF EXISTS `paie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `paie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `personnel_id` int(11) NOT NULL,
  `mois` int(11) NOT NULL,
  `annee` int(11) NOT NULL,
  `salaire_brut` decimal(10,2) NOT NULL,
  `prime` decimal(10,2) DEFAULT 0.00,
  `deduction` decimal(10,2) DEFAULT 0.00,
  `salaire_net` decimal(10,2) DEFAULT NULL,
  `paye` tinyint(1) DEFAULT 0,
  `date_paiement` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_paie` (`personnel_id`,`mois`,`annee`),
  CONSTRAINT `paie_ibfk_1` FOREIGN KEY (`personnel_id`) REFERENCES `personnel` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paie`
--

LOCK TABLES `paie` WRITE;
/*!40000 ALTER TABLE `paie` DISABLE KEYS */;
INSERT INTO `paie` VALUES
(1,1,1,2026,150000.00,77886.00,29582.00,198304.00,1,NULL),
(2,1,2,2026,150000.00,30995.00,24900.00,156095.00,1,NULL),
(3,1,3,2026,150000.00,45965.00,22894.00,173071.00,0,NULL),
(4,2,1,2026,100000.00,39757.00,20231.00,119526.00,1,NULL),
(5,2,2,2026,100000.00,73220.00,19692.00,153528.00,1,NULL),
(6,2,3,2026,100000.00,66701.00,30534.00,136167.00,1,NULL),
(7,3,1,2026,120000.00,26275.00,33646.00,112629.00,1,NULL),
(8,3,2,2026,120000.00,47271.00,26923.00,140348.00,1,NULL),
(9,3,3,2026,120000.00,42719.00,30366.00,132353.00,0,NULL),
(10,4,1,2026,180000.00,75244.00,27778.00,227466.00,1,NULL),
(11,4,2,2026,180000.00,79553.00,28816.00,230737.00,1,NULL),
(12,4,3,2026,180000.00,47840.00,32300.00,195540.00,0,NULL);
/*!40000 ALTER TABLE `paie` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paies`
--

DROP TABLE IF EXISTS `paies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `paies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `personnel_id` int(11) DEFAULT NULL,
  `montant` decimal(10,2) DEFAULT NULL,
  `date_paiement` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `personnel_id` (`personnel_id`),
  CONSTRAINT `paies_ibfk_1` FOREIGN KEY (`personnel_id`) REFERENCES `personnel` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paies`
--

LOCK TABLES `paies` WRITE;
/*!40000 ALTER TABLE `paies` DISABLE KEYS */;
/*!40000 ALTER TABLE `paies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personnel`
--

DROP TABLE IF EXISTS `personnel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `personnel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) DEFAULT NULL,
  `prenom` varchar(100) DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `poste` varchar(100) DEFAULT NULL,
  `salaire_base` decimal(10,2) DEFAULT NULL,
  `date_embauche` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personnel`
--

LOCK TABLES `personnel` WRITE;
/*!40000 ALTER TABLE `personnel` DISABLE KEYS */;
INSERT INTO `personnel` VALUES
(1,'SARR','Papa','77 111 22 33','Réceptionniste',150000.00,'2023-01-15'),
(2,'GUEYE','Mariama','78 222 33 44','Femme de ménage',100000.00,'2023-02-01'),
(3,'DIALLO','Ibrahima','76 333 44 55','Garde',120000.00,'2023-03-10'),
(4,'NDIAYE','Aminata','77 444 55 66','Gouvernante',180000.00,'2022-11-20');
/*!40000 ALTER TABLE `personnel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recettes`
--

DROP TABLE IF EXISTS `recettes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `recettes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reservation_id` int(11) DEFAULT NULL,
  `montant` decimal(12,2) NOT NULL,
  `date_recette` date NOT NULL,
  `mode_paiement` varchar(50) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `reservation_id` (`reservation_id`),
  CONSTRAINT `recettes_ibfk_1` FOREIGN KEY (`reservation_id`) REFERENCES `reservations` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recettes`
--

LOCK TABLES `recettes` WRITE;
/*!40000 ALTER TABLE `recettes` DISABLE KEYS */;
INSERT INTO `recettes` VALUES
(1,1,50000.00,'2026-01-05','Virement',NULL,'2026-03-30 15:28:32'),
(2,2,50000.00,'2026-01-10','Espèces',NULL,'2026-03-30 15:28:32'),
(3,3,75000.00,'2026-01-15','Espèces',NULL,'2026-03-30 15:28:32'),
(4,4,50000.00,'2026-01-20','Carte',NULL,'2026-03-30 15:28:32'),
(5,5,90000.00,'2026-01-25','Carte',NULL,'2026-03-30 15:28:32'),
(6,6,50000.00,'2026-02-01','Espèces',NULL,'2026-03-30 15:28:32'),
(7,7,75000.00,'2026-02-05','Carte',NULL,'2026-03-30 15:28:32'),
(8,8,75000.00,'2026-02-10','Espèces',NULL,'2026-03-30 15:28:32'),
(9,9,75000.00,'2026-02-15','Carte',NULL,'2026-03-30 15:28:32'),
(10,10,135000.00,'2026-02-20','Carte',NULL,'2026-03-30 15:28:32'),
(11,11,300000.00,'2026-02-25','Mobile Money',NULL,'2026-03-30 15:28:32'),
(12,12,50000.00,'2026-03-01','Mobile Money',NULL,'2026-03-30 15:28:32'),
(13,13,135000.00,'2026-03-05','Espèces',NULL,'2026-03-30 15:28:32'),
(14,14,75000.00,'2026-03-10','Espèces',NULL,'2026-03-30 15:28:32'),
(15,15,100000.00,'2026-03-15','Carte',NULL,'2026-03-30 15:28:32'),
(16,16,135000.00,'2026-03-20','Virement',NULL,'2026-03-30 15:28:32'),
(17,17,135000.00,'2026-03-25','Espèces',NULL,'2026-03-30 15:28:32');
/*!40000 ALTER TABLE `recettes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recettes_journalieres`
--

DROP TABLE IF EXISTS `recettes_journalieres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `recettes_journalieres` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `montant_total` decimal(12,2) DEFAULT 0.00,
  `nb_reservations` int(11) DEFAULT 0,
  `nb_nuits` int(11) DEFAULT 0,
  `taux_occupation` decimal(5,2) DEFAULT 0.00,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `date` (`date`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recettes_journalieres`
--

LOCK TABLES `recettes_journalieres` WRITE;
/*!40000 ALTER TABLE `recettes_journalieres` DISABLE KEYS */;
INSERT INTO `recettes_journalieres` VALUES
(1,'2026-01-05',50000.00,1,0,11.11,'2026-03-30 15:28:32'),
(2,'2026-01-10',50000.00,1,0,11.11,'2026-03-30 15:28:32'),
(3,'2026-01-15',75000.00,1,0,11.11,'2026-03-30 15:28:32'),
(4,'2026-01-20',50000.00,1,0,11.11,'2026-03-30 15:28:32'),
(5,'2026-01-25',90000.00,1,0,11.11,'2026-03-30 15:28:32'),
(6,'2026-02-01',50000.00,1,0,11.11,'2026-03-30 15:28:32'),
(7,'2026-02-05',75000.00,1,0,11.11,'2026-03-30 15:28:32'),
(8,'2026-02-10',75000.00,1,0,11.11,'2026-03-30 15:28:32'),
(9,'2026-02-15',75000.00,1,0,11.11,'2026-03-30 15:28:32'),
(10,'2026-02-20',135000.00,1,0,11.11,'2026-03-30 15:28:32'),
(11,'2026-02-25',300000.00,1,0,11.11,'2026-03-30 15:28:32'),
(12,'2026-03-01',50000.00,1,0,11.11,'2026-03-30 15:28:32'),
(13,'2026-03-05',135000.00,1,0,11.11,'2026-03-30 15:28:32'),
(14,'2026-03-10',75000.00,1,0,11.11,'2026-03-30 15:28:32'),
(15,'2026-03-15',100000.00,1,0,11.11,'2026-03-30 15:28:32'),
(16,'2026-03-20',135000.00,1,0,11.11,'2026-03-30 15:28:32'),
(17,'2026-03-25',135000.00,1,0,11.11,'2026-03-30 15:28:32');
/*!40000 ALTER TABLE `recettes_journalieres` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservations`
--

DROP TABLE IF EXISTS `reservations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `reservations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `chambre_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `date_arrivee` date NOT NULL,
  `date_depart` date NOT NULL,
  `nb_nuits` int(11) DEFAULT NULL,
  `prix_total` decimal(10,2) DEFAULT NULL,
  `statut` enum('Confirmée','En cours','Terminée','Annulée') DEFAULT 'Confirmée',
  `mode_paiement` enum('Espèces','Carte','Virement','Mobile Money') DEFAULT 'Espèces',
  `notes` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `montant_recu` decimal(12,2) DEFAULT 0.00,
  `date_paiement` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `chambre_id` (`chambre_id`),
  KEY `client_id` (`client_id`),
  CONSTRAINT `reservations_ibfk_1` FOREIGN KEY (`chambre_id`) REFERENCES `chambres` (`id`),
  CONSTRAINT `reservations_ibfk_2` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservations`
--

LOCK TABLES `reservations` WRITE;
/*!40000 ALTER TABLE `reservations` DISABLE KEYS */;
INSERT INTO `reservations` VALUES
(1,1,2,'2026-01-05','2026-01-07',2,50000.00,'Terminée','Virement',NULL,'2026-03-30 15:28:32',0.00,NULL),
(2,3,7,'2026-01-10','2026-01-12',2,50000.00,'Terminée','Espèces',NULL,'2026-03-30 15:28:32',0.00,NULL),
(3,2,2,'2026-01-15','2026-01-18',3,75000.00,'Terminée','Espèces',NULL,'2026-03-30 15:28:32',0.00,NULL),
(4,2,2,'2026-01-20','2026-01-22',2,50000.00,'Terminée','Carte',NULL,'2026-03-30 15:28:32',0.00,NULL),
(5,5,9,'2026-01-25','2026-01-27',2,90000.00,'Terminée','Carte',NULL,'2026-03-30 15:28:32',0.00,NULL),
(6,1,8,'2026-02-01','2026-02-03',2,50000.00,'Terminée','Espèces',NULL,'2026-03-30 15:28:32',0.00,NULL),
(7,3,2,'2026-02-05','2026-02-08',3,75000.00,'Terminée','Carte',NULL,'2026-03-30 15:28:32',0.00,NULL),
(8,1,5,'2026-02-10','2026-02-13',3,75000.00,'Terminée','Espèces',NULL,'2026-03-30 15:28:32',0.00,NULL),
(9,3,4,'2026-02-15','2026-02-18',3,75000.00,'Terminée','Carte',NULL,'2026-03-30 15:28:32',0.00,NULL),
(10,5,7,'2026-02-20','2026-02-23',3,135000.00,'Terminée','Carte',NULL,'2026-03-30 15:28:32',0.00,NULL),
(11,9,2,'2026-02-25','2026-02-27',2,300000.00,'Terminée','Mobile Money',NULL,'2026-03-30 15:28:32',0.00,NULL),
(12,3,10,'2026-03-01','2026-03-03',2,50000.00,'Terminée','Mobile Money',NULL,'2026-03-30 15:28:32',0.00,NULL),
(13,4,9,'2026-03-05','2026-03-08',3,135000.00,'Terminée','Espèces',NULL,'2026-03-30 15:28:32',0.00,NULL),
(14,3,2,'2026-03-10','2026-03-13',3,75000.00,'Terminée','Espèces',NULL,'2026-03-30 15:28:32',0.00,NULL),
(15,3,9,'2026-03-15','2026-03-19',4,100000.00,'Terminée','Carte',NULL,'2026-03-30 15:28:32',0.00,NULL),
(16,5,3,'2026-03-20','2026-03-23',3,135000.00,'Terminée','Virement',NULL,'2026-03-30 15:28:32',0.00,NULL),
(17,6,7,'2026-03-25','2026-03-28',3,135000.00,'Terminée','Espèces',NULL,'2026-03-30 15:28:32',0.00,NULL);
/*!40000 ALTER TABLE `reservations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `utilisateurs_hotel`
--

DROP TABLE IF EXISTS `utilisateurs_hotel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `utilisateurs_hotel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(20) DEFAULT 'user',
  `actif` tinyint(1) DEFAULT 1,
  `date_creation` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `utilisateurs_hotel`
--

LOCK TABLES `utilisateurs_hotel` WRITE;
/*!40000 ALTER TABLE `utilisateurs_hotel` DISABLE KEYS */;
INSERT INTO `utilisateurs_hotel` VALUES
(2,'admin','$2y$10$Ew.Y/iV0C0b7gM6rM1C.J.8XjPqV6s1lG7fL/fNf2Ff2Ff2Ff2Ff2','admin',1,'2026-03-30 14:35:23');
/*!40000 ALTER TABLE `utilisateurs_hotel` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-22 16:35:54
