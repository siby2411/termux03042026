/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: centrediop
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `actes_medicaux`
--

DROP TABLE IF EXISTS `actes_medicaux`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `actes_medicaux` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code_acte` varchar(20) NOT NULL,
  `libelle` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `categorie` enum('consultation','soin','examen','vaccination','chirurgie') NOT NULL,
  `prix_consultation` decimal(10,2) DEFAULT 0.00,
  `prix_traitement` decimal(10,2) DEFAULT 0.00,
  `duree_estimee` int(11) DEFAULT NULL COMMENT 'Durée en minutes',
  `service_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code_acte` (`code_acte`),
  KEY `service_id` (`service_id`),
  CONSTRAINT `actes_medicaux_ibfk_1` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `actes_medicaux`
--

LOCK TABLES `actes_medicaux` WRITE;
/*!40000 ALTER TABLE `actes_medicaux` DISABLE KEYS */;
INSERT INTO `actes_medicaux` VALUES
(1,'CONS-GEN','Consultation générale',NULL,'consultation',5000.00,5000.00,NULL,NULL,'2026-03-12 12:54:06'),
(2,'CONS-PED','Consultation pédiatrique',NULL,'consultation',6000.00,6000.00,NULL,NULL,'2026-03-12 12:54:06'),
(3,'CONS-DENT','Consultation dentaire',NULL,'consultation',7000.00,7000.00,NULL,NULL,'2026-03-12 12:54:06'),
(4,'CONS-GYN','Consultation gynécologique',NULL,'consultation',8000.00,8000.00,NULL,NULL,'2026-03-12 12:54:06'),
(5,'SOIN-PAN','Pansement simple',NULL,'soin',0.00,3000.00,NULL,NULL,'2026-03-12 12:54:06'),
(6,'SOIN-COMP','Pansement complexe',NULL,'soin',0.00,8000.00,NULL,NULL,'2026-03-12 12:54:06'),
(7,'VAC-ROU','Vaccin rougeole',NULL,'vaccination',0.00,5000.00,NULL,NULL,'2026-03-12 12:54:06'),
(8,'VAC-DTP','Vaccin DTP',NULL,'vaccination',0.00,6000.00,NULL,NULL,'2026-03-12 12:54:06'),
(9,'EXAM-ECHO','Échographie',NULL,'examen',0.00,15000.00,NULL,NULL,'2026-03-12 12:54:06'),
(10,'EXAM-RADIO','Radiographie',NULL,'examen',0.00,10000.00,NULL,NULL,'2026-03-12 12:54:06'),
(11,'CONS-CARD','Consultation cardiologie',NULL,'consultation',15000.00,10000.00,NULL,8,'2026-03-13 03:11:01'),
(12,'CONS-OPHT','Consultation ophtalmologie',NULL,'consultation',12000.00,8000.00,NULL,9,'2026-03-13 03:11:01'),
(13,'CONS-DIAB','Consultation diabétologie',NULL,'consultation',13000.00,9000.00,NULL,10,'2026-03-13 03:11:01'),
(14,'CONS-NEURO','Consultation neurologie',NULL,'consultation',18000.00,12000.00,NULL,11,'2026-03-13 03:11:01'),
(15,'CONS-DERM','Consultation dermatologie',NULL,'consultation',11000.00,7000.00,NULL,12,'2026-03-13 03:11:01'),
(16,'ECHO-CARD','Échographie cardiaque',NULL,'examen',0.00,35000.00,NULL,8,'2026-03-13 03:11:01'),
(17,'ECG','Électrocardiogramme',NULL,'examen',0.00,15000.00,NULL,8,'2026-03-13 03:11:01'),
(18,'FOND-OEIL','Fond d\'oeil',NULL,'examen',0.00,12000.00,NULL,9,'2026-03-13 03:11:01'),
(19,'TONO','Tonométrie',NULL,'examen',0.00,8000.00,NULL,9,'2026-03-13 03:11:01'),
(20,'HEMOGLOBINE','Hémoglobine glyquée',NULL,'examen',0.00,10000.00,NULL,10,'2026-03-13 03:11:01'),
(21,'EEG','Électroencéphalogramme',NULL,'examen',0.00,25000.00,NULL,11,'2026-03-13 03:11:01'),
(22,'BIOPSIE','Biopsie cutanée',NULL,'examen',0.00,20000.00,NULL,12,'2026-03-13 03:11:01'),
(23,'VACCIN-CARD','Vaccin anti-grippal',NULL,'vaccination',0.00,5000.00,NULL,NULL,'2026-03-13 03:11:01'),
(24,'VACCIN-COVID','Vaccin COVID-19',NULL,'vaccination',0.00,0.00,NULL,NULL,'2026-03-13 03:11:01'),
(25,'SOIN-PLAIE','Pansement plaie complexe',NULL,'soin',0.00,15000.00,NULL,NULL,'2026-03-13 03:11:01'),
(26,'SUTURE','Suture plaie',NULL,'chirurgie',0.00,25000.00,NULL,NULL,'2026-03-13 03:11:01');
/*!40000 ALTER TABLE `actes_medicaux` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendance`
--

DROP TABLE IF EXISTS `attendance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `attendance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `doctor_id` int(11) NOT NULL,
  `check_in` datetime DEFAULT NULL,
  `check_out` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `doctor_id` (`doctor_id`),
  CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendance`
--

LOCK TABLES `attendance` WRITE;
/*!40000 ALTER TABLE `attendance` DISABLE KEYS */;
INSERT INTO `attendance` VALUES
(1,1,'2026-03-12 08:00:00','2026-03-12 17:00:00','2026-03-12 10:42:50'),
(2,2,'2026-03-12 09:00:00','2026-03-12 18:00:00','2026-03-12 10:42:50'),
(3,3,'2026-03-12 08:30:00',NULL,'2026-03-12 10:42:50');
/*!40000 ALTER TABLE `attendance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `batiments`
--

DROP TABLE IF EXISTS `batiments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `batiments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batiments`
--

LOCK TABLES `batiments` WRITE;
/*!40000 ALTER TABLE `batiments` DISABLE KEYS */;
INSERT INTO `batiments` VALUES
(1,'Bâtiment Principal A','Bâtiment principal - Accueil et administrations','2026-03-14 00:40:09'),
(2,'Bâtiment Principal B','Bâtiment principal - Consultations générales','2026-03-14 00:40:09'),
(3,'Pavillon Pédiatrie','Pavillon des enfants','2026-03-14 00:40:09'),
(4,'Pavillon Mère-Enfant','Gynécologie et obstétrique','2026-03-14 00:40:09'),
(5,'Annexe Technique','Radiologie et laboratoires','2026-03-14 00:40:09');
/*!40000 ALTER TABLE `batiments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `caissiers_affectation`
--

DROP TABLE IF EXISTS `caissiers_affectation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `caissiers_affectation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `date_affectation` date NOT NULL,
  `salle_principale` int(11) DEFAULT NULL,
  `actif` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `service_id` (`service_id`),
  CONSTRAINT `caissiers_affectation_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `caissiers_affectation_ibfk_2` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `caissiers_affectation`
--

LOCK TABLES `caissiers_affectation` WRITE;
/*!40000 ALTER TABLE `caissiers_affectation` DISABLE KEYS */;
/*!40000 ALTER TABLE `caissiers_affectation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories_materiel`
--

DROP TABLE IF EXISTS `categories_materiel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories_materiel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories_materiel`
--

LOCK TABLES `categories_materiel` WRITE;
/*!40000 ALTER TABLE `categories_materiel` DISABLE KEYS */;
INSERT INTO `categories_materiel` VALUES
(1,'Équipement médical',NULL,'2026-03-15 01:47:18'),
(2,'Mobilier',NULL,'2026-03-15 01:47:18'),
(3,'Informatique',NULL,'2026-03-15 01:47:18'),
(4,'Consommables',NULL,'2026-03-15 01:47:18'),
(5,'Instrumentation',NULL,'2026-03-15 01:47:18'),
(6,'Imagerie',NULL,'2026-03-15 01:47:18'),
(7,'Laboratoire',NULL,'2026-03-15 01:47:18'),
(8,'Urgence',NULL,'2026-03-15 01:47:18');
/*!40000 ALTER TABLE `categories_materiel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consultation_actes`
--

DROP TABLE IF EXISTS `consultation_actes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `consultation_actes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `consultation_id` int(11) NOT NULL,
  `acte_id` int(11) NOT NULL,
  `quantite` int(11) DEFAULT 1,
  `prix_applique` decimal(10,2) NOT NULL,
  `observations` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `consultation_id` (`consultation_id`),
  KEY `acte_id` (`acte_id`),
  CONSTRAINT `consultation_actes_ibfk_1` FOREIGN KEY (`consultation_id`) REFERENCES `consultations` (`id`),
  CONSTRAINT `consultation_actes_ibfk_2` FOREIGN KEY (`acte_id`) REFERENCES `actes_medicaux` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consultation_actes`
--

LOCK TABLES `consultation_actes` WRITE;
/*!40000 ALTER TABLE `consultation_actes` DISABLE KEYS */;
INSERT INTO `consultation_actes` VALUES
(1,1,19,1,0.00,NULL),
(2,2,4,1,8000.00,NULL),
(3,3,5,1,0.00,NULL),
(4,4,9,1,0.00,NULL),
(5,5,22,1,0.00,NULL),
(6,6,18,1,0.00,NULL),
(7,7,14,1,18000.00,NULL),
(8,8,19,1,0.00,NULL),
(9,9,19,1,0.00,NULL),
(10,10,11,1,15000.00,NULL),
(11,11,2,1,6000.00,NULL),
(12,12,23,1,0.00,NULL),
(13,13,2,1,6000.00,NULL),
(14,14,6,1,0.00,NULL),
(15,15,4,1,8000.00,NULL),
(16,16,8,1,0.00,NULL),
(17,17,21,1,0.00,NULL),
(18,18,20,1,0.00,NULL),
(19,19,7,1,0.00,NULL),
(20,20,1,1,5000.00,NULL),
(21,21,14,1,18000.00,NULL),
(22,22,13,1,13000.00,NULL),
(23,23,13,1,13000.00,NULL),
(24,24,25,1,0.00,NULL),
(25,25,15,1,11000.00,NULL),
(26,26,20,1,0.00,NULL),
(27,27,11,1,15000.00,NULL),
(28,28,13,1,13000.00,NULL),
(29,29,25,1,0.00,NULL),
(30,30,12,1,12000.00,NULL),
(31,31,12,1,12000.00,NULL),
(32,32,18,1,0.00,NULL),
(33,33,3,1,7000.00,NULL),
(34,34,5,1,0.00,NULL),
(35,35,3,1,7000.00,NULL),
(36,36,7,1,0.00,NULL),
(37,37,14,1,18000.00,NULL),
(38,38,14,1,18000.00,NULL),
(39,39,21,1,0.00,NULL),
(40,40,2,1,6000.00,NULL),
(41,41,3,1,7000.00,NULL),
(42,42,12,1,12000.00,NULL),
(43,43,4,1,8000.00,NULL),
(44,44,16,1,0.00,NULL),
(45,45,8,1,0.00,NULL),
(46,46,26,1,0.00,NULL),
(47,47,15,1,11000.00,NULL),
(48,48,23,1,0.00,NULL),
(49,49,24,1,0.00,NULL),
(50,50,23,1,0.00,NULL),
(51,1,1,1,5000.00,NULL),
(52,1,5,1,3000.00,NULL),
(53,51,1,1,5000.00,NULL),
(54,51,5,1,0.00,NULL),
(55,52,11,1,15000.00,NULL);
/*!40000 ALTER TABLE `consultation_actes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consultations`
--

DROP TABLE IF EXISTS `consultations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `consultations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numero_consultation` varchar(20) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `medecin_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `date_consultation` datetime NOT NULL,
  `motif_consultation` text DEFAULT NULL,
  `diagnostic` text DEFAULT NULL,
  `traitement_prescrit` text DEFAULT NULL,
  `observations` text DEFAULT NULL,
  `type_consultation` enum('normale','urgence','controle') DEFAULT 'normale',
  `statut` enum('planifiee','en_cours','terminee','annulee','attente_paiement','payee') DEFAULT 'planifiee',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `prix` decimal(10,2) DEFAULT 0.00,
  PRIMARY KEY (`id`),
  UNIQUE KEY `numero_consultation` (`numero_consultation`),
  KEY `idx_patient` (`patient_id`),
  KEY `idx_medecin` (`medecin_id`),
  KEY `idx_date` (`date_consultation`),
  KEY `idx_statut` (`statut`),
  KEY `idx_consultation_service` (`service_id`),
  KEY `idx_consultation_statut` (`statut`),
  CONSTRAINT `consultations_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`),
  CONSTRAINT `consultations_ibfk_2` FOREIGN KEY (`medecin_id`) REFERENCES `users` (`id`),
  CONSTRAINT `consultations_ibfk_3` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consultations`
--

LOCK TABLES `consultations` WRITE;
/*!40000 ALTER TABLE `consultations` DISABLE KEYS */;
INSERT INTO `consultations` VALUES
(3,'C001',1,1,1,'2026-06-11 08:00:00','Contrôle tension',NULL,NULL,NULL,'normale','terminee','2026-06-11 08:11:35',0.00),
(4,'C002',2,1,1,'2026-06-11 08:30:00','Douleurs abdo',NULL,NULL,NULL,'urgence','payee','2026-06-11 08:11:35',0.00),
(7,NULL,1,1,1,'2026-06-12 00:46:59',NULL,NULL,NULL,NULL,'normale','attente_paiement','2026-06-12 00:46:59',5000.00),
(9,NULL,1,1,1,'2026-06-12 00:50:37',NULL,NULL,NULL,NULL,'normale','en_cours','2026-06-12 00:50:37',5000.00),
(10,NULL,1,1,1,'2026-06-12 21:30:18',NULL,NULL,NULL,NULL,'normale','planifiee','2026-06-12 21:30:18',0.00),
(11,NULL,1,4,3,'2026-06-13 18:31:04','Contrôle pédiatrique habituel',NULL,NULL,NULL,'normale','en_cours','2026-06-13 18:31:04',0.00);
/*!40000 ALTER TABLE `consultations` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER after_consultation_insert
AFTER INSERT ON consultations
FOR EACH ROW
BEGIN
    INSERT INTO file_attente (token, patient_id, service_id, statut, cree_a)
    VALUES (
        LEFT(UUID(), 8), 
        NEW.patient_id, 
        NEW.service_id, 
        'en_attente', 
        NOW()
    );
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `doctors`
--

DROP TABLE IF EXISTS `doctors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `doctors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `specialty` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctors`
--

LOCK TABLES `doctors` WRITE;
/*!40000 ALTER TABLE `doctors` DISABLE KEYS */;
INSERT INTO `doctors` VALUES
(1,'Dr. Fall','Pédiatre','771234567','2026-03-12 10:42:50'),
(2,'Dr. Diop','Dentiste','772345678','2026-03-12 10:42:50'),
(3,'Dr. Sow','Gynécologue','773456789','2026-03-12 10:42:50'),
(4,'Dr. Ndiaye','Médecin Généraliste','774567890','2026-03-12 10:42:50'),
(9,'Dr. Fall','Cardiologie',NULL,'2026-06-12 21:29:53'),
(10,'Dr. Diop','Pédiatrie',NULL,'2026-06-12 21:29:53');
/*!40000 ALTER TABLE `doctors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_categories`
--

DROP TABLE IF EXISTS `document_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `document_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_categories`
--

LOCK TABLES `document_categories` WRITE;
/*!40000 ALTER TABLE `document_categories` DISABLE KEYS */;
INSERT INTO `document_categories` VALUES
(1,'Comptes rendus médicaux','Comptes rendus de consultation, d\'hospitalisation','2026-03-15 05:34:22'),
(2,'Prescriptions','Ordonnances, prescriptions médicales','2026-03-15 05:34:22'),
(3,'Comptes rendus d\'examens','Radiologies, analyses, échographies','2026-03-15 05:34:22'),
(4,'Courriers médicaux','Lettres de liaison, correspondances','2026-03-15 05:34:22'),
(5,'Administratif','Documents administratifs, formulaires','2026-03-15 05:34:22'),
(6,'Protocoles','Protocoles de soins, procédures','2026-03-15 05:34:22'),
(7,'Rapports','Rapports d\'activité, statistiques','2026-03-15 05:34:22'),
(8,'Divers','Autres documents','2026-03-15 05:34:22');
/*!40000 ALTER TABLE `document_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_notifications`
--

DROP TABLE IF EXISTS `document_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `document_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `document_id` int(11) DEFAULT NULL,
  `destinataire_id` int(11) DEFAULT NULL,
  `lu` tinyint(1) DEFAULT 0,
  `date_envoi` timestamp NULL DEFAULT current_timestamp(),
  `date_lecture` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `document_id` (`document_id`),
  KEY `destinataire_id` (`destinataire_id`),
  CONSTRAINT `document_notifications_ibfk_1` FOREIGN KEY (`document_id`) REFERENCES `documents` (`id`) ON DELETE CASCADE,
  CONSTRAINT `document_notifications_ibfk_2` FOREIGN KEY (`destinataire_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_notifications`
--

LOCK TABLES `document_notifications` WRITE;
/*!40000 ALTER TABLE `document_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `document_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents`
--

DROP TABLE IF EXISTS `documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `fichier_nom` varchar(255) NOT NULL,
  `fichier_chemin` varchar(500) NOT NULL,
  `fichier_taille` int(11) DEFAULT NULL,
  `fichier_type` varchar(100) DEFAULT NULL,
  `categorie_id` int(11) DEFAULT NULL,
  `expediteur_id` int(11) NOT NULL,
  `destinataire_service_id` int(11) DEFAULT NULL,
  `destinataire_medecin_id` int(11) DEFAULT NULL,
  `est_public` tinyint(1) DEFAULT 0,
  `date_expiration` date DEFAULT NULL,
  `statut` enum('actif','archive','supprime') DEFAULT 'actif',
  `lu` tinyint(1) DEFAULT 0,
  `date_lecture` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `categorie_id` (`categorie_id`),
  KEY `expediteur_id` (`expediteur_id`),
  KEY `destinataire_service_id` (`destinataire_service_id`),
  KEY `destinataire_medecin_id` (`destinataire_medecin_id`),
  CONSTRAINT `documents_ibfk_1` FOREIGN KEY (`categorie_id`) REFERENCES `document_categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `documents_ibfk_2` FOREIGN KEY (`expediteur_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `documents_ibfk_3` FOREIGN KEY (`destinataire_service_id`) REFERENCES `services` (`id`) ON DELETE SET NULL,
  CONSTRAINT `documents_ibfk_4` FOREIGN KEY (`destinataire_medecin_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents`
--

LOCK TABLES `documents` WRITE;
/*!40000 ALTER TABLE `documents` DISABLE KEYS */;
INSERT INTO `documents` VALUES
(1,'Gestion ',NULL,'Facture_1.pdf','uploads/documents/6a2c5cb2b5af8_Facture_1.pdf',NULL,NULL,NULL,50,NULL,NULL,0,NULL,'actif',0,NULL,'2026-06-12 19:23:30');
/*!40000 ALTER TABLE `documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dossiers_medicaux`
--

DROP TABLE IF EXISTS `dossiers_medicaux`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `dossiers_medicaux` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_id` int(11) NOT NULL,
  `antecedents_familiaux` text DEFAULT NULL,
  `habitudes_vie` text DEFAULT NULL,
  `vaccinations` text DEFAULT NULL,
  `allergies_connues` text DEFAULT NULL,
  `traitement_long_cours` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `patient_id` (`patient_id`),
  CONSTRAINT `dossiers_medicaux_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dossiers_medicaux`
--

LOCK TABLES `dossiers_medicaux` WRITE;
/*!40000 ALTER TABLE `dossiers_medicaux` DISABLE KEYS */;
INSERT INTO `dossiers_medicaux` VALUES
(1,1,NULL,NULL,NULL,NULL,NULL,'2026-03-12 12:54:09','2026-03-12 12:54:09'),
(2,2,NULL,NULL,NULL,NULL,NULL,'2026-03-12 12:54:09','2026-03-12 12:54:09'),
(3,3,NULL,NULL,NULL,NULL,NULL,'2026-03-12 12:54:09','2026-03-12 12:54:09'),
(4,4,NULL,NULL,NULL,NULL,NULL,'2026-03-12 12:54:09','2026-03-12 12:54:09'),
(5,5,NULL,NULL,NULL,NULL,NULL,'2026-03-12 12:54:09','2026-03-12 12:54:09'),
(6,7,NULL,NULL,NULL,NULL,NULL,'2026-03-13 03:11:01','2026-03-13 03:11:01'),
(7,8,NULL,NULL,NULL,NULL,NULL,'2026-03-13 03:11:01','2026-03-13 03:11:01'),
(8,9,NULL,NULL,NULL,NULL,NULL,'2026-03-13 03:11:01','2026-03-13 03:11:01'),
(9,10,NULL,NULL,NULL,NULL,NULL,'2026-03-13 03:11:01','2026-03-13 03:11:01'),
(10,11,NULL,NULL,NULL,NULL,NULL,'2026-03-13 03:11:01','2026-03-13 03:11:01'),
(11,12,NULL,NULL,NULL,NULL,NULL,'2026-03-13 03:11:01','2026-03-13 03:11:01'),
(12,13,NULL,NULL,NULL,NULL,NULL,'2026-03-13 03:11:01','2026-03-13 03:11:01'),
(13,14,NULL,NULL,NULL,NULL,NULL,'2026-03-13 03:11:01','2026-03-13 03:11:01'),
(14,15,NULL,NULL,NULL,NULL,NULL,'2026-03-13 03:11:01','2026-03-13 03:11:01'),
(15,16,NULL,NULL,NULL,NULL,NULL,'2026-03-13 03:11:01','2026-03-13 03:11:01'),
(16,17,'X',NULL,NULL,'X','Y','2026-03-14 08:34:44','2026-03-14 08:34:44'),
(17,18,'X',NULL,NULL,'X','Y','2026-03-14 09:02:21','2026-03-14 09:02:21'),
(18,19,'X',NULL,NULL,'X','Y','2026-03-14 09:03:38','2026-03-14 09:03:38'),
(19,20,'X',NULL,NULL,'X','Y','2026-03-14 09:04:08','2026-03-14 09:04:08'),
(20,21,'X',NULL,NULL,'X','Y','2026-03-14 09:04:39','2026-03-14 09:04:39'),
(21,22,'X',NULL,NULL,'X','Y','2026-03-14 09:05:09','2026-03-14 09:05:09'),
(22,23,'X',NULL,NULL,'X','Y','2026-03-14 09:07:10','2026-03-14 09:07:10'),
(23,24,'X',NULL,NULL,'X','Y','2026-03-14 09:07:41','2026-03-14 09:07:41'),
(24,25,'X',NULL,NULL,'X','Y','2026-03-14 09:08:11','2026-03-14 09:08:11'),
(25,26,'X',NULL,NULL,'X','Y','2026-03-14 09:08:42','2026-03-14 09:08:42'),
(26,27,'X',NULL,NULL,'X','Y','2026-03-14 09:10:24','2026-03-14 09:10:24'),
(27,28,'X',NULL,NULL,'X','Y','2026-03-14 09:10:55','2026-03-14 09:10:55'),
(28,29,'X',NULL,NULL,'X','Y','2026-03-14 09:11:25','2026-03-14 09:11:25'),
(29,30,'X',NULL,NULL,'X','Y','2026-03-14 09:11:56','2026-03-14 09:11:56'),
(30,32,NULL,NULL,NULL,NULL,NULL,'2026-03-15 03:23:48','2026-03-15 03:23:48'),
(31,33,NULL,NULL,NULL,NULL,NULL,'2026-03-15 03:23:48','2026-03-15 03:23:48'),
(32,34,NULL,NULL,NULL,NULL,NULL,'2026-03-15 03:23:48','2026-03-15 03:23:48'),
(33,35,NULL,NULL,NULL,NULL,NULL,'2026-03-15 03:23:48','2026-03-15 03:23:48'),
(34,36,NULL,NULL,NULL,NULL,NULL,'2026-03-15 03:23:48','2026-03-15 03:23:48'),
(35,37,NULL,NULL,NULL,NULL,NULL,'2026-03-15 03:23:48','2026-03-15 03:23:48'),
(36,38,NULL,NULL,NULL,NULL,NULL,'2026-03-15 03:23:48','2026-03-15 03:23:48');
/*!40000 ALTER TABLE `dossiers_medicaux` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `factures`
--

DROP TABLE IF EXISTS `factures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `factures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom_patient` varchar(255) DEFAULT NULL,
  `montant` decimal(10,2) DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT current_timestamp(),
  `consultation_id` int(11) DEFAULT NULL,
  `statut_paiement` enum('en_attente','payee') DEFAULT 'en_attente',
  PRIMARY KEY (`id`),
  KEY `fk_cons_fact` (`consultation_id`),
  CONSTRAINT `fk_cons_fact` FOREIGN KEY (`consultation_id`) REFERENCES `consultations` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `factures`
--

LOCK TABLES `factures` WRITE;
/*!40000 ALTER TABLE `factures` DISABLE KEYS */;
INSERT INTO `factures` VALUES
(1,'Diop Mamadou',0.00,'2026-06-11 08:21:10',3,'en_attente');
/*!40000 ALTER TABLE `factures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_attente`
--

DROP TABLE IF EXISTS `file_attente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `file_attente` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` varchar(20) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `departement` varchar(50) DEFAULT NULL,
  `priorite` enum('normal','senior','urgence') DEFAULT 'normal',
  `statut` enum('en_attente','appele','en_consultation','termine') DEFAULT 'en_attente',
  `cree_a` timestamp NULL DEFAULT current_timestamp(),
  `appele_a` datetime DEFAULT NULL,
  `commence_a` datetime DEFAULT NULL,
  `termine_a` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`),
  KEY `patient_id` (`patient_id`),
  KEY `idx_service` (`service_id`),
  KEY `idx_statut` (`statut`),
  CONSTRAINT `file_attente_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`),
  CONSTRAINT `file_attente_ibfk_2` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_attente`
--

LOCK TABLES `file_attente` WRITE;
/*!40000 ALTER TABLE `file_attente` DISABLE KEYS */;
INSERT INTO `file_attente` VALUES
(1,'ba21c1ea',1,1,NULL,'normal','en_attente','2026-06-12 00:50:37',NULL,NULL,NULL),
(2,'e8b97f29',1,1,NULL,'normal','en_attente','2026-06-12 21:30:18',NULL,NULL,NULL),
(3,'09708371',1,3,NULL,'normal','en_attente','2026-06-13 18:31:04',NULL,NULL,NULL);
/*!40000 ALTER TABLE `file_attente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fournisseurs`
--

DROP TABLE IF EXISTS `fournisseurs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fournisseurs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(200) NOT NULL,
  `contact` varchar(100) DEFAULT NULL,
  `telephone` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `adresse` text DEFAULT NULL,
  `specialite` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fournisseurs`
--

LOCK TABLES `fournisseurs` WRITE;
/*!40000 ALTER TABLE `fournisseurs` DISABLE KEYS */;
INSERT INTO `fournisseurs` VALUES
(25,'Siemens Healthineers','M. Diallo','+221 33 849 30 00','contact@siemens.sn','Dakar','Imagerie médicale'),
(26,'GE Healthcare','Mme Diop','+221 33 859 40 00','info@gehealthcare.sn','Dakar','Équipement médical'),
(27,'Philips Medical Systems','M. Fall','+221 33 869 50 00','senegal@philips.com','Dakar','Équipement hospitalier'),
(28,'Dell Technologies','M. Ndiaye','+221 33 879 60 00','ventes@dell.sn','Dakar','Informatique'),
(29,'HP Inc.','Mme Ba','+221 33 889 70 00','info@hp.sn','Dakar','Ordinateurs, imprimantes'),
(30,'Fresenius','M. Sow','+221 33 899 80 00','info@fresenius.sn','Dakar','Dialyse, réanimation'),
(31,'Roche Diagnostics','Mme Ndiaye','+221 33 919 00 11','roche@roche.sn','Dakar','Diagnostic, laboratoire'),
(32,'Medtronic','M. Diouf','+221 33 929 11 22','medtronic@medtronic.sn','Dakar','Équipement chirurgical'),
(33,'Stryker','M. Thiam','+221 33 939 22 33','stryker@stryker.sn','Dakar','Matériel orthopédique'),
(34,'Dräger','M. Faye','+221 33 959 44 55','draege@draeger.sn','Dakar','Réanimation, anesthésie');
/*!40000 ALTER TABLE `fournisseurs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `historique_pharmacie`
--

DROP TABLE IF EXISTS `historique_pharmacie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `historique_pharmacie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `medicament` varchar(255) DEFAULT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `date_delivrance` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `historique_pharmacie`
--

LOCK TABLES `historique_pharmacie` WRITE;
/*!40000 ALTER TABLE `historique_pharmacie` DISABLE KEYS */;
/*!40000 ALTER TABLE `historique_pharmacie` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `materiel`
--

DROP TABLE IF EXISTS `materiel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `materiel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code_materiel` varchar(50) NOT NULL,
  `nom` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `categorie_id` int(11) DEFAULT NULL,
  `service_id` int(11) DEFAULT NULL,
  `salle_id` int(11) DEFAULT NULL,
  `date_acquisition` date DEFAULT NULL,
  `valeur_achat` decimal(10,2) DEFAULT NULL,
  `fournisseur` varchar(200) DEFAULT NULL,
  `numero_serie` varchar(100) DEFAULT NULL,
  `statut` enum('actif','maintenance','hors_service','stock') DEFAULT 'actif',
  `date_derniere_maintenance` date DEFAULT NULL,
  `prochaine_maintenance` date DEFAULT NULL,
  `quantite` int(11) DEFAULT 1,
  `observations` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code_materiel` (`code_materiel`),
  KEY `categorie_id` (`categorie_id`),
  KEY `service_id` (`service_id`),
  KEY `salle_id` (`salle_id`),
  CONSTRAINT `materiel_ibfk_1` FOREIGN KEY (`categorie_id`) REFERENCES `categories_materiel` (`id`),
  CONSTRAINT `materiel_ibfk_2` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`),
  CONSTRAINT `materiel_ibfk_3` FOREIGN KEY (`salle_id`) REFERENCES `salles` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `materiel`
--

LOCK TABLES `materiel` WRITE;
/*!40000 ALTER TABLE `materiel` DISABLE KEYS */;
INSERT INTO `materiel` VALUES
(33,'MAT-2026-0001','ECG 12 dérivations','Électrocardiographe numérique',1,8,8,'2026-03-15',3500000.00,'GE Healthcare','ECG-2025-001','actif',NULL,NULL,2,NULL,'2026-03-15 02:06:47'),
(34,'MAT-2026-0002','Holter ECG','Enregistreur ECG 24h',1,8,8,'2026-03-15',2800000.00,'Philips Medical Systems','HOL-2025-002','actif',NULL,NULL,1,NULL,'2026-03-15 02:06:47'),
(35,'MAT-2026-0003','Échocardiographe','Échographe cardiaque portable',1,8,8,'2026-03-15',8500000.00,'Siemens Healthineers','ECHO-2025-003','actif',NULL,NULL,1,NULL,'2026-03-15 02:06:47'),
(36,'MAT-2026-0004','Tensiomètre automatique','Tensiomètre brassard électronique',1,8,8,'2026-03-15',450000.00,'Fresenius','TENS-2025-004','actif',NULL,NULL,5,NULL,'2026-03-15 02:06:47'),
(37,'MAT-2026-0005','Défibrillateur','Défibrillateur avec monitoring',1,8,8,'2026-03-15',4200000.00,'Medtronic','DEF-2025-005','actif',NULL,NULL,1,NULL,'2026-03-15 02:06:47'),
(38,'MAT-2026-0006','Balance bébé','Balance électronique pour nourrissons',1,3,3,'2026-03-15',125000.00,'Seca','BAL-2025-006','actif',NULL,NULL,3,NULL,'2026-03-15 02:06:47'),
(39,'MAT-2026-0007','Incubateur','Incubateur néonatal',1,3,3,'2026-03-15',8500000.00,'Dräger','INC-2025-007','actif',NULL,NULL,1,NULL,'2026-03-15 02:06:47'),
(40,'MAT-2026-0008','Table à langer','Table d\'examen pour bébés',1,3,3,'2026-03-15',250000.00,'Stryker','TAB-2025-008','actif',NULL,NULL,2,NULL,'2026-03-15 02:06:47'),
(41,'MAT-2026-0009','Nébuliseur pédiatrique','Nébuliseur pour enfants',1,3,3,'2026-03-15',85000.00,'Philips Medical Systems','NEB-2025-009','actif',NULL,NULL,4,NULL,'2026-03-15 02:06:47'),
(42,'MAT-2026-0010','Stéthoscope pédiatrique','Stéthoscope pour enfants',1,3,3,'2026-03-15',75000.00,'Medtronic','STET-2025-010','actif',NULL,NULL,3,NULL,'2026-03-15 02:06:47'),
(43,'MAT-2026-0011','Table gynécologique','Table d\'examen gynécologique électrique',1,5,5,'2026-03-15',950000.00,'Stryker','TABG-2025-011','actif',NULL,NULL,2,NULL,'2026-03-15 02:06:47'),
(44,'MAT-2026-0012','Échographe obstétrical','Échographe avec doppler fœtal',1,5,5,'2026-03-15',12000000.00,'GE Healthcare','ECHO-2025-012','actif',NULL,NULL,1,NULL,'2026-03-15 02:06:47'),
(45,'MAT-2026-0013','Colposcope','Colposcope de gynécologie',1,5,5,'2026-03-15',4500000.00,'Leisegang','COLPO-2025-013','actif',NULL,NULL,1,NULL,'2026-03-15 02:06:47'),
(46,'MAT-2026-0014','Monitorage fœtal','Moniteur fœtal',1,5,5,'2026-03-15',3500000.00,'Philips Medical Systems','FOET-2025-014','actif',NULL,NULL,1,NULL,'2026-03-15 02:06:47'),
(47,'MAT-2026-0015','Spéculum set','Set de spéculums stériles',1,5,5,'2026-03-15',25000.00,'Medtronic','SPEC-2025-015','actif',NULL,NULL,20,NULL,'2026-03-15 02:06:47'),
(48,'MAT-2026-0016','Fauteuil dentaire','Fauteuil de consultation dentaire électrique',1,4,4,'2026-03-15',3500000.00,'Stryker','FAUT-2025-016','actif',NULL,NULL,2,NULL,'2026-03-15 02:06:47'),
(49,'MAT-2026-0017','Radiologie dentaire','Radio panoramique dentaire',1,4,4,'2026-03-15',8500000.00,'Siemens Healthineers','RAD-2025-017','actif',NULL,NULL,1,NULL,'2026-03-15 02:06:47'),
(50,'MAT-2026-0018','Instrumentation dentaire','Kit d\'instruments dentaires complet',1,4,4,'2026-03-15',450000.00,'Medtronic','KIT-2025-018','actif',NULL,NULL,5,NULL,'2026-03-15 02:06:47'),
(51,'MAT-2026-0019','Autoclave dentaire','Stérilisateur pour instruments dentaires',1,4,4,'2026-03-15',1200000.00,'Tuttnauer','AUTO-2025-019','actif',NULL,NULL,1,NULL,'2026-03-15 02:06:47'),
(52,'MAT-2026-0020','Lampe photopolymériseuse','Lampe à polymériser',1,4,4,'2026-03-15',250000.00,'3M','LAMP-2025-020','actif',NULL,NULL,3,NULL,'2026-03-15 02:06:47'),
(53,'MAT-2026-0021','Table d\'examen','Table d\'auscultation',1,6,6,'2026-03-15',450000.00,'Stryker','TAB-2025-021','actif',NULL,NULL,5,NULL,'2026-03-15 02:06:47'),
(54,'MAT-2026-0022','Armoire médicale','Armoire de rangement',1,6,6,'2026-03-15',180000.00,'Lista','ARM-2025-022','actif',NULL,NULL,4,NULL,'2026-03-15 02:06:47'),
(55,'MAT-2026-0023','Stéthoscope','Stéthoscope professionnel',1,6,6,'2026-03-15',65000.00,'Medtronic','STET-2025-023','actif',NULL,NULL,8,NULL,'2026-03-15 02:06:47'),
(56,'MAT-2026-0024','Otoscope','Otoscope LED',1,6,6,'2026-03-15',85000.00,'Welch Allyn','OTO-2025-024','actif',NULL,NULL,3,NULL,'2026-03-15 02:06:47'),
(57,'MAT-2026-0025','Tensiomètre','Tensiomètre manuel',1,6,6,'2026-03-15',35000.00,'Omron','TENS-2025-025','actif',NULL,NULL,6,NULL,'2026-03-15 02:06:47'),
(58,'MAT-2026-0026','Réfrigérateur pharmaceutique','Réfrigérateur pour médicaments',1,7,7,'2026-03-15',2200000.00,'Liebherr','FRIG-2025-026','actif',NULL,NULL,2,NULL,'2026-03-15 02:06:47'),
(59,'MAT-2026-0027','Comptoir de pharmacie','Comptoir de dispensation',1,7,7,'2026-03-15',550000.00,'Steelcase','COMP-2025-027','actif',NULL,NULL,1,NULL,'2026-03-15 02:06:47'),
(60,'MAT-2026-0028','Armoire sécurisée','Armoire pour produits contrôlés',1,7,7,'2026-03-15',350000.00,'Lista','ARMS-2025-028','actif',NULL,NULL,1,NULL,'2026-03-15 02:06:47'),
(61,'MAT-2026-0029','Lampe à fente','Lampe à fente pour examen oculaire',1,9,9,'2026-03-15',5500000.00,'Haag-Streit','LAMP-2025-029','actif',NULL,NULL,1,NULL,'2026-03-15 02:06:47'),
(62,'MAT-2026-0030','Ophtalmoscope','Ophtalmoscope LED',1,9,9,'2026-03-15',250000.00,'Welch Allyn','OPHT-2025-030','actif',NULL,NULL,2,NULL,'2026-03-15 02:06:47'),
(63,'MAT-2026-0031','Réfractomètre','Auto-réfractomètre',1,9,9,'2026-03-15',4500000.00,'Topcon','REF-2025-031','actif',NULL,NULL,1,NULL,'2026-03-15 02:06:47'),
(64,'MAT-2026-0032','Glucomètre','Lecteur de glycémie',1,10,10,'2026-03-15',25000.00,'Roche Diagnostics','GLUC-2025-032','actif',NULL,NULL,10,NULL,'2026-03-15 02:06:47'),
(65,'MAT-2026-0033','Pompe à insuline','Pompe à insuline programmable',1,10,10,'2026-03-15',450000.00,'Medtronic','POMP-2025-033','actif',NULL,NULL,2,NULL,'2026-03-15 02:06:47'),
(66,'MAT-2026-0034','Pèse-personne','Balance médicale',1,10,10,'2026-03-15',85000.00,'Seca','BAL-2025-034','actif',NULL,NULL,2,NULL,'2026-03-15 02:06:47'),
(67,'MAT-2026-0035','Marteau réflexes','Marteau neurologique',1,11,11,'2026-03-15',15000.00,'Medtronic','MART-2025-035','actif',NULL,NULL,5,NULL,'2026-03-15 02:06:47'),
(68,'MAT-2026-0036','Diapason','Diapason neurologique',1,11,11,'2026-03-15',25000.00,'Ryvac','DIAP-2025-036','actif',NULL,NULL,3,NULL,'2026-03-15 02:06:47'),
(69,'MAT-2026-0037','EEG portable','Électroencéphalographe',1,11,11,'2026-03-15',12500000.00,'Natus','EEG-2025-037','actif',NULL,NULL,1,NULL,'2026-03-15 02:06:47'),
(70,'MAT-2026-0038','Dermatoscope','Dermatoscope LED',1,12,12,'2026-03-15',350000.00,'Heine','DERM-2025-038','actif',NULL,NULL,1,NULL,'2026-03-15 02:06:47'),
(71,'MAT-2026-0039','Lampe UV','Lampe de photothérapie',1,12,12,'2026-03-15',850000.00,'Philips Medical Systems','UV-2025-039','actif',NULL,NULL,1,NULL,'2026-03-15 02:06:47'),
(72,'MAT-2026-0040','Cryothérapie','Appareil de cryothérapie',1,12,12,'2026-03-15',1200000.00,'CryoAlpha','CRYO-2025-040','actif',NULL,NULL,1,NULL,'2026-03-15 02:06:47'),
(73,'MAT-2026-0041','Ordinateur','PC de bureau',1,2,2,'2026-03-15',450000.00,'Dell Technologies','PC-2025-041','actif',NULL,NULL,3,NULL,'2026-03-15 02:06:47'),
(74,'MAT-2026-0042','Imprimante','Imprimante multifonction',1,2,2,'2026-03-15',250000.00,'HP Inc.','IMP-2025-042','actif',NULL,NULL,2,NULL,'2026-03-15 02:06:47'),
(75,'MAT-2026-0043','Scanner codes-barres','Lecteur de codes patients',1,2,2,'2026-03-15',45000.00,'Zebra','SCAN-2025-043','actif',NULL,NULL,2,NULL,'2026-03-15 02:06:47'),
(76,'MAT-2026-0044','Terminal de paiement','TPE bancaire',1,2,2,'2026-03-15',150000.00,'Ingenico','TPE-2025-044','actif',NULL,NULL,1,NULL,'2026-03-15 02:06:47'),
(77,'MAT-2026-0045','Bureau accueil','Bureau de réception',1,1,1,'2026-03-15',250000.00,'Steelcase','BUR-2025-045','actif',NULL,NULL,1,NULL,'2026-03-15 02:06:47'),
(78,'MAT-2026-0046','Chaise','Chaise d\'attente',1,1,1,'2026-03-15',85000.00,'Herman Miller','CHAISE-2025-046','actif',NULL,NULL,10,NULL,'2026-03-15 02:06:47'),
(79,'MAT-2026-0047','Écran d\'affichage','TV pour file d\'attente',1,1,1,'2026-03-15',350000.00,'Samsung','TV-2025-047','actif',NULL,NULL,1,NULL,'2026-03-15 02:06:47');
/*!40000 ALTER TABLE `materiel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medecin_salles`
--

DROP TABLE IF EXISTS `medecin_salles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `medecin_salles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `medecin_id` int(11) NOT NULL,
  `salle_id` int(11) NOT NULL,
  `date_affectation` date NOT NULL,
  `heure_debut` time DEFAULT NULL,
  `heure_fin` time DEFAULT NULL,
  `actif` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `medecin_id` (`medecin_id`),
  KEY `salle_id` (`salle_id`),
  CONSTRAINT `medecin_salles_ibfk_1` FOREIGN KEY (`medecin_id`) REFERENCES `users` (`id`),
  CONSTRAINT `medecin_salles_ibfk_2` FOREIGN KEY (`salle_id`) REFERENCES `salles` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medecin_salles`
--

LOCK TABLES `medecin_salles` WRITE;
/*!40000 ALTER TABLE `medecin_salles` DISABLE KEYS */;
INSERT INTO `medecin_salles` VALUES
(1,4,3,'2026-03-14','08:00:00','12:00:00',1,'2026-03-14 01:54:12'),
(2,4,18,'2026-03-14','14:00:00','18:00:00',1,'2026-03-14 01:54:12'),
(3,5,4,'2026-03-14','08:00:00','12:00:00',1,'2026-03-14 01:54:12'),
(4,5,19,'2026-03-14','14:00:00','18:00:00',1,'2026-03-14 01:54:12'),
(5,37,8,'2026-03-14','08:00:00','12:00:00',1,'2026-03-14 01:54:12'),
(6,37,23,'2026-03-14','14:00:00','18:00:00',1,'2026-03-14 01:54:12');
/*!40000 ALTER TABLE `medecin_salles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medical_records`
--

DROP TABLE IF EXISTS `medical_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `medical_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `record_id` varchar(20) NOT NULL,
  `consultation_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `doctor_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `diagnosis` text DEFAULT NULL,
  `treatment` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `record_id` (`record_id`),
  KEY `consultation_id` (`consultation_id`),
  KEY `patient_id` (`patient_id`),
  KEY `doctor_id` (`doctor_id`),
  KEY `service_id` (`service_id`),
  CONSTRAINT `medical_records_ibfk_1` FOREIGN KEY (`consultation_id`) REFERENCES `consultations` (`id`),
  CONSTRAINT `medical_records_ibfk_2` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`),
  CONSTRAINT `medical_records_ibfk_3` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`),
  CONSTRAINT `medical_records_ibfk_4` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medical_records`
--

LOCK TABLES `medical_records` WRITE;
/*!40000 ALTER TABLE `medical_records` DISABLE KEYS */;
INSERT INTO `medical_records` VALUES
(1,'DOS-ABC123',1,1,1,1,'Fièvre et toux','Paracétamol et repos','2026-03-12 10:42:50'),
(2,'DOS-DEF456',2,2,2,2,'Carie dentaire','Dévitalisation','2026-03-12 10:42:50'),
(3,'DOS-GHI789',3,3,3,3,'Grossesse - suivi','Vitamines et échographie','2026-03-12 10:42:50');
/*!40000 ALTER TABLE `medical_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mouvements_materiel`
--

DROP TABLE IF EXISTS `mouvements_materiel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mouvements_materiel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `materiel_id` int(11) DEFAULT NULL,
  `type_mouvement` enum('entree','sortie','transfert','maintenance') NOT NULL,
  `service_source` int(11) DEFAULT NULL,
  `service_destination` int(11) DEFAULT NULL,
  `salle_source` int(11) DEFAULT NULL,
  `salle_destination` int(11) DEFAULT NULL,
  `quantite` int(11) DEFAULT 1,
  `motif` text DEFAULT NULL,
  `date_mouvement` timestamp NULL DEFAULT current_timestamp(),
  `utilisateur_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `materiel_id` (`materiel_id`),
  KEY `service_source` (`service_source`),
  KEY `service_destination` (`service_destination`),
  KEY `salle_source` (`salle_source`),
  KEY `salle_destination` (`salle_destination`),
  KEY `utilisateur_id` (`utilisateur_id`),
  CONSTRAINT `mouvements_materiel_ibfk_1` FOREIGN KEY (`materiel_id`) REFERENCES `materiel` (`id`),
  CONSTRAINT `mouvements_materiel_ibfk_2` FOREIGN KEY (`service_source`) REFERENCES `services` (`id`),
  CONSTRAINT `mouvements_materiel_ibfk_3` FOREIGN KEY (`service_destination`) REFERENCES `services` (`id`),
  CONSTRAINT `mouvements_materiel_ibfk_4` FOREIGN KEY (`salle_source`) REFERENCES `salles` (`id`),
  CONSTRAINT `mouvements_materiel_ibfk_5` FOREIGN KEY (`salle_destination`) REFERENCES `salles` (`id`),
  CONSTRAINT `mouvements_materiel_ibfk_6` FOREIGN KEY (`utilisateur_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mouvements_materiel`
--

LOCK TABLES `mouvements_materiel` WRITE;
/*!40000 ALTER TABLE `mouvements_materiel` DISABLE KEYS */;
/*!40000 ALTER TABLE `mouvements_materiel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `niveaux`
--

DROP TABLE IF EXISTS `niveaux`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `niveaux` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batiment_id` int(11) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `ordre` int(11) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `batiment_id` (`batiment_id`),
  CONSTRAINT `niveaux_ibfk_1` FOREIGN KEY (`batiment_id`) REFERENCES `batiments` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `niveaux`
--

LOCK TABLES `niveaux` WRITE;
/*!40000 ALTER TABLE `niveaux` DISABLE KEYS */;
INSERT INTO `niveaux` VALUES
(1,1,'Rez-de-chaussée',1,'2026-03-14 00:40:09'),
(2,1,'1er étage',2,'2026-03-14 00:40:09'),
(3,1,'2ème étage',3,'2026-03-14 00:40:09'),
(4,2,'Rez-de-chaussée',1,'2026-03-14 00:40:09'),
(5,2,'1er étage',2,'2026-03-14 00:40:09'),
(6,3,'Rez-de-chaussée',1,'2026-03-14 00:40:09'),
(7,3,'1er étage',2,'2026-03-14 00:40:09'),
(8,4,'Rez-de-chaussée',1,'2026-03-14 00:40:09'),
(9,4,'1er étage',2,'2026-03-14 00:40:09'),
(10,5,'Rez-de-chaussée',1,'2026-03-14 00:40:09');
/*!40000 ALTER TABLE `niveaux` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paiements`
--

DROP TABLE IF EXISTS `paiements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `paiements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numero_facture` varchar(20) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `consultation_id` int(11) DEFAULT NULL,
  `caissier_id` int(11) NOT NULL,
  `montant_total` decimal(10,2) NOT NULL,
  `montant_paye` decimal(10,2) NOT NULL,
  `montant_restant` decimal(10,2) DEFAULT 0.00,
  `mode_paiement` enum('especes','carte','cheque','mobile_money','assurance') DEFAULT 'especes',
  `statut` enum('paye','partiel','impaye') DEFAULT 'impaye',
  `date_paiement` timestamp NULL DEFAULT current_timestamp(),
  `observations` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `numero_facture` (`numero_facture`),
  KEY `consultation_id` (`consultation_id`),
  KEY `caissier_id` (`caissier_id`),
  KEY `idx_patient` (`patient_id`),
  KEY `idx_statut` (`statut`),
  KEY `idx_date` (`date_paiement`),
  CONSTRAINT `paiements_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`),
  CONSTRAINT `paiements_ibfk_2` FOREIGN KEY (`consultation_id`) REFERENCES `consultations` (`id`),
  CONSTRAINT `paiements_ibfk_3` FOREIGN KEY (`caissier_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paiements`
--

LOCK TABLES `paiements` WRITE;
/*!40000 ALTER TABLE `paiements` DISABLE KEYS */;
INSERT INTO `paiements` VALUES
(4,'FACT-1781225552',2,4,1,0.00,1500.00,0.00,'especes','paye','2026-06-12 00:52:32',NULL),
(5,'FACT-1781225775',2,4,1,0.00,1500.00,0.00,'especes','paye','2026-06-12 00:56:15',NULL);
/*!40000 ALTER TABLE `paiements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paies`
--

DROP TABLE IF EXISTS `paies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `paies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `mois` int(11) NOT NULL,
  `annee` int(11) NOT NULL,
  `salaire_base` decimal(10,2) NOT NULL,
  `nb_consultations` int(11) DEFAULT 0,
  `nb_actes` int(11) DEFAULT 0,
  `prime_consultation` decimal(10,2) DEFAULT 0.00,
  `prime_acte` decimal(10,2) DEFAULT 0.00,
  `total_brut` decimal(10,2) NOT NULL,
  `cotisations` decimal(10,2) DEFAULT 0.00,
  `total_net` decimal(10,2) NOT NULL,
  `statut` enum('calcule','valide','paye') DEFAULT 'calcule',
  `date_paiement` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_paie` (`user_id`,`mois`,`annee`),
  CONSTRAINT `paies_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paies`
--

LOCK TABLES `paies` WRITE;
/*!40000 ALTER TABLE `paies` DISABLE KEYS */;
/*!40000 ALTER TABLE `paies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patients`
--

DROP TABLE IF EXISTS `patients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `patients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code_patient_unique` varchar(20) DEFAULT NULL,
  `qr_code` varchar(255) DEFAULT NULL,
  `numero_patient` varchar(20) DEFAULT NULL,
  `prenom` varchar(100) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `date_naissance` date NOT NULL,
  `lieu_naissance` varchar(100) DEFAULT NULL,
  `sexe` enum('M','F') NOT NULL,
  `groupe_sanguin` varchar(5) DEFAULT NULL,
  `allergie` text DEFAULT NULL,
  `antecedent_medicaux` text DEFAULT NULL,
  `traitement_en_cours` text DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `adresse` text DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `personne_contact` varchar(100) DEFAULT NULL,
  `telephone_contact` varchar(20) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `numero_patient` (`numero_patient`),
  UNIQUE KEY `code_patient_unique` (`code_patient_unique`),
  KEY `idx_numero` (`numero_patient`),
  KEY `idx_nom` (`nom`),
  KEY `fk_patients_created_by` (`created_by`),
  CONSTRAINT `fk_patients_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patients`
--

LOCK TABLES `patients` WRITE;
/*!40000 ALTER TABLE `patients` DISABLE KEYS */;
INSERT INTO `patients` VALUES
(1,'PAT-000001',NULL,NULL,'Mamadou','Diop','1990-01-01',NULL,'M',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-11 08:09:38'),
(2,'PAT-000002',NULL,NULL,'Fatou','Sarr','1995-05-20',NULL,'F',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-11 08:09:38'),
(3,'PAT-000003',NULL,NULL,'Diop','Mamadou','1990-05-15',NULL,'M',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-12 21:30:18'),
(4,'PAT-000004',NULL,NULL,'Moussa','Diop','1990-05-15',NULL,'M',NULL,NULL,NULL,NULL,'770000000',NULL,NULL,NULL,NULL,NULL,'2026-06-13 18:31:04');
/*!40000 ALTER TABLE `patients` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER generate_patient_code
BEFORE INSERT ON patients
FOR EACH ROW
BEGIN
    DECLARE next_num INT;
    
    
    SELECT COALESCE(MAX(CAST(SUBSTRING(code_patient_unique, 5) AS UNSIGNED)), 0) + 1 
    INTO next_num 
    FROM patients;
    
    
    SET NEW.code_patient_unique = CONCAT('PAT-', LPAD(next_num, 6, '0'));
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_id` int(11) NOT NULL,
  `consultation_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_method` enum('cash','mobile_money','insurance') DEFAULT 'cash',
  `status` enum('pending','completed','refunded') DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `patient_id` (`patient_id`),
  KEY `consultation_id` (`consultation_id`),
  CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`),
  CONSTRAINT `payments_ibfk_2` FOREIGN KEY (`consultation_id`) REFERENCES `consultations` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES
(1,1,1,5000.00,'cash','completed','2026-03-12 10:42:50'),
(2,2,2,7500.00,'mobile_money','completed','2026-03-12 10:42:50'),
(3,3,3,10000.00,'insurance','pending','2026-03-12 10:42:50'),
(4,4,4,3000.00,'cash','completed','2026-03-12 10:42:50'),
(5,5,5,15000.00,'mobile_money','refunded','2026-03-12 10:42:50');
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pointages`
--

DROP TABLE IF EXISTS `pointages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pointages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `date_pointage` date NOT NULL,
  `heure_arrivee` time DEFAULT NULL,
  `heure_depart` time DEFAULT NULL,
  `statut` enum('present','absent','retard','conge') DEFAULT 'present',
  `qr_code_scan` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_pointage` (`user_id`,`date_pointage`),
  CONSTRAINT `pointages_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=288 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pointages`
--

LOCK TABLES `pointages` WRITE;
/*!40000 ALTER TABLE `pointages` DISABLE KEYS */;
INSERT INTO `pointages` VALUES
(1,1,'2026-03-13','09:33:00','19:21:00','present',NULL,'2026-03-13 03:18:08'),
(2,2,'2026-03-13','07:40:00','16:54:00','present',NULL,'2026-03-13 03:18:08'),
(3,3,'2026-03-13','09:15:00','18:07:00','present',NULL,'2026-03-13 03:18:08'),
(4,4,'2026-03-13','10:40:00','19:04:00','present',NULL,'2026-03-13 03:18:08'),
(5,5,'2026-03-13','08:10:00','18:25:00','present',NULL,'2026-03-13 03:18:08'),
(6,37,'2026-03-13','10:58:00','20:36:00','present',NULL,'2026-03-13 03:18:08'),
(7,38,'2026-03-13','10:10:00','18:08:00','present',NULL,'2026-03-13 03:18:08'),
(8,39,'2026-03-13','10:05:00','20:24:00','present',NULL,'2026-03-13 03:18:08'),
(9,40,'2026-03-13','10:40:00','18:41:00','present',NULL,'2026-03-13 03:18:08'),
(10,41,'2026-03-13','08:48:00','20:20:00','present',NULL,'2026-03-13 03:18:08'),
(11,43,'2026-03-13','08:45:00','20:26:00','present',NULL,'2026-03-13 03:18:08'),
(12,44,'2026-03-13','08:19:00','19:39:00','present',NULL,'2026-03-13 03:18:08'),
(13,1,'2026-03-12','09:41:00','19:02:00','present',NULL,'2026-03-13 03:18:08'),
(14,2,'2026-03-12','08:56:00','16:09:00','present',NULL,'2026-03-13 03:18:08'),
(15,4,'2026-03-12','09:59:00','18:14:00','present',NULL,'2026-03-13 03:18:08'),
(16,5,'2026-03-12','08:35:00',NULL,'present',NULL,'2026-03-13 03:18:08'),
(17,37,'2026-03-12','08:06:00',NULL,'present',NULL,'2026-03-13 03:18:08'),
(18,39,'2026-03-12','08:32:00','20:05:00','present',NULL,'2026-03-13 03:18:08'),
(19,40,'2026-03-12','10:48:00','18:50:00','present',NULL,'2026-03-13 03:18:08'),
(20,41,'2026-03-12','09:00:00','19:39:00','present',NULL,'2026-03-13 03:18:08'),
(21,42,'2026-03-12','10:00:00','19:36:00','present',NULL,'2026-03-13 03:18:08'),
(22,43,'2026-03-12','08:56:00','20:51:00','present',NULL,'2026-03-13 03:18:08'),
(23,44,'2026-03-12','10:28:00','20:21:00','present',NULL,'2026-03-13 03:18:08'),
(24,1,'2026-03-11','09:41:00','17:54:00','present',NULL,'2026-03-13 03:18:08'),
(25,2,'2026-03-11','07:57:00','17:23:00','present',NULL,'2026-03-13 03:18:08'),
(26,4,'2026-03-11','08:34:00','19:54:00','present',NULL,'2026-03-13 03:18:08'),
(27,5,'2026-03-11','09:06:00','18:03:00','present',NULL,'2026-03-13 03:18:08'),
(28,37,'2026-03-11','09:07:00','20:50:00','present',NULL,'2026-03-13 03:18:08'),
(29,38,'2026-03-11','09:13:00','18:47:00','present',NULL,'2026-03-13 03:18:08'),
(30,39,'2026-03-11','08:26:00',NULL,'present',NULL,'2026-03-13 03:18:08'),
(31,40,'2026-03-11','08:56:00','18:33:00','present',NULL,'2026-03-13 03:18:08'),
(32,41,'2026-03-11','09:52:00',NULL,'present',NULL,'2026-03-13 03:18:08'),
(33,42,'2026-03-11','08:06:00','19:40:00','present',NULL,'2026-03-13 03:18:08'),
(34,43,'2026-03-11','10:45:00','19:58:00','present',NULL,'2026-03-13 03:18:08'),
(35,44,'2026-03-11','10:30:00','18:22:00','present',NULL,'2026-03-13 03:18:08'),
(36,1,'2026-03-10','08:17:00','19:43:00','present',NULL,'2026-03-13 03:18:08'),
(37,2,'2026-03-10','07:29:00','16:42:00','present',NULL,'2026-03-13 03:18:08'),
(38,3,'2026-03-10','09:52:00','16:00:00','present',NULL,'2026-03-13 03:18:08'),
(39,4,'2026-03-10','08:35:00','19:47:00','present',NULL,'2026-03-13 03:18:08'),
(40,5,'2026-03-10','09:49:00','19:30:00','present',NULL,'2026-03-13 03:18:08'),
(41,37,'2026-03-10','09:53:00','19:31:00','present',NULL,'2026-03-13 03:18:08'),
(42,38,'2026-03-10','09:38:00','20:47:00','present',NULL,'2026-03-13 03:18:08'),
(43,39,'2026-03-10','08:01:00','20:04:00','present',NULL,'2026-03-13 03:18:08'),
(44,40,'2026-03-10','08:04:00','20:42:00','present',NULL,'2026-03-13 03:18:08'),
(45,41,'2026-03-10','09:58:00','18:50:00','present',NULL,'2026-03-13 03:18:08'),
(46,42,'2026-03-10','08:36:00','18:59:00','present',NULL,'2026-03-13 03:18:08'),
(47,43,'2026-03-10','08:19:00','20:34:00','present',NULL,'2026-03-13 03:18:08'),
(48,44,'2026-03-10','08:10:00','19:17:00','present',NULL,'2026-03-13 03:18:08'),
(49,1,'2026-03-09','09:57:00','18:37:00','present',NULL,'2026-03-13 03:18:08'),
(50,2,'2026-03-09','07:44:00','16:05:00','present',NULL,'2026-03-13 03:18:08'),
(51,3,'2026-03-09','08:11:00','18:35:00','present',NULL,'2026-03-13 03:18:08'),
(52,4,'2026-03-09','10:42:00',NULL,'present',NULL,'2026-03-13 03:18:08'),
(53,5,'2026-03-09','08:22:00','19:38:00','present',NULL,'2026-03-13 03:18:08'),
(54,37,'2026-03-09','09:16:00','19:51:00','present',NULL,'2026-03-13 03:18:08'),
(55,38,'2026-03-09','09:42:00','20:26:00','present',NULL,'2026-03-13 03:18:08'),
(56,39,'2026-03-09','08:38:00','20:17:00','present',NULL,'2026-03-13 03:18:08'),
(57,40,'2026-03-09','09:32:00','18:15:00','present',NULL,'2026-03-13 03:18:08'),
(58,41,'2026-03-09','10:17:00','19:18:00','present',NULL,'2026-03-13 03:18:08'),
(59,42,'2026-03-09','09:21:00','19:57:00','present',NULL,'2026-03-13 03:18:08'),
(60,43,'2026-03-09','10:52:00',NULL,'present',NULL,'2026-03-13 03:18:08'),
(61,44,'2026-03-09','10:34:00','20:33:00','present',NULL,'2026-03-13 03:18:08'),
(62,3,'2026-03-08','09:17:00','16:36:00','present',NULL,'2026-03-13 03:18:08'),
(63,44,'2026-03-08','08:59:00','19:35:00','present',NULL,'2026-03-13 03:18:08'),
(64,4,'2026-03-07','09:43:00','18:34:00','present',NULL,'2026-03-13 03:18:08'),
(65,5,'2026-03-07','08:11:00','18:01:00','present',NULL,'2026-03-13 03:18:08'),
(66,42,'2026-03-07','10:11:00','20:52:00','present',NULL,'2026-03-13 03:18:08'),
(67,1,'2026-03-06','07:06:00','18:44:00','present',NULL,'2026-03-13 03:18:08'),
(68,2,'2026-03-06','08:38:00','16:18:00','present',NULL,'2026-03-13 03:18:08'),
(69,3,'2026-03-06','08:30:00','17:31:00','present',NULL,'2026-03-13 03:18:08'),
(70,4,'2026-03-06','10:42:00','18:38:00','present',NULL,'2026-03-13 03:18:08'),
(71,5,'2026-03-06','08:02:00','18:03:00','present',NULL,'2026-03-13 03:18:08'),
(72,37,'2026-03-06','08:06:00','19:32:00','present',NULL,'2026-03-13 03:18:08'),
(73,38,'2026-03-06','10:36:00','18:25:00','present',NULL,'2026-03-13 03:18:08'),
(74,39,'2026-03-06','09:37:00','20:37:00','present',NULL,'2026-03-13 03:18:08'),
(75,40,'2026-03-06','10:44:00','18:22:00','present',NULL,'2026-03-13 03:18:08'),
(76,41,'2026-03-06','09:13:00','18:03:00','present',NULL,'2026-03-13 03:18:08'),
(77,42,'2026-03-06','10:43:00','18:36:00','present',NULL,'2026-03-13 03:18:08'),
(78,43,'2026-03-06','10:52:00','18:19:00','present',NULL,'2026-03-13 03:18:08'),
(79,44,'2026-03-06','09:55:00','18:54:00','present',NULL,'2026-03-13 03:18:08'),
(80,1,'2026-03-05','08:32:00','18:17:00','present',NULL,'2026-03-13 03:18:08'),
(81,2,'2026-03-05','08:16:00',NULL,'present',NULL,'2026-03-13 03:18:08'),
(82,3,'2026-03-05','07:34:00','17:55:00','present',NULL,'2026-03-13 03:18:08'),
(83,4,'2026-03-05','10:35:00','19:29:00','present',NULL,'2026-03-13 03:18:08'),
(84,5,'2026-03-05','09:33:00','18:00:00','present',NULL,'2026-03-13 03:18:08'),
(85,38,'2026-03-05','10:14:00','18:26:00','present',NULL,'2026-03-13 03:18:08'),
(86,39,'2026-03-05','09:40:00','19:13:00','present',NULL,'2026-03-13 03:18:08'),
(87,40,'2026-03-05','10:37:00','19:05:00','present',NULL,'2026-03-13 03:18:08'),
(88,41,'2026-03-05','10:39:00','20:24:00','present',NULL,'2026-03-13 03:18:08'),
(89,42,'2026-03-05','09:52:00','19:03:00','present',NULL,'2026-03-13 03:18:08'),
(90,43,'2026-03-05','10:22:00','18:29:00','present',NULL,'2026-03-13 03:18:08'),
(91,44,'2026-03-05','09:35:00','20:16:00','present',NULL,'2026-03-13 03:18:08'),
(92,1,'2026-03-04','07:02:00','19:27:00','present',NULL,'2026-03-13 03:18:08'),
(93,2,'2026-03-04','09:46:00','18:43:00','present',NULL,'2026-03-13 03:18:08'),
(94,3,'2026-03-04','09:34:00',NULL,'present',NULL,'2026-03-13 03:18:08'),
(95,4,'2026-03-04','09:43:00','20:04:00','present',NULL,'2026-03-13 03:18:08'),
(96,5,'2026-03-04','08:50:00','18:09:00','present',NULL,'2026-03-13 03:18:08'),
(97,37,'2026-03-04','09:26:00','18:50:00','present',NULL,'2026-03-13 03:18:08'),
(98,38,'2026-03-04','09:52:00','19:22:00','present',NULL,'2026-03-13 03:18:08'),
(99,39,'2026-03-04','08:39:00','18:42:00','present',NULL,'2026-03-13 03:18:08'),
(100,40,'2026-03-04','08:11:00',NULL,'present',NULL,'2026-03-13 03:18:08'),
(101,41,'2026-03-04','09:24:00','19:14:00','present',NULL,'2026-03-13 03:18:08'),
(102,42,'2026-03-04','10:57:00','19:33:00','present',NULL,'2026-03-13 03:18:08'),
(103,43,'2026-03-04','08:18:00','20:16:00','present',NULL,'2026-03-13 03:18:08'),
(104,44,'2026-03-04','08:13:00','19:57:00','present',NULL,'2026-03-13 03:18:08'),
(105,1,'2026-03-03','07:08:00','17:07:00','present',NULL,'2026-03-13 03:18:08'),
(106,2,'2026-03-03','09:44:00','16:21:00','present',NULL,'2026-03-13 03:18:08'),
(107,4,'2026-03-03','08:09:00','20:32:00','present',NULL,'2026-03-13 03:18:08'),
(108,5,'2026-03-03','09:10:00','18:03:00','present',NULL,'2026-03-13 03:18:08'),
(109,37,'2026-03-03','08:35:00','19:58:00','present',NULL,'2026-03-13 03:18:08'),
(110,39,'2026-03-03','09:04:00','20:37:00','present',NULL,'2026-03-13 03:18:08'),
(111,40,'2026-03-03','10:47:00','20:40:00','present',NULL,'2026-03-13 03:18:08'),
(112,41,'2026-03-03','10:59:00','18:30:00','present',NULL,'2026-03-13 03:18:08'),
(113,42,'2026-03-03','09:08:00','19:31:00','present',NULL,'2026-03-13 03:18:08'),
(114,43,'2026-03-03','08:50:00','19:36:00','present',NULL,'2026-03-13 03:18:08'),
(115,44,'2026-03-03','09:36:00','18:50:00','present',NULL,'2026-03-13 03:18:08'),
(116,1,'2026-03-02','08:41:00','17:27:00','present',NULL,'2026-03-13 03:18:08'),
(117,2,'2026-03-02','07:51:00','18:39:00','present',NULL,'2026-03-13 03:18:08'),
(118,3,'2026-03-02','07:27:00','17:16:00','present',NULL,'2026-03-13 03:18:08'),
(119,4,'2026-03-02','08:52:00','20:15:00','present',NULL,'2026-03-13 03:18:08'),
(120,5,'2026-03-02','10:04:00','20:13:00','present',NULL,'2026-03-13 03:18:08'),
(121,37,'2026-03-02','09:35:00','20:24:00','present',NULL,'2026-03-13 03:18:08'),
(122,38,'2026-03-02','10:46:00','19:25:00','present',NULL,'2026-03-13 03:18:08'),
(123,39,'2026-03-02','10:24:00','19:28:00','present',NULL,'2026-03-13 03:18:08'),
(124,40,'2026-03-02','08:04:00','20:50:00','present',NULL,'2026-03-13 03:18:08'),
(125,41,'2026-03-02','09:56:00','20:43:00','present',NULL,'2026-03-13 03:18:08'),
(126,42,'2026-03-02','08:59:00','19:39:00','present',NULL,'2026-03-13 03:18:08'),
(127,43,'2026-03-02','08:13:00','19:05:00','present',NULL,'2026-03-13 03:18:08'),
(128,44,'2026-03-02','08:54:00','20:25:00','present',NULL,'2026-03-13 03:18:08'),
(129,40,'2026-03-01','10:35:00','18:39:00','present',NULL,'2026-03-13 03:18:08'),
(130,41,'2026-03-01','09:47:00','20:01:00','present',NULL,'2026-03-13 03:18:08'),
(131,43,'2026-03-01','09:44:00','19:10:00','present',NULL,'2026-03-13 03:18:08'),
(132,2,'2026-02-28','07:53:00','16:39:00','present',NULL,'2026-03-13 03:18:08'),
(133,40,'2026-02-28','10:02:00','19:29:00','present',NULL,'2026-03-13 03:18:08'),
(134,41,'2026-02-28','09:59:00','18:43:00','present',NULL,'2026-03-13 03:18:08'),
(135,43,'2026-02-28','08:49:00','18:40:00','present',NULL,'2026-03-13 03:18:08'),
(136,44,'2026-02-28','10:55:00','20:55:00','present',NULL,'2026-03-13 03:18:08'),
(137,1,'2026-02-27','08:05:00','19:04:00','present',NULL,'2026-03-13 03:18:08'),
(138,2,'2026-02-27','07:36:00','18:53:00','present',NULL,'2026-03-13 03:18:08'),
(139,3,'2026-02-27','09:30:00','17:44:00','present',NULL,'2026-03-13 03:18:08'),
(140,4,'2026-02-27','09:18:00','20:57:00','present',NULL,'2026-03-13 03:18:08'),
(141,5,'2026-02-27','08:18:00','18:14:00','present',NULL,'2026-03-13 03:18:08'),
(142,37,'2026-02-27','10:32:00','18:36:00','present',NULL,'2026-03-13 03:18:08'),
(143,38,'2026-02-27','08:00:00','20:05:00','present',NULL,'2026-03-13 03:18:08'),
(144,39,'2026-02-27','08:30:00',NULL,'present',NULL,'2026-03-13 03:18:08'),
(145,40,'2026-02-27','08:57:00','20:30:00','present',NULL,'2026-03-13 03:18:08'),
(146,41,'2026-02-27','10:32:00','19:27:00','present',NULL,'2026-03-13 03:18:08'),
(147,42,'2026-02-27','10:43:00',NULL,'present',NULL,'2026-03-13 03:18:08'),
(148,43,'2026-02-27','09:26:00','20:46:00','present',NULL,'2026-03-13 03:18:08'),
(149,44,'2026-02-27','08:35:00','19:45:00','present',NULL,'2026-03-13 03:18:08'),
(150,1,'2026-02-26','09:49:00','19:04:00','present',NULL,'2026-03-13 03:18:08'),
(151,2,'2026-02-26','09:13:00','18:33:00','present',NULL,'2026-03-13 03:18:08'),
(152,3,'2026-02-26','08:10:00','16:20:00','present',NULL,'2026-03-13 03:18:08'),
(153,4,'2026-02-26','08:38:00','19:24:00','present',NULL,'2026-03-13 03:18:08'),
(154,5,'2026-02-26','09:10:00','20:29:00','present',NULL,'2026-03-13 03:18:08'),
(155,37,'2026-02-26','10:48:00','19:00:00','present',NULL,'2026-03-13 03:18:08'),
(156,38,'2026-02-26','09:50:00','18:53:00','present',NULL,'2026-03-13 03:18:08'),
(157,39,'2026-02-26','10:15:00','20:17:00','present',NULL,'2026-03-13 03:18:08'),
(158,40,'2026-02-26','08:05:00','18:15:00','present',NULL,'2026-03-13 03:18:08'),
(159,41,'2026-02-26','08:45:00','20:08:00','present',NULL,'2026-03-13 03:18:08'),
(160,42,'2026-02-26','09:07:00','18:22:00','present',NULL,'2026-03-13 03:18:08'),
(161,44,'2026-02-26','08:52:00','18:26:00','present',NULL,'2026-03-13 03:18:08'),
(162,1,'2026-02-25','08:07:00',NULL,'present',NULL,'2026-03-13 03:18:08'),
(163,2,'2026-02-25','08:23:00','16:15:00','present',NULL,'2026-03-13 03:18:08'),
(164,3,'2026-02-25','09:19:00','17:18:00','present',NULL,'2026-03-13 03:18:08'),
(165,4,'2026-02-25','10:29:00','20:48:00','present',NULL,'2026-03-13 03:18:08'),
(166,5,'2026-02-25','10:28:00','20:46:00','present',NULL,'2026-03-13 03:18:08'),
(167,37,'2026-02-25','08:46:00','20:51:00','present',NULL,'2026-03-13 03:18:08'),
(168,38,'2026-02-25','10:57:00','19:05:00','present',NULL,'2026-03-13 03:18:08'),
(169,39,'2026-02-25','09:38:00','18:59:00','present',NULL,'2026-03-13 03:18:08'),
(170,40,'2026-02-25','08:52:00','20:38:00','present',NULL,'2026-03-13 03:18:08'),
(171,41,'2026-02-25','10:45:00','18:51:00','present',NULL,'2026-03-13 03:18:08'),
(172,42,'2026-02-25','08:01:00','20:13:00','present',NULL,'2026-03-13 03:18:08'),
(173,43,'2026-02-25','10:39:00','20:10:00','present',NULL,'2026-03-13 03:18:08'),
(174,44,'2026-02-25','08:04:00','19:41:00','present',NULL,'2026-03-13 03:18:08'),
(175,1,'2026-02-24','09:11:00','18:59:00','present',NULL,'2026-03-13 03:18:08'),
(176,2,'2026-02-24','09:51:00','16:07:00','present',NULL,'2026-03-13 03:18:08'),
(177,3,'2026-02-24','07:09:00','18:42:00','present',NULL,'2026-03-13 03:18:08'),
(178,4,'2026-02-24','10:46:00','20:06:00','present',NULL,'2026-03-13 03:18:08'),
(179,5,'2026-02-24','08:17:00','20:54:00','present',NULL,'2026-03-13 03:18:08'),
(180,37,'2026-02-24','08:14:00','20:36:00','present',NULL,'2026-03-13 03:18:08'),
(181,38,'2026-02-24','10:32:00','18:38:00','present',NULL,'2026-03-13 03:18:08'),
(182,39,'2026-02-24','08:37:00','20:21:00','present',NULL,'2026-03-13 03:18:08'),
(183,40,'2026-02-24','09:37:00','19:21:00','present',NULL,'2026-03-13 03:18:08'),
(184,41,'2026-02-24','09:27:00','18:37:00','present',NULL,'2026-03-13 03:18:08'),
(185,42,'2026-02-24','10:10:00','20:51:00','present',NULL,'2026-03-13 03:18:08'),
(186,43,'2026-02-24','10:51:00','20:46:00','present',NULL,'2026-03-13 03:18:08'),
(187,44,'2026-02-24','10:53:00','20:49:00','present',NULL,'2026-03-13 03:18:08'),
(188,1,'2026-02-23','07:48:00','18:07:00','present',NULL,'2026-03-13 03:18:08'),
(189,2,'2026-02-23','08:46:00','16:31:00','present',NULL,'2026-03-13 03:18:08'),
(190,3,'2026-02-23','08:21:00','18:43:00','present',NULL,'2026-03-13 03:18:08'),
(191,4,'2026-02-23','10:37:00','18:34:00','present',NULL,'2026-03-13 03:18:08'),
(192,37,'2026-02-23','10:41:00','20:35:00','present',NULL,'2026-03-13 03:18:08'),
(193,40,'2026-02-23','08:12:00','20:12:00','present',NULL,'2026-03-13 03:18:08'),
(194,41,'2026-02-23','09:16:00','20:45:00','present',NULL,'2026-03-13 03:18:08'),
(195,42,'2026-02-23','08:09:00','19:49:00','present',NULL,'2026-03-13 03:18:08'),
(196,43,'2026-02-23','08:59:00','18:39:00','present',NULL,'2026-03-13 03:18:08'),
(197,44,'2026-02-23','09:20:00','19:28:00','present',NULL,'2026-03-13 03:18:08'),
(198,1,'2026-02-22','07:25:00','19:55:00','present',NULL,'2026-03-13 03:18:08'),
(199,41,'2026-02-22','10:06:00','18:12:00','present',NULL,'2026-03-13 03:18:08'),
(200,43,'2026-02-22','10:17:00','19:37:00','present',NULL,'2026-03-13 03:18:08'),
(201,37,'2026-02-21','08:54:00','18:19:00','present',NULL,'2026-03-13 03:18:08'),
(202,44,'2026-02-21','08:43:00','18:50:00','present',NULL,'2026-03-13 03:18:08'),
(203,1,'2026-02-20','08:53:00','18:03:00','present',NULL,'2026-03-13 03:18:08'),
(204,2,'2026-02-20','07:11:00','16:32:00','present',NULL,'2026-03-13 03:18:08'),
(205,3,'2026-02-20','07:59:00','17:58:00','present',NULL,'2026-03-13 03:18:08'),
(206,4,'2026-02-20','10:47:00','18:41:00','present',NULL,'2026-03-13 03:18:08'),
(207,5,'2026-02-20','08:16:00','20:30:00','present',NULL,'2026-03-13 03:18:08'),
(208,37,'2026-02-20','08:49:00','18:35:00','present',NULL,'2026-03-13 03:18:08'),
(209,38,'2026-02-20','09:41:00','20:45:00','present',NULL,'2026-03-13 03:18:08'),
(210,39,'2026-02-20','08:51:00','18:41:00','present',NULL,'2026-03-13 03:18:08'),
(211,40,'2026-02-20','08:17:00','20:34:00','present',NULL,'2026-03-13 03:18:08'),
(212,41,'2026-02-20','08:49:00','19:54:00','present',NULL,'2026-03-13 03:18:08'),
(213,43,'2026-02-20','09:55:00','19:21:00','present',NULL,'2026-03-13 03:18:08'),
(214,44,'2026-02-20','08:09:00','18:00:00','present',NULL,'2026-03-13 03:18:08'),
(215,1,'2026-02-19','08:24:00','18:01:00','present',NULL,'2026-03-13 03:18:08'),
(216,2,'2026-02-19','07:43:00','17:48:00','present',NULL,'2026-03-13 03:18:08'),
(217,3,'2026-02-19','07:38:00','18:48:00','present',NULL,'2026-03-13 03:18:08'),
(218,4,'2026-02-19','10:55:00','20:47:00','present',NULL,'2026-03-13 03:18:08'),
(219,5,'2026-02-19','09:32:00','19:44:00','present',NULL,'2026-03-13 03:18:08'),
(220,37,'2026-02-19','08:53:00','20:18:00','present',NULL,'2026-03-13 03:18:08'),
(221,38,'2026-02-19','08:53:00','20:39:00','present',NULL,'2026-03-13 03:18:08'),
(222,39,'2026-02-19','09:08:00','20:45:00','present',NULL,'2026-03-13 03:18:08'),
(223,40,'2026-02-19','08:19:00','18:19:00','present',NULL,'2026-03-13 03:18:08'),
(224,41,'2026-02-19','09:10:00',NULL,'present',NULL,'2026-03-13 03:18:08'),
(225,42,'2026-02-19','08:04:00','18:19:00','present',NULL,'2026-03-13 03:18:08'),
(226,44,'2026-02-19','10:15:00','19:38:00','present',NULL,'2026-03-13 03:18:08'),
(227,1,'2026-02-18','09:42:00','17:11:00','present',NULL,'2026-03-13 03:18:08'),
(228,2,'2026-02-18','08:20:00','17:09:00','present',NULL,'2026-03-13 03:18:08'),
(229,3,'2026-02-18','09:28:00','17:02:00','present',NULL,'2026-03-13 03:18:08'),
(230,4,'2026-02-18','10:27:00','19:41:00','present',NULL,'2026-03-13 03:18:08'),
(231,5,'2026-02-18','09:40:00','18:24:00','present',NULL,'2026-03-13 03:18:08'),
(232,37,'2026-02-18','09:26:00','18:32:00','present',NULL,'2026-03-13 03:18:08'),
(233,38,'2026-02-18','08:35:00','19:37:00','present',NULL,'2026-03-13 03:18:08'),
(234,39,'2026-02-18','10:26:00','18:32:00','present',NULL,'2026-03-13 03:18:08'),
(235,40,'2026-02-18','10:26:00','18:32:00','present',NULL,'2026-03-13 03:18:08'),
(236,41,'2026-02-18','10:42:00','18:23:00','present',NULL,'2026-03-13 03:18:08'),
(237,42,'2026-02-18','10:50:00','19:27:00','present',NULL,'2026-03-13 03:18:08'),
(238,1,'2026-02-17','07:20:00','19:08:00','present',NULL,'2026-03-13 03:18:08'),
(239,2,'2026-02-17','08:54:00','17:00:00','present',NULL,'2026-03-13 03:18:08'),
(240,3,'2026-02-17','08:19:00','17:48:00','present',NULL,'2026-03-13 03:18:08'),
(241,4,'2026-02-17','09:02:00','18:14:00','present',NULL,'2026-03-13 03:18:08'),
(242,5,'2026-02-17','08:20:00','19:18:00','present',NULL,'2026-03-13 03:18:08'),
(243,37,'2026-02-17','08:06:00','18:40:00','present',NULL,'2026-03-13 03:18:08'),
(244,38,'2026-02-17','09:57:00','19:11:00','present',NULL,'2026-03-13 03:18:08'),
(245,39,'2026-02-17','08:12:00','19:19:00','present',NULL,'2026-03-13 03:18:08'),
(246,40,'2026-02-17','09:43:00','20:48:00','present',NULL,'2026-03-13 03:18:08'),
(247,42,'2026-02-17','09:46:00','20:17:00','present',NULL,'2026-03-13 03:18:08'),
(248,44,'2026-02-17','08:21:00','20:17:00','present',NULL,'2026-03-13 03:18:08'),
(249,1,'2026-02-16','09:29:00','18:56:00','present',NULL,'2026-03-13 03:18:08'),
(250,2,'2026-02-16','09:22:00','18:03:00','present',NULL,'2026-03-13 03:18:08'),
(251,3,'2026-02-16','07:28:00','17:35:00','present',NULL,'2026-03-13 03:18:08'),
(252,4,'2026-02-16','10:34:00','19:43:00','present',NULL,'2026-03-13 03:18:08'),
(253,5,'2026-02-16','10:44:00','19:33:00','present',NULL,'2026-03-13 03:18:08'),
(254,37,'2026-02-16','10:09:00','20:00:00','present',NULL,'2026-03-13 03:18:08'),
(255,38,'2026-02-16','09:46:00','20:43:00','present',NULL,'2026-03-13 03:18:08'),
(256,39,'2026-02-16','08:43:00','18:49:00','present',NULL,'2026-03-13 03:18:08'),
(257,40,'2026-02-16','09:47:00','18:18:00','present',NULL,'2026-03-13 03:18:08'),
(258,41,'2026-02-16','09:54:00','20:12:00','present',NULL,'2026-03-13 03:18:08'),
(259,42,'2026-02-16','09:30:00','18:28:00','present',NULL,'2026-03-13 03:18:08'),
(260,43,'2026-02-16','10:52:00','18:51:00','present',NULL,'2026-03-13 03:18:08'),
(261,44,'2026-02-16','09:01:00','19:16:00','present',NULL,'2026-03-13 03:18:08'),
(262,41,'2026-02-14','08:10:00','19:38:00','present',NULL,'2026-03-13 03:18:08'),
(263,44,'2026-02-14','08:58:00',NULL,'present',NULL,'2026-03-13 03:18:08'),
(264,1,'2026-02-13','07:27:00',NULL,'present',NULL,'2026-03-13 03:18:08'),
(265,2,'2026-02-13','09:22:00','16:24:00','present',NULL,'2026-03-13 03:18:08'),
(266,3,'2026-02-13','08:04:00','17:58:00','present',NULL,'2026-03-13 03:18:08'),
(267,4,'2026-02-13','10:41:00','18:04:00','present',NULL,'2026-03-13 03:18:08'),
(268,5,'2026-02-13','10:55:00','18:35:00','present',NULL,'2026-03-13 03:18:08'),
(269,37,'2026-02-13','08:51:00','18:12:00','present',NULL,'2026-03-13 03:18:08'),
(270,38,'2026-02-13','09:57:00','18:09:00','present',NULL,'2026-03-13 03:18:08'),
(271,39,'2026-02-13','09:35:00','20:23:00','present',NULL,'2026-03-13 03:18:08'),
(272,40,'2026-02-13','10:51:00','18:39:00','present',NULL,'2026-03-13 03:18:08'),
(273,41,'2026-02-13','08:45:00','19:05:00','present',NULL,'2026-03-13 03:18:08'),
(274,42,'2026-02-13','09:17:00','20:01:00','present',NULL,'2026-03-13 03:18:08'),
(275,43,'2026-02-13','09:48:00','18:11:00','present',NULL,'2026-03-13 03:18:08'),
(276,1,'2026-02-12','08:01:00','17:49:00','present',NULL,'2026-03-13 03:18:08'),
(277,2,'2026-02-12','07:01:00','18:22:00','present',NULL,'2026-03-13 03:18:08'),
(278,3,'2026-02-12','09:33:00','16:47:00','present',NULL,'2026-03-13 03:18:08'),
(279,4,'2026-02-12','10:19:00','20:02:00','present',NULL,'2026-03-13 03:18:08'),
(280,5,'2026-02-12','09:32:00','19:55:00','present',NULL,'2026-03-13 03:18:08'),
(281,37,'2026-02-12','08:36:00','18:33:00','present',NULL,'2026-03-13 03:18:08'),
(282,38,'2026-02-12','09:29:00','20:05:00','present',NULL,'2026-03-13 03:18:08'),
(283,39,'2026-02-12','08:04:00','18:38:00','present',NULL,'2026-03-13 03:18:08'),
(284,40,'2026-02-12','10:03:00','20:49:00','present',NULL,'2026-03-13 03:18:08'),
(285,41,'2026-02-12','10:25:00','20:47:00','present',NULL,'2026-03-13 03:18:08'),
(286,42,'2026-02-12','09:35:00','20:26:00','present',NULL,'2026-03-13 03:18:08'),
(287,44,'2026-02-12','08:47:00','19:50:00','present',NULL,'2026-03-13 03:18:08');
/*!40000 ALTER TABLE `pointages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qr_codes`
--

DROP TABLE IF EXISTS `qr_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `qr_codes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) NOT NULL,
  `type` enum('personnel','patient') NOT NULL,
  `reference_id` int(11) NOT NULL,
  `date_generation` timestamp NULL DEFAULT current_timestamp(),
  `actif` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `idx_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qr_codes`
--

LOCK TABLES `qr_codes` WRITE;
/*!40000 ALTER TABLE `qr_codes` DISABLE KEYS */;
INSERT INTO `qr_codes` VALUES
(1,'QR-ADMIN-000001','personnel',1,'2026-03-13 02:10:25',1),
(2,'QR-CAISSIER-000002','personnel',2,'2026-03-13 02:10:25',1),
(3,'QR-SAGEFEMME-000003','personnel',3,'2026-03-13 02:10:25',1),
(4,'QR-MEDECIN-000004','personnel',4,'2026-03-13 02:10:25',1),
(5,'QR-MEDECIN-000005','personnel',5,'2026-03-13 02:10:25',1);
/*!40000 ALTER TABLE `qr_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `token` varchar(10) NOT NULL,
  `priority` enum('normal','senior') DEFAULT 'normal',
  `status` enum('waiting','in_progress','completed') DEFAULT 'waiting',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `patient_id` (`patient_id`),
  KEY `service_id` (`service_id`),
  CONSTRAINT `queue_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`),
  CONSTRAINT `queue_ibfk_2` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rapport_modeles`
--

DROP TABLE IF EXISTS `rapport_modeles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rapport_modeles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `type_rapport` enum('consultations','rendezvous','patients','paiements','personnalise') NOT NULL,
  `periode` enum('jour','semaine','mois','trimestre','an') DEFAULT 'mois',
  `service_id` int(11) DEFAULT NULL,
  `destinataires` text DEFAULT NULL,
  `actif` tinyint(1) DEFAULT 1,
  `dernier_envoi` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `service_id` (`service_id`),
  CONSTRAINT `rapport_modeles_ibfk_1` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rapport_modeles`
--

LOCK TABLES `rapport_modeles` WRITE;
/*!40000 ALTER TABLE `rapport_modeles` DISABLE KEYS */;
/*!40000 ALTER TABLE `rapport_modeles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rapports`
--

DROP TABLE IF EXISTS `rapports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rapports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(255) NOT NULL,
  `type_rapport` varchar(100) DEFAULT NULL,
  `periode_debut` date DEFAULT NULL,
  `periode_fin` date DEFAULT NULL,
  `fichier_nom` varchar(255) DEFAULT NULL,
  `fichier_chemin` varchar(500) DEFAULT NULL,
  `service_id` int(11) DEFAULT NULL,
  `genere_par` int(11) DEFAULT NULL,
  `date_generation` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `service_id` (`service_id`),
  KEY `genere_par` (`genere_par`),
  CONSTRAINT `rapports_ibfk_1` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE SET NULL,
  CONSTRAINT `rapports_ibfk_2` FOREIGN KEY (`genere_par`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rapports`
--

LOCK TABLES `rapports` WRITE;
/*!40000 ALTER TABLE `rapports` DISABLE KEYS */;
/*!40000 ALTER TABLE `rapports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rendez_vous`
--

DROP TABLE IF EXISTS `rendez_vous`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rendez_vous` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `medecin_id` int(11) DEFAULT NULL,
  `date_rdv` date NOT NULL,
  `heure_rdv` time NOT NULL,
  `motif` varchar(255) DEFAULT NULL,
  `statut` enum('programme','confirme','honore','annule','reporte') DEFAULT 'programme',
  `notes` text DEFAULT NULL,
  `cree_le` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_rdv` (`medecin_id`,`date_rdv`,`heure_rdv`),
  KEY `patient_id` (`patient_id`),
  KEY `service_id` (`service_id`),
  KEY `idx_date` (`date_rdv`),
  KEY `idx_statut` (`statut`),
  CONSTRAINT `rendez_vous_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`),
  CONSTRAINT `rendez_vous_ibfk_2` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`),
  CONSTRAINT `rendez_vous_ibfk_3` FOREIGN KEY (`medecin_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rendez_vous`
--

LOCK TABLES `rendez_vous` WRITE;
/*!40000 ALTER TABLE `rendez_vous` DISABLE KEYS */;
/*!40000 ALTER TABLE `rendez_vous` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `salles`
--

DROP TABLE IF EXISTS `salles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `salles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service_id` int(11) NOT NULL,
  `batiment_id` int(11) DEFAULT NULL,
  `niveau_id` int(11) DEFAULT NULL,
  `zone_attente_id` int(11) DEFAULT NULL,
  `numero_salle` int(11) NOT NULL,
  `etage` varchar(10) DEFAULT NULL,
  `capacite` int(11) DEFAULT 10,
  `patients_en_cours` int(11) DEFAULT 0,
  `statut` enum('ouverte','fermee','maintenance') DEFAULT 'ouverte',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `code_couleur` varchar(20) DEFAULT '#3498db',
  `instructions_acces` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_salle` (`service_id`,`numero_salle`),
  CONSTRAINT `salles_ibfk_1` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salles`
--

LOCK TABLES `salles` WRITE;
/*!40000 ALTER TABLE `salles` DISABLE KEYS */;
INSERT INTO `salles` VALUES
(1,1,1,1,1,1,'RDC',10,0,'ouverte','2026-03-13 02:08:33','#3498db','Entrée principale, suivre les panneaux \"Accueil\"'),
(2,2,1,1,2,1,'RDC',10,0,'ouverte','2026-03-13 02:08:33','#2ecc71','Rez-de-chaussée, à gauche de l\'accueil'),
(3,3,3,6,4,1,'1er',10,0,'ouverte','2026-03-13 02:08:33','#e74c3c','Pavillon Pédiatrie - Entrée séparée, suivre les ballons'),
(4,4,2,4,3,1,'1er',10,0,'ouverte','2026-03-13 02:08:33','#f39c12','Bâtiment B, 1er étage - Suivre \"Odontologie\"'),
(5,5,4,8,5,1,'1er',10,0,'ouverte','2026-03-13 02:08:33','#9b59b6','Pavillon Mère-Enfant - Entrée par le jardin'),
(6,6,1,1,1,1,'2ème',10,0,'ouverte','2026-03-13 02:08:33','#1abc9c','Bâtiment A, 1er étage - Suivre \"Médecine\"'),
(7,7,1,1,1,1,'2ème',10,0,'ouverte','2026-03-13 02:08:33','#e67e22','Bâtiment A, Rez-de-chaussée - À droite de la caisse'),
(8,8,5,10,6,1,'2ème',10,0,'ouverte','2026-03-13 02:08:33','#34495e','Annexe Technique - Bâtiment C, suivre \"Cardiologie\"'),
(9,9,2,4,1,1,'3ème',10,0,'ouverte','2026-03-13 02:08:33','#3498db','Suivre les panneaux de signalisation'),
(10,10,5,10,6,1,'3ème',10,0,'ouverte','2026-03-13 02:08:33','#3498db','Suivre les panneaux de signalisation'),
(11,11,5,10,6,1,'3ème',10,0,'ouverte','2026-03-13 02:08:33','#3498db','Suivre les panneaux de signalisation'),
(12,12,2,4,1,1,'4ème',10,0,'ouverte','2026-03-13 02:08:33','#3498db','Suivre les panneaux de signalisation'),
(16,1,1,1,1,2,'RDC',10,0,'ouverte','2026-03-13 02:08:33','#3498db','Entrée principale, suivre les panneaux \"Accueil\"'),
(17,2,1,1,2,2,'RDC',10,0,'ouverte','2026-03-13 02:08:33','#2ecc71','Rez-de-chaussée, à gauche de l\'accueil'),
(18,3,3,6,4,2,'1er',10,0,'ouverte','2026-03-13 02:08:33','#e74c3c','Pavillon Pédiatrie - Entrée séparée, suivre les ballons'),
(19,4,2,4,3,2,'1er',10,0,'ouverte','2026-03-13 02:08:33','#f39c12','Bâtiment B, 1er étage - Suivre \"Odontologie\"'),
(20,5,4,8,5,2,'1er',10,0,'ouverte','2026-03-13 02:08:33','#9b59b6','Pavillon Mère-Enfant - Entrée par le jardin'),
(21,6,1,1,1,2,'2ème',10,0,'ouverte','2026-03-13 02:08:33','#1abc9c','Bâtiment A, 1er étage - Suivre \"Médecine\"'),
(22,7,1,1,1,2,'2ème',10,0,'ouverte','2026-03-13 02:08:33','#e67e22','Bâtiment A, Rez-de-chaussée - À droite de la caisse'),
(23,8,5,10,6,2,'2ème',10,0,'ouverte','2026-03-13 02:08:33','#34495e','Annexe Technique - Bâtiment C, suivre \"Cardiologie\"'),
(24,9,2,4,1,2,'3ème',10,0,'ouverte','2026-03-13 02:08:33','#3498db','Suivre les panneaux de signalisation'),
(25,10,5,10,6,2,'3ème',10,0,'ouverte','2026-03-13 02:08:33','#3498db','Suivre les panneaux de signalisation'),
(26,11,5,10,6,2,'3ème',10,0,'ouverte','2026-03-13 02:08:33','#3498db','Suivre les panneaux de signalisation'),
(27,12,2,4,1,2,'4ème',10,0,'ouverte','2026-03-13 02:08:33','#3498db','Suivre les panneaux de signalisation');
/*!40000 ALTER TABLE `salles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `secretariats`
--

DROP TABLE IF EXISTS `secretariats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `secretariats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `responsable_id` int(11) DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `responsable_id` (`responsable_id`),
  CONSTRAINT `secretariats_ibfk_1` FOREIGN KEY (`responsable_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `secretariats`
--

LOCK TABLES `secretariats` WRITE;
/*!40000 ALTER TABLE `secretariats` DISABLE KEYS */;
INSERT INTO `secretariats` VALUES
(1,'Secrétariat Général',NULL,'33 123 45 01','secretariat.general@centre.sn','2026-03-13 02:08:33'),
(2,'Secrétariat Médical',NULL,'33 123 45 02','secretariat.medical@centre.sn','2026-03-13 02:08:33'),
(3,'Secrétariat Administratif',NULL,'33 123 45 03','secretariat.admin@centre.sn','2026-03-13 02:08:33'),
(4,'Bureau des Admissions',NULL,'33 123 45 04','admissions@centre.sn','2026-03-13 02:08:33'),
(5,'Service des Ressources Humaines',NULL,'33 123 45 05','rh@centre.sn','2026-03-13 02:08:33'),
(6,'Bureau des Réunions',NULL,'33 123 45 06','reunions@centre.sn','2026-03-13 02:08:33'),
(7,'Archives Médicales',NULL,'33 123 45 07','archives@centre.sn','2026-03-13 02:08:33');
/*!40000 ALTER TABLE `secretariats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `nb_salles` int(11) DEFAULT 2,
  `prix_consultation` decimal(10,2) DEFAULT 5000.00,
  `patients_en_attente_salle1` int(11) DEFAULT 0,
  `patients_en_attente_salle2` int(11) DEFAULT 0,
  `couleur` varchar(20) DEFAULT '#3498db',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `services`
--

LOCK TABLES `services` WRITE;
/*!40000 ALTER TABLE `services` DISABLE KEYS */;
INSERT INTO `services` VALUES
(1,'Accueil/Triage','Service d\'accueil et orientation',2,5000.00,0,0,'#3498db','2026-03-12 12:54:06'),
(2,'Caisse','Service de paiement',2,5000.00,0,0,'#2ecc71','2026-03-12 12:54:06'),
(3,'Pédiatrie','Soins pour enfants',2,5000.00,0,0,'#e74c3c','2026-03-12 12:54:06'),
(4,'Odontologie','Soins dentaires',2,5000.00,0,0,'#f39c12','2026-03-12 12:54:06'),
(5,'Gynécologie','Santé de la femme',2,5000.00,0,0,'#9b59b6','2026-03-12 12:54:06'),
(6,'Médecine générale','Consultations générales',2,5000.00,0,0,'#1abc9c','2026-03-12 12:54:06'),
(7,'Pharmacie','Dispensation médicaments',2,5000.00,0,0,'#e67e22','2026-03-12 12:54:06'),
(8,'Cardiologie','Services cardiologiques et examens du cœur',2,5000.00,0,0,'#e74c3c','2026-03-13 01:48:43'),
(9,'Ophtalmologie','Soins des yeux et troubles de la vision',2,5000.00,0,0,'#3498db','2026-03-13 01:48:43'),
(10,'Diabétologie','Prise en charge du diabète',2,5000.00,0,0,'#f39c12','2026-03-13 01:48:43'),
(11,'Neurologie','Troubles du système nerveux',2,5000.00,0,0,'#9b59b6','2026-03-13 01:48:43'),
(12,'Dermatologie','Traitement des affections cutanées',2,5000.00,0,0,'#1abc9c','2026-03-13 01:48:43'),
(13,'Accueil/Triage',NULL,2,5000.00,0,0,'#3498db','2026-06-12 21:29:53'),
(14,'Cardiologie',NULL,2,5000.00,0,0,'#3498db','2026-06-12 21:29:53'),
(15,'Pharmacie',NULL,2,5000.00,0,0,'#3498db','2026-06-12 21:29:53'),
(16,'Pédiatrie',NULL,2,5000.00,0,0,'#3498db','2026-06-13 18:31:04');
/*!40000 ALTER TABLE `services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stats_journalieres`
--

DROP TABLE IF EXISTS `stats_journalieres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `stats_journalieres` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_stats` date NOT NULL,
  `service_id` int(11) DEFAULT NULL,
  `nb_consultations` int(11) DEFAULT 0,
  `nb_patients` int(11) DEFAULT 0,
  `nb_urgences` int(11) DEFAULT 0,
  `nb_rdv` int(11) DEFAULT 0,
  `recettes` decimal(10,2) DEFAULT 0.00,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_stats` (`date_stats`,`service_id`),
  KEY `service_id` (`service_id`),
  CONSTRAINT `stats_journalieres_ibfk_1` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stats_journalieres`
--

LOCK TABLES `stats_journalieres` WRITE;
/*!40000 ALTER TABLE `stats_journalieres` DISABLE KEYS */;
/*!40000 ALTER TABLE `stats_journalieres` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock`
--

DROP TABLE IF EXISTS `stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom_produit` varchar(255) NOT NULL,
  `quantite` int(11) DEFAULT 0,
  `seuil_alerte` int(11) DEFAULT 5,
  `date_ajout` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock`
--

LOCK TABLES `stock` WRITE;
/*!40000 ALTER TABLE `stock` DISABLE KEYS */;
INSERT INTO `stock` VALUES
(1,'Paracétamol',50,10,'2026-06-12 21:29:53'),
(2,'Amoxicilline',20,5,'2026-06-12 21:29:53'),
(3,'Ibuprofène',0,10,'2026-06-12 21:29:53');
/*!40000 ALTER TABLE `stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `traitements`
--

DROP TABLE IF EXISTS `traitements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `traitements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_id` int(11) NOT NULL,
  `medicament` varchar(255) NOT NULL,
  `posologie` text DEFAULT NULL,
  `duree` varchar(100) DEFAULT NULL,
  `date_prescription` date DEFAULT NULL,
  `medecin_prescripteur` varchar(100) DEFAULT NULL,
  `instructions` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `patient_id` (`patient_id`),
  CONSTRAINT `traitements_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `traitements`
--

LOCK TABLES `traitements` WRITE;
/*!40000 ALTER TABLE `traitements` DISABLE KEYS */;
INSERT INTO `traitements` VALUES
(1,1,'Paracétamol',NULL,NULL,NULL,'Dr. Fall',NULL,'2026-06-12 21:30:18');
/*!40000 ALTER TABLE `traitements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','medecin','sagefemme','caissier','pharmacien','secretariat') NOT NULL,
  `code_personnel` varchar(20) DEFAULT NULL,
  `service_id` int(11) DEFAULT NULL,
  `planning_json` text DEFAULT NULL,
  `prenom` varchar(100) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `specialite` varchar(100) DEFAULT NULL,
  `numero_ordre` varchar(50) DEFAULT NULL,
  `qr_code` varchar(255) DEFAULT NULL,
  `dernier_pointage` datetime DEFAULT NULL,
  `heures_travaillees` decimal(10,2) DEFAULT 0.00,
  `actif` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `consultation_duree` int(11) DEFAULT 15 COMMENT 'Durée moyenne d''une consultation en minutes',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `code_personnel` (`code_personnel`),
  KEY `idx_role` (`role`),
  KEY `idx_service` (`service_id`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'admin','$2y$10$IFBqtvyzSqNL3ndk47FuEeEOGNoSsxVJ.wsxivIBPAdP7SxMQMXzm','admin',NULL,1,NULL,'Admin','System',NULL,NULL,NULL,NULL,'QR-ADMIN-000001',NULL,198.00,1,'2026-03-12 12:54:07',15),
(2,'caissier1','$2y$10$45935n39Snn0XUdRXvWnU.5YcyHHh7LsfOxhAC4cdxqi3l4nnkzmG','caissier','CS-002',2,NULL,'Oumar','Sow',NULL,NULL,NULL,NULL,'QR-CAISSIER-000002',NULL,182.00,1,'2026-03-12 12:54:08',15),
(3,'sagefemme1','$2y$10$I8wxEcH8EwRYgHsCGKuqeO12m4ZC1t5fUUE0vxjixLqzhnoEE0KBC','sagefemme','SF-003',5,NULL,'Fatou','Ndiaye',NULL,NULL,NULL,NULL,'QR-SAGEFEMME-000003',NULL,165.00,1,'2026-03-12 12:54:08',15),
(4,'dr.fall','$2y$10$pXOOFQ4TgXte7lFD9VQxXOe/CZg2sMHqPcL.YtcOi1cOJ/T/NFwF.','medecin','MED-PED-0004',3,NULL,'Aminata','Fall',NULL,NULL,NULL,NULL,'QR-MEDECIN-000004',NULL,200.00,1,'2026-03-12 12:54:08',15),
(5,'dr.diop','$2y$10$oELPVqgUiSAKtdEz3tyLg.HfQOOZKaypwYf3Cw.4P76.pLaM/CmNy','medecin','MED-ODT-0005',4,NULL,'Moussa','Diop',NULL,NULL,NULL,NULL,'QR-MEDECIN-000005',NULL,199.00,1,'2026-03-12 12:54:08',15),
(37,'dr.ndiaye','$2y$10$oELPVqgUiSAKtdEz3tyLg.HfQOOZKaypwYf3Cw.4P76.pLaM/CmNy','medecin','MED-CAR-0001',8,NULL,'Moussa','Ndiaye','77 123 45 67','dr.ndiaye@centre.sn','Cardiologue interventionnel',NULL,NULL,NULL,204.00,1,'2026-03-13 02:13:18',15),
(38,'dr.seck','$2y$10$oELPVqgUiSAKtdEz3tyLg.HfQOOZKaypwYf3Cw.4P76.pLaM/CmNy','medecin','MED-OPH-0001',9,NULL,'Fatou','Seck','70 456 78 90','dr.seck@centre.sn','Ophtalmologue pédiatrique',NULL,NULL,NULL,176.00,1,'2026-03-13 02:13:18',15),
(39,'dr.ba','$2y$10$oELPVqgUiSAKtdEz3tyLg.HfQOOZKaypwYf3Cw.4P76.pLaM/CmNy','medecin','MED-DIA-0001',10,NULL,'Ibrahima','Ba','77 567 89 01','dr.ba@centre.sn','Diabétologue',NULL,NULL,NULL,193.00,1,'2026-03-13 02:13:19',15),
(40,'dr.gueye','$2y$10$oELPVqgUiSAKtdEz3tyLg.HfQOOZKaypwYf3Cw.4P76.pLaM/CmNy','medecin','MED-DIA-0002',10,NULL,'Mariama','Gueye','78 678 90 12','dr.gueye@centre.sn','Nutritionniste',NULL,NULL,NULL,217.00,1,'2026-03-13 02:13:19',15),
(41,'dr.cisse','$2y$10$oELPVqgUiSAKtdEz3tyLg.HfQOOZKaypwYf3Cw.4P76.pLaM/CmNy','medecin','MED-NEU-0001',11,NULL,'Cheikh','Cissé','76 789 01 23','dr.cisse@centre.sn','Neurologue',NULL,NULL,NULL,213.00,1,'2026-03-13 02:13:19',15),
(42,'dr.thiam','$2y$10$oELPVqgUiSAKtdEz3tyLg.HfQOOZKaypwYf3Cw.4P76.pLaM/CmNy','medecin','MED-NEU-0002',11,NULL,'Awa','Thiam','70 890 12 34','dr.thiam@centre.sn','Neuropédiatre',NULL,NULL,NULL,192.00,1,'2026-03-13 02:13:19',15),
(43,'dr.sow','$2y$10$oELPVqgUiSAKtdEz3tyLg.HfQOOZKaypwYf3Cw.4P76.pLaM/CmNy','medecin','MED-DER-0001',12,NULL,'Papa','Sow','77 901 23 45','dr.sow@centre.sn','Dermatologue',NULL,NULL,NULL,178.00,1,'2026-03-13 02:13:19',15),
(44,'dr.kane','$2y$10$oELPVqgUiSAKtdEz3tyLg.HfQOOZKaypwYf3Cw.4P76.pLaM/CmNy','medecin','MED-DER-0002',12,NULL,'Rokhaya','Kane','78 012 34 56','dr.kane@centre.sn','Dermato-pédiatre',NULL,NULL,NULL,226.00,1,'2026-03-13 02:13:20',15),
(45,'caissier2','$2y$10$Ew.Y/iV0C0b7gM6rM1C.J.8XjPqV6s1lG7fL/fNf2Ff2Ff2Ff2Ff2','caissier','CS-003',2,NULL,'Fatou','Dieng',NULL,NULL,NULL,NULL,NULL,NULL,0.00,1,'2026-03-15 04:16:32',15),
(46,'caissier.diop','$2y$10$Ew.Y/iV0C0b7gM6rM1C.J.8XjPqV6s1lG7fL/fNf2Ff2Ff2Ff2Ff2','caissier',NULL,2,NULL,'Oumar','Diop',NULL,NULL,NULL,NULL,NULL,NULL,0.00,1,'2026-03-15 12:22:53',15),
(47,'caissier.ndiaye','$2y$10$Ew.Y/iV0C0b7gM6rM1C.J.8XjPqV6s1lG7fL/fNf2Ff2Ff2Ff2Ff2','caissier',NULL,2,NULL,'Fatou','Ndiaye',NULL,NULL,NULL,NULL,NULL,NULL,0.00,1,'2026-03-15 12:22:53',15),
(48,'caissier.fall','$2y$10$Ew.Y/iV0C0b7gM6rM1C.J.8XjPqV6s1lG7fL/fNf2Ff2Ff2Ff2Ff2','caissier',NULL,2,NULL,'Aminata','Fall',NULL,NULL,NULL,NULL,NULL,NULL,0.00,1,'2026-03-15 12:22:53',15),
(49,'pharmacie1','$2y$10$Euji8BvY1tzJvBSbTEWVTeDPrkcJ1HtFhrYL2wl/cpqypeDktNhSi','pharmacien',NULL,NULL,NULL,'Pharmacie','Diop',NULL,NULL,NULL,NULL,NULL,NULL,0.00,1,'2026-06-11 15:50:00',15),
(50,'secretariat','$2y$10$bKlr8bNki4r8it9Zgmd/dugM000iiT9EWeCZis8994dDt8hSoXYmu','secretariat',NULL,NULL,NULL,'Agent','Secretariat',NULL,NULL,NULL,NULL,NULL,NULL,0.00,1,'2026-06-12 11:19:10',15);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `vue_medecin_salle`
--

DROP TABLE IF EXISTS `vue_medecin_salle`;
/*!50001 DROP VIEW IF EXISTS `vue_medecin_salle`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vue_medecin_salle` AS SELECT
 1 AS `medecin_id`,
  1 AS `prenom`,
  1 AS `nom`,
  1 AS `username`,
  1 AS `service_id`,
  1 AS `service_nom`,
  1 AS `salle_id`,
  1 AS `numero_salle`,
  1 AS `etage`,
  1 AS `batiment`,
  1 AS `niveau`,
  1 AS `zone_attente` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `zones_attente`
--

DROP TABLE IF EXISTS `zones_attente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `zones_attente` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `batiment_id` int(11) NOT NULL,
  `niveau_id` int(11) NOT NULL,
  `couleur` varchar(20) DEFAULT '#3498db',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `batiment_id` (`batiment_id`),
  KEY `niveau_id` (`niveau_id`),
  CONSTRAINT `zones_attente_ibfk_1` FOREIGN KEY (`batiment_id`) REFERENCES `batiments` (`id`),
  CONSTRAINT `zones_attente_ibfk_2` FOREIGN KEY (`niveau_id`) REFERENCES `niveaux` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zones_attente`
--

LOCK TABLES `zones_attente` WRITE;
/*!40000 ALTER TABLE `zones_attente` DISABLE KEYS */;
INSERT INTO `zones_attente` VALUES
(1,'Salle d\'attente A1',1,1,'#3498db','2026-03-14 00:40:09'),
(2,'Salle d\'attente A2',1,1,'#2ecc71','2026-03-14 00:40:09'),
(3,'Salle d\'attente B1',2,4,'#e74c3c','2026-03-14 00:40:09'),
(4,'Espace Pédiatrie',3,6,'#f39c12','2026-03-14 00:40:09'),
(5,'Espace Maternité',4,8,'#9b59b6','2026-03-14 00:40:09'),
(6,'Salle technique',5,10,'#1abc9c','2026-03-14 00:40:09');
/*!40000 ALTER TABLE `zones_attente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `vue_medecin_salle`
--

/*!50001 DROP VIEW IF EXISTS `vue_medecin_salle`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vue_medecin_salle` AS select `u`.`id` AS `medecin_id`,`u`.`prenom` AS `prenom`,`u`.`nom` AS `nom`,`u`.`username` AS `username`,`u`.`service_id` AS `service_id`,`s`.`name` AS `service_nom`,`sa`.`id` AS `salle_id`,`sa`.`numero_salle` AS `numero_salle`,`sa`.`etage` AS `etage`,`b`.`nom` AS `batiment`,`n`.`nom` AS `niveau`,`za`.`nom` AS `zone_attente` from (((((`users` `u` join `services` `s` on(`u`.`service_id` = `s`.`id`)) join `salles` `sa` on(`s`.`id` = `sa`.`service_id`)) left join `batiments` `b` on(`sa`.`batiment_id` = `b`.`id`)) left join `niveaux` `n` on(`sa`.`niveau_id` = `n`.`id`)) left join `zones_attente` `za` on(`sa`.`zone_attente_id` = `za`.`id`)) where `u`.`role` = 'medecin' and `u`.`actif` = 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-22 16:35:46
