/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: transport_omega
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `affectations`
--

DROP TABLE IF EXISTS `affectations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `affectations` (
  `id_affectation` int(11) NOT NULL AUTO_INCREMENT,
  `id_eleve` int(11) NOT NULL,
  `id_bus` int(11) NOT NULL,
  `date_affectation` date DEFAULT curdate(),
  `sens_trajet` enum('matin_ecole','soir_domicile') NOT NULL,
  PRIMARY KEY (`id_affectation`),
  KEY `id_eleve` (`id_eleve`),
  KEY `id_bus` (`id_bus`),
  CONSTRAINT `affectations_ibfk_1` FOREIGN KEY (`id_eleve`) REFERENCES `eleves` (`id_eleve`),
  CONSTRAINT `affectations_ibfk_2` FOREIGN KEY (`id_bus`) REFERENCES `bus` (`id_bus`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `affectations`
--

LOCK TABLES `affectations` WRITE;
/*!40000 ALTER TABLE `affectations` DISABLE KEYS */;
/*!40000 ALTER TABLE `affectations` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER verifier_capacite_bus
BEFORE INSERT ON affectations
FOR EACH ROW
BEGIN
    DECLARE nb_eleves INT;
    SELECT COUNT(*) INTO nb_eleves FROM affectations 
    WHERE id_bus = NEW.id_bus AND sens_trajet = NEW.sens_trajet;
    IF nb_eleves >= 20 THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Ce bus a déjà atteint sa capacité maximale de 20 élèves';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER check_assurance_before_affectation
BEFORE INSERT ON affectations
FOR EACH ROW
BEGIN
    DECLARE assurance_active INT;
    SELECT COUNT(*) INTO assurance_active 
    FROM assurances_bus 
    WHERE id_bus = NEW.id_bus 
    AND statut = 'active' 
    AND CURDATE() BETWEEN date_debut AND date_fin;
    
    IF assurance_active = 0 THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Ce bus n\'a pas d\'assurance valide !';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `assurances_bus`
--

DROP TABLE IF EXISTS `assurances_bus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `assurances_bus` (
  `id_assurance` int(11) NOT NULL AUTO_INCREMENT,
  `id_bus` int(11) NOT NULL,
  `compagnie_assurance` varchar(100) NOT NULL,
  `numero_police` varchar(50) NOT NULL,
  `type_assurance` enum('tous_risques','tiers','responsabilite_civile') DEFAULT 'tiers',
  `date_debut` date NOT NULL,
  `date_fin` date NOT NULL,
  `prime_annuelle` decimal(12,2) NOT NULL,
  `id_facture_assurance` int(11) DEFAULT NULL,
  `statut` enum('active','expiree','resiliee') DEFAULT 'active',
  PRIMARY KEY (`id_assurance`),
  KEY `id_bus` (`id_bus`),
  KEY `id_facture_assurance` (`id_facture_assurance`),
  CONSTRAINT `assurances_bus_ibfk_1` FOREIGN KEY (`id_bus`) REFERENCES `bus` (`id_bus`),
  CONSTRAINT `assurances_bus_ibfk_2` FOREIGN KEY (`id_facture_assurance`) REFERENCES `factures_parc` (`id_facture`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assurances_bus`
--

LOCK TABLES `assurances_bus` WRITE;
/*!40000 ALTER TABLE `assurances_bus` DISABLE KEYS */;
INSERT INTO `assurances_bus` VALUES
(1,1,'SUNU Assurance','POL-SUNU-001','tous_risques','2025-01-01','2025-12-31',450000.00,NULL,'active'),
(2,2,'AXA Sénégal','POL-AXA-002','tiers','2025-02-01','2026-01-31',320000.00,NULL,'active'),
(3,3,'Allianz','POL-ALL-003','tiers','2024-06-01','2025-05-31',300000.00,NULL,'expiree');
/*!40000 ALTER TABLE `assurances_bus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bus`
--

DROP TABLE IF EXISTS `bus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bus` (
  `id_bus` int(11) NOT NULL AUTO_INCREMENT,
  `immatriculation` varchar(20) NOT NULL,
  `modele` varchar(50) DEFAULT NULL,
  `capacite_max` int(11) DEFAULT 20 CHECK (`capacite_max` <= 20),
  `photo_principale` varchar(255) DEFAULT NULL,
  `statut_bus` enum('operationnel','maintenance','hors_service') DEFAULT 'operationnel',
  `consommation_moyenne` decimal(5,2) DEFAULT NULL,
  PRIMARY KEY (`id_bus`),
  UNIQUE KEY `immatriculation` (`immatriculation`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bus`
--

LOCK TABLES `bus` WRITE;
/*!40000 ALTER TABLE `bus` DISABLE KEYS */;
INSERT INTO `bus` VALUES
(1,'DK-123-AB','Toyota Coaster',20,NULL,'operationnel',12.50),
(2,'DK-456-CD','Mercedes Sprinter',20,NULL,'operationnel',13.00),
(3,'DK-789-EF','Hyundai County',20,NULL,'operationnel',11.80);
/*!40000 ALTER TABLE `bus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories_depenses`
--

DROP TABLE IF EXISTS `categories_depenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories_depenses` (
  `id_categorie` int(11) NOT NULL AUTO_INCREMENT,
  `nom_categorie` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `code_comptable` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_categorie`),
  UNIQUE KEY `nom_categorie` (`nom_categorie`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories_depenses`
--

LOCK TABLES `categories_depenses` WRITE;
/*!40000 ALTER TABLE `categories_depenses` DISABLE KEYS */;
INSERT INTO `categories_depenses` VALUES
(1,'Carburant','Toutes réparations liées au moteur','60101'),
(2,'Réparation carrosserie','Carrosserie et peinture','60102'),
(3,'Réparation moteur','Vidange, filtres, courroies','60103'),
(4,'Pneumatiques','Achat et réparation pneus','60104'),
(5,'Assurance','Primes d\'assurance','61101'),
(6,'Pièces détachées','Achat de pièces de rechange','60701'),
(7,'Taxes et vignettes','Frais de mécanicien','62101'),
(8,'Salaires mécaniciens','Salaires du personnel technique',NULL),
(9,'Main d\'œuvre','Main d\'œuvre externe',NULL),
(11,'Lavage','Nettoyage des bus',NULL),
(12,'Divers','Autres dépenses',NULL);
/*!40000 ALTER TABLE `categories_depenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charges`
--

DROP TABLE IF EXISTS `charges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `charges` (
  `id_charge` int(11) NOT NULL AUTO_INCREMENT,
  `reference_charge` varchar(50) DEFAULT NULL,
  `id_categorie` int(11) DEFAULT NULL,
  `id_fournisseur` int(11) DEFAULT NULL,
  `id_bus` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `montant_ht` decimal(12,2) DEFAULT NULL,
  `montant_tva` decimal(12,2) DEFAULT 0.00,
  `montant_ttc` decimal(12,2) DEFAULT NULL,
  `date_charge` date DEFAULT NULL,
  `mode_paiement` enum('especes','wave','orange_money','virement','cheque') DEFAULT 'especes',
  `statut_paiement` enum('paye','impaye','partiel') DEFAULT 'paye',
  `facture_scannee` varchar(255) DEFAULT NULL,
  `date_saisie` datetime DEFAULT current_timestamp(),
  `id_secretaire` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_charge`),
  UNIQUE KEY `reference_charge` (`reference_charge`),
  KEY `id_categorie` (`id_categorie`),
  KEY `id_fournisseur` (`id_fournisseur`),
  KEY `id_bus` (`id_bus`),
  CONSTRAINT `charges_ibfk_1` FOREIGN KEY (`id_categorie`) REFERENCES `categories_depenses` (`id_categorie`),
  CONSTRAINT `charges_ibfk_2` FOREIGN KEY (`id_fournisseur`) REFERENCES `fournisseurs` (`id_fournisseur`),
  CONSTRAINT `charges_ibfk_3` FOREIGN KEY (`id_bus`) REFERENCES `bus` (`id_bus`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charges`
--

LOCK TABLES `charges` WRITE;
/*!40000 ALTER TABLE `charges` DISABLE KEYS */;
INSERT INTO `charges` VALUES
(1,'CHG202604167091',1,4,1,'Carburant - Plein complet DK-123-AB',NULL,0.00,75000.00,'2026-04-15','wave','paye',NULL,'2026-04-16 22:55:37',NULL),
(2,'CHG202604164860',1,4,2,'Carburant - Plein complet DK-456-CD',NULL,0.00,68000.00,'2026-04-10','especes','paye',NULL,'2026-04-16 22:55:37',NULL),
(3,'CHG202604163029',1,4,3,'Carburant - DK-789-EF',NULL,0.00,72000.00,'2026-04-05','orange_money','paye',NULL,'2026-04-16 22:55:37',NULL),
(4,'CHG202604160563',2,1,1,'Vidange + révision 5000km DK-123-AB',NULL,0.00,120000.00,'2026-04-08','virement','paye',NULL,'2026-04-16 22:55:37',NULL),
(5,'CHG202604163730',8,2,NULL,'Salaire mécanicien - Avril 2026',NULL,0.00,250000.00,'2026-04-30','virement','paye',NULL,'2026-04-16 22:55:37',NULL),
(6,'CHG202604166962',9,2,1,'Main d\'œuvre réparation freins',NULL,0.00,45000.00,'2026-04-12','especes','paye',NULL,'2026-04-16 22:55:37',NULL),
(7,'CHG202604163620',11,NULL,1,'Lavage bus DK-123-AB',NULL,0.00,15000.00,'2026-04-14','especes','paye',NULL,'2026-04-16 22:55:37',NULL),
(8,'CHG202604167216',11,NULL,2,'Lavage bus DK-456-CD',NULL,0.00,15000.00,'2026-04-14','especes','paye',NULL,'2026-04-16 22:55:37',NULL),
(9,'CHG202604165220',1,4,1,'Carburant Mars DK-123-AB',NULL,0.00,72000.00,'2026-03-15','wave','paye',NULL,'2026-04-16 22:55:37',NULL),
(10,'CHG202604164451',1,4,2,'Carburant Mars DK-456-CD',NULL,0.00,65000.00,'2026-03-10','especes','paye',NULL,'2026-04-16 22:55:37',NULL),
(11,'CHG202604166596',3,2,1,'Réparation moteur - Joint culasse',NULL,0.00,350000.00,'2026-03-20','virement','paye',NULL,'2026-04-16 22:55:37',NULL),
(12,'CHG202604169627',4,3,1,'Achat bougies + filtres',NULL,0.00,65000.00,'2026-03-20','wave','paye',NULL,'2026-04-16 22:55:37',NULL),
(13,'CHG202604168347',5,1,1,'2 pneus neufs avant',NULL,0.00,180000.00,'2026-03-05','cheque','paye',NULL,'2026-04-16 22:55:37',NULL),
(14,'CHG202604162854',8,2,NULL,'Salaire mécanicien - Mars 2026',NULL,0.00,250000.00,'2026-03-31','virement','paye',NULL,'2026-04-16 22:55:37',NULL),
(15,'CHG202604169232',2,1,2,'Entretien courant DK-456-CD',NULL,0.00,95000.00,'2026-03-18','virement','paye',NULL,'2026-04-16 22:55:37',NULL),
(16,'CHG202604167598',1,4,1,'Carburant Février DK-123-AB',NULL,0.00,70000.00,'2026-02-15','wave','paye',NULL,'2026-04-16 22:55:37',NULL),
(17,'CHG202604160293',1,4,2,'Carburant Février DK-456-CD',NULL,0.00,68000.00,'2026-02-12','especes','paye',NULL,'2026-04-16 22:55:37',NULL),
(18,'CHG202604168673',1,4,3,'Carburant Février DK-789-EF',NULL,0.00,71000.00,'2026-02-08','orange_money','paye',NULL,'2026-04-16 22:55:37',NULL),
(19,'CHG202604162488',10,2,2,'Réparation carrosserie DK-456-CD',NULL,0.00,125000.00,'2026-02-20','virement','paye',NULL,'2026-04-16 22:55:37',NULL),
(20,'CHG202604166420',6,5,NULL,'Assurance annuelle flotte',NULL,0.00,1050000.00,'2026-02-01','virement','paye',NULL,'2026-04-16 22:55:37',NULL),
(21,'CHG202604164637',8,2,NULL,'Salaire mécanicien - Février 2026',NULL,0.00,250000.00,'2026-02-28','virement','paye',NULL,'2026-04-16 22:55:37',NULL),
(22,'CHG202604163925',4,3,2,'Achat plaquettes de frein',NULL,0.00,45000.00,'2026-02-22','wave','paye',NULL,'2026-04-16 22:55:37',NULL),
(23,'CHG202604165713',1,4,1,'Carburant Janvier DK-123-AB',NULL,0.00,73000.00,'2026-01-15','wave','paye',NULL,'2026-04-16 22:55:37',NULL),
(24,'CHG202604166791',1,4,2,'Carburant Janvier DK-456-CD',NULL,0.00,69000.00,'2026-01-12','especes','paye',NULL,'2026-04-16 22:55:37',NULL),
(25,'CHG202604166819',7,NULL,NULL,'Vignette 2026 - Tous bus',NULL,0.00,150000.00,'2026-01-10','especes','paye',NULL,'2026-04-16 22:55:37',NULL),
(26,'CHG202604163720',8,2,NULL,'Salaire mécanicien - Janvier 2026',NULL,0.00,250000.00,'2026-01-31','virement','paye',NULL,'2026-04-16 22:55:37',NULL),
(27,'CHG202604168145',2,1,3,'Entretien DK-789-EF',NULL,0.00,85000.00,'2026-01-25','virement','paye',NULL,'2026-04-16 22:55:37',NULL),
(28,'CHG202604169563',12,NULL,NULL,'Fournitures bureau secrétariat',NULL,0.00,35000.00,'2026-01-05','especes','paye',NULL,'2026-04-16 22:55:37',NULL),
(29,'CHG202604163382',1,4,1,'Carburant Décembre DK-123-AB',NULL,0.00,74000.00,'2025-12-15','wave','paye',NULL,'2026-04-16 22:55:37',NULL),
(30,'CHG202604168220',1,4,2,'Carburant Décembre DK-456-CD',NULL,0.00,67000.00,'2025-12-12','especes','paye',NULL,'2026-04-16 22:55:37',NULL),
(31,'CHG202604160954',1,4,3,'Carburant Décembre DK-789-EF',NULL,0.00,70000.00,'2025-12-08','orange_money','paye',NULL,'2026-04-16 22:55:37',NULL),
(32,'CHG202604160111',8,2,NULL,'Salaire mécanicien - Décembre 2025',NULL,0.00,250000.00,'2025-12-31','virement','paye',NULL,'2026-04-16 22:55:37',NULL),
(33,'CHG202604167694',5,1,3,'4 pneus DK-789-EF',NULL,0.00,360000.00,'2025-12-18','cheque','paye',NULL,'2026-04-16 22:55:37',NULL),
(34,'CHG202604168139',3,2,2,'Réparation embrayage DK-456-CD',NULL,0.00,280000.00,'2025-12-22','virement','paye',NULL,'2026-04-16 22:55:37',NULL),
(35,'CHG202604167610',1,4,1,'Carburant Novembre DK-123-AB',NULL,0.00,71000.00,'2025-11-15','wave','paye',NULL,'2026-04-16 22:55:37',NULL),
(36,'CHG202604163636',1,4,2,'Carburant Novembre DK-456-CD',NULL,0.00,66000.00,'2025-11-12','especes','paye',NULL,'2026-04-16 22:55:37',NULL),
(37,'CHG202604165352',8,2,NULL,'Salaire mécanicien - Novembre 2025',NULL,0.00,250000.00,'2025-11-30','virement','paye',NULL,'2026-04-16 22:55:37',NULL),
(38,'CHG202604165849',4,3,1,'Achat batterie',NULL,0.00,85000.00,'2025-11-20','wave','paye',NULL,'2026-04-16 22:55:37',NULL),
(39,'CHG202604163191',9,2,3,'Main d\'œuvre révision',NULL,0.00,55000.00,'2025-11-25','especes','paye',NULL,'2026-04-16 22:55:37',NULL);
/*!40000 ALTER TABLE `charges` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER before_insert_charges
BEFORE INSERT ON charges
FOR EACH ROW
BEGIN
    DECLARE new_ref VARCHAR(50);
    SET new_ref = CONCAT('CHG', DATE_FORMAT(NOW(), '%Y%m%d'), LPAD(FLOOR(RAND() * 10000), 4, '0'));
    WHILE EXISTS (SELECT 1 FROM charges WHERE reference_charge = new_ref) DO
        SET new_ref = CONCAT('CHG', DATE_FORMAT(NOW(), '%Y%m%d'), LPAD(FLOOR(RAND() * 10000), 4, '0'));
    END WHILE;
    SET NEW.reference_charge = new_ref;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `chauffeurs`
--

DROP TABLE IF EXISTS `chauffeurs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chauffeurs` (
  `id_chauffeur` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `telephone` varchar(20) NOT NULL,
  `permis_conduire` varchar(30) NOT NULL,
  `date_embauche` date DEFAULT NULL,
  `statut_chauffeur` enum('actif','conge','suspendu') DEFAULT 'actif',
  `photo_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_chauffeur`),
  UNIQUE KEY `telephone` (`telephone`),
  UNIQUE KEY `permis_conduire` (`permis_conduire`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chauffeurs`
--

LOCK TABLES `chauffeurs` WRITE;
/*!40000 ALTER TABLE `chauffeurs` DISABLE KEYS */;
INSERT INTO `chauffeurs` VALUES
(1,'Diop','Mamadou','771234567','PERM-001','2024-01-15','actif',NULL),
(2,'Ndiaye','Aissatou','772345678','PERM-002','2024-02-01','actif',NULL),
(3,'Fall','Oumar','773456789','PERM-003','2024-03-10','actif',NULL);
/*!40000 ALTER TABLE `chauffeurs` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER log_chauffeur_statut
AFTER UPDATE ON chauffeurs
FOR EACH ROW
BEGIN
    IF OLD.statut_chauffeur != NEW.statut_chauffeur THEN
        INSERT INTO logs_chauffeur (id_chauffeur, ancien_statut, nouveau_statut)
        VALUES (NEW.id_chauffeur, OLD.statut_chauffeur, NEW.statut_chauffeur);
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `ecoles`
--

DROP TABLE IF EXISTS `ecoles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ecoles` (
  `id_ecole` int(11) NOT NULL AUTO_INCREMENT,
  `nom_ecole` varchar(100) NOT NULL,
  `adresse_ecole` text DEFAULT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `horaire_matin` time NOT NULL,
  `horaire_soir` time NOT NULL,
  PRIMARY KEY (`id_ecole`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ecoles`
--

LOCK TABLES `ecoles` WRITE;
/*!40000 ALTER TABLE `ecoles` DISABLE KEYS */;
INSERT INTO `ecoles` VALUES
(1,'École Internationale de Dakar','Mermoz',14.69370000,-17.44470000,'07:30:00','16:30:00'),
(2,'Lycée Jean Mermoz','Fann',14.68910000,-17.46630000,'07:45:00','16:45:00'),
(3,'École Française de Dakar','Plateau',14.67220000,-17.43710000,'08:00:00','17:00:00');
/*!40000 ALTER TABLE `ecoles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eleves`
--

DROP TABLE IF EXISTS `eleves`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `eleves` (
  `id_eleve` int(11) NOT NULL AUTO_INCREMENT,
  `id_parent` int(11) NOT NULL,
  `id_ecole` int(11) NOT NULL,
  `code_eleve` varchar(20) DEFAULT NULL,
  `nom_eleve` varchar(50) NOT NULL,
  `prenom_eleve` varchar(50) NOT NULL,
  `classe` varchar(20) DEFAULT NULL,
  `photo_url` varchar(255) DEFAULT NULL,
  `date_naissance` date DEFAULT NULL,
  `point_prise_en_charge` varchar(255) DEFAULT NULL,
  `latitude_prise` decimal(10,8) DEFAULT NULL,
  `longitude_prise` decimal(11,8) DEFAULT NULL,
  `statut_inscription` enum('en_attente','valide','refuse') DEFAULT 'en_attente',
  PRIMARY KEY (`id_eleve`),
  UNIQUE KEY `code_eleve` (`code_eleve`),
  KEY `id_parent` (`id_parent`),
  KEY `id_ecole` (`id_ecole`),
  KEY `idx_code_eleve` (`code_eleve`),
  CONSTRAINT `eleves_ibfk_1` FOREIGN KEY (`id_parent`) REFERENCES `parents` (`id_parent`) ON DELETE CASCADE,
  CONSTRAINT `eleves_ibfk_2` FOREIGN KEY (`id_ecole`) REFERENCES `ecoles` (`id_ecole`),
  CONSTRAINT `chk_code_eleve_format` CHECK (`code_eleve` regexp '^E[0-9]{13}$')
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eleves`
--

LOCK TABLES `eleves` WRITE;
/*!40000 ALTER TABLE `eleves` DISABLE KEYS */;
INSERT INTO `eleves` VALUES
(1,1,1,'E7812345676336','DIOP','Marième','CM1',NULL,NULL,NULL,NULL,NULL,'valide');
/*!40000 ALTER TABLE `eleves` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER before_insert_eleves
BEFORE INSERT ON eleves
FOR EACH ROW
BEGIN
    DECLARE parent_phone VARCHAR(20);
    DECLARE base_code VARCHAR(20);
    DECLARE final_code VARCHAR(20);
    DECLARE phone_clean VARCHAR(20);
    
    
    IF NEW.code_eleve IS NOT NULL AND NEW.code_eleve != '' THEN
        SET final_code = NEW.code_eleve;
    ELSE
        
        SELECT telephone INTO parent_phone FROM parents WHERE id_parent = NEW.id_parent;
        
        
        SET phone_clean = REGEXP_REPLACE(parent_phone, '[^0-9]', '');
        IF LENGTH(phone_clean) >= 9 THEN
            SET phone_clean = RIGHT(phone_clean, 9);
        ELSE
            SET phone_clean = LPAD(phone_clean, 9, '0');
        END IF;
        
        
        SET base_code = CONCAT('E', phone_clean);
        SET final_code = CONCAT(base_code, LPAD(FLOOR(RAND() * 10000), 4, '0'));
        
        
        WHILE EXISTS (SELECT 1 FROM eleves WHERE code_eleve = final_code) DO
            SET final_code = CONCAT(base_code, LPAD(FLOOR(RAND() * 10000), 4, '0'));
        END WHILE;
    END IF;
    
    SET NEW.code_eleve = final_code;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `factures_parc`
--

DROP TABLE IF EXISTS `factures_parc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `factures_parc` (
  `id_facture` int(11) NOT NULL AUTO_INCREMENT,
  `numero_facture` varchar(50) NOT NULL,
  `date_facture` date NOT NULL,
  `id_bus` int(11) DEFAULT NULL,
  `type_facture` enum('reparation','assurance','pieces','main_oeuvre','mixte') NOT NULL,
  `montant_total` decimal(12,2) NOT NULL,
  `statut_paiement` enum('paye','impaye','partiel') DEFAULT 'impaye',
  `date_paiement` date DEFAULT NULL,
  `mode_paiement` varchar(20) DEFAULT NULL,
  `reference_paiement` varchar(100) DEFAULT NULL,
  `piece_justificative` varchar(255) DEFAULT NULL,
  `observations` text DEFAULT NULL,
  `date_creation` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id_facture`),
  UNIQUE KEY `numero_facture` (`numero_facture`),
  KEY `id_bus` (`id_bus`),
  CONSTRAINT `factures_parc_ibfk_1` FOREIGN KEY (`id_bus`) REFERENCES `bus` (`id_bus`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `factures_parc`
--

LOCK TABLES `factures_parc` WRITE;
/*!40000 ALTER TABLE `factures_parc` DISABLE KEYS */;
INSERT INTO `factures_parc` VALUES
(1,'FAC-2025-001','2025-04-01',1,'reparation',125000.00,'paye',NULL,NULL,NULL,'facture_001.pdf','Réparation moteur bus DK-123-AB','2026-04-15 11:33:46'),
(2,'FAC-2025-002','2025-04-10',2,'pieces',85000.00,'impaye',NULL,NULL,NULL,NULL,'Achat pneus et plaquettes','2026-04-15 11:33:46'),
(3,'FAC-2025-003','2025-04-15',1,'assurance',450000.00,'paye',NULL,NULL,NULL,'assurance_2025.pdf','Prime annuelle SUNU Assurance','2026-04-15 11:33:46'),
(4,'FAC-2025-004','2025-05-02',3,'reparation',67000.00,'impaye',NULL,NULL,NULL,NULL,'Réparation carrosserie','2026-04-15 11:33:46'),
(5,'FAC-2025-005','2025-05-10',2,'main_oeuvre',35000.00,'paye',NULL,NULL,NULL,NULL,'Main d\'oeuvre vidange + révision','2026-04-15 11:33:46');
/*!40000 ALTER TABLE `factures_parc` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER log_facture_paiement
AFTER UPDATE ON factures_parc
FOR EACH ROW
BEGIN
    IF OLD.statut_paiement != NEW.statut_paiement THEN
        INSERT INTO logs_factures_parc (id_facture, action, ancien_statut, nouveau_statut, utilisateur)
        VALUES (NEW.id_facture, 'CHANGE_STATUS', OLD.statut_paiement, NEW.statut_paiement, USER());
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `fournisseurs`
--

DROP TABLE IF EXISTS `fournisseurs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fournisseurs` (
  `id_fournisseur` int(11) NOT NULL AUTO_INCREMENT,
  `nom_fournisseur` varchar(100) NOT NULL,
  `type_fournisseur` enum('pieces','mecanicien','assurance','carburant','autre') DEFAULT 'autre',
  `telephone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `adresse` text DEFAULT NULL,
  `contact_personne` varchar(100) DEFAULT NULL,
  `statut` enum('actif','inactif') DEFAULT 'actif',
  `date_creation` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id_fournisseur`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fournisseurs`
--

LOCK TABLES `fournisseurs` WRITE;
/*!40000 ALTER TABLE `fournisseurs` DISABLE KEYS */;
INSERT INTO `fournisseurs` VALUES
(1,'Garage Moderne Dakar','pieces','771234567','contact@autopieces.sn',NULL,NULL,'actif','2026-04-15 11:32:06'),
(2,'Mécanique Fall','mecanicien','772345678','garage@central.sn',NULL,NULL,'actif','2026-04-15 11:32:06'),
(3,'Pièces Auto Sénégal','assurance','773456789','assurance@sunu.sn',NULL,NULL,'actif','2026-04-15 11:32:06'),
(4,'Station Total Mermoz','carburant','774567890','total.mermoz@total.sn',NULL,NULL,'actif','2026-04-16 22:55:23'),
(5,'Assurances SUNU','assurance','775678901','contact@sunu.sn',NULL,NULL,'actif','2026-04-16 22:55:23');
/*!40000 ALTER TABLE `fournisseurs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `historique_trajets`
--

DROP TABLE IF EXISTS `historique_trajets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `historique_trajets` (
  `id_trajet` int(11) NOT NULL AUTO_INCREMENT,
  `id_bus` int(11) NOT NULL,
  `id_chauffeur` int(11) NOT NULL,
  `date_trajet` date NOT NULL,
  `km_parcourus` decimal(6,2) DEFAULT NULL,
  `carburant_consomme` decimal(6,2) DEFAULT NULL,
  `temps_reel` time DEFAULT NULL,
  PRIMARY KEY (`id_trajet`),
  KEY `id_bus` (`id_bus`),
  KEY `id_chauffeur` (`id_chauffeur`),
  CONSTRAINT `historique_trajets_ibfk_1` FOREIGN KEY (`id_bus`) REFERENCES `bus` (`id_bus`),
  CONSTRAINT `historique_trajets_ibfk_2` FOREIGN KEY (`id_chauffeur`) REFERENCES `chauffeurs` (`id_chauffeur`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `historique_trajets`
--

LOCK TABLES `historique_trajets` WRITE;
/*!40000 ALTER TABLE `historique_trajets` DISABLE KEYS */;
/*!40000 ALTER TABLE `historique_trajets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `itineraire`
--

DROP TABLE IF EXISTS `itineraire`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `itineraire` (
  `id_itineraire` int(11) NOT NULL AUTO_INCREMENT,
  `id_bus` int(11) NOT NULL,
  `id_chauffeur` int(11) NOT NULL,
  `id_ecole` int(11) NOT NULL,
  `point_depart` varchar(255) DEFAULT NULL,
  `latitude_depart` decimal(10,8) DEFAULT NULL,
  `longitude_depart` decimal(11,8) DEFAULT NULL,
  `point_arrivee` varchar(255) DEFAULT NULL,
  `latitude_arrivee` decimal(10,8) DEFAULT NULL,
  `longitude_arrivee` decimal(11,8) DEFAULT NULL,
  `distance_km` decimal(6,2) DEFAULT NULL,
  `duree_estimee` time DEFAULT NULL,
  `cout_carburant_estime` decimal(8,2) DEFAULT NULL,
  PRIMARY KEY (`id_itineraire`),
  KEY `id_bus` (`id_bus`),
  KEY `id_chauffeur` (`id_chauffeur`),
  KEY `id_ecole` (`id_ecole`),
  CONSTRAINT `itineraire_ibfk_1` FOREIGN KEY (`id_bus`) REFERENCES `bus` (`id_bus`),
  CONSTRAINT `itineraire_ibfk_2` FOREIGN KEY (`id_chauffeur`) REFERENCES `chauffeurs` (`id_chauffeur`),
  CONSTRAINT `itineraire_ibfk_3` FOREIGN KEY (`id_ecole`) REFERENCES `ecoles` (`id_ecole`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `itineraire`
--

LOCK TABLES `itineraire` WRITE;
/*!40000 ALTER TABLE `itineraire` DISABLE KEYS */;
INSERT INTO `itineraire` VALUES
(1,1,1,1,'Mermoz',14.70610000,-17.46170000,'École Internationale',14.69370000,-17.44470000,3.50,NULL,NULL),
(2,2,2,2,'Fann',14.68910000,-17.46630000,'Lycée Mermoz',14.68910000,-17.46630000,2.80,NULL,NULL);
/*!40000 ALTER TABLE `itineraire` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lignes_facture_parc`
--

DROP TABLE IF EXISTS `lignes_facture_parc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lignes_facture_parc` (
  `id_ligne` int(11) NOT NULL AUTO_INCREMENT,
  `id_facture` int(11) NOT NULL,
  `type_ligne` enum('reparation','piece','main_oeuvre','assurance','autre') NOT NULL,
  `description` varchar(255) NOT NULL,
  `quantite` decimal(10,2) DEFAULT 1.00,
  `prix_unitaire` decimal(10,2) NOT NULL,
  `montant_ligne` decimal(10,2) NOT NULL,
  `id_piece` int(11) DEFAULT NULL,
  `id_mecanicien` int(11) DEFAULT NULL,
  `heures_travail` decimal(5,2) DEFAULT NULL,
  PRIMARY KEY (`id_ligne`),
  KEY `id_facture` (`id_facture`),
  KEY `id_piece` (`id_piece`),
  KEY `id_mecanicien` (`id_mecanicien`),
  CONSTRAINT `lignes_facture_parc_ibfk_1` FOREIGN KEY (`id_facture`) REFERENCES `factures_parc` (`id_facture`) ON DELETE CASCADE,
  CONSTRAINT `lignes_facture_parc_ibfk_2` FOREIGN KEY (`id_piece`) REFERENCES `pieces_detachees` (`id_piece`),
  CONSTRAINT `lignes_facture_parc_ibfk_3` FOREIGN KEY (`id_mecanicien`) REFERENCES `mecaniciens` (`id_mecanicien`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lignes_facture_parc`
--

LOCK TABLES `lignes_facture_parc` WRITE;
/*!40000 ALTER TABLE `lignes_facture_parc` DISABLE KEYS */;
INSERT INTO `lignes_facture_parc` VALUES
(1,1,'reparation','Réparation injecteur',1.00,75000.00,75000.00,NULL,NULL,NULL),
(2,1,'main_oeuvre','Main d\'oeuvre',10.00,5000.00,50000.00,NULL,NULL,NULL),
(3,2,'piece','Pneu Michelin',2.00,35000.00,70000.00,NULL,NULL,NULL),
(4,2,'piece','Plaquette frein',2.00,7500.00,15000.00,NULL,NULL,NULL),
(5,4,'reparation','Carrosserie aile avant',1.00,50000.00,50000.00,NULL,NULL,NULL),
(6,4,'main_oeuvre','Peinture',1.00,17000.00,17000.00,NULL,NULL,NULL);
/*!40000 ALTER TABLE `lignes_facture_parc` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER update_stock_pieces
AFTER INSERT ON lignes_facture_parc
FOR EACH ROW
BEGIN
    IF NEW.type_ligne = 'piece' AND NEW.id_piece IS NOT NULL THEN
        UPDATE pieces_detachees 
        SET quantite_stock = quantite_stock - NEW.quantite
        WHERE id_piece = NEW.id_piece;
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `logs_chauffeur`
--

DROP TABLE IF EXISTS `logs_chauffeur`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `logs_chauffeur` (
  `id_log` int(11) NOT NULL AUTO_INCREMENT,
  `id_chauffeur` int(11) DEFAULT NULL,
  `ancien_statut` varchar(20) DEFAULT NULL,
  `nouveau_statut` varchar(20) DEFAULT NULL,
  `date_modification` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id_log`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs_chauffeur`
--

LOCK TABLES `logs_chauffeur` WRITE;
/*!40000 ALTER TABLE `logs_chauffeur` DISABLE KEYS */;
/*!40000 ALTER TABLE `logs_chauffeur` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logs_factures_parc`
--

DROP TABLE IF EXISTS `logs_factures_parc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `logs_factures_parc` (
  `id_log` int(11) NOT NULL AUTO_INCREMENT,
  `id_facture` int(11) DEFAULT NULL,
  `action` varchar(20) DEFAULT NULL,
  `ancien_statut` varchar(20) DEFAULT NULL,
  `nouveau_statut` varchar(20) DEFAULT NULL,
  `date_modification` datetime DEFAULT current_timestamp(),
  `utilisateur` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_log`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs_factures_parc`
--

LOCK TABLES `logs_factures_parc` WRITE;
/*!40000 ALTER TABLE `logs_factures_parc` DISABLE KEYS */;
/*!40000 ALTER TABLE `logs_factures_parc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mecaniciens`
--

DROP TABLE IF EXISTS `mecaniciens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mecaniciens` (
  `id_mecanicien` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `telephone` varchar(20) NOT NULL,
  `specialite` varchar(100) DEFAULT NULL,
  `taux_horaire` decimal(10,2) DEFAULT NULL,
  `type_contrat` enum('interne','externe') DEFAULT 'externe',
  `statut` enum('actif','inactif') DEFAULT 'actif',
  `date_embauche` date DEFAULT NULL,
  PRIMARY KEY (`id_mecanicien`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mecaniciens`
--

LOCK TABLES `mecaniciens` WRITE;
/*!40000 ALTER TABLE `mecaniciens` DISABLE KEYS */;
INSERT INTO `mecaniciens` VALUES
(1,'NDIAYE','Pape','771234567','Moteur diesel',5000.00,'externe','actif',NULL),
(2,'DIOP','Mamadou','772345678','Électricité auto',4500.00,'externe','actif',NULL),
(3,'FALL','Omar','773456789','Carrosserie',6000.00,'externe','actif',NULL);
/*!40000 ALTER TABLE `mecaniciens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paiements`
--

DROP TABLE IF EXISTS `paiements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `paiements` (
  `id_paiement` int(11) NOT NULL AUTO_INCREMENT,
  `id_eleve` int(11) NOT NULL,
  `code_parent_ref` varchar(20) DEFAULT NULL,
  `code_eleve_ref` varchar(20) DEFAULT NULL,
  `montant` decimal(10,2) NOT NULL,
  `mois_periode` date NOT NULL,
  `date_paiement` datetime DEFAULT current_timestamp(),
  `mode_paiement` enum('especes','wave','orange_money','cheque') NOT NULL,
  `reference_transaction` varchar(100) DEFAULT NULL,
  `statut_paiement` enum('paye','impaye','partiel') DEFAULT 'impaye',
  `id_secretaire` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_paiement`),
  UNIQUE KEY `unique_paiement_par_mois_eleve` (`id_eleve`,`mois_periode`),
  KEY `idx_code_parent_ref` (`code_parent_ref`),
  KEY `idx_code_eleve_ref` (`code_eleve_ref`),
  CONSTRAINT `paiements_ibfk_1` FOREIGN KEY (`id_eleve`) REFERENCES `eleves` (`id_eleve`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paiements`
--

LOCK TABLES `paiements` WRITE;
/*!40000 ALTER TABLE `paiements` DISABLE KEYS */;
INSERT INTO `paiements` VALUES
(1,1,'P7812345677174','E7812345676336',15000.00,'2025-04-01','2026-04-15 22:28:02','wave',NULL,'paye',1),
(3,1,'P7812345677174','E7812345676336',15000.00,'2026-04-01','2026-04-16 01:10:33','especes',NULL,'paye',1);
/*!40000 ALTER TABLE `paiements` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER before_insert_paiements
BEFORE INSERT ON paiements
FOR EACH ROW
BEGIN
    DECLARE parent_code VARCHAR(20);
    DECLARE eleve_code VARCHAR(20);
    
    
    SELECT p.code_parent, e.code_eleve INTO parent_code, eleve_code
    FROM eleves e
    JOIN parents p ON e.id_parent = p.id_parent
    WHERE e.id_eleve = NEW.id_eleve;
    
    SET NEW.code_parent_ref = parent_code;
    SET NEW.code_eleve_ref = eleve_code;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `parents`
--

DROP TABLE IF EXISTS `parents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `parents` (
  `id_parent` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `telephone` varchar(20) NOT NULL,
  `code_parent` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `adresse_complete` text DEFAULT NULL,
  `profession` varchar(50) DEFAULT NULL,
  `login_user` varchar(50) NOT NULL,
  `mot_de_passe` varchar(255) NOT NULL,
  `date_inscription` datetime DEFAULT current_timestamp(),
  `statut_compte` enum('actif','suspendu') DEFAULT 'actif',
  PRIMARY KEY (`id_parent`),
  UNIQUE KEY `telephone` (`telephone`),
  UNIQUE KEY `login_user` (`login_user`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `code_parent` (`code_parent`),
  KEY `idx_code_parent` (`code_parent`),
  CONSTRAINT `chk_code_parent_format` CHECK (`code_parent` regexp '^P[0-9]{13}$')
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parents`
--

LOCK TABLES `parents` WRITE;
/*!40000 ALTER TABLE `parents` DISABLE KEYS */;
INSERT INTO `parents` VALUES
(1,'TEST_CODE','Alpha','781234567','P7812345677174','alpha@test.sn','Dakar Sacré Coeur',NULL,'alpha.test','password_hash','2026-04-15 22:26:36','actif');
/*!40000 ALTER TABLE `parents` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER before_insert_parents
BEFORE INSERT ON parents
FOR EACH ROW
BEGIN
    DECLARE base_code VARCHAR(20);
    DECLARE final_code VARCHAR(20);
    DECLARE counter INT DEFAULT 1;
    DECLARE phone_clean VARCHAR(20);
    
    
    IF NEW.code_parent IS NOT NULL AND NEW.code_parent != '' THEN
        SET final_code = NEW.code_parent;
    ELSE
        
        SET phone_clean = REGEXP_REPLACE(NEW.telephone, '[^0-9]', '');
        
        
        IF LENGTH(phone_clean) >= 9 THEN
            SET phone_clean = RIGHT(phone_clean, 9);
        ELSE
            SET phone_clean = LPAD(phone_clean, 9, '0');
        END IF;
        
        
        SET base_code = CONCAT('P', phone_clean);
        SET final_code = CONCAT(base_code, LPAD(FLOOR(RAND() * 10000), 4, '0'));
        
        
        WHILE EXISTS (SELECT 1 FROM parents WHERE code_parent = final_code) DO
            SET final_code = CONCAT(base_code, LPAD(FLOOR(RAND() * 10000), 4, '0'));
        END WHILE;
    END IF;
    
    SET NEW.code_parent = final_code;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `pieces_detachees`
--

DROP TABLE IF EXISTS `pieces_detachees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pieces_detachees` (
  `id_piece` int(11) NOT NULL AUTO_INCREMENT,
  `reference_piece` varchar(50) NOT NULL,
  `nom_piece` varchar(100) NOT NULL,
  `categorie_piece` varchar(50) DEFAULT NULL,
  `prix_unitaire` decimal(10,2) NOT NULL,
  `quantite_stock` int(11) DEFAULT 0,
  `quantite_minimum` int(11) DEFAULT 5,
  `emplacement_stock` varchar(50) DEFAULT NULL,
  `fournisseur_id` int(11) DEFAULT NULL,
  `date_dernier_achat` date DEFAULT NULL,
  PRIMARY KEY (`id_piece`),
  UNIQUE KEY `reference_piece` (`reference_piece`),
  KEY `fournisseur_id` (`fournisseur_id`),
  CONSTRAINT `pieces_detachees_ibfk_1` FOREIGN KEY (`fournisseur_id`) REFERENCES `fournisseurs` (`id_fournisseur`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pieces_detachees`
--

LOCK TABLES `pieces_detachees` WRITE;
/*!40000 ALTER TABLE `pieces_detachees` DISABLE KEYS */;
INSERT INTO `pieces_detachees` VALUES
(1,'PNEU-001','Pneu Michelin 205/55R16','Pneumatique',35000.00,8,4,NULL,1,NULL),
(2,'FILTRE-001','Filtre à huile','Filtrage',5500.00,15,5,NULL,1,NULL),
(3,'PLAQUETTE-001','Plaquette de frein AV','Freinage',12500.00,6,3,NULL,1,NULL),
(4,'COURROIE-001','Courroie de distribution','Moteur',18500.00,5,2,NULL,1,NULL),
(5,'BATTERIE-001','Batterie 12V 60Ah','Électrique',45000.00,4,2,NULL,1,NULL);
/*!40000 ALTER TABLE `pieces_detachees` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER check_stock_minimum
AFTER UPDATE ON pieces_detachees
FOR EACH ROW
BEGIN
    IF NEW.quantite_stock <= NEW.quantite_minimum AND OLD.quantite_stock > NEW.quantite_minimum THEN
        INSERT INTO logs_factures_parc (id_facture, action, ancien_statut, nouveau_statut, utilisateur)
        VALUES (0, 'STOCK_ALERT', CONCAT('Pièce: ', NEW.nom_piece), 
                CONCAT('Stock bas: ', NEW.quantite_stock, ' < ', NEW.quantite_minimum), 'SYSTEM');
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `presence_chauffeur`
--

DROP TABLE IF EXISTS `presence_chauffeur`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `presence_chauffeur` (
  `id_presence` int(11) NOT NULL AUTO_INCREMENT,
  `id_chauffeur` int(11) NOT NULL,
  `date_presence` date NOT NULL,
  `present` tinyint(1) DEFAULT 1,
  `remarques` text DEFAULT NULL,
  PRIMARY KEY (`id_presence`),
  KEY `id_chauffeur` (`id_chauffeur`),
  CONSTRAINT `presence_chauffeur_ibfk_1` FOREIGN KEY (`id_chauffeur`) REFERENCES `chauffeurs` (`id_chauffeur`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `presence_chauffeur`
--

LOCK TABLES `presence_chauffeur` WRITE;
/*!40000 ALTER TABLE `presence_chauffeur` DISABLE KEYS */;
/*!40000 ALTER TABLE `presence_chauffeur` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rappels_entretien`
--

DROP TABLE IF EXISTS `rappels_entretien`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rappels_entretien` (
  `id_rappel` int(11) NOT NULL AUTO_INCREMENT,
  `id_bus` int(11) NOT NULL,
  `type_entretien` varchar(50) NOT NULL,
  `date_rappel` date NOT NULL,
  `kilometrage_rappel` int(11) DEFAULT NULL,
  `statut` enum('en_attente','effectue','annule') DEFAULT 'en_attente',
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id_rappel`),
  KEY `id_bus` (`id_bus`),
  CONSTRAINT `rappels_entretien_ibfk_1` FOREIGN KEY (`id_bus`) REFERENCES `bus` (`id_bus`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rappels_entretien`
--

LOCK TABLES `rappels_entretien` WRITE;
/*!40000 ALTER TABLE `rappels_entretien` DISABLE KEYS */;
INSERT INTO `rappels_entretien` VALUES
(1,1,'Vidange','2025-05-15',25000,'en_attente',NULL),
(2,1,'Révision générale','2025-06-01',30000,'en_attente',NULL),
(3,2,'Changement pneus','2025-05-20',22000,'en_attente',NULL);
/*!40000 ALTER TABLE `rappels_entretien` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suivis_reparation`
--

DROP TABLE IF EXISTS `suivis_reparation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `suivis_reparation` (
  `id_suivi` int(11) NOT NULL AUTO_INCREMENT,
  `id_bus` int(11) NOT NULL,
  `id_facture` int(11) NOT NULL,
  `date_debut_reparation` date NOT NULL,
  `date_fin_reparation` date DEFAULT NULL,
  `kilometrage_atelier` int(11) DEFAULT NULL,
  `panne_constatee` text DEFAULT NULL,
  `travail_effectue` text DEFAULT NULL,
  `statut_reparation` enum('en_cours','termine','en_attente_pieces') DEFAULT 'en_cours',
  `responsable_controle` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_suivi`),
  KEY `id_bus` (`id_bus`),
  KEY `id_facture` (`id_facture`),
  CONSTRAINT `suivis_reparation_ibfk_1` FOREIGN KEY (`id_bus`) REFERENCES `bus` (`id_bus`),
  CONSTRAINT `suivis_reparation_ibfk_2` FOREIGN KEY (`id_facture`) REFERENCES `factures_parc` (`id_facture`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suivis_reparation`
--

LOCK TABLES `suivis_reparation` WRITE;
/*!40000 ALTER TABLE `suivis_reparation` DISABLE KEYS */;
INSERT INTO `suivis_reparation` VALUES
(1,1,1,'2025-04-01','2025-04-03',24500,'Moteur qui cale, perte de puissance','Nettoyage injecteurs, remplacement filtre','termine',NULL),
(2,2,2,'2025-04-10','2025-04-11',22000,'Usure excessive des pneus avant','Remplacement 2 pneus, équilibrage','termine',NULL);
/*!40000 ALTER TABLE `suivis_reparation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tarifications`
--

DROP TABLE IF EXISTS `tarifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tarifications` (
  `id_tarif` int(11) NOT NULL AUTO_INCREMENT,
  `distance_km_min` decimal(5,2) DEFAULT NULL,
  `distance_km_max` decimal(5,2) DEFAULT NULL,
  `prix_mensuel` decimal(8,2) NOT NULL,
  `prix_trimestriel` decimal(8,2) DEFAULT NULL,
  `prix_annuel` decimal(8,2) DEFAULT NULL,
  `date_debut_validite` date NOT NULL,
  `date_fin_validite` date DEFAULT NULL,
  PRIMARY KEY (`id_tarif`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tarifications`
--

LOCK TABLES `tarifications` WRITE;
/*!40000 ALTER TABLE `tarifications` DISABLE KEYS */;
INSERT INTO `tarifications` VALUES
(1,0.00,5.00,15000.00,40000.00,140000.00,'2025-01-01',NULL),
(2,5.01,10.00,20000.00,55000.00,190000.00,'2025-01-01',NULL),
(3,10.01,20.00,25000.00,70000.00,240000.00,'2025-01-01',NULL);
/*!40000 ALTER TABLE `tarifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions_paiement`
--

DROP TABLE IF EXISTS `transactions_paiement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `transactions_paiement` (
  `id_transaction` int(11) NOT NULL AUTO_INCREMENT,
  `id_paiement` int(11) NOT NULL,
  `reference_externe` varchar(100) NOT NULL,
  `operateur` enum('wave','orange_money','especes','cheque') NOT NULL,
  `statut_transaction` enum('pending','success','failed') DEFAULT 'pending',
  `numero_telephone` varchar(20) DEFAULT NULL,
  `date_transaction` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id_transaction`),
  UNIQUE KEY `reference_externe` (`reference_externe`),
  KEY `id_paiement` (`id_paiement`),
  CONSTRAINT `transactions_paiement_ibfk_1` FOREIGN KEY (`id_paiement`) REFERENCES `paiements` (`id_paiement`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions_paiement`
--

LOCK TABLES `transactions_paiement` WRITE;
/*!40000 ALTER TABLE `transactions_paiement` DISABLE KEYS */;
/*!40000 ALTER TABLE `transactions_paiement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `vue_tracabilite_transactions`
--

DROP TABLE IF EXISTS `vue_tracabilite_transactions`;
/*!50001 DROP VIEW IF EXISTS `vue_tracabilite_transactions`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vue_tracabilite_transactions` AS SELECT
 1 AS `id_paiement`,
  1 AS `date_paiement`,
  1 AS `montant`,
  1 AS `mode_paiement`,
  1 AS `statut_paiement`,
  1 AS `code_parent_ref`,
  1 AS `code_eleve_ref`,
  1 AS `nom_eleve`,
  1 AS `prenom_eleve`,
  1 AS `code_eleve`,
  1 AS `classe`,
  1 AS `parent_nom`,
  1 AS `parent_prenom`,
  1 AS `parent_telephone`,
  1 AS `code_parent`,
  1 AS `nom_ecole`,
  1 AS `bus_immatriculation` */;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `vue_tracabilite_transactions`
--

/*!50001 DROP VIEW IF EXISTS `vue_tracabilite_transactions`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vue_tracabilite_transactions` AS select `p`.`id_paiement` AS `id_paiement`,`p`.`date_paiement` AS `date_paiement`,`p`.`montant` AS `montant`,`p`.`mode_paiement` AS `mode_paiement`,`p`.`statut_paiement` AS `statut_paiement`,`p`.`code_parent_ref` AS `code_parent_ref`,`p`.`code_eleve_ref` AS `code_eleve_ref`,`e`.`nom_eleve` AS `nom_eleve`,`e`.`prenom_eleve` AS `prenom_eleve`,`e`.`code_eleve` AS `code_eleve`,`e`.`classe` AS `classe`,`pa`.`nom` AS `parent_nom`,`pa`.`prenom` AS `parent_prenom`,`pa`.`telephone` AS `parent_telephone`,`pa`.`code_parent` AS `code_parent`,`ec`.`nom_ecole` AS `nom_ecole`,`b`.`immatriculation` AS `bus_immatriculation` from (((((`paiements` `p` join `eleves` `e` on(`p`.`id_eleve` = `e`.`id_eleve`)) join `parents` `pa` on(`e`.`id_parent` = `pa`.`id_parent`)) left join `ecoles` `ec` on(`e`.`id_ecole` = `ec`.`id_ecole`)) left join `affectations` `a` on(`e`.`id_eleve` = `a`.`id_eleve`)) left join `bus` `b` on(`a`.`id_bus` = `b`.`id_bus`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-22 16:36:20
