/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: gp_db
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `agenda_rdv`
--

DROP TABLE IF EXISTS `agenda_rdv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `agenda_rdv` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `date_rdv` date NOT NULL,
  `heure_rdv` time DEFAULT NULL,
  `duree` int(11) DEFAULT 60 COMMENT 'durée en minutes',
  `lieu` varchar(255) DEFAULT NULL,
  `type_rdv` enum('prospect','client','partenaire','foire','salon','autre') DEFAULT 'prospect',
  `contact_nom` varchar(100) DEFAULT NULL,
  `contact_telephone` varchar(20) DEFAULT NULL,
  `contact_email` varchar(100) DEFAULT NULL,
  `statut` enum('planifie','effectue','annule','reporte') DEFAULT 'planifie',
  `materiel_requis` text DEFAULT NULL COMMENT 'matériel à ne pas oublier (ex: tablette, brochures, échantillons)',
  `notes_apres` text DEFAULT NULL,
  `utilisateur` varchar(50) DEFAULT 'Dieynaba',
  `date_creation` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agenda_rdv`
--

LOCK TABLES `agenda_rdv` WRITE;
/*!40000 ALTER TABLE `agenda_rdv` DISABLE KEYS */;
INSERT INTO `agenda_rdv` VALUES
(1,'Rendez-vous Association Sénégalaise','Présentation des services de fret et des boutiques en ligne','2026-05-01','10:00:00',60,'Paris 10e, Grande Mosquée de Paris','partenaire','Mamadou Diallo','+33712345678',NULL,'planifie','Tablette, brochures, QR codes',NULL,'Dieynaba','2026-04-29 14:05:37'),
(2,'Visite Foire Africaine','Participation à la Foire Africaine de Paris - Stand Dieynaba GP Holding','2026-05-04','09:30:00',60,'Paris Expo Porte de Versailles','foire','Organisateurs','+33123456789',NULL,'planifie','Roll-up, flyers, échantillons',NULL,'Dieynaba','2026-04-29 14:05:37'),
(3,'Prospection Restaurant Le Ndar','Proposition de partenariat pour l\'expédition de produits','2026-04-30','14:00:00',60,'18 Rue des Rosiers, Paris 4e','prospect','Cheikh Ndiaye','+33611223344',NULL,'planifie','Carte de visite, plaquettes',NULL,'Dieynaba','2026-04-29 14:05:37'),
(4,'Réunion Association Keur Sénégal','Présentation du programme fidélité et des tarifs groupe','2026-05-02','11:00:00',60,'30 Rue Pasteur, Lyon 7e','client','Awa Fall','+33799887766',NULL,'planifie','Tableau des tarifs, QR codes',NULL,'Dieynaba','2026-04-29 14:05:37'),
(5,'Salon du Voyage Marseille','Exposition des produits et services fret','2026-05-09','10:00:00',60,'Parc Chanot, Marseille','foire','Service commercial','+33491234567',NULL,'planifie','Matériel de stand, goodies',NULL,'Dieynaba','2026-04-29 14:05:37'),
(6,'Rendez-vous prospect - Envois groupés','Proposition pour envois réguliers de colis vers Sénégal','2026-05-03','15:30:00',60,'Saint-Denis, 22 Rue de la Légion d\'Honneur','prospect','Ibrahima Sarr','+33699887755',NULL,'planifie','Grille tarifaire, exemple étiquettes',NULL,'Dieynaba','2026-04-29 14:05:37'),
(7,'Visite showroom Han Maristes','Présentation du showroom négoce et joaillerie','2026-04-29','09:00:00',60,'Hann Maristes, Dakar','client','Dieynaba Keita','+221776542803',NULL,'effectue','Catalogue, bijoux en démonstration',NULL,'Dieynaba','2026-04-29 14:05:37'),
(8,'Prospection Association Grand Dakar','Proposition de service pour la diaspora','2026-05-05','10:30:00',60,'Dakar Plateau','prospect','Oumar Sow','+221771234567',NULL,'planifie','Brochures, QR codes',NULL,'Dieynaba','2026-04-29 14:05:37'),
(9,'Rendez-vous client Moussa Diop','Suivi de colis et proposition nouvel abonnement','2026-04-30','09:00:00',60,'Dakar, 15 Avenue Faidherbe','client','Moussa Diop','+221771234567',NULL,'planifie','Justificatifs, proposition tarifaire',NULL,'Dieynaba','2026-04-29 14:05:37'),
(10,'Livreur - Remise de colis','Livraison de colis haut de gamme Négoce','2026-04-29','11:00:00',60,'Saint-Denis, 10 Rue de Paris','client','Khadim Ndiaye','+33758686348',NULL,'planifie','Colis à remettre',NULL,'Dieynaba','2026-04-29 14:05:37');
/*!40000 ALTER TABLE `agenda_rdv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bijouterie`
--

DROP TABLE IF EXISTS `bijouterie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bijouterie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code_produit` varchar(50) NOT NULL,
  `nom` varchar(200) NOT NULL,
  `categorie` enum('bague','collier','boucle_oreille','bracelet','montre','diamant','autre') DEFAULT 'autre',
  `matiere` enum('or','argent','platine','diamant','pierre_precieuse','autre') DEFAULT 'autre',
  `description` text DEFAULT NULL,
  `prix_achat` decimal(12,2) NOT NULL,
  `prix_vente` decimal(12,2) NOT NULL,
  `stock` int(11) DEFAULT 0,
  `image` varchar(255) DEFAULT NULL,
  `poids_gramme` decimal(8,2) DEFAULT NULL,
  `pierres` varchar(100) DEFAULT NULL,
  `certificat` tinyint(1) DEFAULT 0,
  `date_ajout` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code_produit` (`code_produit`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bijouterie`
--

LOCK TABLES `bijouterie` WRITE;
/*!40000 ALTER TABLE `bijouterie` DISABLE KEYS */;
INSERT INTO `bijouterie` VALUES
(1,'BAG-000326','Bague Solitaire Diamant','bague','or','Bague en or blanc 18 carats avec diamant taille brillant 0.50ct',1000.00,2000.00,3,'uploads/bijoux/bijou_1.jpg',4.50,'Diamant 0.50ct',1,'2026-04-28 12:32:24'),
(2,'COL-054635','Collier Perles de Culture','collier','argent','Collier en argent 925 avec perles de culture authentiques',350.00,890.00,5,'uploads/bijoux/collier_perles.jpg',15.20,'Perles 8mm',0,'2026-04-28 12:32:24'),
(3,'BOU-072196','Boucles Oreilles Saphir','boucle_oreille','or','Boucles d\'oreilles en or jaune avec saphirs bleus',450.00,1000.00,2,'uploads/bijoux/boucles_saphir.jpg',3.80,'Saphirs 2ct',1,'2026-04-28 12:32:24'),
(4,'MON-097076','Montre Oyster Perpetual','montre','argent','Montre automatique luxe, boîtier acier inoxydable',2500.00,5800.00,1,'uploads/bijoux/montre_luxe.jpg',120.00,'',1,'2026-04-28 12:32:24'),
(5,'BRA-068793','Bracelet Or Massif','bracelet','or','Bracelet en or massif 18 carats maillons',800.00,1850.00,4,'uploads/bijoux/bracelet_or.jpg',12.50,'',1,'2026-04-28 12:32:24');
/*!40000 ALTER TABLE `bijouterie` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER generate_bijouterie_code BEFORE INSERT ON bijouterie
FOR EACH ROW
BEGIN
    DECLARE prefix VARCHAR(10);
    DECLARE random_num VARCHAR(8);
    DECLARE new_code VARCHAR(50);
    DECLARE existing INT DEFAULT 1;
    
    SET prefix = CASE NEW.categorie
        WHEN 'bague' THEN 'BAG'
        WHEN 'collier' THEN 'COL'
        WHEN 'boucle_oreille' THEN 'BOU'
        WHEN 'bracelet' THEN 'BRA'
        WHEN 'montre' THEN 'MON'
        WHEN 'diamant' THEN 'DIA'
        ELSE 'BIJ'
    END;
    
    WHILE existing > 0 DO
        SET random_num = LPAD(FLOOR(RAND() * 100000), 6, '0');
        SET new_code = CONCAT(prefix, '-', random_num);
        SELECT COUNT(*) INTO existing FROM bijouterie WHERE code_produit = new_code;
    END WHILE;
    
    SET NEW.code_produit = new_code;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `boutiques`
--

DROP TABLE IF EXISTS `boutiques`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `boutiques` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) DEFAULT NULL,
  `domaine` varchar(100) DEFAULT NULL,
  `slogan` varchar(255) DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `produits` text DEFAULT NULL,
  `forme_geometrique` varchar(50) DEFAULT NULL,
  `produits_specifiques` text DEFAULT NULL,
  `slogan_pub` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `boutiques`
--

LOCK TABLES `boutiques` WRITE;
/*!40000 ALTER TABLE `boutiques` DISABLE KEYS */;
INSERT INTO `boutiques` VALUES
(1,'Négoce Dakar Paris','Ameublement de Luxe','L’Élégance de la Provence au Sénégal','+33 7 58 68 63 48','Salons complets, ameublement haut de gamme','rectangle',NULL,'Core i7 '),
(2,'Joaillerie & Bijouterie','Bijoux de Luxe','Brillez entre deux mondes : Paris - Dakar','+33 7 58 68 63 48','Colliers, bagues, pierres précieuses','cercle',NULL,'Bijou collier '),
(3,'Épicerie fine','Gastronomie Africaine','Les Trésors du Terroir Sélectionnés pour Vous','+33 7 58 68 63 48','Attiéké, Beurre de karité, Crevettes séchées, Huile de palme rouge, Miel de Casamance, Soupe de poisson, Soupe kandia, Thé à la menthe, Bissap naturelle','hexagone',NULL,NULL),
(4,'Vêtements Couture','Mode Africaine de Luxe','L’Héritage Africain, l’Élégance Universelle','+33 7 58 68 63 48','Boubou Sénégalais Homme, Robe Kaftan Femme, Grand Boubou Femme Wax, Chemise Africaine, Dentelle Sénégalaise, Bazin Riche','losange',NULL,NULL);
/*!40000 ALTER TABLE `boutiques` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charges`
--

DROP TABLE IF EXISTS `charges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `charges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `colis_id` int(11) DEFAULT NULL,
  `lien_colis` tinyint(1) DEFAULT 0,
  `libelle` varchar(150) NOT NULL,
  `montant` decimal(10,2) NOT NULL,
  `date_charge` date NOT NULL,
  `categorie` enum('carburant','personnel','location','maintenance','douane','autres') DEFAULT 'autres',
  `type_charge` enum('directe','indirecte','structurelle') DEFAULT 'directe',
  `notes` text DEFAULT NULL,
  `date_ajout` timestamp NULL DEFAULT current_timestamp(),
  `secteur` enum('fret','bijouterie','negoce','holding') DEFAULT 'fret',
  PRIMARY KEY (`id`),
  KEY `idx_charges_colis` (`colis_id`),
  KEY `idx_charges_date` (`date_charge`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charges`
--

LOCK TABLES `charges` WRITE;
/*!40000 ALTER TABLE `charges` DISABLE KEYS */;
INSERT INTO `charges` VALUES
(1,1,1,'Carburant - Vol SN202',150.00,'2026-05-01','carburant','directe','Plein du vol Paris-Dakar','2026-04-26 03:33:55','fret'),
(2,2,1,'Carburant - Vol AF823',135.00,'2026-05-02','carburant','directe','Plein du vol retour','2026-04-26 03:33:55','fret'),
(3,NULL,0,'Salaires équipe Dakar - Mai',800.00,'2026-05-05','personnel','indirecte','Salaires 5 employés','2026-04-26 03:33:55','fret'),
(4,NULL,0,'Salaires équipe Paris - Mai',750.00,'2026-05-05','personnel','indirecte','Salaires 4 employés','2026-04-26 03:33:55','fret'),
(5,NULL,0,'Location entrepôt Paris',400.00,'2026-05-01','location','structurelle','Loyer mensuel Paris 18e','2026-04-26 03:33:55','fret'),
(6,NULL,0,'Location entrepôt Dakar',120.00,'2026-05-01','location','structurelle','Loyer mensuel Dakar Plateau','2026-04-26 03:33:55','fret'),
(7,NULL,0,'Maintenance camionnette',95.00,'2026-05-10','maintenance','indirecte','Vidange et révision','2026-04-26 03:33:55','fret'),
(8,5,1,'Frais douane groupé',200.00,'2026-05-08','douane','directe','Dédouanement colis 5','2026-04-26 03:33:55','fret'),
(9,NULL,0,'Publicité WhatsApp mai',50.00,'2026-05-12','autres','indirecte','Campagne SMS/WhatsApp','2026-04-26 03:33:55','fret'),
(10,NULL,0,'Fournitures bureau',45.00,'2026-05-15','autres','structurelle','Papeterie et cartouches','2026-04-26 03:33:55','fret'),
(11,3,1,'Assurance colis',60.00,'2026-05-03','autres','directe','Assurance colis 3','2026-04-26 03:33:55','fret');
/*!40000 ALTER TABLE `charges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `telephone` varchar(20) NOT NULL,
  `code_qr` text DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `adresse` text DEFAULT NULL,
  `type` enum('expediteur','destinataire','both') DEFAULT 'expediteur',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `code_client` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `telephone` (`telephone`),
  UNIQUE KEY `code_client` (`code_client`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` VALUES
(1,'Dieynaba Keita','+33758686348',NULL,'dieynaba@dieynaba.com','Paris, France','both','2026-04-26 03:33:55','CLT-00001'),
(2,'Moussa Diop','+221771234567',NULL,'moussa.diop@email.com','15 Avenue Faidherbe, Dakar, Sénégal','expediteur','2026-04-26 03:33:55','CLT-00002'),
(3,'Fatou Sow','+33712345678',NULL,'fatou.sow@email.com','25 Rue de la République, 69001 Lyon, France','destinataire','2026-04-26 03:33:55','CLT-00003'),
(4,'Amadou Ba','+221776543210',NULL,'amadou.ba@email.com','8 Boulevard de la Gare, Thiès, Sénégal','expediteur','2026-04-26 03:33:55','CLT-00004'),
(5,'Claire Martin','+33698765432',NULL,'claire.martin@email.com','42 Rue Paradis, 13001 Marseille, France','destinataire','2026-04-26 03:33:55','CLT-00005'),
(6,'Mamadou Diallo','+221778888888',NULL,'mamadou.diallo@email.com','12 Rue de la Liberté, Dakar, Sénégal','expediteur','2026-04-26 03:33:55','CLT-00006'),
(7,'Sophie Dubois','+33612345678',NULL,'sophie.dubois@email.com','18 Avenue des Champs, 33000 Bordeaux, France','destinataire','2026-04-26 03:33:55','CLT-00007'),
(9,'Khadim Ndiaye','+33799887766',NULL,'khadim@dieynaba.com','10 Rue de Paris, Saint-Denis, France','destinataire','2026-04-29 16:53:23','CLT-0099');
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clients_dakar`
--

DROP TABLE IF EXISTS `clients_dakar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clients_dakar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom_complet` varchar(150) DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `adresse_dakar` text DEFAULT NULL,
  `nom_enfant_france` varchar(150) DEFAULT NULL,
  `tel_enfant_france` varchar(20) DEFAULT NULL,
  `ville_enfant` varchar(100) DEFAULT NULL,
  `copine_referent` varchar(100) DEFAULT NULL,
  `consentement` tinyint(4) DEFAULT 0,
  `date_contact` datetime DEFAULT NULL,
  `source` enum('flyer','copine','voisinage','marche','autre') DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients_dakar`
--

LOCK TABLES `clients_dakar` WRITE;
/*!40000 ALTER TABLE `clients_dakar` DISABLE KEYS */;
/*!40000 ALTER TABLE `clients_dakar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clients_vetements`
--

DROP TABLE IF EXISTS `clients_vetements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clients_vetements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `telephone` varchar(20) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `adresse` text DEFAULT NULL,
  `date_inscription` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `telephone` (`telephone`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients_vetements`
--

LOCK TABLES `clients_vetements` WRITE;
/*!40000 ALTER TABLE `clients_vetements` DISABLE KEYS */;
INSERT INTO `clients_vetements` VALUES
(1,'Aïssatou Diallo','+33711223344','aissatou.diallo@email.com','15 Rue de la Mode, 75001 Paris, France','2026-04-26 03:33:55'),
(2,'Oumar Ndiaye','+33755667788','oumar.ndiaye@email.com','8 Avenue de la République, 69001 Lyon, France','2026-04-26 03:33:55'),
(3,'Khadija Fall','+33799887766','khadija.fall@email.com','32 Boulevard du Sud, 13001 Marseille, France','2026-04-26 03:33:55'),
(4,'Ibrahima Sarr','+33744332211','ibrahima.sarr@email.com','5 Rue des Arts, 33000 Bordeaux, France','2026-04-26 03:33:55'),
(5,'Marième Diouf','+33777889900','marieme.diouf@email.com','22 Place de la Liberté, 59000 Lille, France','2026-04-26 03:33:55');
/*!40000 ALTER TABLE `clients_vetements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `colis`
--

DROP TABLE IF EXISTS `colis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `colis` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entite_origine_id` int(11) DEFAULT NULL,
  `entite_destination_id` int(11) DEFAULT NULL,
  `numero_suivi` varchar(50) NOT NULL,
  `client_expediteur_id` int(11) DEFAULT NULL,
  `client_destinataire_id` int(11) DEFAULT NULL,
  `destinataire_nom` varchar(100) DEFAULT NULL,
  `destinataire_telephone` varchar(20) DEFAULT NULL,
  `destinataire_adresse` text DEFAULT NULL,
  `lieu_depart` varchar(100) DEFAULT NULL,
  `lieu_arrivee` varchar(100) DEFAULT NULL,
  `date_depart_reel` datetime DEFAULT NULL,
  `date_arrivee_reelle` datetime DEFAULT NULL,
  `frais_expedition` decimal(10,2) DEFAULT 0.00,
  `frais_douane` decimal(10,2) DEFAULT 0.00,
  `montant_encaisse` decimal(10,2) DEFAULT 0.00,
  `vol_id` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `poids_kg` decimal(6,2) DEFAULT NULL,
  `statut` enum('enregistre','depart','transit','arrivee','livre') DEFAULT 'enregistre',
  `position_gps` varchar(100) DEFAULT NULL,
  `derniere_mise_a_jour` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `sens` enum('paris_dakar','dakar_paris') DEFAULT 'paris_dakar',
  PRIMARY KEY (`id`),
  KEY `client_expediteur_id` (`client_expediteur_id`),
  KEY `client_destinataire_id` (`client_destinataire_id`),
  KEY `vol_id` (`vol_id`),
  CONSTRAINT `colis_ibfk_1` FOREIGN KEY (`client_expediteur_id`) REFERENCES `clients` (`id`),
  CONSTRAINT `colis_ibfk_2` FOREIGN KEY (`client_destinataire_id`) REFERENCES `clients` (`id`),
  CONSTRAINT `colis_ibfk_3` FOREIGN KEY (`vol_id`) REFERENCES `vols` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `colis`
--

LOCK TABLES `colis` WRITE;
/*!40000 ALTER TABLE `colis` DISABLE KEYS */;
INSERT INTO `colis` VALUES
(1,2,1,'221771234567-06018889',2,3,'Fatou Sow','+33712345678','25 Rue de la République, 69001 Lyon','Dakar','Paris',NULL,NULL,45.00,15.00,60.00,1,'Ordinateur portable Dell XPS',2.50,'depart','14.7167,-17.4677','2026-04-26 03:33:55','dakar_paris'),
(2,2,1,'221771234567-11666084',2,1,'Dieynaba Keita','+33758686348','10 Rue de Paris, 75001 Paris','Dakar','Paris',NULL,NULL,65.00,20.00,85.00,2,'Vêtements traditionnels (lot 5 boubous)',5.00,'transit','14.7167,-17.4677','2026-04-29 00:49:05','dakar_paris'),
(3,2,1,'221776543210-40273754',4,5,'Claire Martin','+33698765432','42 Rue Paradis, 13001 Marseille','Thiès','Lyon',NULL,NULL,55.00,18.00,73.00,3,'Matériel électronique (lot smartphones)',8.20,'enregistre','14.7167,-17.4677','2026-04-26 03:33:55','dakar_paris'),
(4,2,1,'221778888888-66370521',6,7,'Sophie Dubois','+33612345678','18 Avenue des Champs, 33000 Bordeaux','Dakar','Bordeaux',NULL,NULL,45.00,12.00,57.00,4,'Tissus et pagnes (lot de 15 pièces)',3.00,'arrivee','48.8566,2.3522','2026-04-26 03:33:55','dakar_paris'),
(5,1,2,'33758686348-11031348',1,2,'Moussa Diop','+221771234567','15 Avenue Faidherbe, Dakar, Sénégal','Paris','Dakar',NULL,NULL,85.00,25.00,110.00,5,'Vins et fromages (lot France)',12.00,'livre','48.8566,-17.4677','2026-04-29 00:47:18','paris_dakar'),
(6,1,2,'33612345678-56045180',7,6,'Mamadou Diallo','+221778888888','12 Rue de la Liberté, Dakar, Sénégal','Bordeaux','Dakar',NULL,NULL,95.00,30.00,125.00,6,'Pièces automobiles',18.50,'transit','14.7167,-17.4677','2026-04-29 00:49:05','paris_dakar'),
(7,1,2,'33758686348-81906359',1,6,NULL,NULL,NULL,'Paris','Dakar',NULL,NULL,25.00,10.00,40.00,NULL,'Noix de cajou ',5.00,'enregistre','14.7167,-17.4677','2026-04-29 00:47:53','paris_dakar'),
(8,NULL,NULL,'UNKNOWN-30060813',NULL,NULL,'Khadim Ndiaye','+33758686348','10 Rue de Paris, 75001 Saint-Denis, France','Saint-Denis, France','Dakar, Sénégal','2026-04-29 14:06:02',NULL,45.00,15.00,60.00,4,'Colis personnel - Effets personnels et produits',5.50,'enregistre',NULL,'2026-04-29 14:06:02','paris_dakar'),
(9,NULL,NULL,'UNKNOWN-02063771',NULL,NULL,'Khadim Ndiaye','+33758686348','10 Rue de Paris, 75001 Saint-Denis','Saint-Denis, France','Hann Maristes, Dakar',NULL,'2026-04-29 16:49:04',45.00,15.00,60.00,NULL,'Colis personnel - Effets personnels',5.50,'arrivee','14.7225,-17.4308','2026-04-29 16:49:04','paris_dakar'),
(10,NULL,NULL,'33758686348-41019800',1,1,'Khadim Ndiaye','+33711112222','10 Rue de Paris, 75001 Saint-Denis','Saint-Denis, France','Hann Maristes, Dakar',NULL,'2026-04-29 16:52:11',45.00,15.00,60.00,NULL,'Colis Khadim - Effets personnels',5.50,'arrivee','14.7225,-17.4308','2026-04-29 16:52:11','paris_dakar'),
(11,NULL,NULL,'33799887766-20481527',9,9,'Khadim Ndiaye','+33799887766','10 Rue de Paris, 75001 Saint-Denis','Saint-Denis, France','Hann Maristes, Dakar',NULL,'2026-04-29 16:54:34',45.00,15.00,60.00,NULL,'Colis Khadim - Effets personnels',5.50,'arrivee','14.7225,-17.4308','2026-04-29 16:54:34','paris_dakar');
/*!40000 ALTER TABLE `colis` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER generate_colis_number
BEFORE INSERT ON colis
FOR EACH ROW
BEGIN
    DECLARE base_tel VARCHAR(20);
    DECLARE random_suffix VARCHAR(8);
    DECLARE new_number VARCHAR(50);
    DECLARE existing INT DEFAULT 1;
    
    IF NEW.client_expediteur_id IS NOT NULL THEN
        SELECT telephone INTO base_tel FROM clients WHERE id = NEW.client_expediteur_id LIMIT 1;
    END IF;
    
    IF base_tel IS NULL THEN
        SET base_tel = 'UNKNOWN';
    END IF;
    
    SET base_tel = REPLACE(REPLACE(REPLACE(base_tel, '+', ''), ' ', ''), '-', '');
    
    WHILE existing > 0 DO
        SET random_suffix = LPAD(FLOOR(RAND() * 100000000), 8, '0');
        SET new_number = CONCAT(base_tel, '-', random_suffix);
        SELECT COUNT(*) INTO existing FROM colis WHERE numero_suivi = new_number;
    END WHILE;
    
    SET NEW.numero_suivi = new_number;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `entites`
--

DROP TABLE IF EXISTS `entites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `entites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `ville` varchar(100) NOT NULL,
  `pays` varchar(100) NOT NULL,
  `adresse` text DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `date_creation` date DEFAULT NULL,
  `statut` enum('active','inactive') DEFAULT 'active',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entites`
--

LOCK TABLES `entites` WRITE;
/*!40000 ALTER TABLE `entites` DISABLE KEYS */;
INSERT INTO `entites` VALUES
(1,'Dieynaba Paris','Paris','France','10 Rue de Paris, 75001 Paris, France','+33123456789','contact@dieynaba-paris.fr','2024-01-01','active'),
(2,'Dieynaba Dakar','Dakar','Sénégal','15 Avenue Faidherbe, Dakar, Sénégal','+221338888888','contact@dieynaba-dakar.sn','2024-01-01','active');
/*!40000 ALTER TABLE `entites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fruits_tropicaux`
--

DROP TABLE IF EXISTS `fruits_tropicaux`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fruits_tropicaux` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `categorie` enum('mangue','ditakh','bissap','baobab','autre') DEFAULT 'autre',
  `prix` decimal(10,2) DEFAULT 0.00,
  `stock` int(11) DEFAULT 0,
  `badge` varchar(50) DEFAULT NULL,
  `date_ajout` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fruits_tropicaux`
--

LOCK TABLES `fruits_tropicaux` WRITE;
/*!40000 ALTER TABLE `fruits_tropicaux` DISABLE KEYS */;
INSERT INTO `fruits_tropicaux` VALUES
(1,'Mangue séchée & jus','Jus de mangue artisanal, pulpe congelée, mangues séchées.','https://images.unsplash.com/photo-1601493700631-2b16ec4b4716?w=400&h=250&fit=crop','mangue',17.00,0,'Exporter','2026-05-02 03:24:28'),
(2,'Ditakh (Jujube)','Fruit du jujubier, idéal pour jus et compléments alimentaires.','uploads/fruits/fruit_69f5fae882183.webp','ditakh',15.00,0,'Bio','2026-05-02 03:24:28'),
(3,'Bissap (Hibiscus)','Fleurs d\'hibiscus séchées, excellente base pour boissons.','uploads/fruits/fruit_69f5fa76d16b1.png','bissap',0.00,0,'Certifié','2026-05-02 03:24:28'),
(4,'Baobab (Bouye)','Poudre de fruit de baobab, riche en vitamine C.','uploads/fruits/fruit_69f5fb1c2aafd.jpg','baobab',14.00,0,'Naturel','2026-05-02 03:24:28');
/*!40000 ALTER TABLE `fruits_tropicaux` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `geolocalisation_entites`
--

DROP TABLE IF EXISTS `geolocalisation_entites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `geolocalisation_entites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entite_id` int(11) NOT NULL,
  `latitude` decimal(10,7) NOT NULL,
  `longitude` decimal(10,7) NOT NULL,
  `adresse_complete` text DEFAULT NULL,
  `date_mise_a_jour` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `entite_id` (`entite_id`),
  CONSTRAINT `geolocalisation_entites_ibfk_1` FOREIGN KEY (`entite_id`) REFERENCES `entites` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `geolocalisation_entites`
--

LOCK TABLES `geolocalisation_entites` WRITE;
/*!40000 ALTER TABLE `geolocalisation_entites` DISABLE KEYS */;
INSERT INTO `geolocalisation_entites` VALUES
(1,1,48.8566000,2.3522000,'10 Rue de Paris, 75001 Paris, France','2026-04-26 03:33:55'),
(2,2,14.7167000,-17.4677000,'15 Avenue Faidherbe, Dakar, Sénégal','2026-04-26 03:33:55');
/*!40000 ALTER TABLE `geolocalisation_entites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `geolocalisation_points`
--

DROP TABLE IF EXISTS `geolocalisation_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `geolocalisation_points` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `ville` varchar(50) NOT NULL,
  `pays` varchar(50) NOT NULL,
  `latitude` decimal(10,7) NOT NULL,
  `longitude` decimal(10,7) NOT NULL,
  `entite_id` int(11) DEFAULT NULL,
  `date_ajout` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `entite_id` (`entite_id`),
  CONSTRAINT `geolocalisation_points_ibfk_1` FOREIGN KEY (`entite_id`) REFERENCES `entites` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `geolocalisation_points`
--

LOCK TABLES `geolocalisation_points` WRITE;
/*!40000 ALTER TABLE `geolocalisation_points` DISABLE KEYS */;
INSERT INTO `geolocalisation_points` VALUES
(1,'Hann Maristes','Dakar','Sénégal',14.7225000,-17.4308000,2,'2026-04-27 22:24:09'),
(2,'Hann Bel-Air','Dakar','Sénégal',14.7180000,-17.4340000,2,'2026-04-27 22:24:09'),
(3,'Yoff','Dakar','Sénégal',14.7560000,-17.4666000,2,'2026-04-27 22:24:09'),
(4,'Yoff Aéroport','Dakar','Sénégal',14.7400000,-17.4670000,2,'2026-04-27 22:24:09'),
(5,'Quakam','Dakar','Sénégal',14.7350000,-17.4450000,2,'2026-04-27 22:24:09'),
(6,'Quakam Cité Douane','Dakar','Sénégal',14.7385000,-17.4480000,2,'2026-04-27 22:24:09'),
(7,'HLM Grand Yoff','Dakar','Sénégal',14.7330000,-17.4540000,2,'2026-04-27 22:24:09'),
(8,'HLM Patte d Oie','Dakar','Sénégal',14.6880000,-17.4670000,2,'2026-04-27 22:24:09'),
(9,'Colobane','Dakar','Sénégal',14.6840000,-17.4460000,2,'2026-04-27 22:24:09'),
(10,'Grand Dakar','Dakar','Sénégal',14.6920000,-17.4480000,2,'2026-04-27 22:24:09'),
(11,'Mermoz','Dakar','Sénégal',14.7020000,-17.4690000,2,'2026-04-27 22:24:09'),
(12,'Plateau','Dakar','Sénégal',14.6650000,-17.4365000,2,'2026-04-27 22:24:09'),
(13,'Saint-Denis Centre','Saint-Denis','France',48.9358000,2.3580000,1,'2026-04-27 22:24:09'),
(14,'Saint-Denis Basilique','Saint-Denis','France',48.9354000,2.3595000,1,'2026-04-27 22:24:09'),
(15,'Saint-Denis Université','Saint-Denis','France',48.9440000,2.3620000,1,'2026-04-27 22:24:09'),
(16,'Saint-Denis Pleyel','Saint-Denis','France',48.9202000,2.3448000,1,'2026-04-27 22:24:09'),
(17,'Saint-Denis Porte de Paris','Saint-Denis','France',48.9230000,2.3550000,1,'2026-04-27 22:24:09'),
(18,'Saint-Denis La Plaine','Saint-Denis','France',48.9163000,2.3540000,1,'2026-04-27 22:24:09'),
(19,'Stade de France','Saint-Denis','France',48.9245000,2.3600000,1,'2026-04-27 22:24:09'),
(20,'Aubervilliers','Aubervilliers','France',48.9160000,2.3880000,1,'2026-04-27 22:24:09'),
(21,'La Courneuve','La Courneuve','France',48.9300000,2.3920000,1,'2026-04-27 22:24:09');
/*!40000 ALTER TABLE `geolocalisation_points` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `images_generees`
--

DROP TABLE IF EXISTS `images_generees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `images_generees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `boutique_id` int(11) DEFAULT NULL,
  `chemin_image` varchar(255) DEFAULT NULL,
  `date_creation` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `boutique_id` (`boutique_id`),
  CONSTRAINT `images_generees_ibfk_1` FOREIGN KEY (`boutique_id`) REFERENCES `boutiques` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `images_generees`
--

LOCK TABLES `images_generees` WRITE;
/*!40000 ALTER TABLE `images_generees` DISABLE KEYS */;
INSERT INTO `images_generees` VALUES
(1,1,'images/gp_1_1777380696.jpg','2026-04-28 12:51:36'),
(2,1,'images/gp_1_1777380876.jpg','2026-04-28 12:54:36'),
(3,2,'images/gp_2_1777380966.jpg','2026-04-28 12:56:06'),
(4,3,'images/gp_3_1777381056.jpg','2026-04-28 12:57:36'),
(5,4,'images/gp_4_1777381146.jpg','2026-04-28 12:59:06'),
(6,1,'images/gp_custom_1_1777471704.jpg','2026-04-29 14:08:24'),
(7,2,'images/gp_custom_2_1777471792.jpg','2026-04-29 14:09:52');
/*!40000 ALTER TABLE `images_generees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lieux_convergence`
--

DROP TABLE IF EXISTS `lieux_convergence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lieux_convergence` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(150) NOT NULL,
  `type` enum('restaurant','association','mosquee','foire','salon','mairie','autre') DEFAULT 'autre',
  `adresse` text DEFAULT NULL,
  `ville` varchar(100) DEFAULT NULL,
  `pays` varchar(50) DEFAULT 'Sénégal',
  `latitude` decimal(10,6) DEFAULT NULL,
  `longitude` decimal(10,6) DEFAULT NULL,
  `horaires` text DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `site_web` varchar(200) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lieux_convergence`
--

LOCK TABLES `lieux_convergence` WRITE;
/*!40000 ALTER TABLE `lieux_convergence` DISABLE KEYS */;
INSERT INTO `lieux_convergence` VALUES
(1,'Grande Mosquée de Paris','mosquee','2bis Place du Puits de l\'Ermite, 75005 Paris','Paris','Sénégal',NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(2,'Restaurant Le Ndar','restaurant','18 Rue des Rosiers, 75004 Paris','Paris','Sénégal',NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(3,'Association Sénégalaise de France (ASF)','association','35 Rue de la Grange aux Belles, 75010 Paris','Paris','Sénégal',NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4,'Foire Africaine de Paris','foire','Paris Expo Porte de Versailles','Paris','Sénégal',NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(5,'Marché Saint-Denis','autre','Place du Marché, 93200 Saint-Denis','Saint-Denis','Sénégal',NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(6,'Restaurant Thiossane','restaurant','24 Rue de Marseille, 69007 Lyon','Lyon','Sénégal',NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(7,'Association Keur Sénégal','association','30 Rue Pasteur, 69007 Lyon','Lyon','Sénégal',NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(8,'Grande Mosquee de Paris','mosquee',NULL,'Paris','Sénégal',NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(9,'Restaurant Le Ndar','restaurant',NULL,'Paris','Sénégal',NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(10,'Association Senegalais de France','association',NULL,'Paris','Sénégal',NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(11,'Foire Africaine de Paris','foire',NULL,'Paris','Sénégal',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `lieux_convergence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mode_accessoires`
--

DROP TABLE IF EXISTS `mode_accessoires`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mode_accessoires` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code_produit` varchar(50) NOT NULL,
  `nom` varchar(200) NOT NULL,
  `categorie` enum('chaussures','sacs','accessoires','ceintures','montres','parfums') DEFAULT 'accessoires',
  `genre` enum('femme','homme','unisexe') DEFAULT 'femme',
  `marque` varchar(100) DEFAULT NULL,
  `matiere` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `prix_achat` decimal(12,2) NOT NULL,
  `prix_vente` decimal(12,2) NOT NULL,
  `stock` int(11) DEFAULT 0,
  `image` varchar(255) DEFAULT NULL,
  `tailles_disponibles` varchar(100) DEFAULT NULL,
  `couleurs` varchar(100) DEFAULT NULL,
  `date_ajout` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code_produit` (`code_produit`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mode_accessoires`
--

LOCK TABLES `mode_accessoires` WRITE;
/*!40000 ALTER TABLE `mode_accessoires` DISABLE KEYS */;
INSERT INTO `mode_accessoires` VALUES
(1,'SAC-055108','Sac à main Luxe','sacs','femme','Gucci','Cuir véritable','Sac à main en cuir italien, doublure satinée',250.00,450.00,5,'uploads/mode/mode_1.jpeg','Unique','Noir,Beige,Bordeaux','2026-04-30 00:47:31'),
(2,'CHA-057835','Escarpins Louboutin','chaussures','femme','Christian Louboutin','Cuir verni','Escarpins talon 10cm semelle rouge',180.00,350.00,3,'uploads/mode/mode_2.jpg','36,37,38,39,40','Noir,Rouge,Nude','2026-04-30 00:47:31'),
(3,'CEI-023850','Ceinture Hermès','ceintures','homme','Hermès','Cuir','Ceinture réversible boucle H',120.00,250.00,8,NULL,'85,90,95,100,105','Noir,Brun','2026-04-30 00:47:31'),
(4,'MON-045746','Montre Cartier','montres','unisexe','Cartier','Acier','Montre Tank Française, mouvement automatique',2500.00,4800.00,2,'uploads/mode/mode_4.jpg','Unique','Argent,Or','2026-04-30 00:47:31'),
(5,'PAR-057178','Parfum Oud','parfums','unisexe','Maison Francis','Extrait','Parfum oriental Oud, notes boisées',80.00,150.00,12,'uploads/mode/mode_5.jpg','50ml,100ml','','2026-04-30 00:47:31'),
(6,'CHA-048656','Mocassins Tod\'s','chaussures','homme','Tod\'s','Cuir','Mocassins en cuir, semelle gomme',150.00,290.00,6,NULL,'39,40,41,42,43,44','Noir,Brun','2026-04-30 00:47:31'),
(7,'ACC-071744','Pochette Soirée','accessoires','femme','Dior','Satin','Pochette de soirée strass',90.00,199.00,4,NULL,'Unique','Noir,Or,Rose','2026-04-30 00:47:31'),
(8,'SAC-012755','Sac à dos Cuir','sacs','homme','Louis Vuitton','Cuir','Sac à dos luxe pour homme',350.00,650.00,2,'uploads/mode/mode_8.jpeg','Unique','Noir,Marron','2026-04-30 00:47:31');
/*!40000 ALTER TABLE `mode_accessoires` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER generate_mode_code BEFORE INSERT ON mode_accessoires
FOR EACH ROW
BEGIN
    DECLARE prefix VARCHAR(10);
    DECLARE random_num VARCHAR(8);
    DECLARE new_code VARCHAR(50);
    DECLARE existing INT DEFAULT 1;
    
    SET prefix = CASE NEW.categorie
        WHEN 'chaussures' THEN 'CHA'
        WHEN 'sacs' THEN 'SAC'
        WHEN 'accessoires' THEN 'ACC'
        WHEN 'ceintures' THEN 'CEI'
        WHEN 'montres' THEN 'MON'
        WHEN 'parfums' THEN 'PAR'
        ELSE 'MOD'
    END;
    
    WHILE existing > 0 DO
        SET random_num = LPAD(FLOOR(RAND() * 100000), 6, '0');
        SET new_code = CONCAT(prefix, '-', random_num);
        SELECT COUNT(*) INTO existing FROM mode_accessoires WHERE code_produit = new_code;
    END WHILE;
    
    SET NEW.code_produit = new_code;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `negoce`
--

DROP TABLE IF EXISTS `negoce`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `negoce` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code_produit` varchar(50) NOT NULL,
  `nom` varchar(200) NOT NULL,
  `categorie` enum('telephone','informatique','electromenager','mobilier','vehicule','autre') DEFAULT 'autre',
  `marque` varchar(100) DEFAULT NULL,
  `modele` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `prix_achat` decimal(12,2) NOT NULL,
  `prix_vente` decimal(12,2) NOT NULL,
  `stock` int(11) DEFAULT 0,
  `image` varchar(255) DEFAULT NULL,
  `garantie_mois` int(11) DEFAULT 12,
  `etat` enum('neuf','occasion','reconditionne') DEFAULT 'neuf',
  `date_ajout` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code_produit` (`code_produit`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `negoce`
--

LOCK TABLES `negoce` WRITE;
/*!40000 ALTER TABLE `negoce` DISABLE KEYS */;
INSERT INTO `negoce` VALUES
(1,'TEL-052739','iPhone 15 Pro Max','telephone','Apple','A17 Pro - 256 Go','iPhone 15 Pro Max, écran 6.7\", 256GB, Noir',950.00,1299.00,5,'uploads/negoce/negoce_1.jpg',24,'neuf','2026-04-28 12:32:24'),
(2,'INF-057315','MacBook Pro M3','informatique','Apple','M3 Pro - 512 Go','MacBook Pro 14\", puce M3 Pro, 18GB RAM, 512GB SSD',1800.00,2499.00,3,'uploads/negoce/negoce_2.jpg',24,'neuf','2026-04-28 12:32:24'),
(3,'ELE-028357','Samsung QLED 65\"','electromenager','Samsung','QN90C','TV QLED 65 pouces 4K, Smart TV, Quantum HDR',900.00,1450.00,4,'uploads/negoce/negoce_3.jpg',24,'neuf','2026-04-28 12:32:24'),
(4,'MOB-069840','Canapé Cuir Italien','mobilier','Natuzzi','Modèle Eden','Canapé 3 places en cuir véritable italien',1200.00,2200.00,2,'uploads/negoce/negoce_4.jpg',12,'neuf','2026-04-28 12:32:24'),
(5,'VEH-064129','Moto Cross 250cc','telephone','Yamaha','YZ250F','Moto cross 250cc, faible kilométrage',3500.00,5600.00,1,'uploads/negoce/moto.jpg',6,'occasion','2026-04-28 12:32:24'),
(6,'ELE-011127','Réfrigérateur Américain','electromenager','LG','InstaView','Réfrigérateur américain 500L, distributeur eau/glace',850.00,1490.00,3,'uploads/negoce/frigo.jpg',24,'neuf','2026-04-28 12:32:24'),
(7,'INF-063247','PC Gamer i9 RTX 4080','informatique','Dell','Alienware','PC Gamer Intel i9, 32GB RAM, RTX 4080, 2TB SSD',2200.00,3200.00,2,'uploads/negoce/pc_gamer.jpg',24,'reconditionne','2026-04-28 12:32:24');
/*!40000 ALTER TABLE `negoce` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER generate_negoce_code BEFORE INSERT ON negoce
FOR EACH ROW
BEGIN
    DECLARE prefix VARCHAR(10);
    DECLARE random_num VARCHAR(8);
    DECLARE new_code VARCHAR(50);
    DECLARE existing INT DEFAULT 1;
    
    SET prefix = CASE NEW.categorie
        WHEN 'telephone' THEN 'TEL'
        WHEN 'informatique' THEN 'INF'
        WHEN 'electromenager' THEN 'ELE'
        WHEN 'mobilier' THEN 'MOB'
        WHEN 'vehicule' THEN 'VEH'
        ELSE 'NEG'
    END;
    
    WHILE existing > 0 DO
        SET random_num = LPAD(FLOOR(RAND() * 100000), 6, '0');
        SET new_code = CONCAT(prefix, '-', random_num);
        SELECT COUNT(*) INTO existing FROM negoce WHERE code_produit = new_code;
    END WHILE;
    
    SET NEW.code_produit = new_code;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `notifications_whatsapp`
--

DROP TABLE IF EXISTS `notifications_whatsapp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications_whatsapp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `destinataire_telephone` varchar(20) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `statut_envoi` enum('envoye','echoue') DEFAULT 'envoye',
  `date_envoi` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications_whatsapp`
--

LOCK TABLES `notifications_whatsapp` WRITE;
/*!40000 ALTER TABLE `notifications_whatsapp` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications_whatsapp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `offres_services`
--

DROP TABLE IF EXISTS `offres_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `offres_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `type_offre` enum('fret','boutique','premium','abonnement') DEFAULT 'fret',
  `montant_ht` decimal(12,2) NOT NULL,
  `montant_tva` decimal(12,2) DEFAULT 0.00,
  `montant_ttc` decimal(12,2) NOT NULL,
  `description` text DEFAULT NULL,
  `conditions` text DEFAULT NULL,
  `validite` date DEFAULT NULL,
  `statut` enum('en_attente','envoye','accepte','refuse') DEFAULT 'en_attente',
  `date_creation` timestamp NULL DEFAULT current_timestamp(),
  `date_envoi` datetime DEFAULT NULL,
  `pdf_path` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `client_id` (`client_id`),
  CONSTRAINT `offres_services_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offres_services`
--

LOCK TABLES `offres_services` WRITE;
/*!40000 ALTER TABLE `offres_services` DISABLE KEYS */;
INSERT INTO `offres_services` VALUES
(1,4,'fret',1500.00,300.00,1800.00,'Expédition de colis entre la France et le Sénégal, suivi GPS en temps réel, QR code personnalisé, notification WhatsApp, assistance 7j/7.','Offre valable 30 jours. Paiement à réception de facture. Livraison sous 48-72h.','2026-05-27','envoye','2026-04-27 18:48:40','2026-04-28 00:06:46',NULL),
(2,4,'fret',150.00,30.00,180.00,'Noix de cajou ','Offre valable 30 jours. Paiement à réception. Livraison sous 48-72h.','2026-05-27','envoye','2026-04-27 23:36:01','2026-04-28 14:09:17',NULL);
/*!40000 ALTER TABLE `offres_services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `operations_financieres`
--

DROP TABLE IF EXISTS `operations_financieres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `operations_financieres` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `colis_id` int(11) NOT NULL,
  `entite_origine` int(11) NOT NULL,
  `entite_destination` int(11) NOT NULL,
  `type_operation` enum('expedition','reception','transfert','douane') DEFAULT 'expedition',
  `montant_expedition` decimal(12,2) DEFAULT 0.00,
  `montant_douane` decimal(12,2) DEFAULT 0.00,
  `montant_taxe` decimal(12,2) DEFAULT 0.00,
  `montant_total` decimal(12,2) DEFAULT 0.00,
  `devise` varchar(3) DEFAULT 'EUR',
  `date_operation` datetime DEFAULT current_timestamp(),
  `reference_facture` varchar(50) DEFAULT NULL,
  `statut_paiement` enum('en_attente','paye','annule') DEFAULT 'en_attente',
  PRIMARY KEY (`id`),
  KEY `colis_id` (`colis_id`),
  KEY `entite_origine` (`entite_origine`),
  KEY `entite_destination` (`entite_destination`),
  CONSTRAINT `operations_financieres_ibfk_1` FOREIGN KEY (`colis_id`) REFERENCES `colis` (`id`),
  CONSTRAINT `operations_financieres_ibfk_2` FOREIGN KEY (`entite_origine`) REFERENCES `entites` (`id`),
  CONSTRAINT `operations_financieres_ibfk_3` FOREIGN KEY (`entite_destination`) REFERENCES `entites` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `operations_financieres`
--

LOCK TABLES `operations_financieres` WRITE;
/*!40000 ALTER TABLE `operations_financieres` DISABLE KEYS */;
INSERT INTO `operations_financieres` VALUES
(1,1,2,1,'expedition',45.00,15.00,9.00,69.00,'EUR','2026-04-26 03:33:55',NULL,'paye'),
(2,2,2,1,'expedition',65.00,20.00,13.00,98.00,'EUR','2026-04-26 03:33:55',NULL,'paye'),
(3,3,2,1,'expedition',55.00,18.00,9.90,82.90,'EUR','2026-04-26 03:33:55',NULL,'en_attente'),
(4,4,2,1,'expedition',45.00,12.00,8.10,65.10,'EUR','2026-04-26 03:33:55',NULL,'paye'),
(5,5,1,2,'expedition',85.00,25.00,17.00,127.00,'EUR','2026-04-26 03:33:55',NULL,'paye'),
(6,6,1,2,'expedition',95.00,30.00,19.00,144.00,'EUR','2026-04-26 03:33:55',NULL,'en_attente'),
(7,7,1,2,'expedition',25.00,10.00,5.00,40.00,'EUR','2026-04-27 10:47:03',NULL,'en_attente');
/*!40000 ALTER TABLE `operations_financieres` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `produits`
--

DROP TABLE IF EXISTS `produits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `produits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `prix` decimal(10,2) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `stock` int(11) DEFAULT 0,
  `date_ajout` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produits`
--

LOCK TABLES `produits` WRITE;
/*!40000 ALTER TABLE `produits` DISABLE KEYS */;
INSERT INTO `produits` VALUES
(1,'Huile de palme rouge (1L)','Huile naturelle 100% pure, idéale pour la cuisine ouest-africaine. Conditionnée au Sénégal.',8.50,'uploads/produit_1.jpeg',25,'2026-04-26 03:33:55'),
(2,'Crevettes séchées (200g)','Crevettes artisanales séchées au soleil, très parfumées, conditionnées sous vide.',12.90,'uploads/produit_2.jpeg',15,'2026-04-26 03:33:55'),
(3,'Soupe kandia (Gombo)','Mélange d\'épices traditionnelles pour soupe kandia (gombo). Recette authentique.',5.50,'uploads/produit_3.jpeg',40,'2026-04-26 03:33:55'),
(4,'Miel de Casamance (250g)','Miel sauvage récolté en forêt de Casamance, 100% pur et naturel.',11.50,'uploads/produit_4.jpeg',20,'2026-04-26 03:33:55'),
(5,'Thé à la menthe','Thé vert importé du Sénégal, accompagné de menthe fraîche.',6.00,'uploads/produit_5.jpeg',35,'2026-04-26 03:33:55'),
(6,'Attiéké (500g)','Semoule de manioc, spécialité ivoirienne très prisée en Afrique de l\'Ouest.',4.90,'uploads/produit_6.jpeg',30,'2026-04-26 03:33:55'),
(7,'Beurre de karité pur','Beurre de karité bio 100g, hydratation naturelle pour peau et cheveux.',9.00,'uploads/produit_7.jpeg',18,'2026-04-26 03:33:55'),
(8,'Soupe de poisson (sachet)','Mélange d\'épices pour soupe de poisson sénégalaise (thiof).',4.50,'uploads/produit_8.jpeg',50,'2026-04-26 03:33:55');
/*!40000 ALTER TABLE `produits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prospects_senegalais`
--

DROP TABLE IF EXISTS `prospects_senegalais`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `prospects_senegalais` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `civilite` varchar(10) DEFAULT NULL,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) DEFAULT NULL,
  `fonction` varchar(150) DEFAULT NULL,
  `association_entreprise` varchar(200) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `adresse` text DEFAULT NULL,
  `code_postal` varchar(10) DEFAULT NULL,
  `ville` varchar(100) DEFAULT NULL,
  `region` varchar(100) DEFAULT NULL,
  `type_contact` enum('association','restaurant','influenceur','foire','autre') DEFAULT 'autre',
  `notes` text DEFAULT NULL,
  `date_ajout` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prospects_senegalais`
--

LOCK TABLES `prospects_senegalais` WRITE;
/*!40000 ALTER TABLE `prospects_senegalais` DISABLE KEYS */;
INSERT INTO `prospects_senegalais` VALUES
(1,'M.','Sall','Maguette','Président','Grande Mosquée de Paris','contact@grandemosqueeparis.fr','+33142345678',NULL,NULL,'Paris',NULL,'association',NULL,'2026-04-26 03:33:55'),
(2,'Mme','Ndiaye','Awa','Gérante','Restaurant Le Ndar','contact@restaurant-ndar.fr','+33140305060',NULL,NULL,'Paris',NULL,'restaurant',NULL,'2026-04-26 03:33:55'),
(3,'M.','Fall','Cheikh','Influenceur Mode','Sunu Afro Style','cheikh.fall@sunuafro.com','+33788990011',NULL,NULL,'Lyon',NULL,'influenceur',NULL,'2026-04-26 03:33:55'),
(4,'Mme','Diop','Mame','Organisatrice','Foire Africaine de Paris','mame.diop@foireafricaine.fr','+33655443322',NULL,NULL,'Paris',NULL,'foire',NULL,'2026-04-26 03:33:55'),
(5,'M.','Mbaye','Pape','Président','Association Sénégalaise de Lyon','contact@aslyon.fr','+33478234567',NULL,NULL,'Lyon',NULL,'association',NULL,'2026-04-26 03:33:55');
/*!40000 ALTER TABLE `prospects_senegalais` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sponsors`
--

DROP TABLE IF EXISTS `sponsors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sponsors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `logo_url` varchar(255) DEFAULT NULL,
  `site_web` varchar(255) DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `statut` enum('actif','inactif') DEFAULT 'actif',
  `date_ajout` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sponsors`
--

LOCK TABLES `sponsors` WRITE;
/*!40000 ALTER TABLE `sponsors` DISABLE KEYS */;
INSERT INTO `sponsors` VALUES
(1,'SEN PULPE','Spécialiste du ditakh','https://placehold.co/150x150/2c5f2d/white?text=SEN+PULPE','#','','','actif','2026-05-02 03:24:28'),
(2,'AfricAlliance','Export fruits tropicaux','https://placehold.co/150x150/2c5f2d/white?text=AfricAlliance','#',NULL,NULL,'actif','2026-05-02 03:24:28'),
(3,'Cedus','Logistique & export','https://placehold.co/150x150/2c5f2d/white?text=Cedus','#',NULL,NULL,'actif','2026-05-02 03:24:28'),
(4,'Tropic Box','Panier fruitier','https://placehold.co/150x150/2c5f2d/white?text=Tropic+Box','#',NULL,NULL,'actif','2026-05-02 03:24:28');
/*!40000 ALTER TABLE `sponsors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stats_globales`
--

DROP TABLE IF EXISTS `stats_globales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `stats_globales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_stat` date NOT NULL,
  `total_colis_expedies` int(11) DEFAULT 0,
  `total_colis_paris_dakar` int(11) DEFAULT 0,
  `total_colis_dakar_paris` int(11) DEFAULT 0,
  `total_charges` decimal(12,2) DEFAULT 0.00,
  `total_encaissements` decimal(12,2) DEFAULT 0.00,
  `benefice_net` decimal(12,2) DEFAULT 0.00,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `date_stat` (`date_stat`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stats_globales`
--

LOCK TABLES `stats_globales` WRITE;
/*!40000 ALTER TABLE `stats_globales` DISABLE KEYS */;
INSERT INTO `stats_globales` VALUES
(1,'2026-04-26',6,2,4,2855.00,586.00,-2269.00,'2026-04-26 03:33:55');
/*!40000 ALTER TABLE `stats_globales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `statuts_suivi`
--

DROP TABLE IF EXISTS `statuts_suivi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `statuts_suivi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `colis_id` int(11) DEFAULT NULL,
  `statut` varchar(50) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `localisation` varchar(100) DEFAULT NULL,
  `date_heure` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `colis_id` (`colis_id`),
  CONSTRAINT `statuts_suivi_ibfk_1` FOREIGN KEY (`colis_id`) REFERENCES `colis` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `statuts_suivi`
--

LOCK TABLES `statuts_suivi` WRITE;
/*!40000 ALTER TABLE `statuts_suivi` DISABLE KEYS */;
INSERT INTO `statuts_suivi` VALUES
(1,1,'enregistre',NULL,'Dakar Sénégal','2026-05-01 09:00:00'),
(2,1,'depart',NULL,'Aéroport Dakar','2026-05-02 10:30:00'),
(3,2,'enregistre',NULL,'Dakar Sénégal','2026-05-03 14:00:00'),
(4,2,'depart',NULL,'Aéroport Dakar','2026-05-09 11:00:00'),
(5,2,'transit',NULL,'En vol - Océan Atlantique','2026-05-09 13:00:00'),
(6,3,'enregistre',NULL,'Thiès Sénégal','2026-05-10 08:00:00'),
(7,4,'enregistre',NULL,'Dakar Sénégal','2026-05-04 10:00:00'),
(8,4,'depart',NULL,'Aéroport Dakar','2026-05-09 11:00:00'),
(9,4,'arrivee',NULL,'Paris CDG','2026-05-16 16:00:00'),
(10,5,'enregistre',NULL,'Paris France','2026-05-02 09:00:00'),
(11,5,'depart',NULL,'Paris CDG','2026-05-05 08:00:00'),
(12,5,'arrivee',NULL,'Aéroport Dakar','2026-05-12 15:30:00'),
(13,5,'livre',NULL,'Dakar Sénégal','2026-05-14 14:00:00'),
(14,6,'enregistre',NULL,'Bordeaux France','2026-05-10 11:00:00');
/*!40000 ALTER TABLE `statuts_suivi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taxes`
--

DROP TABLE IF EXISTS `taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `taxes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entite_id` int(11) NOT NULL,
  `direction` enum('paris_dakar','dakar_paris') NOT NULL,
  `type_taxe` varchar(50) NOT NULL,
  `taux` decimal(5,2) NOT NULL,
  `description` text DEFAULT NULL,
  `date_application` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entite_id` (`entite_id`),
  CONSTRAINT `taxes_ibfk_1` FOREIGN KEY (`entite_id`) REFERENCES `entites` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taxes`
--

LOCK TABLES `taxes` WRITE;
/*!40000 ALTER TABLE `taxes` DISABLE KEYS */;
INSERT INTO `taxes` VALUES
(1,1,'paris_dakar','TVA',20.00,'Taxe sur la valeur ajoutée France',NULL),
(2,1,'paris_dakar','Frais de dossier',5.00,'Frais administratifs Paris',NULL),
(3,2,'dakar_paris','TVA',18.00,'TVA Sénégal',NULL),
(4,2,'dakar_paris','Frais de douane',15.00,'Droits de douane Sénégal',NULL);
/*!40000 ALTER TABLE `taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ventes`
--

DROP TABLE IF EXISTS `ventes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ventes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_produit` enum('bijouterie','negoce') NOT NULL,
  `produit_id` int(11) NOT NULL,
  `client_nom` varchar(100) DEFAULT NULL,
  `client_telephone` varchar(20) DEFAULT NULL,
  `quantite` int(11) DEFAULT 1,
  `prix_unitaire` decimal(12,2) NOT NULL,
  `montant_total` decimal(12,2) NOT NULL,
  `date_vente` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ventes`
--

LOCK TABLES `ventes` WRITE;
/*!40000 ALTER TABLE `ventes` DISABLE KEYS */;
/*!40000 ALTER TABLE `ventes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vetements`
--

DROP TABLE IF EXISTS `vetements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `vetements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `categorie` varchar(50) DEFAULT NULL,
  `prix` decimal(10,2) NOT NULL,
  `tailles` varchar(100) DEFAULT NULL,
  `couleurs` varchar(100) DEFAULT NULL,
  `stock` int(11) DEFAULT 0,
  `image` varchar(255) DEFAULT NULL,
  `date_ajout` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vetements`
--

LOCK TABLES `vetements` WRITE;
/*!40000 ALTER TABLE `vetements` DISABLE KEYS */;
INSERT INTO `vetements` VALUES
(1,'Boubou Sénégalais Homme','Boubou traditionnel en tissu bazin riche, brodé main. Idéal pour cérémonies.','Homme',89.00,'M,L,XL,XXL','Bleu,Marron,Noir,Bordeaux',12,'uploads/vetements/vetement_69f217ec5887d.png','2026-04-26 03:33:55'),
(2,'Robe Kaftan Femme','Kaftan en soie avec motifs dorés, idéal pour cérémonies et soirées.','Femme',120.00,'S,M,L,XL','Or,Rose,Bordeaux,Vert',8,'uploads/vetements/vetement_69f2182dde573.jpg','2026-04-26 03:33:55'),
(3,'Grand Boubou Femme Wax','Ensemble pagne + boubou en tissu wax imprimé, coloré et élégant.','Femme',95.00,'M,L,XL','Multicolore,Orange,Bleu',15,'uploads/vetements/grand_boubou_femme.jpg','2026-04-26 03:33:55'),
(4,'Chemise Africaine','Chemise casual en tissu pagne, manches courtes, coupe moderne.','Homme',55.00,'S,M,L,XL','Bleu,Vert,Gris,Noir',20,'uploads/vetements/vetement_69f2184775082.png','2026-04-26 03:33:55'),
(5,'Dentelle Sénégalaise','Tenue de cérémonie en dentelle fine, broderie main.','Femme',150.00,'S,M,L','Blanche,Ivoire,Champagne',6,'uploads/vetements/dentelle_senegalaise.jpg','2026-04-26 03:33:55'),
(6,'Bazin Riche Homme','Bazin riche de luxe, broderie fine, pour mariages et grandes occasions.','Homme',180.00,'L,XL,XXL','Bleu,Noir,Marron',5,'uploads/vetements/vetement_69f218c086849.png','2026-04-26 03:33:55');
/*!40000 ALTER TABLE `vetements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vols`
--

DROP TABLE IF EXISTS `vols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `vols` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numero_vol` varchar(20) NOT NULL,
  `depart_ville` varchar(100) NOT NULL,
  `arrivee_ville` varchar(100) NOT NULL,
  `date_depart` datetime NOT NULL,
  `date_arrivee_estimee` datetime DEFAULT NULL,
  `statut` enum('planifie','en-vol','arrive','annule') DEFAULT 'planifie',
  PRIMARY KEY (`id`),
  UNIQUE KEY `numero_vol` (`numero_vol`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vols`
--

LOCK TABLES `vols` WRITE;
/*!40000 ALTER TABLE `vols` DISABLE KEYS */;
INSERT INTO `vols` VALUES
(1,'SN202','Paris','Dakar','2026-05-05 08:00:00','2026-05-05 14:30:00','planifie'),
(2,'SN204','Paris','Dakar','2026-05-12 09:00:00','2026-05-12 15:30:00','planifie'),
(3,'SN206','Paris','Dakar','2026-05-19 08:30:00','2026-05-19 15:00:00','planifie'),
(4,'AF823','Dakar','Paris','2026-05-02 10:30:00','2026-05-02 16:00:00','planifie'),
(5,'AF825','Dakar','Paris','2026-05-09 11:00:00','2026-05-09 16:30:00','planifie'),
(6,'AF827','Dakar','Paris','2026-05-16 10:00:00','2026-05-16 15:30:00','planifie');
/*!40000 ALTER TABLE `vols` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-22 16:40:02
