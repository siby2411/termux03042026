/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: portail_ecommerce
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `actif` tinyint(1) DEFAULT 1,
  `ordre` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`),
  CONSTRAINT `categories_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES
(1,'Informatique','Ordinateurs, périphériques et accessoires informatiques',NULL,NULL,1,0),
(2,'Électronique','Smartphones, tablettes, TV et appareils électroniques',NULL,NULL,1,0),
(3,'Réseau','Routeurs, switches, câbles et équipements réseau',NULL,NULL,1,0),
(4,'Accessoires','Souris, claviers, casques, sacoches',NULL,NULL,1,0),
(5,'Consommables','Cartouches, toner, papier, fournitures de bureau',NULL,NULL,1,0);
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_client` enum('particulier','entreprise') DEFAULT 'particulier',
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `telephone2` varchar(20) DEFAULT NULL,
  `adresse` text DEFAULT NULL,
  `ville` varchar(100) DEFAULT NULL,
  `pays` varchar(50) DEFAULT 'Sénégal',
  `ninea` varchar(50) DEFAULT NULL,
  `registre_commerce` varchar(50) DEFAULT NULL,
  `statut` enum('actif','inactif','suspendu') DEFAULT 'actif',
  `plafond_credit` decimal(12,2) DEFAULT 0.00,
  `remise_habituelle` decimal(5,2) DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `mot_de_passe` varchar(255) NOT NULL,
  `date_creation` datetime DEFAULT current_timestamp(),
  `derniere_connexion` datetime DEFAULT NULL,
  `actif` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` VALUES
(1,'particulier','Diop','Mamadou','mamadou.diop@email.sn','77 123 45 67',NULL,NULL,'Dakar','Sénégal',NULL,NULL,'actif',0.00,0.00,NULL,'$2y$10$Ew.Y/iV0C0b7gM6rM1C.J.8XjPqV6s1lG7fL/fNf2Ff2Ff2Ff2Ff2','2026-03-28 17:15:38',NULL,1),
(2,'particulier','Fall','Aïcha','aicha.fall@email.sn','78 234 56 78',NULL,NULL,'Thiès','Sénégal',NULL,NULL,'actif',0.00,0.00,NULL,'$2y$10$Ew.Y/iV0C0b7gM6rM1C.J.8XjPqV6s1lG7fL/fNf2Ff2Ff2Ff2Ff2','2026-03-28 17:15:38',NULL,1),
(3,'entreprise','NDIAYE ET FILS',NULL,'contact@ndiaye.sn','33 123 45 67',NULL,NULL,'Dakar','Sénégal','123456789','123456789','actif',0.00,0.00,NULL,'$2y$10$Ew.Y/iV0C0b7gM6rM1C.J.8XjPqV6s1lG7fL/fNf2Ff2Ff2Ff2Ff2','2026-03-28 17:15:38',NULL,1),
(4,'particulier','Sow','Oumar','oumar.sow@email.sn','76 345 67 89',NULL,NULL,'Saint-Louis','Sénégal',NULL,NULL,'actif',0.00,0.00,NULL,'$2y$10$Ew.Y/iV0C0b7gM6rM1C.J.8XjPqV6s1lG7fL/fNf2Ff2Ff2Ff2Ff2','2026-03-28 17:15:38',NULL,1),
(5,'entreprise','DIENG CORPORATION',NULL,'commercial@dieng.sn','33 987 65 43',NULL,NULL,'Dakar','Sénégal','987654321','987654321','actif',0.00,0.00,NULL,'$2y$10$Ew.Y/iV0C0b7gM6rM1C.J.8XjPqV6s1lG7fL/fNf2Ff2Ff2Ff2Ff2','2026-03-28 17:15:38',NULL,1),
(6,'entreprise','ADMIN','Super','admin@portail.sn','77 000 00 00',NULL,NULL,NULL,'Sénégal',NULL,NULL,'actif',0.00,0.00,NULL,'$2y$10$Ew.Y/iV0C0b7gM6rM1C.J.8XjPqV6s1lG7fL/fNf2Ff2Ff2Ff2Ff2','2026-04-04 21:32:26',NULL,1);
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commandes`
--

DROP TABLE IF EXISTS `commandes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `commandes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numero_commande` varchar(20) NOT NULL,
  `type_commande` enum('achat','vente') NOT NULL,
  `client_id` int(11) DEFAULT NULL,
  `fournisseur_id` int(11) DEFAULT NULL,
  `reference_externe` varchar(100) DEFAULT NULL,
  `date_commande` datetime DEFAULT current_timestamp(),
  `date_livraison_souhaitee` date DEFAULT NULL,
  `date_livraison` date DEFAULT NULL,
  `adresse_livraison` text DEFAULT NULL,
  `remise_globale` decimal(12,2) DEFAULT 0.00,
  `frais_livraison` decimal(12,2) DEFAULT 0.00,
  `total_ht` decimal(12,2) DEFAULT 0.00,
  `total_tva` decimal(12,2) DEFAULT 0.00,
  `total_ttc` decimal(12,2) DEFAULT 0.00,
  `mode_paiement` varchar(50) DEFAULT NULL,
  `statut` enum('brouillon','confirmée','en_préparation','expédiée','livrée','annulée') DEFAULT 'brouillon',
  `notes` text DEFAULT NULL,
  `conditions` text DEFAULT NULL,
  `date_validation` datetime DEFAULT NULL,
  `date_expedition` datetime DEFAULT NULL,
  `date_livraison_effective` date DEFAULT NULL,
  `creer_par` int(11) DEFAULT NULL,
  `actif` tinyint(1) DEFAULT 1,
  `reference_fournisseur` varchar(100) DEFAULT NULL,
  `num_bl` varchar(50) DEFAULT NULL,
  `num_facture` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `numero_commande` (`numero_commande`),
  KEY `idx_commandes_client` (`client_id`),
  KEY `idx_commandes_fournisseur` (`fournisseur_id`),
  KEY `idx_commandes_statut` (`statut`),
  KEY `idx_numero` (`numero_commande`),
  CONSTRAINT `commandes_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE SET NULL,
  CONSTRAINT `commandes_ibfk_2` FOREIGN KEY (`fournisseur_id`) REFERENCES `fournisseurs` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commandes`
--

LOCK TABLES `commandes` WRITE;
/*!40000 ALTER TABLE `commandes` DISABLE KEYS */;
INSERT INTO `commandes` VALUES
(1,'CMD-20260328-2939','achat',4,NULL,NULL,'2026-02-28 00:00:00',NULL,NULL,NULL,0.00,0.00,105000.00,18900.00,123900.00,NULL,'confirmée',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),
(2,'CMD-20260328-3999','achat',2,NULL,NULL,'2026-03-16 00:00:00',NULL,NULL,NULL,0.00,0.00,115000.00,20700.00,135700.00,NULL,'en_préparation',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),
(3,'CMD-20260328-2167','achat',4,NULL,NULL,'2026-03-08 00:00:00',NULL,NULL,NULL,0.00,0.00,332500.00,59850.00,392350.00,NULL,'livrée',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),
(4,'CMD-20260328-6598','achat',3,NULL,NULL,'2026-03-08 00:00:00',NULL,NULL,NULL,0.00,0.00,2755000.00,495900.00,3250900.00,NULL,'expédiée',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),
(5,'CMD-20260328-3541','achat',3,NULL,NULL,'2026-03-28 00:00:00',NULL,NULL,NULL,0.00,0.00,255000.00,45900.00,300900.00,NULL,'en_préparation',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),
(6,'CMD-20260328-5717','achat',4,NULL,NULL,'2026-03-28 00:00:00',NULL,NULL,NULL,0.00,0.00,25000.00,4500.00,29500.00,NULL,'expédiée',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),
(7,'CMD-20260328-3419','vente',1,NULL,NULL,'2026-03-20 00:00:00',NULL,NULL,NULL,0.00,0.00,1950000.00,351000.00,2301000.00,NULL,'en_préparation',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),
(8,'CMD-20260328-9232','vente',4,NULL,NULL,'2026-03-15 00:00:00',NULL,NULL,NULL,0.00,0.00,25000.00,4500.00,29500.00,NULL,'expédiée',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),
(9,'CMD-20260328-8076','vente',5,NULL,NULL,'2026-02-26 00:00:00',NULL,NULL,NULL,0.00,0.00,37500.00,6750.00,44250.00,NULL,'en_préparation',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),
(10,'CMD-20260328-8939','vente',3,NULL,NULL,'2026-02-27 00:00:00',NULL,NULL,NULL,0.00,0.00,1005000.00,180900.00,1185900.00,NULL,'confirmée',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),
(11,'CMD-20260328-4769','vente',2,NULL,NULL,'2026-02-28 00:00:00',NULL,NULL,NULL,0.00,0.00,2060000.00,370800.00,2430800.00,NULL,'confirmée',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),
(12,'CMD-20260328-1403','vente',2,NULL,NULL,'2026-03-05 00:00:00',NULL,NULL,NULL,0.00,0.00,1325000.00,238500.00,1563500.00,NULL,'confirmée',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),
(13,'CMD-20260328-2279','achat',4,NULL,NULL,'2026-03-24 00:00:00',NULL,NULL,NULL,0.00,0.00,37500.00,6750.00,44250.00,NULL,'livrée',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),
(14,'CMD-20260328-7250','achat',2,NULL,NULL,'2026-03-25 00:00:00',NULL,NULL,NULL,0.00,0.00,407500.00,73350.00,480850.00,NULL,'livrée',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),
(15,'CMD-20260328-2358','achat',1,NULL,NULL,'2026-03-11 00:00:00',NULL,NULL,NULL,0.00,0.00,715000.00,128700.00,843700.00,NULL,'confirmée',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL);
/*!40000 ALTER TABLE `commandes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fournisseurs`
--

DROP TABLE IF EXISTS `fournisseurs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fournisseurs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `contact_nom` varchar(100) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `telephone2` varchar(20) DEFAULT NULL,
  `adresse` text DEFAULT NULL,
  `ville` varchar(100) DEFAULT NULL,
  `pays` varchar(50) DEFAULT 'Sénégal',
  `ninea` varchar(50) DEFAULT NULL,
  `registre_commerce` varchar(50) DEFAULT NULL,
  `statut` enum('actif','inactif') DEFAULT 'actif',
  `notes` text DEFAULT NULL,
  `mot_de_passe` varchar(255) NOT NULL,
  `date_creation` datetime DEFAULT current_timestamp(),
  `derniere_connexion` datetime DEFAULT NULL,
  `actif` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fournisseurs`
--

LOCK TABLES `fournisseurs` WRITE;
/*!40000 ALTER TABLE `fournisseurs` DISABLE KEYS */;
INSERT INTO `fournisseurs` VALUES
(1,'SUNU TECH','Amadou Ba','contact@sunutech.sn','33 111 22 33',NULL,NULL,'Dakar','Sénégal',NULL,NULL,'actif',NULL,'$2y$10$Ew.Y/iV0C0b7gM6rM1C.J.8XjPqV6s1lG7fL/fNf2Ff2Ff2Ff2Ff2','2026-03-28 17:15:39',NULL,1),
(2,'EXPRESS INFORMATIQUE','Fatou Ndiaye','commercial@express-info.sn','33 444 55 66',NULL,NULL,'Thiès','Sénégal',NULL,NULL,'actif',NULL,'$2y$10$Ew.Y/iV0C0b7gM6rM1C.J.8XjPqV6s1lG7fL/fNf2Ff2Ff2Ff2Ff2','2026-03-28 17:15:39',NULL,1),
(3,'MATERIEL PLUS','Ibrahima Gueye','contact@materielplus.sn','77 777 88 99',NULL,NULL,'Dakar','Sénégal',NULL,NULL,'actif',NULL,'$2y$10$Ew.Y/iV0C0b7gM6rM1C.J.8XjPqV6s1lG7fL/fNf2Ff2Ff2Ff2Ff2','2026-03-28 17:15:39',NULL,1);
/*!40000 ALTER TABLE `fournisseurs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lignes_commande`
--

DROP TABLE IF EXISTS `lignes_commande`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lignes_commande` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `commande_id` int(11) NOT NULL,
  `produit_id` int(11) NOT NULL,
  `designation` varchar(200) DEFAULT NULL,
  `quantite` decimal(12,2) NOT NULL,
  `prix_unitaire` decimal(12,2) NOT NULL,
  `remise_ligne` decimal(5,2) DEFAULT 0.00,
  `tva` decimal(5,2) DEFAULT 18.00,
  `total_ht` decimal(12,2) DEFAULT NULL,
  `total_tva` decimal(12,2) DEFAULT NULL,
  `total_ttc` decimal(12,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `commande_id` (`commande_id`),
  KEY `produit_id` (`produit_id`),
  CONSTRAINT `lignes_commande_ibfk_1` FOREIGN KEY (`commande_id`) REFERENCES `commandes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `lignes_commande_ibfk_2` FOREIGN KEY (`produit_id`) REFERENCES `produits` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lignes_commande`
--

LOCK TABLES `lignes_commande` WRITE;
/*!40000 ALTER TABLE `lignes_commande` DISABLE KEYS */;
INSERT INTO `lignes_commande` VALUES
(1,1,6,NULL,3.00,35000.00,0.00,18.00,105000.00,18900.00,123900.00),
(2,2,6,NULL,2.00,35000.00,0.00,18.00,70000.00,12600.00,82600.00),
(3,2,7,NULL,1.00,45000.00,0.00,18.00,45000.00,8100.00,53100.00),
(4,3,3,NULL,1.00,185000.00,0.00,18.00,185000.00,33300.00,218300.00),
(5,3,7,NULL,3.00,45000.00,0.00,18.00,135000.00,24300.00,159300.00),
(6,3,8,NULL,1.00,12500.00,0.00,18.00,12500.00,2250.00,14750.00),
(7,4,1,NULL,3.00,450000.00,0.00,18.00,1350000.00,243000.00,1593000.00),
(8,4,4,NULL,2.00,650000.00,0.00,18.00,1300000.00,234000.00,1534000.00),
(9,4,6,NULL,3.00,35000.00,0.00,18.00,105000.00,18900.00,123900.00),
(10,5,3,NULL,1.00,185000.00,0.00,18.00,185000.00,33300.00,218300.00),
(11,5,7,NULL,1.00,45000.00,0.00,18.00,45000.00,8100.00,53100.00),
(12,5,8,NULL,2.00,12500.00,0.00,18.00,25000.00,4500.00,29500.00),
(13,6,8,NULL,2.00,12500.00,0.00,18.00,25000.00,4500.00,29500.00),
(14,7,4,NULL,3.00,650000.00,0.00,18.00,1950000.00,351000.00,2301000.00),
(15,8,8,NULL,2.00,12500.00,0.00,18.00,25000.00,4500.00,29500.00),
(16,9,8,NULL,3.00,12500.00,0.00,18.00,37500.00,6750.00,44250.00),
(17,10,1,NULL,2.00,450000.00,0.00,18.00,900000.00,162000.00,1062000.00),
(18,10,6,NULL,3.00,35000.00,0.00,18.00,105000.00,18900.00,123900.00),
(19,11,1,NULL,3.00,450000.00,0.00,18.00,1350000.00,243000.00,1593000.00),
(20,11,2,NULL,1.00,525000.00,0.00,18.00,525000.00,94500.00,619500.00),
(21,11,3,NULL,1.00,185000.00,0.00,18.00,185000.00,33300.00,218300.00),
(22,12,4,NULL,2.00,650000.00,0.00,18.00,1300000.00,234000.00,1534000.00),
(23,12,8,NULL,2.00,12500.00,0.00,18.00,25000.00,4500.00,29500.00),
(24,13,5,NULL,3.00,12500.00,0.00,18.00,37500.00,6750.00,44250.00),
(25,14,3,NULL,2.00,185000.00,0.00,18.00,370000.00,66600.00,436600.00),
(26,14,8,NULL,3.00,12500.00,0.00,18.00,37500.00,6750.00,44250.00),
(27,15,3,NULL,3.00,185000.00,0.00,18.00,555000.00,99900.00,654900.00),
(28,15,7,NULL,3.00,45000.00,0.00,18.00,135000.00,24300.00,159300.00),
(29,15,8,NULL,2.00,12500.00,0.00,18.00,25000.00,4500.00,29500.00);
/*!40000 ALTER TABLE `lignes_commande` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lignes_panier`
--

DROP TABLE IF EXISTS `lignes_panier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lignes_panier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `panier_id` int(11) NOT NULL,
  `produit_id` int(11) NOT NULL,
  `quantite` decimal(12,2) DEFAULT 1.00,
  PRIMARY KEY (`id`),
  KEY `panier_id` (`panier_id`),
  KEY `produit_id` (`produit_id`),
  CONSTRAINT `lignes_panier_ibfk_1` FOREIGN KEY (`panier_id`) REFERENCES `paniers_session` (`id`) ON DELETE CASCADE,
  CONSTRAINT `lignes_panier_ibfk_2` FOREIGN KEY (`produit_id`) REFERENCES `produits` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lignes_panier`
--

LOCK TABLES `lignes_panier` WRITE;
/*!40000 ALTER TABLE `lignes_panier` DISABLE KEYS */;
/*!40000 ALTER TABLE `lignes_panier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications_commande`
--

DROP TABLE IF EXISTS `notifications_commande`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications_commande` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `commande_id` int(11) NOT NULL,
  `destinataire_type` enum('client','fournisseur') NOT NULL,
  `lu` tinyint(1) DEFAULT 0,
  `date_creation` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `commande_id` (`commande_id`),
  CONSTRAINT `notifications_commande_ibfk_1` FOREIGN KEY (`commande_id`) REFERENCES `commandes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications_commande`
--

LOCK TABLES `notifications_commande` WRITE;
/*!40000 ALTER TABLE `notifications_commande` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications_commande` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paniers_session`
--

DROP TABLE IF EXISTS `paniers_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `paniers_session` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` int(11) NOT NULL,
  `date_creation` datetime DEFAULT current_timestamp(),
  `valide` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `session_id` (`session_id`),
  CONSTRAINT `paniers_session_ibfk_1` FOREIGN KEY (`session_id`) REFERENCES `sessions_portail` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paniers_session`
--

LOCK TABLES `paniers_session` WRITE;
/*!40000 ALTER TABLE `paniers_session` DISABLE KEYS */;
/*!40000 ALTER TABLE `paniers_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `produits`
--

DROP TABLE IF EXISTS `produits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `produits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `nom` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `categorie_id` int(11) DEFAULT NULL,
  `prix_vente` decimal(12,2) NOT NULL,
  `prix_achat` decimal(12,2) DEFAULT NULL,
  `tva` decimal(5,2) DEFAULT 18.00,
  `unite` varchar(20) DEFAULT 'pièce',
  `quantite_stock` decimal(12,2) DEFAULT 0.00,
  `seuil_alerte` decimal(12,2) DEFAULT 5.00,
  `image` varchar(255) DEFAULT NULL,
  `fournisseur_principal` int(11) DEFAULT NULL,
  `actif` tinyint(1) DEFAULT 1,
  `date_creation` datetime DEFAULT current_timestamp(),
  `code_barre` varchar(50) DEFAULT NULL,
  `poids` decimal(10,2) DEFAULT NULL,
  `dimensions` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `idx_produits_categorie` (`categorie_id`),
  KEY `idx_produits_fournisseur` (`fournisseur_principal`),
  KEY `idx_code` (`code`),
  CONSTRAINT `produits_ibfk_1` FOREIGN KEY (`categorie_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `produits_ibfk_2` FOREIGN KEY (`fournisseur_principal`) REFERENCES `fournisseurs` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produits`
--

LOCK TABLES `produits` WRITE;
/*!40000 ALTER TABLE `produits` DISABLE KEYS */;
INSERT INTO `produits` VALUES
(1,'PC-001','Ordinateur Portable Dell Latitude',NULL,1,450000.00,NULL,18.00,'pièce',15.00,5.00,NULL,1,1,'2026-03-28 17:15:39',NULL,NULL,NULL),
(2,'PC-002','Ordinateur Portable HP EliteBook',NULL,1,525000.00,NULL,18.00,'pièce',8.00,3.00,NULL,2,1,'2026-03-28 17:15:39',NULL,NULL,NULL),
(3,'SM-001','Smartphone Samsung Galaxy A54',NULL,2,185000.00,NULL,18.00,'pièce',25.00,10.00,NULL,2,1,'2026-03-28 17:15:39',NULL,NULL,NULL),
(4,'SM-002','iPhone 14 Pro',NULL,2,650000.00,NULL,18.00,'pièce',5.00,2.00,NULL,2,1,'2026-03-28 17:15:39',NULL,NULL,NULL),
(5,'ACC-001','Souris sans fil Logitech',NULL,4,12500.00,NULL,18.00,'pièce',50.00,20.00,NULL,1,1,'2026-03-28 17:15:39',NULL,NULL,NULL),
(6,'ACC-002','Clavier mécanique RGB',NULL,4,35000.00,NULL,18.00,'pièce',20.00,8.00,NULL,2,1,'2026-03-28 17:15:39',NULL,NULL,NULL),
(7,'RES-001','Routeur WiFi TP-Link',NULL,3,45000.00,NULL,18.00,'pièce',12.00,5.00,NULL,1,1,'2026-03-28 17:15:39',NULL,NULL,NULL),
(8,'CONS-001','Cartouche d\'encre HP 664',NULL,5,12500.00,NULL,18.00,'pièce',30.00,10.00,NULL,1,1,'2026-03-28 17:15:39',NULL,NULL,NULL);
/*!40000 ALTER TABLE `produits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions_portail`
--

DROP TABLE IF EXISTS `sessions_portail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions_portail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_key` varchar(40) NOT NULL,
  `type` enum('client','fournisseur') NOT NULL,
  `client_id` int(11) DEFAULT NULL,
  `fournisseur_id` int(11) DEFAULT NULL,
  `date_creation` datetime DEFAULT current_timestamp(),
  `derniere_activite` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `session_key` (`session_key`),
  KEY `client_id` (`client_id`),
  KEY `fournisseur_id` (`fournisseur_id`),
  KEY `idx_sessions_key` (`session_key`),
  CONSTRAINT `sessions_portail_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sessions_portail_ibfk_2` FOREIGN KEY (`fournisseur_id`) REFERENCES `fournisseurs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions_portail`
--

LOCK TABLES `sessions_portail` WRITE;
/*!40000 ALTER TABLE `sessions_portail` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions_portail` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-22 16:36:05
