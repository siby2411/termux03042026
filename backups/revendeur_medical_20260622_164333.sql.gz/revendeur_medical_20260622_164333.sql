/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: revendeur_medical
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categories_produits`
--

DROP TABLE IF EXISTS `categories_produits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories_produits` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `libelle` varchar(150) NOT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `parent_id` (`parent_id`),
  CONSTRAINT `categories_produits_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `categories_produits` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories_produits`
--

LOCK TABLES `categories_produits` WRITE;
/*!40000 ALTER TABLE `categories_produits` DISABLE KEYS */;
INSERT INTO `categories_produits` VALUES
(1,'IMG','Imagerie médicale',NULL),
(2,'CHIR','Instrumentation chirurgicale',NULL),
(3,'DIAG','Diagnostic / Monitoring',NULL),
(4,'ORTH','Orthopédie / Rééducation',NULL),
(5,'LABO','Equipements laboratoire',NULL),
(6,'DENT','Dentisterie',NULL),
(7,'OPH','Ophtalmologie',NULL),
(8,'CONS','Consommables médicaux',NULL),
(9,'FROID','Chaîne du froid / Vaccins',NULL),
(10,'MOB','Mobilier médical',NULL);
/*!40000 ALTER TABLE `categories_produits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `raison_sociale` varchar(200) NOT NULL,
  `type_client` enum('hopital_public','clinique_privee','cabinet_medical','pharmacie','ong','particulier','autre') DEFAULT 'clinique_privee',
  `ninea` varchar(30) DEFAULT NULL,
  `region` varchar(80) DEFAULT NULL COMMENT 'Dakar, Thiès, Ziguinchor…',
  `adresse` text DEFAULT NULL,
  `telephone` varchar(20) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `contact_nom` varchar(100) DEFAULT NULL,
  `contact_poste` varchar(80) DEFAULT NULL,
  `conditions_paiement` enum('comptant','30j','60j','90j') DEFAULT 'comptant',
  `plafond_credit` decimal(15,2) DEFAULT 0.00,
  `encours_credit` decimal(15,2) DEFAULT 0.00,
  `actif` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commande_lignes`
--

DROP TABLE IF EXISTS `commande_lignes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `commande_lignes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `commande_id` int(10) unsigned NOT NULL,
  `produit_id` int(10) unsigned NOT NULL,
  `quantite` int(11) NOT NULL,
  `quantite_livree` int(11) DEFAULT 0,
  `prix_unitaire` decimal(15,2) NOT NULL,
  `montant_ligne` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `commande_id` (`commande_id`),
  KEY `produit_id` (`produit_id`),
  CONSTRAINT `commande_lignes_ibfk_1` FOREIGN KEY (`commande_id`) REFERENCES `commandes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `commande_lignes_ibfk_2` FOREIGN KEY (`produit_id`) REFERENCES `produits` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commande_lignes`
--

LOCK TABLES `commande_lignes` WRITE;
/*!40000 ALTER TABLE `commande_lignes` DISABLE KEYS */;
/*!40000 ALTER TABLE `commande_lignes` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER trg_livraison_stock
AFTER UPDATE ON commande_lignes
FOR EACH ROW
BEGIN
    DECLARE v_diff INT;
    DECLARE v_stock_avant INT;
    SET v_diff = NEW.quantite_livree - OLD.quantite_livree;
    IF v_diff > 0 THEN
        SELECT stock_actuel INTO v_stock_avant FROM produits WHERE id = NEW.produit_id;
        UPDATE produits SET stock_actuel = stock_actuel - v_diff WHERE id = NEW.produit_id;
        INSERT INTO mouvements_stock
            (produit_id, type_mouvement, quantite, stock_avant, stock_apres, date_mouvement)
        VALUES
            (NEW.produit_id, 'sortie_livraison', v_diff, v_stock_avant, v_stock_avant - v_diff, NOW());
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `commandes`
--

DROP TABLE IF EXISTS `commandes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `commandes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference` varchar(30) NOT NULL,
  `devis_id` int(10) unsigned DEFAULT NULL COMMENT 'Issue d un devis accepté',
  `client_id` int(10) unsigned NOT NULL,
  `commercial_id` int(10) unsigned NOT NULL,
  `date_commande` date NOT NULL,
  `date_livraison_prevue` date DEFAULT NULL,
  `montant_ht` decimal(15,2) DEFAULT 0.00,
  `tva_montant` decimal(15,2) DEFAULT 0.00,
  `net_a_payer` decimal(15,2) DEFAULT 0.00,
  `statut` enum('en_attente','confirmee','en_preparation','expediee','livree','annulee') DEFAULT 'en_attente',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `reference` (`reference`),
  KEY `devis_id` (`devis_id`),
  KEY `client_id` (`client_id`),
  KEY `commercial_id` (`commercial_id`),
  CONSTRAINT `commandes_ibfk_1` FOREIGN KEY (`devis_id`) REFERENCES `devis` (`id`),
  CONSTRAINT `commandes_ibfk_2` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`),
  CONSTRAINT `commandes_ibfk_3` FOREIGN KEY (`commercial_id`) REFERENCES `utilisateurs` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commandes`
--

LOCK TABLES `commandes` WRITE;
/*!40000 ALTER TABLE `commandes` DISABLE KEYS */;
/*!40000 ALTER TABLE `commandes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `devis`
--

DROP TABLE IF EXISTS `devis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `devis` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference` varchar(30) NOT NULL,
  `client_id` int(10) unsigned NOT NULL,
  `commercial_id` int(10) unsigned NOT NULL,
  `date_devis` date NOT NULL,
  `date_validite` date DEFAULT NULL,
  `montant_ht` decimal(15,2) DEFAULT 0.00,
  `tva_montant` decimal(15,2) DEFAULT 0.00,
  `montant_ttc` decimal(15,2) DEFAULT 0.00,
  `remise_pct` decimal(5,2) DEFAULT 0.00,
  `net_a_payer` decimal(15,2) DEFAULT 0.00,
  `statut` enum('brouillon','envoye','accepte','refuse','expire','converti') DEFAULT 'brouillon',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `reference` (`reference`),
  KEY `client_id` (`client_id`),
  KEY `commercial_id` (`commercial_id`),
  CONSTRAINT `devis_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`),
  CONSTRAINT `devis_ibfk_2` FOREIGN KEY (`commercial_id`) REFERENCES `utilisateurs` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `devis`
--

LOCK TABLES `devis` WRITE;
/*!40000 ALTER TABLE `devis` DISABLE KEYS */;
/*!40000 ALTER TABLE `devis` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER trg_devis_reference
BEFORE INSERT ON devis
FOR EACH ROW
BEGIN
    DECLARE v_seq INT;
    SELECT IFNULL(MAX(id),0)+1 INTO v_seq FROM devis;
    SET NEW.reference = CONCAT('DEV-', DATE_FORMAT(NOW(),'%Y'), '-', LPAD(v_seq,5,'0'));
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `devis_lignes`
--

DROP TABLE IF EXISTS `devis_lignes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `devis_lignes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `devis_id` int(10) unsigned NOT NULL,
  `produit_id` int(10) unsigned NOT NULL,
  `designation` varchar(200) DEFAULT NULL,
  `quantite` int(11) NOT NULL,
  `prix_unitaire` decimal(15,2) NOT NULL,
  `tva_taux` decimal(5,2) DEFAULT 18.00,
  `remise_pct` decimal(5,2) DEFAULT 0.00,
  `montant_ligne` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `devis_id` (`devis_id`),
  KEY `produit_id` (`produit_id`),
  CONSTRAINT `devis_lignes_ibfk_1` FOREIGN KEY (`devis_id`) REFERENCES `devis` (`id`) ON DELETE CASCADE,
  CONSTRAINT `devis_lignes_ibfk_2` FOREIGN KEY (`produit_id`) REFERENCES `produits` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `devis_lignes`
--

LOCK TABLES `devis_lignes` WRITE;
/*!40000 ALTER TABLE `devis_lignes` DISABLE KEYS */;
/*!40000 ALTER TABLE `devis_lignes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `facture_lignes`
--

DROP TABLE IF EXISTS `facture_lignes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `facture_lignes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `facture_id` int(10) unsigned NOT NULL,
  `produit_id` int(10) unsigned DEFAULT NULL,
  `designation` varchar(200) NOT NULL,
  `quantite` int(11) NOT NULL,
  `prix_unitaire` decimal(15,2) NOT NULL,
  `tva_taux` decimal(5,2) DEFAULT 18.00,
  `montant_ligne` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `facture_id` (`facture_id`),
  KEY `produit_id` (`produit_id`),
  CONSTRAINT `facture_lignes_ibfk_1` FOREIGN KEY (`facture_id`) REFERENCES `factures` (`id`) ON DELETE CASCADE,
  CONSTRAINT `facture_lignes_ibfk_2` FOREIGN KEY (`produit_id`) REFERENCES `produits` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `facture_lignes`
--

LOCK TABLES `facture_lignes` WRITE;
/*!40000 ALTER TABLE `facture_lignes` DISABLE KEYS */;
/*!40000 ALTER TABLE `facture_lignes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `factures`
--

DROP TABLE IF EXISTS `factures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `factures` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference` varchar(30) NOT NULL,
  `commande_id` int(10) unsigned DEFAULT NULL,
  `client_id` int(10) unsigned NOT NULL,
  `utilisateur_id` int(10) unsigned NOT NULL,
  `date_facture` date NOT NULL,
  `date_echeance` date DEFAULT NULL,
  `montant_ht` decimal(15,2) DEFAULT 0.00,
  `tva_montant` decimal(15,2) DEFAULT 0.00,
  `montant_ttc` decimal(15,2) DEFAULT 0.00,
  `remise_pct` decimal(5,2) DEFAULT 0.00,
  `net_a_payer` decimal(15,2) DEFAULT 0.00,
  `montant_regle` decimal(15,2) DEFAULT 0.00,
  `solde_restant` decimal(15,2) GENERATED ALWAYS AS (`net_a_payer` - `montant_regle`) STORED,
  `statut` enum('emise','partiellement_payee','payee','en_retard','annulee','avoir') DEFAULT 'emise',
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `reference` (`reference`),
  KEY `commande_id` (`commande_id`),
  KEY `client_id` (`client_id`),
  KEY `utilisateur_id` (`utilisateur_id`),
  KEY `idx_statut` (`statut`),
  KEY `idx_echeance` (`date_echeance`),
  CONSTRAINT `factures_ibfk_1` FOREIGN KEY (`commande_id`) REFERENCES `commandes` (`id`),
  CONSTRAINT `factures_ibfk_2` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`),
  CONSTRAINT `factures_ibfk_3` FOREIGN KEY (`utilisateur_id`) REFERENCES `utilisateurs` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `factures`
--

LOCK TABLES `factures` WRITE;
/*!40000 ALTER TABLE `factures` DISABLE KEYS */;
/*!40000 ALTER TABLE `factures` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER trg_facture_reference
BEFORE INSERT ON factures
FOR EACH ROW
BEGIN
    DECLARE v_seq INT;
    SELECT IFNULL(MAX(id),0)+1 INTO v_seq FROM factures;
    SET NEW.reference = CONCAT('FAC-', DATE_FORMAT(NOW(),'%Y'), '-', LPAD(v_seq,5,'0'));
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER trg_facture_encours_client
AFTER INSERT ON factures
FOR EACH ROW
BEGIN
    UPDATE clients
    SET encours_credit = encours_credit + NEW.net_a_payer
    WHERE id = NEW.client_id;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `fournisseurs`
--

DROP TABLE IF EXISTS `fournisseurs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fournisseurs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `raison_sociale` varchar(150) NOT NULL,
  `pays_origine` varchar(80) DEFAULT 'Sénégal',
  `ninea` varchar(30) DEFAULT NULL,
  `registre_commerce` varchar(30) DEFAULT NULL,
  `adresse` text DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `site_web` varchar(200) DEFAULT NULL,
  `conditions_paiement` varchar(100) DEFAULT NULL,
  `delai_livraison` int(11) DEFAULT NULL COMMENT 'jours',
  `actif` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fournisseurs`
--

LOCK TABLES `fournisseurs` WRITE;
/*!40000 ALTER TABLE `fournisseurs` DISABLE KEYS */;
/*!40000 ALTER TABLE `fournisseurs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mouvements_stock`
--

DROP TABLE IF EXISTS `mouvements_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mouvements_stock` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `produit_id` int(10) unsigned NOT NULL,
  `type_mouvement` enum('entree','sortie_livraison','retour_client','ajustement','inventaire','perte') DEFAULT NULL,
  `quantite` int(11) NOT NULL,
  `stock_avant` int(11) NOT NULL,
  `stock_apres` int(11) NOT NULL,
  `reference_doc` varchar(50) DEFAULT NULL,
  `utilisateur_id` int(10) unsigned DEFAULT NULL,
  `date_mouvement` datetime DEFAULT current_timestamp(),
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `produit_id` (`produit_id`),
  KEY `utilisateur_id` (`utilisateur_id`),
  CONSTRAINT `mouvements_stock_ibfk_1` FOREIGN KEY (`produit_id`) REFERENCES `produits` (`id`),
  CONSTRAINT `mouvements_stock_ibfk_2` FOREIGN KEY (`utilisateur_id`) REFERENCES `utilisateurs` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mouvements_stock`
--

LOCK TABLES `mouvements_stock` WRITE;
/*!40000 ALTER TABLE `mouvements_stock` DISABLE KEYS */;
/*!40000 ALTER TABLE `mouvements_stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paiements`
--

DROP TABLE IF EXISTS `paiements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `paiements` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `facture_id` int(10) unsigned NOT NULL,
  `date_paiement` date NOT NULL,
  `montant` decimal(15,2) NOT NULL,
  `mode_paiement` enum('virement','cheque','especes','wave','orange_money','carte') DEFAULT 'virement',
  `reference_paiement` varchar(60) DEFAULT NULL,
  `banque` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `facture_id` (`facture_id`),
  CONSTRAINT `paiements_ibfk_1` FOREIGN KEY (`facture_id`) REFERENCES `factures` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paiements`
--

LOCK TABLES `paiements` WRITE;
/*!40000 ALTER TABLE `paiements` DISABLE KEYS */;
/*!40000 ALTER TABLE `paiements` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER trg_paiement_update_facture
AFTER INSERT ON paiements
FOR EACH ROW
BEGIN
    UPDATE factures
    SET montant_regle = montant_regle + NEW.montant,
        statut = CASE
          WHEN (montant_regle + NEW.montant) >= net_a_payer THEN 'payee'
          WHEN (montant_regle + NEW.montant) > 0           THEN 'partiellement_payee'
          ELSE 'emise'
        END
    WHERE id = NEW.facture_id;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `produits`
--

DROP TABLE IF EXISTS `produits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `produits` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference` varchar(50) NOT NULL,
  `code_barre` varchar(60) DEFAULT NULL,
  `designation` varchar(200) NOT NULL,
  `marque` varchar(100) DEFAULT NULL,
  `modele` varchar(100) DEFAULT NULL,
  `categorie_id` int(10) unsigned DEFAULT NULL,
  `fournisseur_id` int(10) unsigned DEFAULT NULL,
  `description` text DEFAULT NULL,
  `specifications` text DEFAULT NULL COMMENT 'JSON specs techniques',
  `homologation_oms` tinyint(1) DEFAULT 0,
  `ce_marking` tinyint(1) DEFAULT 0 COMMENT 'Marquage CE Europe',
  `prix_achat_ht` decimal(15,2) DEFAULT 0.00,
  `prix_vente_ht` decimal(15,2) DEFAULT 0.00,
  `marge_pct` decimal(5,2) GENERATED ALWAYS AS (case when `prix_achat_ht` > 0 then (`prix_vente_ht` - `prix_achat_ht`) / `prix_achat_ht` * 100 else 0 end) STORED,
  `tva_taux` decimal(5,2) DEFAULT 18.00 COMMENT 'TVA 18% Sénégal',
  `prix_vente_ttc` decimal(15,2) GENERATED ALWAYS AS (`prix_vente_ht` * 1.18) STORED,
  `garantie_mois` int(11) DEFAULT 12,
  `stock_actuel` int(11) DEFAULT 0,
  `stock_min` int(11) DEFAULT 1,
  `necessite_sav` tinyint(1) DEFAULT 1,
  `actif` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `reference` (`reference`),
  KEY `categorie_id` (`categorie_id`),
  KEY `fournisseur_id` (`fournisseur_id`),
  CONSTRAINT `produits_ibfk_1` FOREIGN KEY (`categorie_id`) REFERENCES `categories_produits` (`id`),
  CONSTRAINT `produits_ibfk_2` FOREIGN KEY (`fournisseur_id`) REFERENCES `fournisseurs` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produits`
--

LOCK TABLES `produits` WRITE;
/*!40000 ALTER TABLE `produits` DISABLE KEYS */;
/*!40000 ALTER TABLE `produits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sav_interventions`
--

DROP TABLE IF EXISTS `sav_interventions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sav_interventions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference` varchar(30) NOT NULL,
  `client_id` int(10) unsigned NOT NULL,
  `produit_id` int(10) unsigned NOT NULL,
  `technicien_id` int(10) unsigned DEFAULT NULL,
  `numero_serie` varchar(80) DEFAULT NULL,
  `date_installation` date DEFAULT NULL,
  `date_signalement` date NOT NULL,
  `date_intervention` date DEFAULT NULL,
  `date_cloture` date DEFAULT NULL,
  `type_intervention` enum('installation','maintenance_preventive','reparation','formation','remplacement') DEFAULT 'reparation',
  `description_panne` text DEFAULT NULL,
  `solution_appliquee` text DEFAULT NULL,
  `pieces_remplacees` text DEFAULT NULL,
  `cout_intervention` decimal(12,2) DEFAULT 0.00,
  `sous_garantie` tinyint(1) DEFAULT 0,
  `statut` enum('signale','planifie','en_cours','resolu','cloture','annule') DEFAULT 'signale',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `reference` (`reference`),
  KEY `client_id` (`client_id`),
  KEY `produit_id` (`produit_id`),
  KEY `technicien_id` (`technicien_id`),
  CONSTRAINT `sav_interventions_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`),
  CONSTRAINT `sav_interventions_ibfk_2` FOREIGN KEY (`produit_id`) REFERENCES `produits` (`id`),
  CONSTRAINT `sav_interventions_ibfk_3` FOREIGN KEY (`technicien_id`) REFERENCES `utilisateurs` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sav_interventions`
--

LOCK TABLES `sav_interventions` WRITE;
/*!40000 ALTER TABLE `sav_interventions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sav_interventions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `utilisateurs`
--

DROP TABLE IF EXISTS `utilisateurs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `utilisateurs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) DEFAULT NULL,
  `login` varchar(60) NOT NULL,
  `mot_de_passe` varchar(255) NOT NULL,
  `role` enum('admin','commercial','technicien','comptable','magasinier') DEFAULT 'commercial',
  `telephone` varchar(20) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `actif` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `login` (`login`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `utilisateurs`
--

LOCK TABLES `utilisateurs` WRITE;
/*!40000 ALTER TABLE `utilisateurs` DISABLE KEYS */;
INSERT INTO `utilisateurs` VALUES
(1,'Admin','Système','admin','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','admin',NULL,NULL,1,'2026-03-18 06:37:23');
/*!40000 ALTER TABLE `utilisateurs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `v_factures_en_retard`
--

DROP TABLE IF EXISTS `v_factures_en_retard`;
/*!50001 DROP VIEW IF EXISTS `v_factures_en_retard`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `v_factures_en_retard` AS SELECT
 1 AS `reference`,
  1 AS `date_facture`,
  1 AS `date_echeance`,
  1 AS `client`,
  1 AS `telephone`,
  1 AS `net_a_payer`,
  1 AS `montant_regle`,
  1 AS `solde_restant`,
  1 AS `jours_retard` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_pipeline_devis`
--

DROP TABLE IF EXISTS `v_pipeline_devis`;
/*!50001 DROP VIEW IF EXISTS `v_pipeline_devis`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `v_pipeline_devis` AS SELECT
 1 AS `reference`,
  1 AS `date_devis`,
  1 AS `date_validite`,
  1 AS `client`,
  1 AS `commercial`,
  1 AS `net_a_payer`,
  1 AS `statut`,
  1 AS `est_expire` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_sav_en_cours`
--

DROP TABLE IF EXISTS `v_sav_en_cours`;
/*!50001 DROP VIEW IF EXISTS `v_sav_en_cours`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `v_sav_en_cours` AS SELECT
 1 AS `reference`,
  1 AS `date_signalement`,
  1 AS `client`,
  1 AS `produit`,
  1 AS `technicien`,
  1 AS `type_intervention`,
  1 AS `statut`,
  1 AS `jours_depuis_signalement` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_stock_produits`
--

DROP TABLE IF EXISTS `v_stock_produits`;
/*!50001 DROP VIEW IF EXISTS `v_stock_produits`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `v_stock_produits` AS SELECT
 1 AS `reference`,
  1 AS `designation`,
  1 AS `marque`,
  1 AS `modele`,
  1 AS `stock_actuel`,
  1 AS `stock_min`,
  1 AS `statut`,
  1 AS `prix_vente_ttc`,
  1 AS `categorie` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_tableau_bord_commercial`
--

DROP TABLE IF EXISTS `v_tableau_bord_commercial`;
/*!50001 DROP VIEW IF EXISTS `v_tableau_bord_commercial`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `v_tableau_bord_commercial` AS SELECT
 1 AS `nom`,
  1 AS `prenom`,
  1 AS `nb_commandes`,
  1 AS `ca_total`,
  1 AS `ca_encaisse`,
  1 AS `en_attente_paiement` */;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `v_factures_en_retard`
--

/*!50001 DROP VIEW IF EXISTS `v_factures_en_retard`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_factures_en_retard` AS select `f`.`reference` AS `reference`,`f`.`date_facture` AS `date_facture`,`f`.`date_echeance` AS `date_echeance`,`cl`.`raison_sociale` AS `client`,`cl`.`telephone` AS `telephone`,`f`.`net_a_payer` AS `net_a_payer`,`f`.`montant_regle` AS `montant_regle`,`f`.`solde_restant` AS `solde_restant`,to_days(curdate()) - to_days(`f`.`date_echeance`) AS `jours_retard` from (`factures` `f` join `clients` `cl` on(`cl`.`id` = `f`.`client_id`)) where `f`.`statut` in ('emise','partiellement_payee') and `f`.`date_echeance` < curdate() order by to_days(curdate()) - to_days(`f`.`date_echeance`) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_pipeline_devis`
--

/*!50001 DROP VIEW IF EXISTS `v_pipeline_devis`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_pipeline_devis` AS select `d`.`reference` AS `reference`,`d`.`date_devis` AS `date_devis`,`d`.`date_validite` AS `date_validite`,`cl`.`raison_sociale` AS `client`,concat(`u`.`prenom`,' ',`u`.`nom`) AS `commercial`,`d`.`net_a_payer` AS `net_a_payer`,`d`.`statut` AS `statut`,case when `d`.`date_validite` < curdate() and `d`.`statut` not in ('accepte','refuse','converti') then 1 else 0 end AS `est_expire` from ((`devis` `d` join `clients` `cl` on(`cl`.`id` = `d`.`client_id`)) join `utilisateurs` `u` on(`u`.`id` = `d`.`commercial_id`)) order by `d`.`date_devis` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_sav_en_cours`
--

/*!50001 DROP VIEW IF EXISTS `v_sav_en_cours`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_sav_en_cours` AS select `s`.`reference` AS `reference`,`s`.`date_signalement` AS `date_signalement`,`cl`.`raison_sociale` AS `client`,`p`.`designation` AS `produit`,concat(`u`.`prenom`,' ',`u`.`nom`) AS `technicien`,`s`.`type_intervention` AS `type_intervention`,`s`.`statut` AS `statut`,to_days(curdate()) - to_days(`s`.`date_signalement`) AS `jours_depuis_signalement` from (((`sav_interventions` `s` join `clients` `cl` on(`cl`.`id` = `s`.`client_id`)) join `produits` `p` on(`p`.`id` = `s`.`produit_id`)) left join `utilisateurs` `u` on(`u`.`id` = `s`.`technicien_id`)) where `s`.`statut` not in ('cloture','annule') order by `s`.`date_signalement` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_stock_produits`
--

/*!50001 DROP VIEW IF EXISTS `v_stock_produits`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_stock_produits` AS select `p`.`reference` AS `reference`,`p`.`designation` AS `designation`,`p`.`marque` AS `marque`,`p`.`modele` AS `modele`,`p`.`stock_actuel` AS `stock_actuel`,`p`.`stock_min` AS `stock_min`,case when `p`.`stock_actuel` = 0 then '🔴 RUPTURE' when `p`.`stock_actuel` <= `p`.`stock_min` then '🟠 FAIBLE' else '🟢 DISPONIBLE' end AS `statut`,`p`.`prix_vente_ttc` AS `prix_vente_ttc`,`c`.`libelle` AS `categorie` from (`produits` `p` left join `categories_produits` `c` on(`c`.`id` = `p`.`categorie_id`)) where `p`.`actif` = 1 order by `p`.`stock_actuel` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_tableau_bord_commercial`
--

/*!50001 DROP VIEW IF EXISTS `v_tableau_bord_commercial`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_tableau_bord_commercial` AS select `u`.`nom` AS `nom`,`u`.`prenom` AS `prenom`,count(distinct `c`.`id`) AS `nb_commandes`,sum(`f`.`net_a_payer`) AS `ca_total`,sum(case when `f`.`statut` = 'payee' then `f`.`net_a_payer` else 0 end) AS `ca_encaisse`,sum(`f`.`solde_restant`) AS `en_attente_paiement` from ((`utilisateurs` `u` left join `commandes` `c` on(`c`.`commercial_id` = `u`.`id` and year(`c`.`date_commande`) = year(curdate()))) left join `factures` `f` on(`f`.`commande_id` = `c`.`id`)) where `u`.`role` = 'commercial' group by `u`.`id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-22 16:43:57
