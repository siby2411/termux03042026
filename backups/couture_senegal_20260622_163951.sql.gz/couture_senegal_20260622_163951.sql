/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: couture_senegal
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `client_photos`
--

DROP TABLE IF EXISTS `client_photos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `client_photos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `legende` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `client_id` (`client_id`),
  CONSTRAINT `client_photos_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_photos`
--

LOCK TABLES `client_photos` WRITE;
/*!40000 ALTER TABLE `client_photos` DISABLE KEYS */;
/*!40000 ALTER TABLE `client_photos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code_client` varchar(20) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `genre` enum('H','F') DEFAULT 'F',
  `telephone` varchar(20) DEFAULT NULL,
  `telephone2` varchar(20) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `adresse` text DEFAULT NULL,
  `quartier` varchar(100) DEFAULT NULL,
  `ville` varchar(100) DEFAULT 'Dakar',
  `mesures` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Mesures corporelles en JSON' CHECK (json_valid(`mesures`)),
  `notes` text DEFAULT NULL,
  `statut` enum('actif','inactif') DEFAULT 'actif',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code_client` (`code_client`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` VALUES
(1,'CLI-001','DIALLO','Fatou','F','77 123 45 67',NULL,'fatou.diallo@email.sn','Cité Keur Gorgui','Plateau','Dakar','{\"poitrine\":92,\"taille\":72,\"hanches\":98,\"hauteur\":165}',NULL,'actif','2026-04-01 23:38:21','2026-04-01 23:38:21'),
(2,'CLI-002','NDIAYE','Mariama','F','76 234 56 78',NULL,'mariama.ndiaye@email.sn','Sicap Liberté 4','Liberté','Dakar','{\"poitrine\":88,\"taille\":68,\"hanches\":94,\"hauteur\":160}',NULL,'actif','2026-04-01 23:38:21','2026-04-01 23:38:21'),
(3,'CLI-003','SOW','Rokhaya','F','78 345 67 89',NULL,'rokhaya.sow@email.sn','HLM Grand Yoff','Grand Yoff','Dakar','{\"poitrine\":96,\"taille\":80,\"hanches\":102,\"hauteur\":163}',NULL,'actif','2026-04-01 23:38:21','2026-04-01 23:38:21'),
(4,'CLI-004','FALL','Aïssatou','F','70 456 78 90',NULL,'aissatou.fall@email.sn','Almadies','Almadies','Dakar','{\"poitrine\":90,\"taille\":70,\"hanches\":96,\"hauteur\":168}',NULL,'actif','2026-04-01 23:38:21','2026-04-01 23:38:21'),
(5,'CLI-005','BA','Ndéye Coumba','F','77 567 89 01',NULL,'ndeye.ba@email.sn','Parcelles Assainies','Parcelles','Dakar','{\"poitrine\":94,\"taille\":76,\"hanches\":100,\"hauteur\":162}',NULL,'actif','2026-04-01 23:38:21','2026-04-01 23:38:21');
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commande_lignes`
--

DROP TABLE IF EXISTS `commande_lignes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `commande_lignes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `commande_id` int(11) NOT NULL,
  `modele_id` int(11) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `tissu_id` int(11) DEFAULT NULL,
  `quantite` int(11) DEFAULT 1,
  `prix_unitaire` decimal(12,2) NOT NULL,
  `sous_total` decimal(12,2) NOT NULL,
  `mesures` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`mesures`)),
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `commande_id` (`commande_id`),
  KEY `modele_id` (`modele_id`),
  KEY `tissu_id` (`tissu_id`),
  CONSTRAINT `commande_lignes_ibfk_1` FOREIGN KEY (`commande_id`) REFERENCES `commandes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `commande_lignes_ibfk_2` FOREIGN KEY (`modele_id`) REFERENCES `modeles` (`id`),
  CONSTRAINT `commande_lignes_ibfk_3` FOREIGN KEY (`tissu_id`) REFERENCES `tissus` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commande_lignes`
--

LOCK TABLES `commande_lignes` WRITE;
/*!40000 ALTER TABLE `commande_lignes` DISABLE KEYS */;
/*!40000 ALTER TABLE `commande_lignes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commandes`
--

DROP TABLE IF EXISTS `commandes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `commandes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numero_commande` varchar(30) NOT NULL,
  `client_id` int(11) NOT NULL,
  `date_commande` date NOT NULL,
  `date_livraison` date DEFAULT NULL,
  `statut` enum('brouillon','confirmée','en_cours','essayage','terminée','livrée','annulée') DEFAULT 'confirmée',
  `priorite` enum('normale','urgente','vip') DEFAULT 'normale',
  `notes` text DEFAULT NULL,
  `remise_pct` decimal(5,2) DEFAULT 0.00,
  `acompte_verse` decimal(12,2) DEFAULT 0.00,
  `total_ht` decimal(12,2) DEFAULT 0.00,
  `tva_pct` decimal(5,2) DEFAULT 0.00,
  `total_ttc` decimal(12,2) DEFAULT 0.00,
  `reste_a_payer` decimal(12,2) DEFAULT 0.00,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `numero_commande` (`numero_commande`),
  KEY `client_id` (`client_id`),
  CONSTRAINT `commandes_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commandes`
--

LOCK TABLES `commandes` WRITE;
/*!40000 ALTER TABLE `commandes` DISABLE KEYS */;
INSERT INTO `commandes` VALUES
(1,'CMD-2026-001',1,'2026-04-01','2026-04-10','en_cours','normale',NULL,0.00,75000.00,0.00,0.00,150000.00,75000.00,'2026-04-02 01:37:16','2026-04-02 01:37:16'),
(2,'CMD-2026-002',2,'2026-04-02','2026-04-15','confirmée','normale',NULL,0.00,25000.00,0.00,0.00,25000.00,0.00,'2026-04-02 01:37:16','2026-04-02 01:37:16');
/*!40000 ALTER TABLE `commandes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `depenses`
--

DROP TABLE IF EXISTS `depenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `depenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_dep` date NOT NULL,
  `categorie` enum('tissu','fourniture','loyer','salaire','electricite','transport','marketing','autre') NOT NULL,
  `description` varchar(255) NOT NULL,
  `montant` decimal(12,2) NOT NULL,
  `fournisseur` varchar(150) DEFAULT NULL,
  `reference` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `depenses`
--

LOCK TABLES `depenses` WRITE;
/*!40000 ALTER TABLE `depenses` DISABLE KEYS */;
INSERT INTO `depenses` VALUES
(1,'2026-04-01','loyer','Loyer Atelier Avril',150000.00,NULL,NULL,NULL,'2026-04-02 01:37:16'),
(2,'2026-04-02','fourniture','Achat fils et boutons',15000.00,NULL,NULL,NULL,'2026-04-02 01:37:16');
/*!40000 ALTER TABLE `depenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `factures`
--

DROP TABLE IF EXISTS `factures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `factures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numero_facture` varchar(30) NOT NULL,
  `commande_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `date_facture` date NOT NULL,
  `date_echeance` date DEFAULT NULL,
  `statut` enum('draft','émise','payée_partiel','payée','annulée') DEFAULT 'émise',
  `montant_ht` decimal(12,2) NOT NULL DEFAULT 0.00,
  `tva_pct` decimal(5,2) DEFAULT 0.00,
  `tva_montant` decimal(12,2) DEFAULT 0.00,
  `remise` decimal(12,2) DEFAULT 0.00,
  `montant_ttc` decimal(12,2) NOT NULL DEFAULT 0.00,
  `montant_paye` decimal(12,2) DEFAULT 0.00,
  `reste` decimal(12,2) DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `numero_facture` (`numero_facture`),
  KEY `commande_id` (`commande_id`),
  KEY `client_id` (`client_id`),
  CONSTRAINT `factures_ibfk_1` FOREIGN KEY (`commande_id`) REFERENCES `commandes` (`id`),
  CONSTRAINT `factures_ibfk_2` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `factures`
--

LOCK TABLES `factures` WRITE;
/*!40000 ALTER TABLE `factures` DISABLE KEYS */;
INSERT INTO `factures` VALUES
(1,'FAC-2026-001',1,1,'2026-04-01',NULL,'payée_partiel',0.00,0.00,0.00,0.00,150000.00,75000.00,75000.00,NULL,'2026-04-02 01:37:16'),
(2,'FAC-2026-002',2,2,'2026-04-02',NULL,'payée',0.00,0.00,0.00,0.00,25000.00,25000.00,0.00,NULL,'2026-04-02 01:37:16');
/*!40000 ALTER TABLE `factures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modeles`
--

DROP TABLE IF EXISTS `modeles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `modeles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code_modele` varchar(20) NOT NULL,
  `nom` varchar(150) NOT NULL,
  `categorie` enum('boubou','kaftan','robe','tailleur','chemise','pantalon','jupe','ensemble','autre') NOT NULL,
  `genre` enum('H','F','M') DEFAULT 'F',
  `description` text DEFAULT NULL,
  `prix_base` decimal(12,2) DEFAULT 0.00,
  `image_url` varchar(255) DEFAULT NULL,
  `actif` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code_modele` (`code_modele`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modeles`
--

LOCK TABLES `modeles` WRITE;
/*!40000 ALTER TABLE `modeles` DISABLE KEYS */;
INSERT INTO `modeles` VALUES
(1,'MOD-H-001','Grand Boubou Homme 3pcs','boubou','H',NULL,150000.00,NULL,1,'2026-04-02 01:37:16'),
(2,'MOD-H-002','Chemise Slim Fit Broderie','chemise','H',NULL,25000.00,NULL,1,'2026-04-02 01:37:16'),
(3,'MOD-F-001','Taille Basse Bazin','ensemble','F',NULL,85000.00,NULL,1,'2026-04-02 01:37:16'),
(4,'MOD-F-002','Robe Soirée Dentelle','robe','F',NULL,125000.00,NULL,1,'2026-04-02 01:37:16');
/*!40000 ALTER TABLE `modeles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paiements`
--

DROP TABLE IF EXISTS `paiements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `paiements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `facture_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `date_paiement` date NOT NULL,
  `montant` decimal(12,2) NOT NULL,
  `mode_paiement` enum('espèces','wave','orange_money','free_money','virement','chèque','autre') DEFAULT 'espèces',
  `reference` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `facture_id` (`facture_id`),
  KEY `client_id` (`client_id`),
  CONSTRAINT `paiements_ibfk_1` FOREIGN KEY (`facture_id`) REFERENCES `factures` (`id`),
  CONSTRAINT `paiements_ibfk_2` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paiements`
--

LOCK TABLES `paiements` WRITE;
/*!40000 ALTER TABLE `paiements` DISABLE KEYS */;
INSERT INTO `paiements` VALUES
(1,1,1,'2026-04-01',75000.00,'wave',NULL,NULL,'2026-04-02 01:37:16'),
(2,2,2,'2026-04-02',25000.00,'espèces',NULL,NULL,'2026-04-02 01:37:16');
/*!40000 ALTER TABLE `paiements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stocks`
--

DROP TABLE IF EXISTS `stocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `stocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(100) NOT NULL,
  `type_tissu` enum('Bazin Riche','Wax','Soie','Linen','Voile','Autre') DEFAULT 'Bazin Riche',
  `couleur` varchar(50) DEFAULT NULL,
  `quantite_initiale` decimal(10,2) DEFAULT 0.00,
  `quantite_restante` decimal(10,2) DEFAULT 0.00,
  `unite` enum('mètres','yards') DEFAULT 'mètres',
  `prix_achat_unitaire` int(11) DEFAULT 0,
  `alerte_seuil` decimal(10,2) DEFAULT 2.00,
  `date_achat` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stocks`
--

LOCK TABLES `stocks` WRITE;
/*!40000 ALTER TABLE `stocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `stocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tissus`
--

DROP TABLE IF EXISTS `tissus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tissus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `type_tissu` enum('bazin','wax','soie','coton','velours','dentelle','organza','autre') NOT NULL,
  `couleur` varchar(100) DEFAULT NULL,
  `stock_metres` decimal(10,2) DEFAULT 0.00,
  `prix_metre` decimal(10,2) DEFAULT 0.00,
  `fournisseur` varchar(150) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tissus`
--

LOCK TABLES `tissus` WRITE;
/*!40000 ALTER TABLE `tissus` DISABLE KEYS */;
INSERT INTO `tissus` VALUES
(1,'Bazin Riche Blanc','bazin','Blanc cassé',150.00,8500.00,'Marché Sandaga','2026-04-01 23:38:21'),
(2,'Wax Hollandais Multicolore','wax','Multicolore',80.00,3500.00,'Marché HLM','2026-04-01 23:38:21'),
(3,'Soie Naturelle Ivoire','soie','Ivoire',30.00,15000.00,'Import Dubaï','2026-04-01 23:38:21'),
(4,'Bazin Bleu Royal','bazin','Bleu Royal',100.00,9000.00,'Marché Sandaga','2026-04-01 23:38:21'),
(5,'Dentelle Dorée','dentelle','Or',25.00,12000.00,'Import Chine','2026-04-01 23:38:21');
/*!40000 ALTER TABLE `tissus` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-22 16:39:58
