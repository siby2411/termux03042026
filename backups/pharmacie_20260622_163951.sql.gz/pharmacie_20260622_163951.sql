/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: pharmacie
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `achat_lignes`
--

DROP TABLE IF EXISTS `achat_lignes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `achat_lignes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `achat_id` int(10) unsigned NOT NULL,
  `medicament_id` int(10) unsigned NOT NULL,
  `quantite_cmd` int(11) NOT NULL,
  `quantite_recue` int(11) DEFAULT 0,
  `prix_unitaire` decimal(12,2) NOT NULL,
  `numero_lot` varchar(60) DEFAULT NULL,
  `date_peremption` date DEFAULT NULL,
  `montant_ligne` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `achat_id` (`achat_id`),
  KEY `medicament_id` (`medicament_id`),
  CONSTRAINT `achat_lignes_ibfk_1` FOREIGN KEY (`achat_id`) REFERENCES `achats` (`id`) ON DELETE CASCADE,
  CONSTRAINT `achat_lignes_ibfk_2` FOREIGN KEY (`medicament_id`) REFERENCES `medicaments` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `achat_lignes`
--

LOCK TABLES `achat_lignes` WRITE;
/*!40000 ALTER TABLE `achat_lignes` DISABLE KEYS */;
/*!40000 ALTER TABLE `achat_lignes` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER trg_achat_update_stock
AFTER UPDATE ON achat_lignes
FOR EACH ROW
BEGIN
    DECLARE v_diff INT;
    DECLARE v_stock_avant INT;

    SET v_diff = NEW.quantite_recue - OLD.quantite_recue;

    IF v_diff > 0 THEN
        SELECT stock_actuel INTO v_stock_avant
        FROM medicaments WHERE id = NEW.medicament_id;

        UPDATE medicaments
        SET stock_actuel = stock_actuel + v_diff
        WHERE id = NEW.medicament_id;

        INSERT INTO mouvements_stock
            (medicament_id, type_mouvement, quantite, stock_avant, stock_apres, date_mouvement)
        VALUES
            (NEW.medicament_id, 'entree', v_diff, v_stock_avant, v_stock_avant + v_diff, NOW());

        
        INSERT INTO lots_medicaments
            (medicament_id, numero_lot, date_peremption, quantite_entree, quantite_restante, prix_achat_lot)
        VALUES
            (NEW.medicament_id, IFNULL(NEW.numero_lot,'LOT-AUTO'),
             IFNULL(NEW.date_peremption, DATE_ADD(CURDATE(), INTERVAL 2 YEAR)),
             v_diff, v_diff, NEW.prix_unitaire)
        ON DUPLICATE KEY UPDATE quantite_restante = quantite_restante + v_diff;
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `achats`
--

DROP TABLE IF EXISTS `achats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `achats` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference` varchar(30) NOT NULL,
  `fournisseur_id` int(10) unsigned NOT NULL,
  `utilisateur_id` int(10) unsigned NOT NULL,
  `date_achat` date NOT NULL,
  `montant_ht` decimal(15,2) DEFAULT 0.00,
  `tva_montant` decimal(15,2) DEFAULT 0.00,
  `montant_ttc` decimal(15,2) DEFAULT 0.00,
  `statut` enum('commande','recue','partiellement_recue','annulee') DEFAULT 'commande',
  `facture_fournisseur` varchar(50) DEFAULT NULL,
  `date_echeance` date DEFAULT NULL,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `reference` (`reference`),
  KEY `fournisseur_id` (`fournisseur_id`),
  KEY `utilisateur_id` (`utilisateur_id`),
  CONSTRAINT `achats_ibfk_1` FOREIGN KEY (`fournisseur_id`) REFERENCES `fournisseurs` (`id`),
  CONSTRAINT `achats_ibfk_2` FOREIGN KEY (`utilisateur_id`) REFERENCES `utilisateurs` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `achats`
--

LOCK TABLES `achats` WRITE;
/*!40000 ALTER TABLE `achats` DISABLE KEYS */;
/*!40000 ALTER TABLE `achats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `caisse_sessions`
--

DROP TABLE IF EXISTS `caisse_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `caisse_sessions` (
  `utilisateur_id` int(11) DEFAULT NULL,
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `caissier_id` int(10) unsigned NOT NULL,
  `date_ouverture` datetime NOT NULL DEFAULT current_timestamp(),
  `fond_caisse` decimal(15,2) DEFAULT 0.00,
  `date_cloture` datetime DEFAULT NULL,
  `total_especes` decimal(15,2) DEFAULT 0.00,
  `total_mobile_money` decimal(15,2) DEFAULT 0.00,
  `total_mutuelle` decimal(15,2) DEFAULT 0.00,
  `total_general` decimal(15,2) DEFAULT 0.00,
  `statut` enum('ouverte','fermee') DEFAULT 'ouverte',
  PRIMARY KEY (`id`),
  KEY `caissier_id` (`caissier_id`),
  CONSTRAINT `caisse_sessions_ibfk_1` FOREIGN KEY (`caissier_id`) REFERENCES `utilisateurs` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `caisse_sessions`
--

LOCK TABLES `caisse_sessions` WRITE;
/*!40000 ALTER TABLE `caisse_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `caisse_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories_medicaments`
--

DROP TABLE IF EXISTS `categories_medicaments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories_medicaments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `libelle` varchar(100) NOT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `parent_id` (`parent_id`),
  CONSTRAINT `categories_medicaments_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `categories_medicaments` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories_medicaments`
--

LOCK TABLES `categories_medicaments` WRITE;
/*!40000 ALTER TABLE `categories_medicaments` DISABLE KEYS */;
INSERT INTO `categories_medicaments` VALUES
(1,'ANTIBIO','Antibiotiques',NULL,'2026-03-19 00:36:30'),
(2,'ANALGE','Analgésiques / Antipyrétiques',NULL,'2026-03-19 00:36:30'),
(3,'VITAM','Vitamines & Compléments',NULL,'2026-03-19 00:36:30'),
(4,'CARDIO','Cardiologie',NULL,'2026-03-19 00:36:30'),
(5,'DIAB','Diabétologie',NULL,'2026-03-19 00:36:30'),
(6,'DERMA','Dermatologie',NULL,'2026-03-19 00:36:30'),
(7,'GASTRO','Gastro-entérologie',NULL,'2026-03-19 00:36:30');
/*!40000 ALTER TABLE `categories_medicaments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(20) DEFAULT NULL,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) DEFAULT NULL,
  `telephone` varchar(20) NOT NULL,
  `cni` varchar(30) DEFAULT NULL COMMENT 'Carte Nationale Identité',
  `adresse` text DEFAULT NULL,
  `mutuelle` varchar(100) DEFAULT NULL COMMENT 'IPM, IPRES, CSS, autres',
  `num_assurance` varchar(50) DEFAULT NULL,
  `credit_autorise` decimal(10,2) DEFAULT 0.00,
  `solde_credit` decimal(10,2) DEFAULT 0.00,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `actif` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` VALUES
(1,NULL,'DIOP','Moussa','776543210','1234567890123',NULL,'IPM',NULL,50000.00,0.00,'2026-03-19 00:34:38',1),
(2,NULL,'FALL','Fatou','708889900','2109876543210',NULL,'CSS',NULL,0.00,0.00,'2026-03-19 00:34:38',1),
(3,NULL,'NDIAYE','Ibrahima','764501234',NULL,NULL,NULL,NULL,10000.00,0.00,'2026-03-19 00:34:38',1),
(4,NULL,'SOW','Awa','771234567','1567890123456',NULL,'MSAS',NULL,100000.00,0.00,'2026-03-19 00:34:38',1);
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fournisseurs`
--

DROP TABLE IF EXISTS `fournisseurs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fournisseurs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `code` varchar(20) DEFAULT NULL,
  `raison_sociale` varchar(255) DEFAULT NULL,
  `ninea` varchar(30) DEFAULT NULL COMMENT 'NINEA Sénégal',
  `registre_commerce` varchar(30) DEFAULT NULL,
  `adresse` text DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `contact_nom` varchar(100) DEFAULT NULL,
  `solde` decimal(15,2) DEFAULT 0.00 COMMENT 'Solde dû au fournisseur',
  `actif` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fournisseurs`
--

LOCK TABLES `fournisseurs` WRITE;
/*!40000 ALTER TABLE `fournisseurs` DISABLE KEYS */;
INSERT INTO `fournisseurs` VALUES
(1,'Grossiste Pharma Dakar','GPD-001','Grossiste Pharma Dakar',NULL,NULL,NULL,NULL,NULL,NULL,0.00,1,'2026-03-18 20:33:36','2026-03-18 20:33:36');
/*!40000 ALTER TABLE `fournisseurs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lots_medicaments`
--

DROP TABLE IF EXISTS `lots_medicaments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lots_medicaments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `medicament_id` int(10) unsigned NOT NULL,
  `numero_lot` varchar(60) NOT NULL,
  `date_fabrication` date DEFAULT NULL,
  `date_peremption` date NOT NULL,
  `quantite_initiale` int(11) DEFAULT NULL,
  `quantite_entree` int(11) NOT NULL,
  `quantite_restante` int(11) NOT NULL,
  `prix_achat_lot` decimal(12,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `stock_actuel` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_peremption` (`date_peremption`),
  KEY `idx_medicament` (`medicament_id`),
  CONSTRAINT `lots_medicaments_ibfk_1` FOREIGN KEY (`medicament_id`) REFERENCES `medicaments` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lots_medicaments`
--

LOCK TABLES `lots_medicaments` WRITE;
/*!40000 ALTER TABLE `lots_medicaments` DISABLE KEYS */;
/*!40000 ALTER TABLE `lots_medicaments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medecins`
--

DROP TABLE IF EXISTS `medecins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `medecins` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) DEFAULT NULL,
  `specialite` varchar(100) DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `adresse` text DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `clinique` varchar(150) DEFAULT NULL,
  `num_ordre` varchar(30) DEFAULT NULL COMMENT 'N° Ordre des Médecins Sénégal',
  `actif` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medecins`
--

LOCK TABLES `medecins` WRITE;
/*!40000 ALTER TABLE `medecins` DISABLE KEYS */;
INSERT INTO `medecins` VALUES
(1,'Dr. Amadou Diop',NULL,'Pédiatre','+221 77 000 00 00','Hôpital Principal, Dakar',NULL,NULL,NULL,1);
/*!40000 ALTER TABLE `medecins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medicaments`
--

DROP TABLE IF EXISTS `medicaments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `medicaments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code_barre` varchar(50) DEFAULT NULL,
  `prix_achat` decimal(10,2) DEFAULT NULL,
  `prix_vente` decimal(10,2) DEFAULT NULL,
  `denomination` varchar(255) NOT NULL,
  `nom_commercial` varchar(200) DEFAULT NULL,
  `categorie_id` int(10) unsigned DEFAULT NULL,
  `fournisseur_id` int(10) unsigned DEFAULT NULL,
  `forme` enum('comprimé','gélule','sirop','injectable','pommade','suppositoire','goutte','patch','autre') DEFAULT NULL,
  `dosage` varchar(50) DEFAULT NULL,
  `conditionnement` varchar(100) DEFAULT NULL COMMENT 'boîte 30 cp, flacon 200ml…',
  `prix_achat_ht` decimal(12,2) NOT NULL DEFAULT 0.00,
  `prix_vente_ht` decimal(12,2) NOT NULL DEFAULT 0.00,
  `tva_taux` decimal(5,2) DEFAULT 0.00 COMMENT 'TVA % — médicaments exonérés au Sénégal',
  `prix_vente_ttc` decimal(12,2) DEFAULT NULL,
  `stock_actuel` int(11) DEFAULT 0,
  `stock_min` int(11) DEFAULT 5 COMMENT 'Seuil alerte rupture',
  `stock_max` int(11) DEFAULT 500,
  `ordonnance_obligatoire` tinyint(1) DEFAULT 0,
  `substance_psychotrope` tinyint(1) DEFAULT 0,
  `actif` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code_barre` (`code_barre`),
  KEY `categorie_id` (`categorie_id`),
  KEY `fournisseur_id` (`fournisseur_id`),
  CONSTRAINT `medicaments_ibfk_1` FOREIGN KEY (`categorie_id`) REFERENCES `categories_medicaments` (`id`),
  CONSTRAINT `medicaments_ibfk_2` FOREIGN KEY (`fournisseur_id`) REFERENCES `fournisseurs` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicaments`
--

LOCK TABLES `medicaments` WRITE;
/*!40000 ALTER TABLE `medicaments` DISABLE KEYS */;
INSERT INTO `medicaments` VALUES
(1,'1001',NULL,750.00,'PARACETAMOL 500MG',NULL,1,NULL,NULL,NULL,NULL,0.00,0.00,0.00,NULL,150,5,500,0,0,1,'2026-03-19 01:11:42','2026-03-19 01:11:42'),
(2,'1002',NULL,1200.00,'PARACETAMOL 1G',NULL,1,NULL,NULL,NULL,NULL,0.00,0.00,0.00,NULL,80,5,500,0,0,1,'2026-03-19 01:11:42','2026-03-19 01:11:42'),
(3,'1003',NULL,900.00,'DOLIPRANE 500MG',NULL,2,NULL,NULL,NULL,NULL,0.00,0.00,0.00,NULL,58,5,500,0,0,1,'2026-03-19 01:11:42','2026-03-20 17:53:21');
/*!40000 ALTER TABLE `medicaments` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER trg_alerte_stock_min
AFTER UPDATE ON medicaments
FOR EACH ROW
BEGIN
    IF NEW.stock_actuel <= NEW.stock_min AND OLD.stock_actuel > OLD.stock_min THEN
        INSERT INTO mouvements_stock
            (medicament_id, type_mouvement, quantite, stock_avant, stock_apres, notes, date_mouvement)
        VALUES
            (NEW.id, 'ajustement', 0, OLD.stock_actuel, NEW.stock_actuel,
             CONCAT('⚠️ ALERTE RUPTURE : stock=', NEW.stock_actuel, ' ≤ seuil=', NEW.stock_min), NOW());
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `mouvements_stock`
--

DROP TABLE IF EXISTS `mouvements_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mouvements_stock` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `medicament_id` int(10) unsigned NOT NULL,
  `lot_id` int(10) unsigned DEFAULT NULL,
  `type_mouvement` enum('entree','sortie_vente','sortie_perte','retour_fournisseur','ajustement','inventaire') DEFAULT NULL,
  `quantite` int(11) NOT NULL,
  `stock_avant` int(11) NOT NULL,
  `stock_apres` int(11) NOT NULL,
  `reference_doc` varchar(50) DEFAULT NULL,
  `utilisateur_id` int(10) unsigned DEFAULT NULL,
  `date_mouvement` datetime DEFAULT current_timestamp(),
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `medicament_id` (`medicament_id`),
  KEY `lot_id` (`lot_id`),
  KEY `utilisateur_id` (`utilisateur_id`),
  CONSTRAINT `mouvements_stock_ibfk_1` FOREIGN KEY (`medicament_id`) REFERENCES `medicaments` (`id`),
  CONSTRAINT `mouvements_stock_ibfk_2` FOREIGN KEY (`lot_id`) REFERENCES `lots_medicaments` (`id`),
  CONSTRAINT `mouvements_stock_ibfk_3` FOREIGN KEY (`utilisateur_id`) REFERENCES `utilisateurs` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mouvements_stock`
--

LOCK TABLES `mouvements_stock` WRITE;
/*!40000 ALTER TABLE `mouvements_stock` DISABLE KEYS */;
INSERT INTO `mouvements_stock` VALUES
(1,3,NULL,'sortie_vente',1,60,59,'VNT-202603-00004',NULL,'2026-03-20 17:53:21',NULL);
/*!40000 ALTER TABLE `mouvements_stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ordonnance_lignes`
--

DROP TABLE IF EXISTS `ordonnance_lignes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ordonnance_lignes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ordonnance_id` int(10) unsigned NOT NULL,
  `medicament_id` int(10) unsigned NOT NULL,
  `quantite_prescrite` int(11) NOT NULL,
  `quantite_delivree` int(11) DEFAULT 0,
  `posologie` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ordonnance_id` (`ordonnance_id`),
  KEY `medicament_id` (`medicament_id`),
  CONSTRAINT `ordonnance_lignes_ibfk_1` FOREIGN KEY (`ordonnance_id`) REFERENCES `ordonnances` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ordonnance_lignes_ibfk_2` FOREIGN KEY (`medicament_id`) REFERENCES `medicaments` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ordonnance_lignes`
--

LOCK TABLES `ordonnance_lignes` WRITE;
/*!40000 ALTER TABLE `ordonnance_lignes` DISABLE KEYS */;
/*!40000 ALTER TABLE `ordonnance_lignes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ordonnances`
--

DROP TABLE IF EXISTS `ordonnances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ordonnances` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference` varchar(30) NOT NULL,
  `client_id` int(10) unsigned NOT NULL,
  `medecin_id` int(10) unsigned DEFAULT NULL,
  `date_emission` date NOT NULL,
  `date_validite` date DEFAULT NULL,
  `statut` enum('en_attente','servie_partiellement','servie','annulee') DEFAULT 'en_attente',
  `scan_path` varchar(255) DEFAULT NULL COMMENT 'Image scan ordonnance',
  `notes` text DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `reference` (`reference`),
  KEY `client_id` (`client_id`),
  KEY `medecin_id` (`medecin_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `ordonnances_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`),
  CONSTRAINT `ordonnances_ibfk_2` FOREIGN KEY (`medecin_id`) REFERENCES `medecins` (`id`),
  CONSTRAINT `ordonnances_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `utilisateurs` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ordonnances`
--

LOCK TABLES `ordonnances` WRITE;
/*!40000 ALTER TABLE `ordonnances` DISABLE KEYS */;
/*!40000 ALTER TABLE `ordonnances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `utilisateurs`
--

DROP TABLE IF EXISTS `utilisateurs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `utilisateurs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `login` varchar(60) NOT NULL,
  `mot_de_passe` varchar(255) NOT NULL COMMENT 'bcrypt hash',
  `role` enum('admin','pharmacien','caissier','magasinier','visiteur') DEFAULT 'caissier',
  `telephone` varchar(20) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `actif` tinyint(1) DEFAULT 1,
  `derniere_connexion` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `login` (`login`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `utilisateurs`
--

LOCK TABLES `utilisateurs` WRITE;
/*!40000 ALTER TABLE `utilisateurs` DISABLE KEYS */;
INSERT INTO `utilisateurs` VALUES
(1,'SYSTEME','Admin','admin','admin123','admin',NULL,NULL,1,'2026-03-19 00:22:21','2026-03-18 06:37:22','2026-03-20 14:12:39'),
(2,'DIOP','Amadou','amadou','pass123','caissier',NULL,NULL,1,NULL,'2026-03-20 13:44:47','2026-03-20 13:44:47'),
(3,'SOW','Fatou','fatou','pass456','caissier',NULL,NULL,1,NULL,'2026-03-20 13:44:47','2026-03-20 13:44:47');
/*!40000 ALTER TABLE `utilisateurs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `v_ca_journalier`
--

DROP TABLE IF EXISTS `v_ca_journalier`;
/*!50001 DROP VIEW IF EXISTS `v_ca_journalier`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `v_ca_journalier` AS SELECT
 1 AS `jour`,
  1 AS `nb_ventes`,
  1 AS `ca_total`,
  1 AS `especes`,
  1 AS `mobile_money`,
  1 AS `mutuelle` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_ordonnances_en_attente`
--

DROP TABLE IF EXISTS `v_ordonnances_en_attente`;
/*!50001 DROP VIEW IF EXISTS `v_ordonnances_en_attente`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `v_ordonnances_en_attente` AS SELECT
 1 AS `reference`,
  1 AS `date_emission`,
  1 AS `date_validite`,
  1 AS `patient`,
  1 AS `telephone`,
  1 AS `nb_lignes`,
  1 AS `statut` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_peremptions_proches`
--

DROP TABLE IF EXISTS `v_peremptions_proches`;
/*!50001 DROP VIEW IF EXISTS `v_peremptions_proches`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `v_peremptions_proches` AS SELECT
 1 AS `denomination`,
  1 AS `nom_commercial`,
  1 AS `numero_lot`,
  1 AS `date_peremption`,
  1 AS `quantite_restante`,
  1 AS `jours_restants` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_stock_critique`
--

DROP TABLE IF EXISTS `v_stock_critique`;
/*!50001 DROP VIEW IF EXISTS `v_stock_critique`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `v_stock_critique` AS SELECT
 1 AS `id`,
  1 AS `code_barre`,
  1 AS `denomination`,
  1 AS `nom_commercial`,
  1 AS `stock_actuel`,
  1 AS `stock_min`,
  1 AS `statut_stock`,
  1 AS `quantite_a_commander`,
  1 AS `fournisseur` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_top_medicaments`
--

DROP TABLE IF EXISTS `v_top_medicaments`;
/*!50001 DROP VIEW IF EXISTS `v_top_medicaments`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `v_top_medicaments` AS SELECT
 1 AS `denomination`,
  1 AS `nom_commercial`,
  1 AS `total_vendu`,
  1 AS `ca_genere` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `vente_lignes`
--

DROP TABLE IF EXISTS `vente_lignes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `vente_lignes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vente_id` int(10) unsigned NOT NULL,
  `medicament_id` int(10) unsigned NOT NULL,
  `lot_id` int(10) unsigned DEFAULT NULL,
  `quantite` int(11) NOT NULL,
  `prix_unitaire` decimal(12,2) NOT NULL,
  `tva_taux` decimal(5,2) DEFAULT 0.00,
  `remise_pct` decimal(5,2) DEFAULT 0.00,
  `montant_ligne` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `vente_id` (`vente_id`),
  KEY `medicament_id` (`medicament_id`),
  KEY `lot_id` (`lot_id`),
  CONSTRAINT `vente_lignes_ibfk_1` FOREIGN KEY (`vente_id`) REFERENCES `ventes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `vente_lignes_ibfk_2` FOREIGN KEY (`medicament_id`) REFERENCES `medicaments` (`id`),
  CONSTRAINT `vente_lignes_ibfk_3` FOREIGN KEY (`lot_id`) REFERENCES `lots_medicaments` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vente_lignes`
--

LOCK TABLES `vente_lignes` WRITE;
/*!40000 ALTER TABLE `vente_lignes` DISABLE KEYS */;
INSERT INTO `vente_lignes` VALUES
(1,100,1,NULL,10,750.00,0.00,0.00,7500.00),
(2,100,2,NULL,5,1850.00,0.00,0.00,9250.00),
(3,103,4,NULL,10,6200.00,0.00,0.00,62000.00),
(4,103,3,NULL,20,1300.00,0.00,0.00,26000.00),
(5,106,1,NULL,5,750.00,0.00,0.00,3750.00),
(6,106,5,NULL,10,1800.00,0.00,0.00,18000.00),
(7,4,3,NULL,1,900.00,0.00,0.00,900.00);
/*!40000 ALTER TABLE `vente_lignes` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER trg_vente_update_stock
AFTER INSERT ON vente_lignes
FOR EACH ROW
BEGIN
    DECLARE v_stock_avant INT;

    SELECT stock_actuel INTO v_stock_avant
    FROM medicaments WHERE id = NEW.medicament_id;

    UPDATE medicaments
    SET stock_actuel = stock_actuel - NEW.quantite
    WHERE id = NEW.medicament_id;

    UPDATE lots_medicaments
    SET quantite_restante = quantite_restante - NEW.quantite
    WHERE id = NEW.lot_id AND NEW.lot_id IS NOT NULL;

    INSERT INTO mouvements_stock
        (medicament_id, lot_id, type_mouvement, quantite, stock_avant, stock_apres, reference_doc, date_mouvement)
    SELECT NEW.medicament_id, NEW.lot_id, 'sortie_vente', NEW.quantite,
           v_stock_avant, v_stock_avant - NEW.quantite,
           v.reference, NOW()
    FROM ventes v WHERE v.id = NEW.vente_id;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `ventes`
--

DROP TABLE IF EXISTS `ventes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ventes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference` varchar(30) NOT NULL,
  `client_id` int(10) unsigned DEFAULT NULL,
  `ordonnance_id` int(10) unsigned DEFAULT NULL,
  `utilisateur_id` int(10) unsigned NOT NULL,
  `date_vente` datetime NOT NULL DEFAULT current_timestamp(),
  `montant_total` decimal(10,2) DEFAULT NULL,
  `montant_ht` decimal(15,2) DEFAULT 0.00,
  `tva_montant` decimal(15,2) DEFAULT 0.00,
  `montant_ttc` decimal(15,2) DEFAULT 0.00,
  `remise_pct` decimal(5,2) DEFAULT 0.00,
  `remise_montant` decimal(15,2) DEFAULT 0.00,
  `net_a_payer` decimal(15,2) DEFAULT 0.00,
  `mode_paiement` enum('especes','wave','orange_money','free_money','carte','mutuelle','credit','mixte') DEFAULT 'especes',
  `montant_recu` decimal(15,2) DEFAULT 0.00,
  `monnaie` decimal(15,2) DEFAULT 0.00,
  `statut` varchar(20) DEFAULT 'paye',
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `reference` (`reference`),
  KEY `client_id` (`client_id`),
  KEY `ordonnance_id` (`ordonnance_id`),
  KEY `utilisateur_id` (`utilisateur_id`),
  KEY `idx_date_vente` (`date_vente`),
  KEY `idx_statut` (`statut`),
  CONSTRAINT `ventes_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`),
  CONSTRAINT `ventes_ibfk_2` FOREIGN KEY (`ordonnance_id`) REFERENCES `ordonnances` (`id`),
  CONSTRAINT `ventes_ibfk_3` FOREIGN KEY (`utilisateur_id`) REFERENCES `utilisateurs` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ventes`
--

LOCK TABLES `ventes` WRITE;
/*!40000 ALTER TABLE `ventes` DISABLE KEYS */;
INSERT INTO `ventes` VALUES
(1,'VNT-202603-00001',NULL,NULL,3,'2026-03-20 13:45:46',25000.00,0.00,0.00,0.00,0.00,0.00,0.00,'orange_money',0.00,0.00,'paye',NULL),
(2,'VNT-202603-00002',NULL,NULL,3,'2026-03-20 13:45:46',4500.00,0.00,0.00,0.00,0.00,0.00,0.00,'especes',0.00,0.00,'paye',NULL),
(3,'VNT-202603-00003',NULL,NULL,3,'2026-03-20 13:45:46',15000.00,0.00,0.00,0.00,0.00,0.00,0.00,'wave',0.00,0.00,'paye',NULL),
(4,'VNT-202603-00004',NULL,NULL,1,'2026-03-20 17:53:21',900.00,0.00,0.00,0.00,0.00,0.00,0.00,'especes',0.00,0.00,'paye',NULL);
/*!40000 ALTER TABLE `ventes` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER trg_vente_reference
BEFORE INSERT ON ventes
FOR EACH ROW
BEGIN
    DECLARE v_seq INT;
    SELECT IFNULL(MAX(id),0)+1 INTO v_seq FROM ventes;
    SET NEW.reference = CONCAT('VNT-', DATE_FORMAT(NOW(),'%Y%m'), '-', LPAD(v_seq,5,'0'));
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER trg_vente_calcul_totaux
BEFORE UPDATE ON ventes
FOR EACH ROW
BEGIN
    DECLARE v_ht DECIMAL(15,2);
    DECLARE v_tva DECIMAL(15,2);

    SELECT IFNULL(SUM(montant_ligne),0),
           IFNULL(SUM(montant_ligne * tva_taux/100),0)
    INTO v_ht, v_tva
    FROM vente_lignes WHERE vente_id = NEW.id;

    SET NEW.montant_ht     = v_ht;
    SET NEW.tva_montant    = v_tva;
    SET NEW.montant_ttc    = v_ht + v_tva;
    SET NEW.remise_montant = NEW.montant_ttc * NEW.remise_pct / 100;
    SET NEW.net_a_payer    = NEW.montant_ttc - NEW.remise_montant;
    SET NEW.monnaie        = GREATEST(0, NEW.montant_recu - NEW.net_a_payer);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `v_ca_journalier`
--

/*!50001 DROP VIEW IF EXISTS `v_ca_journalier`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_ca_journalier` AS select cast(`ventes`.`date_vente` as date) AS `jour`,count(0) AS `nb_ventes`,sum(`ventes`.`net_a_payer`) AS `ca_total`,sum(case when `ventes`.`mode_paiement` = 'especes' then `ventes`.`net_a_payer` else 0 end) AS `especes`,sum(case when `ventes`.`mode_paiement` in ('wave','orange_money','free_money') then `ventes`.`net_a_payer` else 0 end) AS `mobile_money`,sum(case when `ventes`.`mode_paiement` = 'mutuelle' then `ventes`.`net_a_payer` else 0 end) AS `mutuelle` from `ventes` where `ventes`.`statut` = 'validee' group by cast(`ventes`.`date_vente` as date) order by cast(`ventes`.`date_vente` as date) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_ordonnances_en_attente`
--

/*!50001 DROP VIEW IF EXISTS `v_ordonnances_en_attente`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_ordonnances_en_attente` AS select `o`.`reference` AS `reference`,`o`.`date_emission` AS `date_emission`,`o`.`date_validite` AS `date_validite`,concat(`c`.`prenom`,' ',`c`.`nom`) AS `patient`,`c`.`telephone` AS `telephone`,count(`ol`.`id`) AS `nb_lignes`,`o`.`statut` AS `statut` from ((`ordonnances` `o` join `clients` `c` on(`c`.`id` = `o`.`client_id`)) join `ordonnance_lignes` `ol` on(`ol`.`ordonnance_id` = `o`.`id`)) where `o`.`statut` in ('en_attente','servie_partiellement') group by `o`.`id` order by `o`.`date_emission` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_peremptions_proches`
--

/*!50001 DROP VIEW IF EXISTS `v_peremptions_proches`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_peremptions_proches` AS select `m`.`denomination` AS `denomination`,`m`.`nom_commercial` AS `nom_commercial`,`l`.`numero_lot` AS `numero_lot`,`l`.`date_peremption` AS `date_peremption`,`l`.`quantite_restante` AS `quantite_restante`,to_days(`l`.`date_peremption`) - to_days(curdate()) AS `jours_restants` from (`lots_medicaments` `l` join `medicaments` `m` on(`m`.`id` = `l`.`medicament_id`)) where `l`.`quantite_restante` > 0 and `l`.`date_peremption` between curdate() and curdate() + interval 60 day order by `l`.`date_peremption` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_stock_critique`
--

/*!50001 DROP VIEW IF EXISTS `v_stock_critique`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_stock_critique` AS select `m`.`id` AS `id`,`m`.`code_barre` AS `code_barre`,`m`.`denomination` AS `denomination`,`m`.`nom_commercial` AS `nom_commercial`,`m`.`stock_actuel` AS `stock_actuel`,`m`.`stock_min` AS `stock_min`,case when `m`.`stock_actuel` = 0 then '🔴 RUPTURE' when `m`.`stock_actuel` <= `m`.`stock_min` then '🟠 CRITIQUE' else '🟢 OK' end AS `statut_stock`,`m`.`stock_min` - `m`.`stock_actuel` AS `quantite_a_commander`,`f`.`raison_sociale` AS `fournisseur` from (`medicaments` `m` left join `fournisseurs` `f` on(`f`.`id` = `m`.`fournisseur_id`)) where `m`.`actif` = 1 order by `m`.`stock_actuel` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_top_medicaments`
--

/*!50001 DROP VIEW IF EXISTS `v_top_medicaments`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_top_medicaments` AS select `m`.`denomination` AS `denomination`,`m`.`nom_commercial` AS `nom_commercial`,sum(`vl`.`quantite`) AS `total_vendu`,sum(`vl`.`montant_ligne`) AS `ca_genere` from ((`vente_lignes` `vl` join `ventes` `v` on(`v`.`id` = `vl`.`vente_id` and `v`.`statut` = 'validee')) join `medicaments` `m` on(`m`.`id` = `vl`.`medicament_id`)) group by `vl`.`medicament_id` order by sum(`vl`.`quantite`) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-22 16:40:10
