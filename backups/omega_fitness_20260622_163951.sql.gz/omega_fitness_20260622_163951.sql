/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: omega_fitness
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `adherents`
--

DROP TABLE IF EXISTS `adherents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `adherents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numero_licence` varchar(20) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `date_naissance` date DEFAULT NULL,
  `adresse` text DEFAULT NULL,
  `discipline_principale` varchar(50) DEFAULT NULL,
  `date_inscription` date DEFAULT curdate(),
  `statut` enum('actif','suspendu','archive') DEFAULT 'actif',
  `photo` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `numero_licence` (`numero_licence`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adherents`
--

LOCK TABLES `adherents` WRITE;
/*!40000 ALTER TABLE `adherents` DISABLE KEYS */;
INSERT INTO `adherents` VALUES
(1,'OM-2024-0001','Diouf','Aliou','aliou.diouf@email.com','771112233','1995-03-15','Dakar, Sicap Liberté','Boxe Anglaise','2024-01-10','actif',NULL,'2026-04-08 22:41:47'),
(2,'OM-2024-0002','Ba','Fatima','fatima.ba@email.com','772223344','1998-07-22','Dakar, Mermoz','Karaté','2024-01-15','actif',NULL,'2026-04-08 22:41:47'),
(3,'OM-2024-0003','Sow','Ibrahima','ibrahima.sow@email.com','773334455','2000-11-05','Dakar, Parcelles Assainies','Jiu-Jitsu Brésilien','2024-02-01','actif',NULL,'2026-04-08 22:41:47'),
(4,'OM-2024-0004','Kane','Awa','awa.kane@email.com','774445566','1992-05-18','Dakar, Ouakam','CrossFit','2024-02-10','actif',NULL,'2026-04-08 22:41:47'),
(5,'OM-2024-0005','Mbaye','Cheikh','cheikh.mbaye@email.com','775556677','2002-09-30','Dakar, Yoff','Muay Thai','2024-03-01','actif',NULL,'2026-04-08 22:41:47'),
(6,'OM-2024-0006','Faye','Ndeye','ndeye.faye@email.com','776667788','1997-12-12','Dakar, Almadies','Yoga','2024-03-15','actif',NULL,'2026-04-08 22:41:47'),
(7,'OM-2024-0007','Diatta','Moussa','moussa.diatta@email.com','777778899','2001-04-25','Dakar, Grand Yoff','Kickboxing','2024-04-01','actif',NULL,'2026-04-08 22:41:47'),
(8,'OM-2024-0008','Seck','Adama','adama.seck@email.com','778889900','1994-08-08','Dakar, Fann','MMA','2024-04-10','actif',NULL,'2026-04-08 22:41:47'),
(9,'OM-2024-0009','Thiam','Rokhaya','rokhaya.thiam@email.com','779990011','1999-06-17','Dakar, Point E','Boxe Anglaise','2024-05-01','actif',NULL,'2026-04-08 22:41:47'),
(10,'OM-2024-0010','Ndiaye','Pape','pape.ndiaye@email.com','770001122','2003-02-28','Dakar, Sacré Coeur','Karaté','2024-05-15','suspendu',NULL,'2026-04-08 22:41:47'),
(11,'OM-2024-0011','Dieng','Marietou','marietou.dieng@email.com','771122334','1996-10-10','Dakar, Ngor','Jiu-Jitsu Brésilien','2024-06-01','actif',NULL,'2026-04-08 22:41:47'),
(12,'OM-2024-0012','Fall','Babacar','babacar.fall@email.com','772233445','2000-03-20','Dakar, Hann','CrossFit','2024-06-15','actif',NULL,'2026-04-08 22:41:47');
/*!40000 ALTER TABLE `adherents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charges`
--

DROP TABLE IF EXISTS `charges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `charges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_charge` date NOT NULL,
  `type_charge` varchar(50) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `montant` decimal(10,2) NOT NULL,
  `fournisseur` varchar(100) DEFAULT NULL,
  `facture_ref` varchar(50) DEFAULT NULL,
  `categorie` enum('materiel','entretien','eau_electricite','loyer','salaires','marketing','autres') DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charges`
--

LOCK TABLES `charges` WRITE;
/*!40000 ALTER TABLE `charges` DISABLE KEYS */;
INSERT INTO `charges` VALUES
(1,'2024-01-05','Loyer','Loyer mensuel local',500000.00,'Immobilière FALL',NULL,'loyer'),
(2,'2024-01-10','Électricité','Facture électricité janvier',150000.00,'SENELEC',NULL,'eau_electricite'),
(3,'2024-01-15','Salaires','Paiement salaires formateurs',3500000.00,'Oméga Fitness',NULL,'salaires'),
(4,'2024-02-05','Loyer','Loyer mensuel local',500000.00,'Immobilière FALL',NULL,'loyer'),
(5,'2024-02-10','Électricité','Facture électricité février',145000.00,'SENELEC',NULL,'eau_electricite'),
(6,'2024-02-20','Matériel','Achat gants de boxe',300000.00,'Decathlon',NULL,'materiel'),
(7,'2024-03-05','Loyer','Loyer mensuel local',500000.00,'Immobilière FALL',NULL,'loyer'),
(8,'2024-03-15','Marketing','Campagne publicitaire',250000.00,'SocialMedia Pro',NULL,'marketing'),
(9,'2024-04-05','Loyer','Loyer mensuel local',500000.00,'Immobilière FALL',NULL,'loyer'),
(10,'2024-04-20','Entretien','Nettoyage et entretien',100000.00,'Clean Service',NULL,'entretien');
/*!40000 ALTER TABLE `charges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cours`
--

DROP TABLE IF EXISTS `cours`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cours` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `discipline_id` int(11) DEFAULT NULL,
  `formateur_id` int(11) DEFAULT NULL,
  `titre` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `niveau` varchar(30) DEFAULT NULL,
  `jour` varchar(15) DEFAULT NULL,
  `heure_debut` time DEFAULT NULL,
  `heure_fin` time DEFAULT NULL,
  `salle` varchar(50) DEFAULT NULL,
  `capacite` int(11) DEFAULT NULL,
  `inscrits` int(11) DEFAULT 0,
  `actif` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `discipline_id` (`discipline_id`),
  KEY `formateur_id` (`formateur_id`),
  CONSTRAINT `cours_ibfk_1` FOREIGN KEY (`discipline_id`) REFERENCES `disciplines` (`id`),
  CONSTRAINT `cours_ibfk_2` FOREIGN KEY (`formateur_id`) REFERENCES `formateurs` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cours`
--

LOCK TABLES `cours` WRITE;
/*!40000 ALTER TABLE `cours` DISABLE KEYS */;
INSERT INTO `cours` VALUES
(1,1,1,'Boxe Débutants',NULL,NULL,'LUNDI','18:00:00','19:30:00','Salle A - Ring',20,15,1),
(2,1,1,'Boxe Avancés',NULL,NULL,'MERCREDI','19:30:00','21:00:00','Salle A - Ring',15,12,1),
(3,2,2,'Karaté Enfants',NULL,NULL,'MARDI','17:00:00','18:00:00','Salle B - Dojo',15,14,1),
(4,2,2,'Karaté Adultes',NULL,NULL,'JEUDI','19:00:00','20:30:00','Salle B - Dojo',20,18,1),
(5,3,3,'JJB All Levels',NULL,NULL,'LUNDI','20:00:00','21:30:00','Salle C - Tapis',15,12,1),
(6,3,3,'JJB No Gi',NULL,NULL,'VENDREDI','19:00:00','20:30:00','Salle C - Tapis',15,10,1),
(7,4,5,'Muay Thai Débutants',NULL,NULL,'MARDI','19:00:00','20:30:00','Salle A - Ring',20,16,1),
(8,4,5,'Muay Thai Avancés',NULL,NULL,'JEUDI','20:30:00','22:00:00','Salle A - Ring',15,11,1),
(9,5,4,'CrossFit Morning',NULL,NULL,'LUNDI','06:00:00','07:00:00','CrossFit Box',12,10,1),
(10,5,4,'CrossFit Soir',NULL,NULL,'MERCREDI','18:00:00','19:00:00','CrossFit Box',15,13,1),
(11,5,4,'CrossFit Weekend',NULL,NULL,'SAMEDI','09:00:00','10:30:00','CrossFit Box',20,17,1),
(12,6,6,'Yoga Doux',NULL,NULL,'LUNDI','08:00:00','09:00:00','Studio Yoga',15,12,1),
(13,6,6,'Yoga Flow',NULL,NULL,'MERCREDI','17:00:00','18:30:00','Studio Yoga',20,18,1),
(14,7,8,'Kickboxing',NULL,NULL,'MARDI','18:30:00','20:00:00','Salle A - Ring',20,14,1),
(15,10,7,'MMA Débutants',NULL,NULL,'MERCREDI','20:00:00','21:30:00','Salle MMA',15,10,1);
/*!40000 ALTER TABLE `cours` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `disciplines`
--

DROP TABLE IF EXISTS `disciplines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `disciplines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `tarif_mensuel` decimal(10,2) NOT NULL,
  `tarif_trimestriel` decimal(10,2) DEFAULT NULL,
  `tarif_annuel` decimal(10,2) DEFAULT NULL,
  `tarif_cours_libre` decimal(10,2) DEFAULT NULL,
  `age_minimum` int(11) DEFAULT NULL,
  `age_maximum` int(11) DEFAULT NULL,
  `capacite_max` int(11) DEFAULT NULL,
  `actif` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nom` (`nom`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `disciplines`
--

LOCK TABLES `disciplines` WRITE;
/*!40000 ALTER TABLE `disciplines` DISABLE KEYS */;
INSERT INTO `disciplines` VALUES
(1,'Boxe Anglaise','Boxe pieds-poings traditionnelle',45000.00,120000.00,420000.00,8000.00,12,NULL,30,1),
(2,'Karaté','Art martial traditionnel japonais',40000.00,110000.00,380000.00,7000.00,6,NULL,25,1),
(3,'Jiu-Jitsu Brésilien','Art martial au sol',50000.00,135000.00,480000.00,10000.00,14,NULL,20,1),
(4,'Muay Thai','Boxe thaïlandaise',48000.00,130000.00,450000.00,9000.00,12,NULL,25,1),
(5,'CrossFit','Entraînement fonctionnel intensif',55000.00,150000.00,520000.00,12000.00,16,NULL,20,1),
(6,'Yoga','Bien-être et souplesse',35000.00,95000.00,320000.00,6000.00,12,NULL,20,1),
(7,'Kickboxing','Boxe pieds-poings',47000.00,125000.00,440000.00,8500.00,12,NULL,25,1),
(8,'Aïkido','Art martial de défense',42000.00,115000.00,400000.00,7500.00,10,NULL,20,1),
(9,'Taekwondo','Art martial coréen',43000.00,118000.00,410000.00,7800.00,8,NULL,25,1),
(10,'MMA','Mixed Martial Arts',65000.00,180000.00,620000.00,15000.00,16,NULL,15,1);
/*!40000 ALTER TABLE `disciplines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formateurs`
--

DROP TABLE IF EXISTS `formateurs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `formateurs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `matricule` varchar(20) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `specialite` varchar(100) DEFAULT NULL,
  `diplomes` text DEFAULT NULL,
  `date_embauche` date DEFAULT NULL,
  `salaire_base` decimal(10,2) DEFAULT NULL,
  `statut` enum('actif','inactif','conge') DEFAULT 'actif',
  `photo` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `matricule` (`matricule`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formateurs`
--

LOCK TABLES `formateurs` WRITE;
/*!40000 ALTER TABLE `formateurs` DISABLE KEYS */;
INSERT INTO `formateurs` VALUES
(1,'FM-2024-001','Diallo','Mamadou','m.diallo@omegafitness.com','771234567','Boxe Anglaise - Pro','Champion National, Diplôme d\'État BPJEPS','2020-01-15',450000.00,'actif',NULL,'2026-04-08 22:41:47'),
(2,'FM-2024-002','Sarr','Fatou','f.sarr@omegafitness.com','772345678','Karaté - 5e Dan','Ceinture Noire 5e Dan, Championne d\'Afrique','2019-03-10',500000.00,'actif',NULL,'2026-04-08 22:41:47'),
(3,'FM-2024-003','Ndiaye','Ousmane','o.ndiaye@omegafitness.com','773456789','Jiu-Jitsu - Ceinture Noire','Ceinture Noire 2e Degré, Champion National','2021-06-20',480000.00,'actif',NULL,'2026-04-08 22:41:47'),
(4,'FM-2024-004','Fall','Aissatou','a.fall@omegafitness.com','774567890','CrossFit - Coach L3','CrossFit Level 3 Trainer, Nutrition Coach','2022-01-05',550000.00,'actif',NULL,'2026-04-08 22:41:47'),
(5,'FM-2024-005','Gueye','Pape','p.gueye@omegafitness.com','775678901','Muay Thai','Champion National, Instructeur certifié Thaïlande','2020-09-12',470000.00,'actif',NULL,'2026-04-08 22:41:47'),
(6,'FM-2024-006','Diop','Marième','m.diop@omegafitness.com','776789012','Yoga & Méditation','Certifiée Yoga Alliance RYT 500','2023-02-18',400000.00,'actif',NULL,'2026-04-08 22:41:47'),
(7,'FM-2024-007','Sy','Abdoulaye','a.sy@omegafitness.com','777890123','MMA - Coach','Ceinture Noire JJB, Boxe Thaï, Lutte','2021-11-30',600000.00,'actif',NULL,'2026-04-08 22:41:47'),
(8,'FM-2024-008','Ngom','Aminata','a.ngom@omegafitness.com','778901234','Kickboxing','Championne Nationale, Coach K1','2022-07-22',460000.00,'conge',NULL,'2026-04-08 22:41:47');
/*!40000 ALTER TABLE `formateurs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inscriptions`
--

DROP TABLE IF EXISTS `inscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `inscriptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adherent_id` int(11) DEFAULT NULL,
  `discipline_id` int(11) DEFAULT NULL,
  `date_inscription` date DEFAULT curdate(),
  `date_debut` date DEFAULT NULL,
  `date_fin` date DEFAULT NULL,
  `type_abonnement` enum('mensuel','trimestriel','annuel','cours_libre') NOT NULL,
  `montant_total` decimal(10,2) DEFAULT NULL,
  `statut` enum('actif','expire','resilie') DEFAULT 'actif',
  PRIMARY KEY (`id`),
  KEY `adherent_id` (`adherent_id`),
  KEY `discipline_id` (`discipline_id`),
  CONSTRAINT `inscriptions_ibfk_1` FOREIGN KEY (`adherent_id`) REFERENCES `adherents` (`id`),
  CONSTRAINT `inscriptions_ibfk_2` FOREIGN KEY (`discipline_id`) REFERENCES `disciplines` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inscriptions`
--

LOCK TABLES `inscriptions` WRITE;
/*!40000 ALTER TABLE `inscriptions` DISABLE KEYS */;
INSERT INTO `inscriptions` VALUES
(1,1,1,'2026-04-08','2024-01-10','2025-01-10','annuel',420000.00,'actif'),
(2,2,2,'2026-04-08','2024-01-15','2024-12-15','annuel',380000.00,'actif'),
(3,3,3,'2026-04-08','2024-02-01','2024-05-01','trimestriel',135000.00,'actif'),
(4,4,5,'2026-04-08','2024-02-10','2024-03-10','mensuel',55000.00,'actif'),
(5,5,4,'2026-04-08','2024-03-01','2024-06-01','trimestriel',130000.00,'actif'),
(6,6,6,'2026-04-08','2024-03-15','2024-04-15','mensuel',35000.00,'actif'),
(7,7,7,'2026-04-08','2024-04-01','2025-04-01','annuel',440000.00,'actif'),
(8,8,10,'2026-04-08','2024-04-10','2024-07-10','trimestriel',180000.00,'actif'),
(9,9,1,'2026-04-08','2024-05-01','2024-08-01','trimestriel',120000.00,'actif'),
(10,11,3,'2026-04-08','2024-06-01','2024-09-01','trimestriel',135000.00,'actif');
/*!40000 ALTER TABLE `inscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(100) NOT NULL,
  `message` text DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL,
  `destinataire` varchar(50) DEFAULT NULL,
  `date_envoi` timestamp NULL DEFAULT current_timestamp(),
  `lu` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paiements`
--

DROP TABLE IF EXISTS `paiements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `paiements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adherent_id` int(11) DEFAULT NULL,
  `inscription_id` int(11) DEFAULT NULL,
  `montant` decimal(10,2) NOT NULL,
  `date_paiement` date DEFAULT curdate(),
  `mode_paiement` enum('especes','carte','cheque','virement','mobile_money') NOT NULL,
  `reference` varchar(50) DEFAULT NULL,
  `statut` enum('valide','annule','en_attente') DEFAULT 'valide',
  `observations` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `adherent_id` (`adherent_id`),
  KEY `inscription_id` (`inscription_id`),
  CONSTRAINT `paiements_ibfk_1` FOREIGN KEY (`adherent_id`) REFERENCES `adherents` (`id`),
  CONSTRAINT `paiements_ibfk_2` FOREIGN KEY (`inscription_id`) REFERENCES `inscriptions` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paiements`
--

LOCK TABLES `paiements` WRITE;
/*!40000 ALTER TABLE `paiements` DISABLE KEYS */;
INSERT INTO `paiements` VALUES
(1,1,1,420000.00,'2024-01-10','virement','TRF-001','valide',NULL),
(2,2,2,380000.00,'2024-01-15','especes','ESP-001','valide',NULL),
(3,3,3,135000.00,'2024-02-01','carte','CRD-001','valide',NULL),
(4,4,4,55000.00,'2024-02-10','mobile_money','MM-001','valide',NULL),
(5,5,5,130000.00,'2024-03-01','cheque','CHQ-001','valide',NULL),
(6,6,6,35000.00,'2024-03-15','especes','ESP-002','valide',NULL),
(7,7,7,440000.00,'2024-04-01','virement','TRF-002','valide',NULL),
(8,8,8,180000.00,'2024-04-10','carte','CRD-002','valide',NULL),
(9,9,9,120000.00,'2024-05-01','mobile_money','MM-002','valide',NULL),
(10,11,10,135000.00,'2024-06-01','especes','ESP-003','valide',NULL),
(11,1,NULL,50000.00,'2024-06-15','carte','CRD-003','valide',NULL),
(12,5,NULL,80000.00,'2024-06-20','mobile_money','MM-003','valide',NULL);
/*!40000 ALTER TABLE `paiements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `presences`
--

DROP TABLE IF EXISTS `presences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `presences` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adherent_id` int(11) DEFAULT NULL,
  `cours_id` int(11) DEFAULT NULL,
  `date_seance` date DEFAULT NULL,
  `heure_arrivee` time DEFAULT NULL,
  `statut` enum('present','retard','absence') DEFAULT 'present',
  PRIMARY KEY (`id`),
  KEY `adherent_id` (`adherent_id`),
  KEY `cours_id` (`cours_id`),
  CONSTRAINT `presences_ibfk_1` FOREIGN KEY (`adherent_id`) REFERENCES `adherents` (`id`),
  CONSTRAINT `presences_ibfk_2` FOREIGN KEY (`cours_id`) REFERENCES `cours` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `presences`
--

LOCK TABLES `presences` WRITE;
/*!40000 ALTER TABLE `presences` DISABLE KEYS */;
INSERT INTO `presences` VALUES
(1,1,1,'2024-06-03','17:55:00','present'),
(2,2,3,'2024-06-04','16:50:00','present'),
(3,3,5,'2024-06-03','19:55:00','present'),
(4,4,9,'2024-06-03','05:55:00','present'),
(5,5,7,'2024-06-04','19:10:00','retard'),
(6,6,12,'2024-06-03','07:55:00','present'),
(7,7,14,'2024-06-04','18:25:00','present'),
(8,8,15,'2024-06-05','20:10:00','retard'),
(9,1,2,'2024-06-05','19:35:00','present'),
(10,2,4,'2024-06-06','19:05:00','present');
/*!40000 ALTER TABLE `presences` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-22 16:40:08
