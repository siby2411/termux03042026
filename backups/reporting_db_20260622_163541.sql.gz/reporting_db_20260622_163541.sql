/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: reporting_db
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ECRITURES_COMPTABLES`
--

DROP TABLE IF EXISTS `ECRITURES_COMPTABLES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ECRITURES_COMPTABLES` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_ecriture` date NOT NULL,
  `libelle` varchar(255) DEFAULT NULL,
  `compte_debite_id` int(11) DEFAULT NULL,
  `compte_credite_id` int(11) DEFAULT NULL,
  `montant` decimal(15,2) NOT NULL,
  `reference_piece` varchar(50) DEFAULT NULL,
  `pointe` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ECRITURES_COMPTABLES`
--

LOCK TABLES `ECRITURES_COMPTABLES` WRITE;
/*!40000 ALTER TABLE `ECRITURES_COMPTABLES` DISABLE KEYS */;
INSERT INTO `ECRITURES_COMPTABLES` VALUES
(1,'2026-03-05','Vente test',2100,701,1500000.00,NULL,0),
(2,'2026-03-05','Achat fournitures',601,2210,500000.00,NULL,0),
(3,'2026-03-05','Ventes de la semaine',2210,701,2500000.00,NULL,0),
(4,'2026-03-05','Paiement loyer',622,2210,300000.00,NULL,0),
(5,'2026-03-05','Constitution Capital',521,101,10000000.00,NULL,0),
(6,'2026-03-05','Achat Camionnette',244,521,3000000.00,NULL,0),
(7,'2026-03-05','FACTURE CLIENT OMEGA 2026',521,701,4000000.00,'FAC-001',0),
(8,'2026-03-05','ACHAT FOURNITURES EXPLOITATION',601,521,800000.00,'CHG-001',0);
/*!40000 ALTER TABLE `ECRITURES_COMPTABLES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FLUX_TRESORERIE`
--

DROP TABLE IF EXISTS `FLUX_TRESORERIE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `FLUX_TRESORERIE` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `periode` varchar(20) NOT NULL,
  `flux_activite_exploit` decimal(15,2) DEFAULT 0.00,
  `flux_activite_invest` decimal(15,2) DEFAULT 0.00,
  `flux_activite_finance` decimal(15,2) DEFAULT 0.00,
  `variation_tresorerie` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`),
  UNIQUE KEY `periode` (`periode`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FLUX_TRESORERIE`
--

LOCK TABLES `FLUX_TRESORERIE` WRITE;
/*!40000 ALTER TABLE `FLUX_TRESORERIE` DISABLE KEYS */;
INSERT INTO `FLUX_TRESORERIE` VALUES
(1,'2026-03',0.00,-3000000.00,10000000.00,7000000.00);
/*!40000 ALTER TABLE `FLUX_TRESORERIE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PLAN_COMPTABLE_UEMOA`
--

DROP TABLE IF EXISTS `PLAN_COMPTABLE_UEMOA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `PLAN_COMPTABLE_UEMOA` (
  `compte_id` int(11) NOT NULL,
  `intitule_compte` varchar(255) DEFAULT NULL,
  `classe` int(11) DEFAULT NULL,
  `nature_resultat` varchar(10) DEFAULT 'EXP',
  PRIMARY KEY (`compte_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PLAN_COMPTABLE_UEMOA`
--

LOCK TABLES `PLAN_COMPTABLE_UEMOA` WRITE;
/*!40000 ALTER TABLE `PLAN_COMPTABLE_UEMOA` DISABLE KEYS */;
INSERT INTO `PLAN_COMPTABLE_UEMOA` VALUES
(10,'CAPITAL',1,'EXP'),
(11,'RESERVES',1,'EXP'),
(12,'REPORT A NOUVEAU',1,'EXP'),
(13,'RESULTAT NET DE L EXERCICE',1,'EXP'),
(14,'SUBVENTIONS D INVESTISSEMENT',1,'EXP'),
(16,'EMPRUNTS ET DETTES ASSIMILEES',1,'EXP'),
(21,'IMMOBILISATIONS INCORPORELLES',2,'EXP'),
(22,'TERRAINS',2,'EXP'),
(23,'BATIMENTS, INSTALLATIONS TECHNIQUES',2,'EXP'),
(24,'MATERIEL, MOBILIER ET ACTIFS BIOLOGIQUES',2,'EXP'),
(27,'IMMOBILISATIONS FINANCIERES',2,'EXP'),
(31,'MARCHANDISES',3,'EXP'),
(32,'MATIERES PREMIERES ET FOURNITURES',3,'EXP'),
(33,'AUTRES APPROVISIONNEMENTS',3,'EXP'),
(35,'PRODUITS FINIS',3,'EXP'),
(40,'FOURNISSEURS ET COMPTES RATTACHES',4,'EXP'),
(41,'CLIENTS ET COMPTES RATTACHES',4,'EXP'),
(42,'PERSONNEL',4,'EXP'),
(43,'ORGANISMES SOCIAUX',4,'EXP'),
(44,'ETAT ET COLLECTIVITES PUBLIQUES',4,'EXP'),
(52,'BANQUES',5,'EXP'),
(57,'CAISSE',5,'EXP'),
(60,'ACHATS ET VARIATIONS DE STOCKS',6,'EXP'),
(61,'TRANSPORTS',6,'EXP'),
(62,'SERVICES EXTERIEURS',6,'EXP'),
(63,'AUTRES SERVICES EXTERIEURS',6,'EXP'),
(64,'IMPOTS ET TAXES',6,'EXP'),
(66,'CHARGES DE PERSONNEL',6,'EXP'),
(67,'FRAIS FINANCIERS',6,'FIN'),
(70,'VENTES',7,'EXP'),
(75,'AUTRES PRODUITS',7,'EXP'),
(77,'REVENUS FINANCIERS',7,'FIN'),
(81,'VALEURS COMPTABLES DES CESSIONS',8,'HAO'),
(82,'PRODUITS DES CESSIONS',8,'HAO'),
(101,'Capital social',1,'EXP'),
(241,'Matériel industriel',2,'EXP'),
(244,'Matériel roulant',2,'EXP'),
(245,'Matériel de bureau',2,'EXP'),
(521,'Banques locales',5,'EXP'),
(571,'Caisse siège',5,'EXP'),
(601,'Achats de marchandises',6,'EXP'),
(622,'Locations',6,'EXP'),
(701,'Ventes de marchandises',7,'EXP'),
(706,'Services produits',7,'EXP'),
(707,'Produits accessoires',7,'EXP');
/*!40000 ALTER TABLE `PLAN_COMPTABLE_UEMOA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SYNTHESES_BALANCE`
--

DROP TABLE IF EXISTS `SYNTHESES_BALANCE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `SYNTHESES_BALANCE` (
  `compte_id` int(11) NOT NULL,
  `mouvement_debit` decimal(15,2) DEFAULT 0.00,
  `mouvement_credit` decimal(15,2) DEFAULT 0.00,
  `solde_debiteur` decimal(15,2) DEFAULT 0.00,
  `solde_crediteur` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`compte_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SYNTHESES_BALANCE`
--

LOCK TABLES `SYNTHESES_BALANCE` WRITE;
/*!40000 ALTER TABLE `SYNTHESES_BALANCE` DISABLE KEYS */;
INSERT INTO `SYNTHESES_BALANCE` VALUES
(601,500000.00,0.00,500000.00,0.00),
(622,300000.00,0.00,300000.00,0.00),
(701,0.00,4000000.00,0.00,4000000.00),
(2100,1500000.00,0.00,1500000.00,0.00),
(2210,2500000.00,800000.00,1700000.00,0.00);
/*!40000 ALTER TABLE `SYNTHESES_BALANCE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `immobilisations`
--

DROP TABLE IF EXISTS `immobilisations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `immobilisations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code_immo` varchar(50) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `date_acquisition` date NOT NULL,
  `valeur_origine` decimal(15,2) NOT NULL,
  `duree_vie` int(11) NOT NULL,
  `amortissement_cumule` decimal(15,2) DEFAULT 0.00,
  `vnc` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `immobilisations`
--

LOCK TABLES `immobilisations` WRITE;
/*!40000 ALTER TABLE `immobilisations` DISABLE KEYS */;
/*!40000 ALTER TABLE `immobilisations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `releves_bancaires`
--

DROP TABLE IF EXISTS `releves_bancaires`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `releves_bancaires` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_operation` date DEFAULT NULL,
  `libelle` varchar(255) DEFAULT NULL,
  `debit` decimal(15,2) DEFAULT 0.00,
  `credit` decimal(15,2) DEFAULT 0.00,
  `pointe` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `releves_bancaires`
--

LOCK TABLES `releves_bancaires` WRITE;
/*!40000 ALTER TABLE `releves_bancaires` DISABLE KEYS */;
INSERT INTO `releves_bancaires` VALUES
(1,'2026-03-05','VIREMENT CLIENT OMEGA',0.00,450000.00,0),
(2,'2026-03-05','VIREMENT CLIENT OMEGA',0.00,1000000.00,0);
/*!40000 ALTER TABLE `releves_bancaires` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sig_results`
--

DROP TABLE IF EXISTS `sig_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sig_results` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `exercice` int(11) DEFAULT NULL,
  `ca` decimal(15,2) DEFAULT NULL,
  `charges` decimal(15,2) DEFAULT NULL,
  `marge_brute` decimal(15,2) DEFAULT NULL,
  `ebe` decimal(15,2) DEFAULT NULL,
  `resultat_net` decimal(15,2) DEFAULT NULL,
  `date_calc` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sig_results`
--

LOCK TABLES `sig_results` WRITE;
/*!40000 ALTER TABLE `sig_results` DISABLE KEYS */;
/*!40000 ALTER TABLE `sig_results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `utilisateurs`
--

DROP TABLE IF EXISTS `utilisateurs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `utilisateurs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` varchar(20) DEFAULT 'admin',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `utilisateurs`
--

LOCK TABLES `utilisateurs` WRITE;
/*!40000 ALTER TABLE `utilisateurs` DISABLE KEYS */;
INSERT INTO `utilisateurs` VALUES
(3,NULL,'admin','123','admin');
/*!40000 ALTER TABLE `utilisateurs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-22 16:36:06
