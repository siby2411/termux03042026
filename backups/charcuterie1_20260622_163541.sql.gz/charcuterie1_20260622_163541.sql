/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: charcuterie1
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `approvisionnements`
--

DROP TABLE IF EXISTS `approvisionnements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `approvisionnements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fournisseur_id` int(11) DEFAULT NULL,
  `produit_id` int(11) NOT NULL,
  `quantite` decimal(10,3) NOT NULL,
  `prix_unitaire` decimal(10,2) NOT NULL,
  `total` decimal(12,2) NOT NULL,
  `date_appro` date NOT NULL,
  `reference` varchar(50) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fournisseur_id` (`fournisseur_id`),
  KEY `produit_id` (`produit_id`),
  CONSTRAINT `approvisionnements_ibfk_1` FOREIGN KEY (`fournisseur_id`) REFERENCES `fournisseurs` (`id`) ON DELETE SET NULL,
  CONSTRAINT `approvisionnements_ibfk_2` FOREIGN KEY (`produit_id`) REFERENCES `produits` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `approvisionnements`
--

LOCK TABLES `approvisionnements` WRITE;
/*!40000 ALTER TABLE `approvisionnements` DISABLE KEYS */;
INSERT INTO `approvisionnements` VALUES
(1,1,21,50.000,2100.00,105000.00,'2026-01-10','BL-2024-001',NULL),
(2,1,55,30.000,2800.00,84000.00,'2026-01-12','BL-2024-002',NULL),
(3,2,23,25.000,3300.00,82500.00,'2026-01-13','BL-2024-003',NULL),
(4,2,27,40.000,2800.00,112000.00,'2026-01-15','BL-2024-004',NULL),
(5,3,1,20.000,2100.00,42000.00,'2026-01-17','BL-2024-005',NULL),
(6,3,2,15.000,2600.00,39000.00,'2026-01-17','BL-2024-006',NULL),
(7,3,11,30.000,2900.00,87000.00,'2026-01-18','BL-2024-007',NULL),
(8,6,5,8.000,7500.00,60000.00,'2026-01-20','BL-2024-008',NULL),
(9,4,41,12.000,1900.00,22800.00,'2026-01-21','BL-2024-009',NULL),
(10,4,43,8.000,2100.00,16800.00,'2026-01-23','BL-2024-010',NULL),
(11,1,21,60.000,2100.00,126000.00,'2026-02-06','BL-2024-011',NULL),
(12,1,56,20.000,2800.00,56000.00,'2026-02-08','BL-2024-012',NULL),
(13,2,22,40.000,2600.00,104000.00,'2026-02-09','BL-2024-013',NULL),
(14,2,28,50.000,1700.00,85000.00,'2026-02-11','BL-2024-014',NULL),
(15,3,12,35.000,2300.00,80500.00,'2026-02-12','BL-2024-015',NULL),
(16,3,13,20.000,1900.00,38000.00,'2026-02-14','BL-2024-016',NULL),
(17,5,59,30.000,500.00,15000.00,'2026-02-16','BL-2024-017',NULL),
(18,5,60,25.000,650.00,16250.00,'2026-02-17','BL-2024-018',NULL),
(19,6,7,10.000,4000.00,40000.00,'2026-02-19','BL-2024-019',NULL),
(20,7,52,60.000,450.00,27000.00,'2026-02-21','BL-2024-020',NULL),
(21,1,21,40.000,2100.00,84000.00,'2026-03-04','BL-2024-021',NULL),
(22,2,25,20.000,2300.00,46000.00,'2026-03-06','BL-2024-022',NULL),
(23,3,11,25.000,2900.00,72500.00,'2026-03-07','BL-2024-023',NULL),
(24,4,42,30.000,1500.00,45000.00,'2026-03-08','BL-2024-024',NULL),
(25,6,1,15.000,2100.00,31500.00,'2026-03-09','BL-2024-025',NULL),
(26,6,2,12.000,2600.00,31200.00,'2026-03-10','BL-2024-026',NULL),
(27,7,49,40.000,700.00,28000.00,'2026-03-11','BL-2024-027',NULL),
(28,5,61,100.000,900.00,90000.00,'2026-03-12','BL-2024-028',NULL),
(29,8,64,50.000,900.00,45000.00,'2026-03-13','BL-2024-029',NULL),
(30,8,63,80.000,2100.00,168000.00,'2026-03-14','BL-2024-030',NULL),
(31,2,53,5.000,2800.00,14000.00,'2026-03-31','','De'),
(32,7,62,2.000,900.00,1800.00,'2026-03-31','','Fs'),
(33,6,62,45.000,900.00,40500.00,'2026-04-01','',''),
(34,8,33,6.000,6000.00,36000.00,'2026-04-01','',''),
(35,6,24,100.000,1700.00,170000.00,'2026-04-01','',''),
(36,2,18,15.000,4800.00,72000.00,'2026-04-01','',''),
(37,6,33,2.000,580.00,1160.00,'2026-04-01','',''),
(38,6,53,2.000,500.00,1000.00,'2026-04-01','','');
/*!40000 ALTER TABLE `approvisionnements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorie_prefixes`
--

DROP TABLE IF EXISTS `categorie_prefixes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorie_prefixes` (
  `categorie_id` int(11) NOT NULL,
  `prefixe` varchar(6) NOT NULL,
  PRIMARY KEY (`categorie_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorie_prefixes`
--

LOCK TABLES `categorie_prefixes` WRITE;
/*!40000 ALTER TABLE `categorie_prefixes` DISABLE KEYS */;
INSERT INTO `categorie_prefixes` VALUES
(1,'CHSEC'),
(2,'CHCUI'),
(3,'VOLFE'),
(4,'VOLTR'),
(5,'FRFRA'),
(6,'FRAFF'),
(7,'OEULA'),
(8,'VIARO'),
(9,'CHEXO'),
(10,'POIFM'),
(11,'CONSR'),
(12,'EPICF'),
(13,'EMBAL'),
(14,'BOISS'),
(15,'BIOHA');
/*!40000 ALTER TABLE `categorie_prefixes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `icone` varchar(10) DEFAULT NULL,
  `couleur` varchar(20) DEFAULT '#e74c3c',
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES
(1,'Charcuterie Sèche','????','#c0392b','Jambon sec, saucisson, salami, chorizo, coppa, bresaola...'),
(2,'Charcuterie Cuite','????','#e67e22','Jambon cuit, mortadelle, pâtés, rillettes, boudin blanc...'),
(3,'Volailles Fraîches','????','#f39c12','Poulet, dinde, pintade, canard, caille, oie, pigeon...'),
(4,'Volailles Transformées','????','#e8a020','Escalopes, cuisses confites, magrets, foie gras...'),
(5,'Fromages Frais','????','#d4ac0d','Mozzarella, ricotta, fromage frais, chèvre frais...'),
(6,'Fromages Affinés','????','#b7950b','Emmental, camembert, brie, roquefort, comté, gruyère...'),
(7,'Oeufs & Laitiers','????','#f1c40f','Oeufs de poule, caille, canard, lait, crème, beurre...'),
(8,'Viandes Rouges','????','#922b21','Boeuf, mouton, agneau, chèvre, veau...'),
(9,'Charcuterie Exotique','????','#8e44ad','Merguez, chipolata, andouille, boudin antillais...'),
(10,'Poissons Fumés','????','#1a5276','Saumon fumé, hareng, maquereau, sardines, thon...'),
(11,'Conserves & Terrines','????','#27ae60','Pâté en croûte, terrine de canard, rillettes, confits...'),
(12,'Épicerie Fine','✨','#2ecc71','Condiments, moutardes, cornichons, câpres, sauces...'),
(13,'Emballages & Matériel','????','#7f8c8d','Sacs sous-vide, barquettes, film alimentaire, étiquettes...'),
(14,'Boissons','????','#2980b9','Jus naturels, sodas artisanaux, eaux minérales...'),
(15,'Produits Bio & Halal','????','#16a085','Gamme certifiée bio, halal et label rouge...');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `adresse` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` VALUES
(1,'Dupont','Jean-Pierre','77 123 45 67','jp.dupont@gmail.com','12 Rue des Fleurs, Plateau, Dakar','2026-03-16 10:56:31'),
(2,'Mbaye','Aminata','78 456 78 90','aminata.mbaye@gmail.com','45 Av Cheikh Anta Diop, Dakar','2026-03-16 10:56:31'),
(3,'Restaurant Le Gourmet',NULL,'33 821 00 00','contact@legourmet.sn','Place Indépendance, Dakar','2026-03-16 10:56:31'),
(4,'Hôtel Teranga',NULL,'33 889 22 00','commandes@teranga.sn','Route Corniche Ouest, Dakar','2026-03-16 10:56:31'),
(5,'Fall','Ousmane','76 234 56 78','ousmane.fall@email.com','Parcelles Assainies U17, Dakar','2026-03-16 10:56:31'),
(6,'Ndiaye','Marème','77 890 12 34','mareme.ndiaye@gmail.com','Point E, Dakar','2026-03-16 10:56:31'),
(7,'Traiteur Festif',NULL,'33 867 45 00','contact@festif.sn','Almadies, Dakar','2026-03-16 10:56:31'),
(8,'Sow','Ibrahim','78 345 67 89','ibrahim.sow@email.com','HLM Grand Yoff, Dakar','2026-03-16 10:56:31'),
(9,'Supermarché Exclusif',NULL,'33 842 11 00','achats@exclusif.sn','Zone Industrielle, Dakar','2026-03-16 10:56:31'),
(10,'Konaté','Aïssatou','76 567 89 01','aissatou.konate@gmail.com','Fann Résidence, Dakar','2026-03-16 10:56:31'),
(11,'Diallo','Boubacar','77 234 56 78','b.diallo@gmail.com','Liberté 6, Dakar','2026-03-16 10:56:31'),
(12,'Brasserie du Sénégal',NULL,'33 823 55 66','cuisine@brasserie.sn','Plateau, Dakar','2026-03-16 10:56:31'),
(13,'Touré','Rokhaya','78 901 23 45','rokhaya.toure@gmail.com','Sacré Coeur 3, Dakar','2026-03-16 10:56:31'),
(14,'Banque Atlantique',NULL,'33 856 78 00','cafeteria@atlantique.sn','Avenue Bourguiba, Dakar','2026-03-16 10:56:31'),
(15,'Sy','Moussa','76 678 90 12','moussa.sy@email.com','Yoff Virage, Dakar','2026-03-16 10:56:31'),
(16,'Club Med Dakar',NULL,'33 899 00 11','cuisine@clubmed-dakar.sn','Almadies, Dakar','2026-03-16 10:56:31'),
(17,'Diop','Ndèye','77 345 67 89','ndeye.diop@gmail.com','Grand Dakar, Dakar','2026-03-16 10:56:31'),
(18,'Collectivité Scolaire',NULL,'33 878 33 00','intendance@ecole-dakar.sn','Mermoz, Dakar','2026-03-16 10:56:31'),
(19,'Ba','Thierno','78 012 34 56','thierno.ba@gmail.com','Ouakam, Dakar','2026-03-16 10:56:31'),
(20,'Cissé','Fatoumata','76 789 01 23','fata.cisse@gmail.com','Pikine Ouest, Dakar','2026-03-16 10:56:31');
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `depenses`
--

DROP TABLE IF EXISTS `depenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `depenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(200) NOT NULL,
  `montant` decimal(12,2) NOT NULL,
  `categorie` enum('salaire','loyer','electricite','eau','transport','emballage','maintenance','publicite','divers') DEFAULT 'divers',
  `date_depense` date NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `depenses`
--

LOCK TABLES `depenses` WRITE;
/*!40000 ALTER TABLE `depenses` DISABLE KEYS */;
INSERT INTO `depenses` VALUES
(1,'Loyer local commercial',300000.00,'loyer','2026-01-10','Loyer mensuel boutique Plateau','2026-03-16 10:56:31'),
(2,'Salaire M. Mamadou Diallo',220000.00,'salaire','2026-01-15','Gestionnaire de stock','2026-03-16 10:56:31'),
(3,'Salaire Mme Fatou Sène',180000.00,'salaire','2026-01-15','Caissière','2026-03-16 10:56:31'),
(4,'Facture SENELEC',55000.00,'electricite','2026-01-17','Électricité + chambre froide','2026-03-16 10:56:31'),
(5,'Facture SDE eau',14000.00,'eau','2026-01-18','Eau mensuelle','2026-03-16 10:56:31'),
(6,'Carburant livraisons',42000.00,'transport','2026-01-23','Livraisons clients professionnels','2026-03-16 10:56:31'),
(7,'Achat sacs sous-vide',35000.00,'emballage','2026-01-25','Sacs PA/PE 500 pièces','2026-03-16 10:56:31'),
(8,'Loyer local commercial',300000.00,'loyer','2026-02-09','Loyer mensuel boutique Plateau','2026-03-16 10:56:31'),
(9,'Salaire M. Mamadou Diallo',220000.00,'salaire','2026-02-14','Gestionnaire de stock','2026-03-16 10:56:31'),
(10,'Salaire Mme Fatou Sène',180000.00,'salaire','2026-02-14','Caissière','2026-03-16 10:56:31'),
(11,'Facture SENELEC',62000.00,'electricite','2026-02-16','Surconsommation chambre froide','2026-03-16 10:56:31'),
(12,'Facture SDE eau',14000.00,'eau','2026-02-17','Eau mensuelle','2026-03-16 10:56:31'),
(13,'Publicité Facebook/Instagram',25000.00,'publicite','2026-02-19','Campagne promo Tabaski','2026-03-16 10:56:31'),
(14,'Réparation chambre froide',85000.00,'maintenance','2026-02-22','Remplacement compresseur','2026-03-16 10:56:31'),
(15,'Carburant livraisons',38000.00,'transport','2026-02-24','Livraisons hôtels et restaurants','2026-03-16 10:56:31'),
(16,'Barquettes alimentaires',22000.00,'emballage','2026-02-26','Barquettes trays 200 pièces','2026-03-16 10:56:31'),
(17,'Fournitures bureau',12000.00,'divers','2026-03-01','Papier, stylos, registres','2026-03-16 10:56:31'),
(18,'Loyer local commercial',300000.00,'loyer','2026-03-11','Loyer mensuel boutique Plateau','2026-03-16 10:56:31'),
(19,'Salaire M. Mamadou Diallo',220000.00,'salaire','2026-03-14','Gestionnaire de stock','2026-03-16 10:56:31'),
(20,'Salaire Mme Fatou Sène',180000.00,'salaire','2026-03-14','Caissière','2026-03-16 10:56:31'),
(21,'Facture SENELEC',58000.00,'electricite','2026-03-13','Électricité mensuelle','2026-03-16 10:56:31'),
(22,'Facture SDE eau',14000.00,'eau','2026-03-13','Eau mensuelle','2026-03-16 10:56:31'),
(23,'Carburant livraisons',35000.00,'transport','2026-03-12','Livraisons semaine','2026-03-16 10:56:31'),
(24,'Publicité Google Ads',18000.00,'publicite','2026-03-10','Campagne référencement local','2026-03-16 10:56:31'),
(25,'Nettoyage et hygiène',15000.00,'divers','2026-03-09','Produits désinfectants HACCP','2026-03-16 10:56:31');
/*!40000 ALTER TABLE `depenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dlc_produits`
--

DROP TABLE IF EXISTS `dlc_produits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `dlc_produits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `produit_id` int(11) NOT NULL,
  `lot` varchar(50) DEFAULT NULL,
  `quantite` decimal(10,3) NOT NULL,
  `date_fabrication` date DEFAULT NULL,
  `date_dlc` date NOT NULL,
  `temperature_stockage` varchar(30) DEFAULT '0-4C',
  `statut` enum('ok','alerte','expire','retire') DEFAULT 'ok',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dlc_produits`
--

LOCK TABLES `dlc_produits` WRITE;
/*!40000 ALTER TABLE `dlc_produits` DISABLE KEYS */;
/*!40000 ALTER TABLE `dlc_produits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `facture_lignes`
--

DROP TABLE IF EXISTS `facture_lignes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `facture_lignes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `facture_id` int(11) NOT NULL,
  `produit_id` int(11) DEFAULT NULL,
  `designation` varchar(200) NOT NULL,
  `quantite` decimal(10,3) NOT NULL,
  `unite` varchar(20) DEFAULT 'kg',
  `prix_unitaire` decimal(10,2) NOT NULL,
  `total_ligne` decimal(12,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `facture_id` (`facture_id`),
  KEY `produit_id` (`produit_id`),
  CONSTRAINT `facture_lignes_ibfk_1` FOREIGN KEY (`facture_id`) REFERENCES `factures` (`id`) ON DELETE CASCADE,
  CONSTRAINT `facture_lignes_ibfk_2` FOREIGN KEY (`produit_id`) REFERENCES `produits` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `facture_lignes`
--

LOCK TABLES `facture_lignes` WRITE;
/*!40000 ALTER TABLE `facture_lignes` DISABLE KEYS */;
INSERT INTO `facture_lignes` VALUES
(1,1,11,'Jambon Cuit Supérieur',10.000,'kg',4800.00,48000.00),
(2,1,1,'Saucisson Sec Artisanal',8.000,'kg',3500.00,28000.00),
(3,1,21,'Poulet Fermier Entier',30.000,'kg',3500.00,105000.00),
(4,1,42,'Camembert Normand AOP',20.000,'pièce',2500.00,50000.00),
(5,1,55,'Boeuf Haché 15% MG',15.000,'kg',4500.00,67500.00),
(6,1,13,'Mortadelle Pistaches',8.000,'kg',3200.00,25600.00),
(7,1,49,'Oeufs Fermiers x12',20.000,'boite',2000.00,40000.00),
(8,1,16,'Rillettes du Mans',10.000,'pot',2500.00,25000.00),
(9,1,2,'Chorizo Doux Espagnol',6.000,'kg',4200.00,25200.00),
(10,1,51,'Crème Fraîche Épaisse 500g',10.000,'pot',1200.00,12000.00),
(11,1,14,'Pâté de Campagne Maison',8.000,'kg',2800.00,22400.00),
(12,1,29,'Canard Entier',4.000,'pièce',5500.00,22000.00),
(13,1,43,'Comté 18 mois AOP',3.000,'kg',5800.00,17400.00),
(14,2,5,'Jambon Sec 24 mois',5.000,'kg',12000.00,60000.00),
(15,2,31,'Magret de Canard Frais',15.000,'pièce',4800.00,72000.00),
(16,2,33,'Foie Gras Entier Mi-Cuit',8.000,'bocal',15000.00,120000.00),
(17,2,11,'Jambon Cuit Supérieur',20.000,'kg',4800.00,96000.00),
(18,2,41,'Emmental Français AOP',10.000,'kg',3200.00,32000.00),
(19,2,35,'Mozzarella di Bufala',15.000,'pièce',3500.00,52500.00),
(20,2,36,'Burrata Crémeuse',10.000,'pièce',4800.00,48000.00),
(21,2,21,'Poulet Fermier Entier',25.000,'kg',3500.00,87500.00),
(22,2,30,'Cuisses de Canard Confites',12.000,'sachet',5500.00,66000.00),
(23,2,49,'Oeufs Fermiers x12',25.000,'boite',2000.00,50000.00),
(24,2,4,'Salami Milano Tranché',5.000,'kg',5500.00,27500.00),
(25,2,14,'Pâté de Campagne Maison',10.000,'kg',2800.00,28000.00),
(26,3,27,'Pintade Fermière',15.000,'pièce',4500.00,67500.00),
(27,3,28,'Cailles Prêtes à Cuire',40.000,'pièce',1800.00,72000.00),
(28,3,1,'Saucisson Sec Artisanal',10.000,'kg',3500.00,35000.00),
(29,3,2,'Chorizo Doux Espagnol',8.000,'kg',4200.00,33600.00),
(30,3,5,'Jambon Sec 24 mois',4.000,'kg',12000.00,48000.00),
(31,3,42,'Camembert Normand AOP',15.000,'pièce',2500.00,37500.00),
(32,3,43,'Comté 18 mois AOP',4.000,'kg',5800.00,23200.00),
(33,3,49,'Oeufs Fermiers x12',15.000,'boite',2000.00,30000.00),
(34,3,14,'Pâté de Campagne Maison',6.000,'kg',2800.00,16800.00),
(35,3,16,'Rillettes du Mans',6.000,'pot',2500.00,15000.00),
(36,3,52,'Beurre Doux Fermier 250g',4.000,'plaquette',1000.00,4000.00),
(37,4,11,'Jambon Cuit Supérieur',30.000,'kg',4800.00,144000.00),
(38,4,12,'Jambon de Paris',25.000,'kg',3800.00,95000.00),
(39,4,1,'Saucisson Sec Artisanal',20.000,'kg',3500.00,70000.00),
(40,4,2,'Chorizo Doux Espagnol',15.000,'kg',4200.00,63000.00),
(41,4,13,'Mortadelle Pistaches',18.000,'kg',3200.00,57600.00),
(42,4,41,'Emmental Français AOP',15.000,'kg',3200.00,48000.00),
(43,4,42,'Camembert Normand AOP',30.000,'pièce',2500.00,75000.00),
(44,4,49,'Oeufs Fermiers x12',50.000,'boite',2000.00,100000.00),
(45,4,50,'Oeufs de Caille x24',30.000,'boite',1500.00,45000.00),
(46,4,52,'Beurre Doux Fermier 250g',50.000,'plaquette',1000.00,50000.00),
(47,4,55,'Boeuf Haché 15% MG',20.000,'kg',4500.00,90000.00),
(48,4,58,'Merguez Boeuf-Agneau',15.000,'kg',3800.00,57000.00),
(49,4,59,'Moutarde de Dijon Forte',20.000,'bocal',900.00,18000.00),
(50,4,60,'Cornichons Extra-Fins',15.000,'bocal',1100.00,16500.00),
(51,5,33,'Foie Gras Entier Mi-Cuit',10.000,'bocal',15000.00,150000.00),
(52,5,5,'Jambon Sec 24 mois',8.000,'kg',12000.00,96000.00),
(53,5,4,'Salami Milano Tranché',10.000,'kg',5500.00,55000.00),
(54,5,7,'Coppa Artisanale',6.000,'kg',6500.00,39000.00),
(55,5,44,'Roquefort AOP',4.000,'kg',6500.00,26000.00),
(56,5,45,'Comté 18 mois AOP',5.000,'kg',5800.00,29000.00),
(57,5,35,'Mozzarella di Bufala',20.000,'pièce',3500.00,70000.00),
(58,5,36,'Burrata Crémeuse',12.000,'pièce',4800.00,57600.00),
(59,5,31,'Magret de Canard Frais',20.000,'pièce',4800.00,96000.00),
(60,5,62,'Huile d Olive Extra Vierge',10.000,'bouteille',3500.00,35000.00),
(61,5,30,'Cuisses de Canard Confites',8.000,'sachet',5500.00,44000.00),
(62,5,15,'Pâté de Foie Fine Herbes',6.000,'kg',2500.00,15000.00),
(63,5,34,'Rillettes Foie Gras',6.000,'pot',6500.00,39000.00),
(64,6,18,'Boudin Blanc Truffé',2.000,'kg',7500.00,15000.00),
(65,7,33,'Bloc de Foie Gras',1.000,'boite',9500.00,9500.00),
(66,7,20,'Fromage de Tête',1.000,'kg',2800.00,2800.00),
(67,8,62,'Barquettes Alimentaires x50',1.500,'pack',1500.00,2250.00),
(68,8,51,'Beurre Demi-Sel 250g',2.000,'plaquette',1100.00,2200.00),
(69,8,58,'Moutarde de Dijon Forte',2.000,'bocal',900.00,1800.00),
(70,8,1,'Saucisson Sec Artisanal',1.000,'kg',3500.00,3500.00),
(71,9,13,'Mortadelle Pistaches',1.000,'kg',3200.00,3200.00),
(72,9,48,'Oeufs de Caille x24',1.000,'boite',1500.00,1500.00),
(73,10,39,'Feta AOP Grecque',1.000,'bloc',2800.00,2800.00),
(74,11,46,'Fromage Fondu Portions x8',1.000,'boite',1800.00,1800.00),
(75,11,32,'Foie Gras Entier Mi-Cuit',1.000,'bocal',15000.00,15000.00),
(76,12,20,'Fromage de Tête',1.000,'kg',2800.00,2800.00),
(77,13,40,'Emmental Français AOP',1.000,'kg',3200.00,3200.00),
(78,14,17,'Rillettes de Canard',1.000,'pot',3200.00,3200.00),
(79,14,43,'Roquefort AOP',1.000,'kg',6500.00,6500.00),
(80,15,46,'Fromage Fondu Portions x8',1.000,'boite',1800.00,1800.00),
(81,16,64,'Film Étirable Alimentaire 50m',1.000,'rouleau',900.00,900.00),
(82,17,64,'Film Étirable Alimentaire 50m',1.000,'rouleau',900.00,900.00),
(83,18,65,'Étiquettes Prix Thermiques',1.000,'rouleau',800.00,800.00);
/*!40000 ALTER TABLE `facture_lignes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `factures`
--

DROP TABLE IF EXISTS `factures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `factures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) DEFAULT NULL,
  `numero` varchar(30) NOT NULL,
  `date_facture` date NOT NULL,
  `total_ht` decimal(12,2) DEFAULT 0.00,
  `tva` decimal(5,2) DEFAULT 18.00,
  `total_ttc` decimal(12,2) DEFAULT 0.00,
  `statut` enum('brouillon','emise','payee','annulee') DEFAULT 'emise',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `numero` (`numero`),
  KEY `client_id` (`client_id`),
  CONSTRAINT `factures_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `factures`
--

LOCK TABLES `factures` WRITE;
/*!40000 ALTER TABLE `factures` DISABLE KEYS */;
INSERT INTO `factures` VALUES
(1,3,'FAC-2024-0001','2026-01-20',488100.00,18.00,575958.00,'payee','Commande hebdomadaire restauration','2026-03-16 10:56:31'),
(2,4,'FAC-2024-0002','2026-01-27',739500.00,18.00,872610.00,'payee','Approvisionnement buffet mensuel','2026-03-16 10:56:31'),
(3,7,'FAC-2024-0003','2026-02-09',382600.00,18.00,451468.00,'payee','Événement mariage 200 personnes','2026-03-16 10:56:31'),
(4,9,'FAC-2024-0004','2026-02-24',929100.00,18.00,1096338.00,'emise','Commande mensuelle rayon charcuterie','2026-03-16 10:56:31'),
(5,16,'FAC-2024-0005','2026-03-08',751600.00,18.00,886888.00,'emise','Buffet international semaine','2026-03-16 10:56:31'),
(6,16,'FAC-20260316-687C','2026-03-16',15000.00,18.00,17700.00,'emise','','2026-03-16 20:03:25'),
(7,NULL,'POS-20260331-100745','2026-03-31',12300.00,18.00,14514.00,'payee','POS – Paiement: especes','2026-03-31 10:07:45'),
(8,NULL,'POS-20260331-101102','2026-03-31',9750.00,18.00,11505.00,'payee','POS – Paiement: especes','2026-03-31 10:11:02'),
(9,NULL,'POS-20260331-101236','2026-03-31',4700.00,18.00,5546.00,'payee','POS – Paiement: especes','2026-03-31 10:12:36'),
(10,NULL,'POS-20260331-101247','2026-03-31',2800.00,18.00,3304.00,'payee','POS – Paiement: especes','2026-03-31 10:12:47'),
(11,NULL,'POS-20260331-101326','2026-03-31',16800.00,18.00,19824.00,'payee','POS – Paiement: especes','2026-03-31 10:13:26'),
(12,NULL,'POS-20260331-101339','2026-03-31',2800.00,18.00,3304.00,'payee','POS – Paiement: especes','2026-03-31 10:13:39'),
(13,NULL,'POS-20260331-101408','2026-03-31',3200.00,18.00,3776.00,'payee','POS – Paiement: especes','2026-03-31 10:14:08'),
(14,NULL,'POS-20260331-101527','2026-03-31',9700.00,18.00,11446.00,'payee','POS – Paiement: especes','2026-03-31 10:15:27'),
(15,NULL,'POS-20260331-101547','2026-03-31',1800.00,18.00,2124.00,'payee','POS – Paiement: mobile_money','2026-03-31 10:15:47'),
(16,NULL,'POS-20260331-141846','2026-03-31',900.00,18.00,1062.00,'payee','POS – Paiement: especes','2026-03-31 14:18:46'),
(17,NULL,'POS-20260331-141936','2026-03-31',900.00,18.00,1062.00,'payee','POS – Paiement: especes','2026-03-31 14:19:36'),
(18,NULL,'POS-20260331-142030','2026-03-31',790.00,18.00,932.20,'payee','POS – Paiement: carte – Remise: 10 FCFA','2026-03-31 14:20:30');
/*!40000 ALTER TABLE `factures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fidelite_points`
--

DROP TABLE IF EXISTS `fidelite_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fidelite_points` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `points` int(11) DEFAULT 0,
  `total_achats` decimal(12,2) DEFAULT 0.00,
  `niveau` enum('Bronze','Argent','Or','Platine') DEFAULT 'Bronze',
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `client_id` (`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fidelite_points`
--

LOCK TABLES `fidelite_points` WRITE;
/*!40000 ALTER TABLE `fidelite_points` DISABLE KEYS */;
INSERT INTO `fidelite_points` VALUES
(1,1,43,43350.00,'Bronze','2026-03-16 12:31:00'),
(2,2,33,33900.00,'Bronze','2026-03-16 12:31:00'),
(3,3,519,519100.00,'Argent','2026-03-16 12:31:00'),
(4,4,745,745900.00,'Argent','2026-03-16 12:31:00'),
(5,5,39,39450.00,'Bronze','2026-03-16 12:31:00'),
(6,6,48,48950.00,'Bronze','2026-03-16 12:31:00'),
(7,7,397,397000.00,'Bronze','2026-03-16 12:31:00'),
(8,8,10,10800.00,'Bronze','2026-03-16 12:31:00'),
(9,9,929,929100.00,'Argent','2026-03-16 12:31:00'),
(10,10,26,26200.00,'Bronze','2026-03-16 12:31:00'),
(11,11,40,40150.00,'Bronze','2026-03-16 12:31:00'),
(12,12,18,18000.00,'Bronze','2026-03-16 12:31:00'),
(13,13,16,16500.00,'Bronze','2026-03-16 12:31:00'),
(14,16,751,751600.00,'Argent','2026-03-16 12:31:00');
/*!40000 ALTER TABLE `fidelite_points` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fournisseurs`
--

DROP TABLE IF EXISTS `fournisseurs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fournisseurs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(150) NOT NULL,
  `contact` varchar(100) DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `adresse` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fournisseurs`
--

LOCK TABLES `fournisseurs` WRITE;
/*!40000 ALTER TABLE `fournisseurs` DISABLE KEYS */;
INSERT INTO `fournisseurs` VALUES
(1,'Abattoir National du Sénégal','M. Amadou Diallo','33 832 00 00','contact@ans.sn','Zone Industrielle, Dakar','2026-03-16 10:56:31'),
(2,'Ferme Avicole du Sahel','Mme Coumba Sow','77 890 12 34','ferme.sahel@gmail.com','Thiès, Sénégal','2026-03-16 10:56:31'),
(3,'Importations Européennes SA','M. Bernard Martin','33 821 55 66','import@euroalim.sn','Port de Dakar','2026-03-16 10:56:31'),
(4,'Fromagerie Artisanale Dakar','M. Lamine Touré','78 567 89 01','fromagerie@artisan.sn','Plateau, Dakar','2026-03-16 10:56:31'),
(5,'Grossiste Épicerie Fine','Mme Djenaba Konaté','76 345 67 89','epicerie@fine.sn','Sandaga, Dakar','2026-03-16 10:56:31'),
(6,'Charcuteries du Terroir France','M. Gilles Dupuis','33 821 44 55','dupuis@terroir-fr.com','Import France via Port','2026-03-16 10:56:31'),
(7,'Ferme Laitière de Thiès','Mme Aminata Ndiaye','77 456 78 90','lait@ferme-thies.sn','Thiès, Sénégal','2026-03-16 10:56:31'),
(8,'Emballages Pro Sénégal','M. Pape Seck','78 678 90 12','contact@emball-pro.sn','Zone Industrielle, Dakar','2026-03-16 10:56:31');
/*!40000 ALTER TABLE `fournisseurs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventaires`
--

DROP TABLE IF EXISTS `inventaires`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventaires` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `produit_id` int(11) NOT NULL,
  `stock_theorique` decimal(10,3) DEFAULT NULL,
  `stock_physique` decimal(10,3) DEFAULT NULL,
  `ecart` decimal(10,3) DEFAULT NULL,
  `motif` varchar(200) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventaires`
--

LOCK TABLES `inventaires` WRITE;
/*!40000 ALTER TABLE `inventaires` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventaires` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` enum('stock','dlc','facture','objectif','systeme') DEFAULT 'systeme',
  `titre` varchar(200) NOT NULL,
  `message` text DEFAULT NULL,
  `niveau` enum('info','warning','danger','success') DEFAULT 'info',
  `lu` tinyint(1) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `produits`
--

DROP TABLE IF EXISTS `produits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `produits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `categorie_id` int(11) DEFAULT NULL,
  `nom` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `prix_vente` decimal(10,2) NOT NULL DEFAULT 0.00,
  `prix_achat` decimal(10,2) NOT NULL DEFAULT 0.00,
  `stock_actuel` decimal(10,3) DEFAULT 0.000,
  `stock_min` decimal(10,3) DEFAULT 1.000,
  `unite` varchar(20) DEFAULT 'kg',
  `image` varchar(255) DEFAULT NULL,
  `actif` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `code_produit` varchar(20) DEFAULT NULL,
  `code_barres` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `categorie_id` (`categorie_id`),
  CONSTRAINT `produits_ibfk_1` FOREIGN KEY (`categorie_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produits`
--

LOCK TABLES `produits` WRITE;
/*!40000 ALTER TABLE `produits` DISABLE KEYS */;
INSERT INTO `produits` VALUES
(1,1,'Saucisson Sec Artisanal','Pur porc, séchage naturel 45 jours, poivre concassé',3500.00,2100.00,17.500,3.000,'kg',NULL,1,'2026-03-16 10:56:31','CHSEC-001','620010000001'),
(2,1,'Chorizo Doux Espagnol','Au paprika doux fumé, spécialité ibérique AOC',4200.00,2600.00,12.000,2.000,'kg',NULL,1,'2026-03-16 10:56:31','CHSEC-002','620010000002'),
(3,1,'Chorizo Fort Piquant','Chorizo relevé, paprika piquant, idéal apéritif',4400.00,2700.00,8.000,2.000,'kg',NULL,1,'2026-03-16 10:56:31','CHSEC-003','620010000003'),
(4,1,'Salami Milano Tranché','Finement tranché, goût délicat, origine Lombardie',5500.00,3400.00,6.500,2.000,'kg',NULL,1,'2026-03-16 10:56:31','CHSEC-004','620010000004'),
(5,1,'Jambon Sec 24 mois','Affiné 24 mois, sel de Guérande, saveur intense',12000.00,7500.00,4.500,1.000,'kg',NULL,1,'2026-03-16 10:56:31','CHSEC-005','620010000005'),
(6,1,'Jambon Sec 12 mois','Affiné 12 mois, équilibre parfait sel et douceur',8500.00,5200.00,7.000,2.000,'kg',NULL,1,'2026-03-16 10:56:31','CHSEC-006','620010000006'),
(7,1,'Coppa Artisanale','Épaule de porc marinée aux herbes, origine italienne',6500.00,4000.00,5.000,1.000,'kg',NULL,1,'2026-03-16 10:56:31','CHSEC-007','620010000007'),
(8,1,'Bresaola de Boeuf','Viande de boeuf séchée, tranchée fine, origine italienne',9000.00,5800.00,3.500,1.000,'kg',NULL,1,'2026-03-16 10:56:31','CHSEC-008','620010000008'),
(9,1,'Pancetta Roulée','Poitrine de porc séchée et épicée, spécialité italienne',5800.00,3600.00,4.000,1.000,'kg',NULL,1,'2026-03-16 10:56:31','CHSEC-009','620010000009'),
(10,1,'Lonzo Corse','Filet de porc corse AOC, séché 6 mois en montagne',11000.00,7000.00,2.500,1.000,'kg',NULL,1,'2026-03-16 10:56:31','CHSEC-010','620010000010'),
(11,2,'Jambon Cuit Supérieur','Sans polyphosphates, label supérieur, tranche épaisse',4800.00,2900.00,22.000,5.000,'kg',NULL,1,'2026-03-16 10:56:31','CHCUI-011','620020000011'),
(12,2,'Jambon de Paris','Jambon cuit classique, fumé légèrement, texture fondante',3800.00,2300.00,18.000,5.000,'kg',NULL,1,'2026-03-16 10:56:31','CHCUI-012','620020000012'),
(13,2,'Mortadelle Pistaches','Spécialité bolognaise DOP, pistaches entières',3200.00,1900.00,13.000,3.000,'kg',NULL,1,'2026-03-16 10:56:31','CHCUI-013','620020000013'),
(14,2,'Pâté de Campagne Maison','Recette traditionnelle grand-mère, herbes fraîches',2800.00,1600.00,10.000,2.000,'kg',NULL,1,'2026-03-16 10:56:31','CHCUI-014','620020000014'),
(15,2,'Pâté de Foie Fine Herbes','Foie de porc, persil, thym, ciboulette',2500.00,1400.00,8.000,2.000,'kg',NULL,1,'2026-03-16 10:56:31','CHCUI-015','620020000015'),
(16,2,'Rillettes du Mans','Porc cuit lentement 6h, pot 400g, texture fondante',2500.00,1400.00,16.000,4.000,'pot',NULL,1,'2026-03-16 10:56:31','CHCUI-016','620020000016'),
(17,2,'Rillettes de Canard','Canard confit effiloché, pot 300g, goût raffiné',3200.00,2000.00,9.000,3.000,'pot',NULL,1,'2026-03-16 10:56:31','CHCUI-017','620020000017'),
(18,2,'Boudin Blanc Truffé','Recette festive aux truffes noires, édition limitée',7500.00,4800.00,16.000,1.000,'kg',NULL,1,'2026-03-16 10:56:31','CHCUI-018','620020000018'),
(19,2,'Boudin Noir Oignons','Boudin artisanal oignons caramélisés, porc Picard',3500.00,2100.00,5.000,2.000,'kg',NULL,1,'2026-03-16 10:56:31','CHCUI-019','620020000019'),
(20,2,'Fromage de Tête','Gelée de tête de porc aux cornichons, recette charcutière',2800.00,1700.00,2.000,1.000,'kg',NULL,1,'2026-03-16 10:56:31','CHCUI-020','620020000020'),
(21,3,'Poulet Fermier Entier','Label Rouge, élevé 81 jours en plein air, 1.5-2kg',3500.00,2100.00,35.000,10.000,'kg',NULL,1,'2026-03-16 10:56:31','VOLFE-021','620030000021'),
(22,3,'Poulet Fermier Découpé','Label Rouge en morceaux, prêt à cuisiner',4200.00,2600.00,20.000,6.000,'kg',NULL,1,'2026-03-16 10:56:31','VOLFE-022','620030000022'),
(23,3,'Filet de Poulet Bio','Certifié bio, sans antibiotiques, chair tendre',5200.00,3300.00,15.000,4.000,'kg',NULL,1,'2026-03-16 10:56:31','VOLFE-023','620030000023'),
(24,3,'Cuisses de Poulet','Cuisses fermières, idéales pour grillades et tajines',2800.00,1700.00,125.000,8.000,'kg',NULL,1,'2026-03-16 10:56:31','VOLFE-024','620030000024'),
(25,3,'Blanc de Dinde Entier','Rôti de dinde, sans os, naturellement maigre',3800.00,2300.00,10.000,4.000,'kg',NULL,1,'2026-03-16 10:56:31','VOLFE-025','620030000025'),
(26,3,'Escalopes de Dinde','Tranches fines, cuisson rapide, légères et saines',4000.00,2500.00,10.000,3.000,'kg',NULL,1,'2026-03-16 10:56:31','VOLFE-026','620030000026'),
(27,3,'Pintade Fermière','Chair savoureuse, plein air, vidée prête à rôtir',4500.00,2800.00,8.000,2.000,'pièce',NULL,1,'2026-03-16 10:56:31','VOLFE-027','620030000027'),
(28,3,'Cailles Prêtes à Cuire','Vidées, bardées lard, idéales festives',1800.00,1100.00,24.000,6.000,'pièce',NULL,1,'2026-03-16 10:56:31','VOLFE-028','620030000028'),
(29,3,'Canard Entier','Canard de Barbarie, chair généreuse, 2-2.5kg',5500.00,3400.00,6.000,2.000,'pièce',NULL,1,'2026-03-16 10:56:31','VOLFE-029','620030000029'),
(30,4,'Magret de Canard Frais','Magret de canard de Barbarie, 350g/pièce',4800.00,3000.00,10.000,3.000,'pièce',NULL,1,'2026-03-16 10:56:31','VOLTR-030','620040000030'),
(31,4,'Cuisses de Canard Confites','Confites au sel et au thym, sous-vide 2 pièces',5500.00,3500.00,12.000,3.000,'sachet',NULL,1,'2026-03-16 10:56:31','VOLTR-031','620040000031'),
(32,4,'Foie Gras Entier Mi-Cuit','Foie gras canard entier mi-cuit, bocal 130g',15000.00,9500.00,5.000,1.000,'bocal',NULL,1,'2026-03-16 10:56:31','VOLTR-032','620040000032'),
(33,4,'Bloc de Foie Gras','Bloc de foie gras canard avec morceaux, 130g',9500.00,6000.00,8.000,2.000,'boite',NULL,1,'2026-03-16 10:56:31','VOLTR-033','620040000033'),
(34,4,'Rillettes Foie Gras','Rillettes de canard au foie gras, pot 180g',6500.00,4200.00,10.000,2.000,'pot',NULL,1,'2026-03-16 10:56:31','VOLTR-034','620040000034'),
(35,5,'Mozzarella di Bufala','AOP italienne, lait de bufflonne, 125g',3500.00,2100.00,14.000,4.000,'pièce',NULL,1,'2026-03-16 10:56:31','FRFRA-035','620050000035'),
(36,5,'Burrata Crémeuse','Burrata artisanale, coeur de crème, 200g',4800.00,3000.00,8.000,2.000,'pièce',NULL,1,'2026-03-16 10:56:31','FRFRA-036','620050000036'),
(37,5,'Ricotta Fraîche','Ricotta artisanale, douce et légère, 500g',2200.00,1300.00,10.000,3.000,'pot',NULL,1,'2026-03-16 10:56:31','FRFRA-037','620050000037'),
(38,5,'Fromage de Chèvre Frais','Chèvre frais local, saveur douce et lactée',1800.00,1000.00,12.000,4.000,'pièce',NULL,1,'2026-03-16 10:56:31','FRFRA-038','620050000038'),
(39,5,'Feta AOP Grecque','Feta authentique grecque au lait de brebis, 200g',2800.00,1600.00,9.000,3.000,'bloc',NULL,1,'2026-03-16 10:56:31','FRFRA-039','620050000039'),
(40,6,'Emmental Français AOP','Fruité et fondant, trous réguliers, 100% lait cru',3200.00,1900.00,8.000,2.000,'kg',NULL,1,'2026-03-16 10:56:31','FRAFF-040','620060000040'),
(41,6,'Camembert Normand AOP','Au lait cru, croûte fleurie, coeur coulant',2500.00,1500.00,18.000,5.000,'pièce',NULL,1,'2026-03-16 10:56:31','FRAFF-041','620060000041'),
(42,6,'Brie de Meaux AOP','Roi des fromages, crémeux à coeur, 200g',3800.00,2300.00,8.000,2.000,'pièce',NULL,1,'2026-03-16 10:56:31','FRAFF-042','620060000042'),
(43,6,'Roquefort AOP','Bleu au lait cru de brebis, cave affinée Combalou',6500.00,4000.00,3.000,1.000,'kg',NULL,1,'2026-03-16 10:56:31','FRAFF-043','620060000043'),
(44,6,'Comté 18 mois AOP','Affiné 18 mois en caves Jura, notes florales',5800.00,3600.00,5.000,1.000,'kg',NULL,1,'2026-03-16 10:56:31','FRAFF-044','620060000044'),
(45,6,'Gruyère Suisse AOP','Cave affinée 12 mois, saveur noisette',5800.00,3600.00,4.500,1.000,'kg',NULL,1,'2026-03-16 10:56:31','FRAFF-045','620060000045'),
(46,6,'Fromage Fondu Portions x8','Idéal sandwich et cuisine, 8 portions individuelles',1800.00,1000.00,23.000,8.000,'boite',NULL,1,'2026-03-16 10:56:31','FRAFF-046','620060000046'),
(47,7,'Oeufs Fermiers x12','Poules élevées plein air, jaune orangé intense',2000.00,1200.00,60.000,20.000,'boite',NULL,1,'2026-03-16 10:56:31','OEULA-047','620070000047'),
(48,7,'Oeufs de Caille x24','Frais, pack 24 pièces, présentation élégante',1500.00,900.00,29.000,10.000,'boite',NULL,1,'2026-03-16 10:56:31','OEULA-048','620070000048'),
(49,7,'Crème Fraîche Épaisse 500g','30% MG, fermière, texture veloutée',1200.00,700.00,30.000,10.000,'pot',NULL,1,'2026-03-16 10:56:31','OEULA-049','620070000049'),
(50,7,'Beurre Doux Fermier 250g','Beurre de qualité supérieure, plaquette traditionnelle',1000.00,580.00,36.000,15.000,'plaquette',NULL,1,'2026-03-16 10:56:31','OEULA-050','620070000050'),
(51,7,'Beurre Demi-Sel 250g','Sel de Guérande, plaquette premium',1100.00,650.00,30.000,12.000,'plaquette',NULL,1,'2026-03-16 10:56:31','OEULA-051','620070000051'),
(52,7,'Lait Entier Fermier 1L','Lait entier pasteurisé de ferme locale',800.00,450.00,50.000,20.000,'bouteille',NULL,1,'2026-03-16 10:56:31','OEULA-052','620070000052'),
(53,8,'Boeuf Haché 15% MG','Pur boeuf frais, 15% matière grasse, fraîcheur garantie',4500.00,2800.00,27.000,5.000,'kg',NULL,1,'2026-03-16 10:56:31','VIARO-053','620080000053'),
(54,8,'Côtes d Agneau Fraîches','Côtelettes d agneau frais, herbes de Provence',6800.00,4200.00,8.000,2.000,'kg',NULL,1,'2026-03-16 10:56:31','VIARO-054','620080000054'),
(55,8,'Gigot d Agneau Désossé','Gigot entier désossé, idéal rôti ou farci',5500.00,3400.00,6.000,2.000,'kg',NULL,1,'2026-03-16 10:56:31','VIARO-055','620080000055'),
(56,8,'Merguez Boeuf-Agneau','Recette artisanale maison, épices traditionnelles',3800.00,2300.00,15.000,5.000,'kg',NULL,1,'2026-03-16 10:56:31','VIARO-056','620080000056'),
(57,8,'Saucisse de Mouton','Saucisse fraîche de mouton, harissa légère',3200.00,1900.00,10.000,3.000,'kg',NULL,1,'2026-03-16 10:56:31','VIARO-057','620080000057'),
(58,12,'Moutarde de Dijon Forte','Bocal 200g, recette originale Amora',900.00,500.00,33.000,10.000,'bocal',NULL,1,'2026-03-16 10:56:31','EPICF-058','620120000058'),
(59,12,'Cornichons Extra-Fins','Au vinaigre blanc, bocal 400g, croquants',1100.00,650.00,28.000,8.000,'bocal',NULL,1,'2026-03-16 10:56:31','EPICF-059','620120000059'),
(60,12,'Sauce Barbecue Fumée','Sauce américaine fumée, idéale grillades, 300ml',1400.00,800.00,20.000,6.000,'bouteille',NULL,1,'2026-03-16 10:56:31','EPICF-060','620120000060'),
(61,12,'Huile d Olive Extra Vierge','AOP première pression à froid, 500ml, Espagne',3500.00,2100.00,18.000,5.000,'bouteille',NULL,1,'2026-03-16 10:56:31','EPICF-061','620120000061'),
(62,13,'Barquettes Alimentaires x50','Plastique alimentaire transparent, 50 pièces',1500.00,900.00,125.500,25.000,'pack',NULL,1,'2026-03-16 10:56:31','EMBAL-062','620130000062'),
(63,13,'Sacs Sous-Vide 25x35 x100','Compatibles toutes machines sous-vide, 100 pièces',3500.00,2100.00,40.000,10.000,'boite',NULL,1,'2026-03-16 10:56:31','EMBAL-063','620130000063'),
(64,13,'Film Étirable Alimentaire 50m','Transparent, BPA free, usage alimentaire',900.00,520.00,53.000,15.000,'rouleau',NULL,1,'2026-03-16 10:56:31','EMBAL-064','620130000064'),
(65,13,'Étiquettes Prix Thermiques','Rouleaux 500 étiquettes blanches 40x20mm',800.00,450.00,29.000,10.000,'rouleau',NULL,1,'2026-03-16 10:56:31','EMBAL-065','620130000065');
/*!40000 ALTER TABLE `produits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `promotions`
--

DROP TABLE IF EXISTS `promotions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `promotions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `type_remise` enum('pourcentage','montant_fixe') DEFAULT 'pourcentage',
  `valeur_remise` decimal(10,2) DEFAULT 0.00,
  `date_debut` date NOT NULL,
  `date_fin` date NOT NULL,
  `produit_id` int(11) DEFAULT NULL,
  `categorie_id` int(11) DEFAULT NULL,
  `actif` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promotions`
--

LOCK TABLES `promotions` WRITE;
/*!40000 ALTER TABLE `promotions` DISABLE KEYS */;
/*!40000 ALTER TABLE `promotions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `utilisateurs`
--

DROP TABLE IF EXISTS `utilisateurs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `utilisateurs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','gestionnaire','caissier') DEFAULT 'caissier',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `utilisateurs`
--

LOCK TABLES `utilisateurs` WRITE;
/*!40000 ALTER TABLE `utilisateurs` DISABLE KEYS */;
INSERT INTO `utilisateurs` VALUES
(12,'Administrateur OMEGA','admin@omega.com','$2y$10$Ew.Y/iV0C0b7gM6rM1C.J.8XjPqV6s1lG7fL/fNf2Ff2Ff2Ff2Ff2','admin','2026-03-16 10:56:31'),
(13,'Mamadou Diallo','mamadou@omega.com','$2y$10$Ew.Y/iV0C0b7gM6rM1C.J.8XjPqV6s1lG7fL/fNf2Ff2Ff2Ff2Ff2','gestionnaire','2026-03-16 10:56:31'),
(14,'Fatou Sène','fatou@omega.com','$2y$10$Ew.Y/iV0C0b7gM6rM1C.J.8XjPqV6s1lG7fL/fNf2Ff2Ff2Ff2Ff2','caissier','2026-03-16 10:56:31'),
(16,'admin','admin@charcuterie.sn','$2y$10$Ew.Y/iV0C0b7gM6rM1C.J.8XjPqV6s1lG7fL/fNf2Ff2Ff2Ff2Ff2','admin','2026-04-01 08:20:09');
/*!40000 ALTER TABLE `utilisateurs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ventes`
--

DROP TABLE IF EXISTS `ventes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ventes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `facture_id` int(11) DEFAULT NULL,
  `produit_id` int(11) DEFAULT NULL,
  `client_id` int(11) DEFAULT NULL,
  `quantite` decimal(10,3) NOT NULL,
  `prix_unitaire` decimal(10,2) NOT NULL,
  `total` decimal(12,2) NOT NULL,
  `date_vente` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `facture_id` (`facture_id`),
  KEY `produit_id` (`produit_id`),
  KEY `client_id` (`client_id`),
  CONSTRAINT `ventes_ibfk_1` FOREIGN KEY (`facture_id`) REFERENCES `factures` (`id`) ON DELETE SET NULL,
  CONSTRAINT `ventes_ibfk_2` FOREIGN KEY (`produit_id`) REFERENCES `produits` (`id`) ON DELETE SET NULL,
  CONSTRAINT `ventes_ibfk_3` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=152 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ventes`
--

LOCK TABLES `ventes` WRITE;
/*!40000 ALTER TABLE `ventes` DISABLE KEYS */;
INSERT INTO `ventes` VALUES
(1,1,11,3,10.000,4800.00,48000.00,'2026-01-20 00:00:00'),
(2,1,1,3,8.000,3500.00,28000.00,'2026-01-20 00:00:00'),
(3,1,21,3,30.000,3500.00,105000.00,'2026-01-20 00:00:00'),
(4,1,42,3,20.000,2500.00,50000.00,'2026-01-20 00:00:00'),
(5,1,55,3,15.000,4500.00,67500.00,'2026-01-20 00:00:00'),
(6,1,13,3,8.000,3200.00,25600.00,'2026-01-20 00:00:00'),
(7,1,49,3,20.000,2000.00,40000.00,'2026-01-20 00:00:00'),
(8,1,16,3,10.000,2500.00,25000.00,'2026-01-20 00:00:00'),
(9,1,2,3,6.000,4200.00,25200.00,'2026-01-20 00:00:00'),
(10,1,51,3,10.000,1200.00,12000.00,'2026-01-20 00:00:00'),
(11,1,14,3,8.000,2800.00,22400.00,'2026-01-20 00:00:00'),
(12,1,29,3,4.000,5500.00,22000.00,'2026-01-20 00:00:00'),
(13,1,43,3,3.000,5800.00,17400.00,'2026-01-20 00:00:00'),
(16,2,5,4,5.000,12000.00,60000.00,'2026-01-27 00:00:00'),
(17,2,31,4,15.000,4800.00,72000.00,'2026-01-27 00:00:00'),
(18,2,33,4,8.000,15000.00,120000.00,'2026-01-27 00:00:00'),
(19,2,11,4,20.000,4800.00,96000.00,'2026-01-27 00:00:00'),
(20,2,41,4,10.000,3200.00,32000.00,'2026-01-27 00:00:00'),
(21,2,35,4,15.000,3500.00,52500.00,'2026-01-27 00:00:00'),
(22,2,36,4,10.000,4800.00,48000.00,'2026-01-27 00:00:00'),
(23,2,21,4,25.000,3500.00,87500.00,'2026-01-27 00:00:00'),
(24,2,30,4,12.000,5500.00,66000.00,'2026-01-27 00:00:00'),
(25,2,49,4,25.000,2000.00,50000.00,'2026-01-27 00:00:00'),
(26,2,4,4,5.000,5500.00,27500.00,'2026-01-27 00:00:00'),
(27,2,14,4,10.000,2800.00,28000.00,'2026-01-27 00:00:00'),
(31,3,27,7,15.000,4500.00,67500.00,'2026-02-09 00:00:00'),
(32,3,28,7,40.000,1800.00,72000.00,'2026-02-09 00:00:00'),
(33,3,1,7,10.000,3500.00,35000.00,'2026-02-09 00:00:00'),
(34,3,2,7,8.000,4200.00,33600.00,'2026-02-09 00:00:00'),
(35,3,5,7,4.000,12000.00,48000.00,'2026-02-09 00:00:00'),
(36,3,42,7,15.000,2500.00,37500.00,'2026-02-09 00:00:00'),
(37,3,43,7,4.000,5800.00,23200.00,'2026-02-09 00:00:00'),
(38,3,49,7,15.000,2000.00,30000.00,'2026-02-09 00:00:00'),
(39,3,14,7,6.000,2800.00,16800.00,'2026-02-09 00:00:00'),
(40,3,16,7,6.000,2500.00,15000.00,'2026-02-09 00:00:00'),
(41,3,52,7,4.000,1000.00,4000.00,'2026-02-09 00:00:00'),
(46,4,11,9,30.000,4800.00,144000.00,'2026-02-24 00:00:00'),
(47,4,12,9,25.000,3800.00,95000.00,'2026-02-24 00:00:00'),
(48,4,1,9,20.000,3500.00,70000.00,'2026-02-24 00:00:00'),
(49,4,2,9,15.000,4200.00,63000.00,'2026-02-24 00:00:00'),
(50,4,13,9,18.000,3200.00,57600.00,'2026-02-24 00:00:00'),
(51,4,41,9,15.000,3200.00,48000.00,'2026-02-24 00:00:00'),
(52,4,42,9,30.000,2500.00,75000.00,'2026-02-24 00:00:00'),
(53,4,49,9,50.000,2000.00,100000.00,'2026-02-24 00:00:00'),
(54,4,50,9,30.000,1500.00,45000.00,'2026-02-24 00:00:00'),
(55,4,52,9,50.000,1000.00,50000.00,'2026-02-24 00:00:00'),
(56,4,55,9,20.000,4500.00,90000.00,'2026-02-24 00:00:00'),
(57,4,58,9,15.000,3800.00,57000.00,'2026-02-24 00:00:00'),
(58,4,59,9,20.000,900.00,18000.00,'2026-02-24 00:00:00'),
(59,4,60,9,15.000,1100.00,16500.00,'2026-02-24 00:00:00'),
(61,5,33,16,10.000,15000.00,150000.00,'2026-03-08 00:00:00'),
(62,5,5,16,8.000,12000.00,96000.00,'2026-03-08 00:00:00'),
(63,5,4,16,10.000,5500.00,55000.00,'2026-03-08 00:00:00'),
(64,5,7,16,6.000,6500.00,39000.00,'2026-03-08 00:00:00'),
(65,5,44,16,4.000,6500.00,26000.00,'2026-03-08 00:00:00'),
(66,5,45,16,5.000,5800.00,29000.00,'2026-03-08 00:00:00'),
(67,5,35,16,20.000,3500.00,70000.00,'2026-03-08 00:00:00'),
(68,5,36,16,12.000,4800.00,57600.00,'2026-03-08 00:00:00'),
(69,5,31,16,20.000,4800.00,96000.00,'2026-03-08 00:00:00'),
(70,5,62,16,10.000,3500.00,35000.00,'2026-03-08 00:00:00'),
(71,5,30,16,8.000,5500.00,44000.00,'2026-03-08 00:00:00'),
(72,5,15,16,6.000,2500.00,15000.00,'2026-03-08 00:00:00'),
(73,5,34,16,6.000,6500.00,39000.00,'2026-03-08 00:00:00'),
(76,NULL,21,1,2.500,3500.00,8750.00,'2026-02-16 00:00:00'),
(77,NULL,11,2,1.000,4800.00,4800.00,'2026-02-16 00:00:00'),
(78,NULL,42,5,3.000,2500.00,7500.00,'2026-02-17 00:00:00'),
(79,NULL,1,6,0.500,3500.00,1750.00,'2026-02-17 00:00:00'),
(80,NULL,49,10,2.000,2000.00,4000.00,'2026-02-18 00:00:00'),
(81,NULL,55,11,3.000,4500.00,13500.00,'2026-02-18 00:00:00'),
(82,NULL,22,NULL,2.000,4200.00,8400.00,'2026-02-19 00:00:00'),
(83,NULL,52,13,4.000,1000.00,4000.00,'2026-02-19 00:00:00'),
(84,NULL,16,1,2.000,2500.00,5000.00,'2026-02-20 00:00:00'),
(85,NULL,2,2,1.000,4200.00,4200.00,'2026-02-20 00:00:00'),
(86,NULL,21,3,5.000,3500.00,17500.00,'2026-02-23 00:00:00'),
(87,NULL,41,4,2.000,3200.00,6400.00,'2026-02-23 00:00:00'),
(88,NULL,28,NULL,6.000,1800.00,10800.00,'2026-02-24 00:00:00'),
(89,NULL,58,6,2.000,3800.00,7600.00,'2026-02-24 00:00:00'),
(90,NULL,11,7,3.000,4800.00,14400.00,'2026-02-25 00:00:00'),
(91,NULL,49,8,3.000,2000.00,6000.00,'2026-02-25 00:00:00'),
(92,NULL,1,10,2.000,3500.00,7000.00,'2026-02-26 00:00:00'),
(93,NULL,51,11,2.000,1200.00,2400.00,'2026-02-26 00:00:00'),
(94,NULL,55,12,4.000,4500.00,18000.00,'2026-02-27 00:00:00'),
(95,NULL,42,13,5.000,2500.00,12500.00,'2026-02-27 00:00:00'),
(96,NULL,21,NULL,3.500,3500.00,12250.00,'2026-03-02 00:00:00'),
(97,NULL,22,1,2.000,4200.00,8400.00,'2026-03-02 00:00:00'),
(98,NULL,23,2,1.500,5200.00,7800.00,'2026-03-03 00:00:00'),
(99,NULL,31,5,3.000,4800.00,14400.00,'2026-03-03 00:00:00'),
(100,NULL,11,NULL,2.500,4800.00,12000.00,'2026-03-04 00:00:00'),
(101,NULL,33,6,2.000,15000.00,30000.00,'2026-03-04 00:00:00'),
(102,NULL,49,NULL,5.000,2000.00,10000.00,'2026-03-05 00:00:00'),
(103,NULL,41,8,1.500,3200.00,4800.00,'2026-03-05 00:00:00'),
(104,NULL,2,10,1.000,4200.00,4200.00,'2026-03-06 00:00:00'),
(105,NULL,58,11,3.000,3800.00,11400.00,'2026-03-06 00:00:00'),
(106,NULL,21,1,4.000,3500.00,14000.00,'2026-03-09 00:00:00'),
(107,NULL,5,NULL,0.500,12000.00,6000.00,'2026-03-09 00:00:00'),
(108,NULL,42,NULL,4.000,2500.00,10000.00,'2026-03-10 00:00:00'),
(109,NULL,11,2,2.000,4800.00,9600.00,'2026-03-10 00:00:00'),
(110,NULL,28,NULL,8.000,1800.00,14400.00,'2026-03-11 00:00:00'),
(111,NULL,55,3,3.000,4500.00,13500.00,'2026-03-11 00:00:00'),
(112,NULL,22,5,1.500,4200.00,6300.00,'2026-03-12 00:00:00'),
(113,NULL,16,6,3.000,2500.00,7500.00,'2026-03-12 00:00:00'),
(114,NULL,49,10,4.000,2000.00,8000.00,'2026-03-13 00:00:00'),
(115,NULL,1,11,1.500,3500.00,5250.00,'2026-03-13 00:00:00'),
(116,NULL,21,NULL,2.000,3500.00,7000.00,'2026-03-16 10:56:31'),
(117,NULL,11,1,1.500,4800.00,7200.00,'2026-03-16 10:56:31'),
(118,NULL,42,2,3.000,2500.00,7500.00,'2026-03-16 10:56:31'),
(119,NULL,22,NULL,1.000,4200.00,4200.00,'2026-03-16 10:56:31'),
(120,NULL,55,5,2.500,4500.00,11250.00,'2026-03-16 10:56:31'),
(121,NULL,49,NULL,2.000,2000.00,4000.00,'2026-03-16 10:56:31'),
(122,NULL,2,6,0.500,4200.00,2100.00,'2026-03-16 10:56:31'),
(123,NULL,52,10,3.000,1000.00,3000.00,'2026-03-16 10:56:31'),
(124,NULL,58,11,2.000,3800.00,7600.00,'2026-03-16 10:56:31'),
(125,NULL,41,NULL,1.000,3200.00,3200.00,'2026-03-16 10:56:31'),
(126,6,18,16,2.000,7500.00,15000.00,'2026-03-16 00:00:00'),
(127,NULL,50,20,2.000,1000.00,2000.00,'2026-03-30 23:47:00'),
(128,NULL,33,16,4.000,9500.00,38000.00,'2026-03-31 09:45:00'),
(129,NULL,51,20,3.000,1100.00,3300.00,'2026-03-31 09:46:00'),
(130,7,33,NULL,1.000,9500.00,9500.00,'2026-03-31 10:07:45'),
(131,7,20,NULL,1.000,2800.00,2800.00,'2026-03-31 10:07:45'),
(132,8,62,NULL,1.500,1500.00,2250.00,'2026-03-31 10:11:02'),
(133,8,51,NULL,2.000,1100.00,2200.00,'2026-03-31 10:11:02'),
(134,8,58,NULL,2.000,900.00,1800.00,'2026-03-31 10:11:02'),
(135,8,1,NULL,1.000,3500.00,3500.00,'2026-03-31 10:11:02'),
(136,9,13,NULL,1.000,3200.00,3200.00,'2026-03-31 10:12:36'),
(137,9,48,NULL,1.000,1500.00,1500.00,'2026-03-31 10:12:36'),
(138,10,39,NULL,1.000,2800.00,2800.00,'2026-03-31 10:12:47'),
(139,11,46,NULL,1.000,1800.00,1800.00,'2026-03-31 10:13:26'),
(140,11,32,NULL,1.000,15000.00,15000.00,'2026-03-31 10:13:26'),
(141,12,20,NULL,1.000,2800.00,2800.00,'2026-03-31 10:13:39'),
(142,13,40,NULL,1.000,3200.00,3200.00,'2026-03-31 10:14:08'),
(143,14,17,NULL,1.000,3200.00,3200.00,'2026-03-31 10:15:27'),
(144,14,43,NULL,1.000,6500.00,6500.00,'2026-03-31 10:15:27'),
(145,15,46,NULL,1.000,1800.00,1800.00,'2026-03-31 10:15:47'),
(146,16,64,NULL,1.000,900.00,900.00,'2026-03-31 14:18:46'),
(147,17,64,NULL,1.000,900.00,900.00,'2026-03-31 14:19:36'),
(148,18,65,NULL,1.000,800.00,800.00,'2026-03-31 14:20:30'),
(149,NULL,33,16,3.000,9500.00,28500.00,'2026-03-31 19:39:00'),
(150,NULL,50,14,2.000,1000.00,2000.00,'2026-04-01 00:47:00'),
(151,NULL,25,20,2.000,3800.00,7600.00,'2026-04-01 08:29:00');
/*!40000 ALTER TABLE `ventes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ventes_lignes`
--

DROP TABLE IF EXISTS `ventes_lignes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ventes_lignes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vente_id` int(11) NOT NULL,
  `produit_id` int(11) NOT NULL,
  `quantite` decimal(12,2) NOT NULL,
  `prix_unitaire` decimal(12,2) NOT NULL,
  `total_ht` decimal(12,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `vente_id` (`vente_id`),
  KEY `produit_id` (`produit_id`),
  CONSTRAINT `ventes_lignes_ibfk_1` FOREIGN KEY (`vente_id`) REFERENCES `ventes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ventes_lignes_ibfk_2` FOREIGN KEY (`produit_id`) REFERENCES `produits` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ventes_lignes`
--

LOCK TABLES `ventes_lignes` WRITE;
/*!40000 ALTER TABLE `ventes_lignes` DISABLE KEYS */;
/*!40000 ALTER TABLE `ventes_lignes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-22 16:35:47
