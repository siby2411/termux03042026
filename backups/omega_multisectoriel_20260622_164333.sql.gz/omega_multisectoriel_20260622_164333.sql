/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: omega_multisectoriel
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `actifs_immobilier`
--

DROP TABLE IF EXISTS `actifs_immobilier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `actifs_immobilier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_actif` enum('Appartement','Restaurant','Matériel') DEFAULT NULL,
  `nom_actif` varchar(100) DEFAULT NULL,
  `statut` enum('Libre','Loué','En Travaux') DEFAULT NULL,
  `loyer_mensuel` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `actifs_immobilier`
--

LOCK TABLES `actifs_immobilier` WRITE;
/*!40000 ALTER TABLE `actifs_immobilier` DISABLE KEYS */;
/*!40000 ALTER TABLE `actifs_immobilier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ai_alerts`
--

DROP TABLE IF EXISTS `ai_alerts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_alerts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `message` text DEFAULT NULL,
  `risk_score` int(11) DEFAULT NULL,
  `priority` varchar(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ai_alerts`
--

LOCK TABLES `ai_alerts` WRITE;
/*!40000 ALTER TABLE `ai_alerts` DISABLE KEYS */;
/*!40000 ALTER TABLE `ai_alerts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bons_commande`
--

DROP TABLE IF EXISTS `bons_commande`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bons_commande` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numero_bc` varchar(50) DEFAULT NULL,
  `date_bc` date DEFAULT NULL,
  `fournisseur_id` int(11) DEFAULT NULL,
  `montant` decimal(15,2) DEFAULT NULL,
  `statut` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bons_commande`
--

LOCK TABLES `bons_commande` WRITE;
/*!40000 ALTER TABLE `bons_commande` DISABLE KEYS */;
INSERT INTO `bons_commande` VALUES
(1,'BC-2026-001','2026-06-20',1,950000.00,'Livré'),
(2,'BC-2026-002','2026-06-20',2,780000.00,'En cours');
/*!40000 ALTER TABLE `bons_commande` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `carburant`
--

DROP TABLE IF EXISTS `carburant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `carburant` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_saisie` date DEFAULT NULL,
  `engin` varchar(100) DEFAULT NULL,
  `litres` decimal(10,2) DEFAULT NULL,
  `cout` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `carburant`
--

LOCK TABLES `carburant` WRITE;
/*!40000 ALTER TABLE `carburant` DISABLE KEYS */;
INSERT INTO `carburant` VALUES
(1,'2026-06-20','Pelle Hydraulique',120.00,102000.00),
(2,'2026-06-20','Camion Benne',80.00,68000.00);
/*!40000 ALTER TABLE `carburant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chantiers`
--

DROP TABLE IF EXISTS `chantiers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chantiers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom_projet` varchar(100) DEFAULT NULL,
  `etape` enum('Fondation','Maçonnerie','Plomberie','Électricité','Finition') DEFAULT NULL,
  `progression` int(11) DEFAULT 0,
  `date_debut` date DEFAULT NULL,
  `date_fin_prevue` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chantiers`
--

LOCK TABLES `chantiers` WRITE;
/*!40000 ALTER TABLE `chantiers` DISABLE KEYS */;
INSERT INTO `chantiers` VALUES
(1,'Immeuble R+3 Dakar','Maçonnerie',58,'2026-01-15','2026-12-30');
/*!40000 ALTER TABLE `chantiers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `composantes`
--

DROP TABLE IF EXISTS `composantes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `composantes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `composantes`
--

LOCK TABLES `composantes` WRITE;
/*!40000 ALTER TABLE `composantes` DISABLE KEYS */;
INSERT INTO `composantes` VALUES
(1,'Génie Civil'),
(2,'Plomberie'),
(3,'Maçonnerie'),
(4,'Électricité'),
(5,'Peinture'),
(6,'Aménagement'),
(7,'Immobilisations'),
(8,'Transport & Logistique'),
(9,'Carrelage & Revêtement'),
(10,'Menuiserie & Vitrerie'),
(11,'Fondation'),
(12,'Maçonnerie'),
(13,'Plomberie'),
(14,'Électricité'),
(15,'Finition');
/*!40000 ALTER TABLE `composantes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `depenses_details`
--

DROP TABLE IF EXISTS `depenses_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `depenses_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `composante_id` int(11) DEFAULT NULL,
  `libelle` varchar(255) DEFAULT NULL,
  `beneficiaire` enum('Ouvrier','Fournisseur','Maître d’Ouvrage','Prestataire') DEFAULT NULL,
  `montant_prevu` decimal(15,2) DEFAULT NULL,
  `montant_reel` decimal(15,2) DEFAULT NULL,
  `date_paiement` date DEFAULT NULL,
  `statut_paiement` enum('En attente','Partiel','Payé') DEFAULT NULL,
  `quantite` int(11) DEFAULT 1,
  `prix_unitaire` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`),
  KEY `composante_id` (`composante_id`),
  CONSTRAINT `depenses_details_ibfk_1` FOREIGN KEY (`composante_id`) REFERENCES `composantes` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `depenses_details`
--

LOCK TABLES `depenses_details` WRITE;
/*!40000 ALTER TABLE `depenses_details` DISABLE KEYS */;
INSERT INTO `depenses_details` VALUES
(1,2,'Robinet ',NULL,12000.00,2500.00,'2026-04-03',NULL,1,0.00),
(2,2,'Eau ',NULL,0.00,1200.00,'2026-04-03',NULL,1,0.00),
(3,8,'Transport Sable 5m3',NULL,50000.00,55000.00,'2026-04-01',NULL,1,0.00),
(4,8,'Transport Fer 10',NULL,25000.00,20000.00,'2026-04-02',NULL,1,0.00),
(5,9,'Achat Carrelage 60x60',NULL,400000.00,410000.00,'2026-04-03',NULL,1,0.00),
(6,4,'Equipe Electricité Acompte',NULL,100000.00,100000.00,'2026-04-03',NULL,1,0.00),
(7,1,'Ciment Fondation','Fournisseur',1000000.00,950000.00,'2026-06-20','Payé',100,9500.00),
(8,2,'Blocs Béton','Fournisseur',800000.00,780000.00,'2026-06-20','Payé',500,1560.00),
(9,3,'Tuyauterie PVC','Fournisseur',300000.00,320000.00,'2026-06-20','Payé',50,6400.00),
(10,4,'Câblage Principal','Fournisseur',450000.00,430000.00,'2026-06-20','Payé',30,14333.00),
(11,5,'Peinture Intérieure','Prestataire',500000.00,520000.00,'2026-06-20','Partiel',1,520000.00);
/*!40000 ALTER TABLE `depenses_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents`
--

DROP TABLE IF EXISTS `documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(200) DEFAULT NULL,
  `fichier` varchar(255) DEFAULT NULL,
  `date_upload` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents`
--

LOCK TABLES `documents` WRITE;
/*!40000 ALTER TABLE `documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipements`
--

DROP TABLE IF EXISTS `equipements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `equipements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(150) DEFAULT NULL,
  `date_acquisition` date DEFAULT NULL,
  `etat` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipements`
--

LOCK TABLES `equipements` WRITE;
/*!40000 ALTER TABLE `equipements` DISABLE KEYS */;
INSERT INTO `equipements` VALUES
(1,'Bétonnière','2026-01-20','Bon'),
(2,'Groupe électrogène','2026-02-01','Bon'),
(3,'Marteau piqueur','2026-03-15','Maintenance');
/*!40000 ALTER TABLE `equipements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evolution_depenses`
--

DROP TABLE IF EXISTS `evolution_depenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `evolution_depenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_pointage` date DEFAULT NULL,
  `cumul_prevu` decimal(15,2) DEFAULT NULL,
  `cumul_reel` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evolution_depenses`
--

LOCK TABLES `evolution_depenses` WRITE;
/*!40000 ALTER TABLE `evolution_depenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `evolution_depenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fournisseurs`
--

DROP TABLE IF EXISTS `fournisseurs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fournisseurs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(150) DEFAULT NULL,
  `telephone` varchar(50) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `adresse` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fournisseurs`
--

LOCK TABLES `fournisseurs` WRITE;
/*!40000 ALTER TABLE `fournisseurs` DISABLE KEYS */;
INSERT INTO `fournisseurs` VALUES
(1,'SEN BETON','771111111','contact@senbeton.sn','Dakar'),
(2,'SEN FER','772222222','contact@senfer.sn','Rufisque'),
(3,'OMEGA MATERIAUX','773333333','vente@omega.sn','Diamniadio');
/*!40000 ALTER TABLE `fournisseurs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `incidents`
--

DROP TABLE IF EXISTS `incidents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `incidents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_incident` date DEFAULT NULL,
  `description` text DEFAULT NULL,
  `gravite` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `incidents`
--

LOCK TABLES `incidents` WRITE;
/*!40000 ALTER TABLE `incidents` DISABLE KEYS */;
INSERT INTO `incidents` VALUES
(1,'2026-06-20','Ouvrier sans casque','Faible'),
(2,'2026-06-20','Chute légère échafaudage','Moyenne'),
(3,'2026-06-20','Court-circuit temporaire','Élevée');
/*!40000 ALTER TABLE `incidents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventaire_materiaux`
--

DROP TABLE IF EXISTS `inventaire_materiaux`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventaire_materiaux` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(100) DEFAULT NULL,
  `quantite_reçue` decimal(10,2) DEFAULT NULL,
  `unite` varchar(20) DEFAULT NULL,
  `date_reception` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventaire_materiaux`
--

LOCK TABLES `inventaire_materiaux` WRITE;
/*!40000 ALTER TABLE `inventaire_materiaux` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventaire_materiaux` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personnel`
--

DROP TABLE IF EXISTS `personnel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `personnel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom_complet` varchar(100) DEFAULT NULL,
  `specialite` varchar(50) DEFAULT NULL,
  `type_remuneration` enum('Journalier','Forfait','Unitaire') DEFAULT NULL,
  `tarif_base` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personnel`
--

LOCK TABLES `personnel` WRITE;
/*!40000 ALTER TABLE `personnel` DISABLE KEYS */;
INSERT INTO `personnel` VALUES
(1,'Equipe Maçonnerie','Maçonnerie','Forfait',0.00),
(2,'Equipe Plomberie','Plomberie','Unitaire',0.00),
(3,'Equipe Électricité','Électricité','Journalier',5000.00),
(4,'Mamadou Diallo','Maçon','Journalier',12000.00),
(5,'Ibrahima Ndiaye','Électricien','Journalier',15000.00),
(6,'Ousmane Ba','Plombier','Journalier',14000.00),
(7,'Aliou Sow','Peintre','Journalier',10000.00),
(8,'Cheikh Fall','Chef Chantier','Forfait',300000.00);
/*!40000 ALTER TABLE `personnel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `planning_travaux`
--

DROP TABLE IF EXISTS `planning_travaux`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `planning_travaux` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `composante_id` int(11) DEFAULT NULL,
  `tache` varchar(100) DEFAULT NULL,
  `date_debut` date DEFAULT NULL,
  `date_fin` date DEFAULT NULL,
  `progression` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `composante_id` (`composante_id`),
  CONSTRAINT `planning_travaux_ibfk_1` FOREIGN KEY (`composante_id`) REFERENCES `composantes` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `planning_travaux`
--

LOCK TABLES `planning_travaux` WRITE;
/*!40000 ALTER TABLE `planning_travaux` DISABLE KEYS */;
INSERT INTO `planning_travaux` VALUES
(1,1,'Fondations & Gros Oeuvre','2026-04-01','2026-04-15',45),
(2,9,'Pose Carrelage Salon','2026-04-16','2026-04-25',10),
(3,4,'Câblage Électrique','2026-04-10','2026-04-18',80),
(4,6,'Pose','2026-04-01','2026-04-10',5),
(5,1,'Fondations','2026-01-15','2026-02-20',100),
(6,2,'Élévation RDC','2026-02-21','2026-04-15',90),
(7,3,'Plomberie RDC','2026-04-01','2026-05-15',70),
(8,4,'Installation électrique','2026-05-01','2026-06-30',60),
(9,5,'Peinture intérieure','2026-07-01','2026-08-15',25);
/*!40000 ALTER TABLE `planning_travaux` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pointage_paie`
--

DROP TABLE IF EXISTS `pointage_paie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pointage_paie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `personnel_id` int(11) DEFAULT NULL,
  `date_travail` date DEFAULT NULL,
  `heures_ou_jours` decimal(5,2) DEFAULT NULL,
  `montant_paye` decimal(15,2) DEFAULT NULL,
  `statut_paiement` enum('Avance','Solde','Complet') DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `personnel_id` (`personnel_id`),
  CONSTRAINT `pointage_paie_ibfk_1` FOREIGN KEY (`personnel_id`) REFERENCES `personnel` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pointage_paie`
--

LOCK TABLES `pointage_paie` WRITE;
/*!40000 ALTER TABLE `pointage_paie` DISABLE KEYS */;
INSERT INTO `pointage_paie` VALUES
(1,1,'2026-06-20',1.00,12000.00,'Complet'),
(2,2,'2026-06-20',1.00,15000.00,'Complet'),
(3,3,'2026-06-20',1.00,14000.00,'Complet'),
(4,4,'2026-06-20',1.00,10000.00,'Complet'),
(5,5,'2026-06-20',1.00,300000.00,'Avance');
/*!40000 ALTER TABLE `pointage_paie` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rapports_mensuels`
--

DROP TABLE IF EXISTS `rapports_mensuels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rapports_mensuels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mois_annee` varchar(7) DEFAULT NULL,
  `secteur_id` int(11) DEFAULT NULL,
  `total_prevu` decimal(15,2) DEFAULT NULL,
  `total_reel` decimal(15,2) DEFAULT NULL,
  `performance_index` decimal(5,2) DEFAULT NULL,
  `date_generation` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rapports_mensuels`
--

LOCK TABLES `rapports_mensuels` WRITE;
/*!40000 ALTER TABLE `rapports_mensuels` DISABLE KEYS */;
/*!40000 ALTER TABLE `rapports_mensuels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ratios_rendement`
--

DROP TABLE IF EXISTS `ratios_rendement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ratios_rendement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation_materiau` varchar(50) DEFAULT NULL,
  `unite` varchar(20) DEFAULT NULL,
  `ratio_standard_m2` decimal(10,4) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ratios_rendement`
--

LOCK TABLES `ratios_rendement` WRITE;
/*!40000 ALTER TABLE `ratios_rendement` DISABLE KEYS */;
INSERT INTO `ratios_rendement` VALUES
(1,'Ciment (Dalle)','Sacs',0.3500,NULL),
(2,'Colle Carrelage','Sacs',0.2000,NULL),
(3,'Peinture','Litres',0.1500,NULL);
/*!40000 ALTER TABLE `ratios_rendement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rdv_chantier`
--

DROP TABLE IF EXISTS `rdv_chantier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rdv_chantier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(100) DEFAULT NULL,
  `date_heure` datetime DEFAULT NULL,
  `type_rdv` enum('Livraison','Réunion','Visite Client','Contrôle') DEFAULT NULL,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rdv_chantier`
--

LOCK TABLES `rdv_chantier` WRITE;
/*!40000 ALTER TABLE `rdv_chantier` DISABLE KEYS */;
/*!40000 ALTER TABLE `rdv_chantier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reserves_qualite`
--

DROP TABLE IF EXISTS `reserves_qualite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `reserves_qualite` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `composante_id` int(11) DEFAULT NULL,
  `description_defaut` text DEFAULT NULL,
  `criticite` enum('Mineure','Majeure','Critique') DEFAULT NULL,
  `statut` enum('A corriger','En cours','Valide') DEFAULT 'A corriger',
  `date_signalement` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `composante_id` (`composante_id`),
  CONSTRAINT `reserves_qualite_ibfk_1` FOREIGN KEY (`composante_id`) REFERENCES `composantes` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reserves_qualite`
--

LOCK TABLES `reserves_qualite` WRITE;
/*!40000 ALTER TABLE `reserves_qualite` DISABLE KEYS */;
INSERT INTO `reserves_qualite` VALUES
(1,2,'Fissure légère mur nord','Mineure','A corriger','2026-06-20 18:01:36'),
(2,4,'Passage gaine non conforme','Majeure','En cours','2026-06-20 18:01:36');
/*!40000 ALTER TABLE `reserves_qualite` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `risques`
--

DROP TABLE IF EXISTS `risques`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `risques` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` text DEFAULT NULL,
  `niveau` varchar(50) DEFAULT NULL,
  `action_corrective` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `risques`
--

LOCK TABLES `risques` WRITE;
/*!40000 ALTER TABLE `risques` DISABLE KEYS */;
/*!40000 ALTER TABLE `risques` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `secteurs`
--

DROP TABLE IF EXISTS `secteurs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `secteurs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `secteurs`
--

LOCK TABLES `secteurs` WRITE;
/*!40000 ALTER TABLE `secteurs` DISABLE KEYS */;
INSERT INTO `secteurs` VALUES
(1,'Génie Civil'),
(2,'Restauration'),
(3,'Location'),
(4,'Gros Oeuvre'),
(5,'Second Oeuvre'),
(6,'Administration');
/*!40000 ALTER TABLE `secteurs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `stats_composantes`
--

DROP TABLE IF EXISTS `stats_composantes`;
/*!50001 DROP VIEW IF EXISTS `stats_composantes`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `stats_composantes` AS SELECT
 1 AS `composante`,
  1 AS `nb_transactions`,
  1 AS `budget_total`,
  1 AS `depense_totale`,
  1 AS `ratio_absorption`,
  1 AS `marge_securite` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `tresorerie`
--

DROP TABLE IF EXISTS `tresorerie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tresorerie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `secteur_id` int(11) DEFAULT NULL,
  `libelle` varchar(255) DEFAULT NULL,
  `montant` decimal(15,2) DEFAULT NULL,
  `type_flux` enum('Recette','Depense','Investissement') DEFAULT NULL,
  `date_op` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `secteur_id` (`secteur_id`),
  CONSTRAINT `tresorerie_ibfk_1` FOREIGN KEY (`secteur_id`) REFERENCES `secteurs` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tresorerie`
--

LOCK TABLES `tresorerie` WRITE;
/*!40000 ALTER TABLE `tresorerie` DISABLE KEYS */;
INSERT INTO `tresorerie` VALUES
(1,1,'Paiement matériaux',950000.00,'Depense','2026-06-20'),
(2,2,'Paiement plomberie',320000.00,'Depense','2026-06-20'),
(3,3,'Apport capital',5000000.00,'Recette','2026-06-20');
/*!40000 ALTER TABLE `tresorerie` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vehicules`
--

DROP TABLE IF EXISTS `vehicules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `vehicules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `immatriculation` varchar(50) DEFAULT NULL,
  `marque` varchar(100) DEFAULT NULL,
  `chauffeur` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vehicules`
--

LOCK TABLES `vehicules` WRITE;
/*!40000 ALTER TABLE `vehicules` DISABLE KEYS */;
/*!40000 ALTER TABLE `vehicules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `stats_composantes`
--

/*!50001 DROP VIEW IF EXISTS `stats_composantes`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `stats_composantes` AS select `c`.`nom` AS `composante`,count(`d`.`id`) AS `nb_transactions`,sum(`d`.`montant_prevu`) AS `budget_total`,sum(`d`.`montant_reel`) AS `depense_totale`,sum(`d`.`montant_reel`) / sum(`d`.`montant_prevu`) * 100 AS `ratio_absorption`,sum(`d`.`montant_prevu`) - sum(`d`.`montant_reel`) AS `marge_securite` from (`composantes` `c` left join `depenses_details` `d` on(`c`.`id` = `d`.`composante_id`)) group by `c`.`id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-22 16:43:51
