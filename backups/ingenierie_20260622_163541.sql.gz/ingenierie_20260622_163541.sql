/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: ingenierie
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Achats`
--

DROP TABLE IF EXISTS `Achats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Achats` (
  `AchatID` int(11) NOT NULL AUTO_INCREMENT,
  `ProduitID` int(11) DEFAULT NULL,
  `FournisseurID` int(11) DEFAULT NULL,
  `DateAchat` date DEFAULT NULL,
  `ReferenceFacture` varchar(100) DEFAULT NULL,
  `Quantite` int(11) DEFAULT NULL,
  `PrixUnitaireAchat` decimal(15,2) DEFAULT NULL,
  `MontantTotal` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`AchatID`),
  KEY `ProduitID` (`ProduitID`),
  KEY `FournisseurID` (`FournisseurID`),
  CONSTRAINT `Achats_ibfk_1` FOREIGN KEY (`ProduitID`) REFERENCES `Produits` (`ProduitID`),
  CONSTRAINT `Achats_ibfk_2` FOREIGN KEY (`FournisseurID`) REFERENCES `Fournisseurs` (`FournisseurID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Achats`
--

LOCK TABLES `Achats` WRITE;
/*!40000 ALTER TABLE `Achats` DISABLE KEYS */;
/*!40000 ALTER TABLE `Achats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Budgets`
--

DROP TABLE IF EXISTS `Budgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Budgets` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Annee` int(11) NOT NULL,
  `Periode` varchar(50) DEFAULT NULL,
  `Poste` varchar(255) DEFAULT NULL,
  `MontantPrevu` decimal(15,2) DEFAULT NULL,
  `TypeBudget` enum('Produit','Charge','Investissement','Financement') DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Budgets`
--

LOCK TABLES `Budgets` WRITE;
/*!40000 ALTER TABLE `Budgets` DISABLE KEYS */;
/*!40000 ALTER TABLE `Budgets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Clients`
--

DROP TABLE IF EXISTS `Clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Clients` (
  `ClientID` int(11) NOT NULL AUTO_INCREMENT,
  `Nom` varchar(255) NOT NULL,
  `Contact` varchar(255) DEFAULT NULL,
  `Telephone` varchar(50) DEFAULT NULL,
  `Adresse` text DEFAULT NULL,
  `Ville` varchar(100) DEFAULT NULL,
  `CodePostal` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ClientID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Clients`
--

LOCK TABLES `Clients` WRITE;
/*!40000 ALTER TABLE `Clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `Clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CommandeDetails`
--

DROP TABLE IF EXISTS `CommandeDetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `CommandeDetails` (
  `DetailID` int(11) NOT NULL AUTO_INCREMENT,
  `CommandeID` int(11) DEFAULT NULL,
  `ProduitID` int(11) DEFAULT NULL,
  `Quantite` int(11) DEFAULT NULL,
  `PrixVenteUnitaire` decimal(15,2) DEFAULT NULL,
  `CUMP_Au_Moment_Vente` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`DetailID`),
  KEY `CommandeID` (`CommandeID`),
  KEY `ProduitID` (`ProduitID`),
  CONSTRAINT `CommandeDetails_ibfk_1` FOREIGN KEY (`CommandeID`) REFERENCES `Commandes` (`CommandeID`),
  CONSTRAINT `CommandeDetails_ibfk_2` FOREIGN KEY (`ProduitID`) REFERENCES `Produits` (`ProduitID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CommandeDetails`
--

LOCK TABLES `CommandeDetails` WRITE;
/*!40000 ALTER TABLE `CommandeDetails` DISABLE KEYS */;
/*!40000 ALTER TABLE `CommandeDetails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Commandes`
--

DROP TABLE IF EXISTS `Commandes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Commandes` (
  `CommandeID` int(11) NOT NULL AUTO_INCREMENT,
  `ClientID` int(11) DEFAULT NULL,
  `DateCommande` date DEFAULT NULL,
  `ReferenceFacture` varchar(100) DEFAULT NULL,
  `MontantTotalHT` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`CommandeID`),
  KEY `ClientID` (`ClientID`),
  CONSTRAINT `Commandes_ibfk_1` FOREIGN KEY (`ClientID`) REFERENCES `Clients` (`ClientID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Commandes`
--

LOCK TABLES `Commandes` WRITE;
/*!40000 ALTER TABLE `Commandes` DISABLE KEYS */;
/*!40000 ALTER TABLE `Commandes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Comptes`
--

DROP TABLE IF EXISTS `Comptes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Comptes` (
  `CodeCompte` varchar(15) NOT NULL,
  `Libelle` varchar(255) NOT NULL,
  `Categorie` enum('Actif','Passif','Charge','Produit') NOT NULL,
  `SousCategorie` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`CodeCompte`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Comptes`
--

LOCK TABLES `Comptes` WRITE;
/*!40000 ALTER TABLE `Comptes` DISABLE KEYS */;
INSERT INTO `Comptes` VALUES
('101','Capital','Passif','Capitaux Propres'),
('162','Emprunts LT','Passif','Dettes Long Terme'),
('211','Immobilisations','Actif','Actif Immobilisé'),
('401','Fournisseurs','Passif','Dettes Court Terme'),
('411','Clients','Actif','Actif Circulant'),
('512','Banque','Actif','Trésorerie Actif'),
('607','Achats Marchandises','Charge','Charges d\'Exploitation'),
('707','Ventes Marchandises','Produit','Produits d\'Exploitation');
/*!40000 ALTER TABLE `Comptes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Ecritures`
--

DROP TABLE IF EXISTS `Ecritures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Ecritures` (
  `EcritureID` int(11) NOT NULL AUTO_INCREMENT,
  `DateComptable` date NOT NULL,
  `Libelle` varchar(255) NOT NULL,
  `Montant` decimal(15,2) NOT NULL,
  `CompteDebiteur` varchar(15) DEFAULT NULL,
  `CompteCrediteur` varchar(15) DEFAULT NULL,
  `UtilisateurID` int(11) DEFAULT NULL,
  `DateSaisie` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`EcritureID`),
  KEY `CompteDebiteur` (`CompteDebiteur`),
  KEY `CompteCrediteur` (`CompteCrediteur`),
  CONSTRAINT `Ecritures_ibfk_1` FOREIGN KEY (`CompteDebiteur`) REFERENCES `Comptes` (`CodeCompte`),
  CONSTRAINT `Ecritures_ibfk_2` FOREIGN KEY (`CompteCrediteur`) REFERENCES `Comptes` (`CodeCompte`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Ecritures`
--

LOCK TABLES `Ecritures` WRITE;
/*!40000 ALTER TABLE `Ecritures` DISABLE KEYS */;
/*!40000 ALTER TABLE `Ecritures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FluxTresorerie`
--

DROP TABLE IF EXISTS `FluxTresorerie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `FluxTresorerie` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DateFlux` date NOT NULL,
  `TypeFlux` enum('Exploitation','Investissement','Financement') NOT NULL,
  `Montant` decimal(15,2) NOT NULL,
  `CodeCompte` varchar(15) DEFAULT NULL,
  `Libelle` text DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `CodeCompte` (`CodeCompte`),
  CONSTRAINT `FluxTresorerie_ibfk_1` FOREIGN KEY (`CodeCompte`) REFERENCES `Comptes` (`CodeCompte`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FluxTresorerie`
--

LOCK TABLES `FluxTresorerie` WRITE;
/*!40000 ALTER TABLE `FluxTresorerie` DISABLE KEYS */;
/*!40000 ALTER TABLE `FluxTresorerie` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fournisseurs`
--

DROP TABLE IF EXISTS `Fournisseurs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Fournisseurs` (
  `FournisseurID` int(11) NOT NULL AUTO_INCREMENT,
  `Nom` varchar(255) NOT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Telephone` varchar(50) DEFAULT NULL,
  `CompteComptable` varchar(20) DEFAULT '401100',
  PRIMARY KEY (`FournisseurID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fournisseurs`
--

LOCK TABLES `Fournisseurs` WRITE;
/*!40000 ALTER TABLE `Fournisseurs` DISABLE KEYS */;
INSERT INTO `Fournisseurs` VALUES
(1,'Fournisseur Alpha','contact@alpha.sn',NULL,'401100');
/*!40000 ALTER TABLE `Fournisseurs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GrandLivre`
--

DROP TABLE IF EXISTS `GrandLivre`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `GrandLivre` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DateComptable` date NOT NULL,
  `Libelle` varchar(255) DEFAULT NULL,
  `Montant` decimal(15,2) NOT NULL,
  `CompteDebiteur` varchar(15) DEFAULT NULL,
  `CompteCrediteur` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `CompteDebiteur` (`CompteDebiteur`),
  KEY `CompteCrediteur` (`CompteCrediteur`),
  CONSTRAINT `GrandLivre_ibfk_1` FOREIGN KEY (`CompteDebiteur`) REFERENCES `Comptes` (`CodeCompte`),
  CONSTRAINT `GrandLivre_ibfk_2` FOREIGN KEY (`CompteCrediteur`) REFERENCES `Comptes` (`CodeCompte`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GrandLivre`
--

LOCK TABLES `GrandLivre` WRITE;
/*!40000 ALTER TABLE `GrandLivre` DISABLE KEYS */;
/*!40000 ALTER TABLE `GrandLivre` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Produits`
--

DROP TABLE IF EXISTS `Produits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Produits` (
  `ProduitID` int(11) NOT NULL AUTO_INCREMENT,
  `Nom` varchar(255) NOT NULL,
  `Reference` varchar(100) NOT NULL,
  `StockActuel` int(11) DEFAULT 0,
  `CUMP` decimal(15,2) DEFAULT 0.00,
  `PrixVente` decimal(15,2) DEFAULT 0.00,
  `FournisseurID` int(11) DEFAULT NULL,
  `CompteStock` varchar(20) DEFAULT '311000',
  PRIMARY KEY (`ProduitID`),
  UNIQUE KEY `Reference` (`Reference`),
  KEY `FournisseurID` (`FournisseurID`),
  CONSTRAINT `Produits_ibfk_1` FOREIGN KEY (`FournisseurID`) REFERENCES `Fournisseurs` (`FournisseurID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Produits`
--

LOCK TABLES `Produits` WRITE;
/*!40000 ALTER TABLE `Produits` DISABLE KEYS */;
/*!40000 ALTER TABLE `Produits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `V_Valorisation_Stock`
--

DROP TABLE IF EXISTS `V_Valorisation_Stock`;
/*!50001 DROP VIEW IF EXISTS `V_Valorisation_Stock`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `V_Valorisation_Stock` AS SELECT
 1 AS `ValeurTotaleStock` */;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `V_Valorisation_Stock`
--

/*!50001 DROP VIEW IF EXISTS `V_Valorisation_Stock`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `V_Valorisation_Stock` AS select sum(`Produits`.`StockActuel` * `Produits`.`CUMP`) AS `ValeurTotaleStock` from `Produits` where `Produits`.`StockActuel` > 0 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-22 16:35:55
