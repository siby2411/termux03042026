/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: o_garage
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `charges_exploitation`
--

DROP TABLE IF EXISTS `charges_exploitation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `charges_exploitation` (
  `id_charge` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(100) DEFAULT NULL,
  `montant` decimal(10,2) DEFAULT NULL,
  `categorie` enum('Atelier','Lavage','Magasin','Général') DEFAULT NULL,
  `date_paiement` date DEFAULT NULL,
  PRIMARY KEY (`id_charge`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charges_exploitation`
--

LOCK TABLES `charges_exploitation` WRITE;
/*!40000 ALTER TABLE `charges_exploitation` DISABLE KEYS */;
INSERT INTO `charges_exploitation` VALUES
(1,'Facture Senelec',5000.00,'Lavage',NULL),
(2,'Salaire Mécanicien',40000.00,'Atelier',NULL);
/*!40000 ALTER TABLE `charges_exploitation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clients` (
  `id_client` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) DEFAULT NULL,
  `telephone` varchar(20) NOT NULL,
  `immatriculation_principale` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `adresse` varchar(255) DEFAULT NULL,
  `date_creation` datetime DEFAULT current_timestamp(),
  `immatriculation_vehicule` varchar(20) DEFAULT NULL,
  `modele_vehicule` varchar(100) DEFAULT NULL,
  `marque_vehicule` varchar(100) DEFAULT NULL,
  `derniere_visite` datetime DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `immatriculation` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_client`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` VALUES
(1,'Momo',NULL,'77 654 28 03 ',NULL,NULL,NULL,'2026-04-07 11:01:09',NULL,NULL,NULL,NULL,NULL,NULL),
(2,'Siby',NULL,'77100100 ','DK5 X',NULL,NULL,'2026-04-08 23:17:30',NULL,NULL,NULL,NULL,NULL,'DK5 X'),
(3,'Assane ',NULL,'Thiam ','Dk12',NULL,NULL,'2026-04-09 03:27:01',NULL,NULL,NULL,NULL,NULL,'Dk12'),
(4,'Fatou ',NULL,'Siby','Dk156',NULL,NULL,'2026-04-09 11:16:35',NULL,NULL,NULL,NULL,NULL,'Dk156'),
(5,'Pierre ',NULL,'78','Dk11',NULL,NULL,'2026-04-09 12:21:22',NULL,NULL,NULL,NULL,NULL,'Dk11'),
(6,'Sall',NULL,'79','Dk33',NULL,NULL,'2026-04-09 16:01:40',NULL,NULL,NULL,NULL,NULL,'Dk33'),
(7,'DIOP','Ibrahima','771234567','DK-1010-A',NULL,NULL,'2026-04-09 22:33:50',NULL,NULL,NULL,NULL,NULL,'DK-1010-A');
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `diagnostics`
--

DROP TABLE IF EXISTS `diagnostics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `diagnostics` (
  `id_diagnostic` int(11) NOT NULL AUTO_INCREMENT,
  `id_client` int(11) NOT NULL,
  `id_vehicule` int(11) NOT NULL,
  `date_entree` datetime DEFAULT current_timestamp(),
  `symptomes` text NOT NULL,
  `diagnostic` text NOT NULL,
  `pieces_a_remplacer` text DEFAULT NULL,
  `main_d_oeuvre` text DEFAULT NULL,
  `etat` enum('En attente','En cours','Terminé','Facturé') DEFAULT 'En attente',
  `id_mecanicien_1` int(11) DEFAULT NULL,
  `id_mecanicien_2` int(11) DEFAULT NULL,
  `cout_estime` decimal(10,2) DEFAULT NULL,
  `date_debut_reparation` datetime DEFAULT NULL,
  `date_fin_reparation` datetime DEFAULT NULL,
  PRIMARY KEY (`id_diagnostic`),
  KEY `id_client` (`id_client`),
  KEY `id_mecanicien_1` (`id_mecanicien_1`),
  KEY `id_mecanicien_2` (`id_mecanicien_2`),
  CONSTRAINT `diagnostics_ibfk_1` FOREIGN KEY (`id_client`) REFERENCES `clients` (`id_client`),
  CONSTRAINT `diagnostics_ibfk_2` FOREIGN KEY (`id_mecanicien_1`) REFERENCES `mecaniciens` (`id_mecanicien`),
  CONSTRAINT `diagnostics_ibfk_3` FOREIGN KEY (`id_mecanicien_2`) REFERENCES `mecaniciens` (`id_mecanicien`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `diagnostics`
--

LOCK TABLES `diagnostics` WRITE;
/*!40000 ALTER TABLE `diagnostics` DISABLE KEYS */;
INSERT INTO `diagnostics` VALUES
(1,1,1,'2026-04-05 00:16:51','Bruit anormal au démarrage','Problème de démarreur à remplacer','Démarreur','Remplacement du démarreur','En cours',1,2,150000.00,NULL,NULL),
(2,2,2,'2026-04-05 00:16:51','Freins qui grincent','Plaquettes de frein usées','Plaquettes de frein AV/AR','Remplacement des plaquettes','Terminé',2,3,80000.00,NULL,NULL),
(3,3,3,'2026-04-05 00:16:51','Voyant moteur allumé','Capteur d\'oxygène défectueux','Capteur O2','Remplacement du capteur','En attente',1,NULL,120000.00,NULL,NULL);
/*!40000 ALTER TABLE `diagnostics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipe`
--

DROP TABLE IF EXISTS `equipe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `equipe` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom_complet` varchar(255) NOT NULL,
  `poste` varchar(100) DEFAULT 'Mécanicien',
  `telephone` varchar(20) DEFAULT NULL,
  `disponible` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipe`
--

LOCK TABLES `equipe` WRITE;
/*!40000 ALTER TABLE `equipe` DISABLE KEYS */;
INSERT INTO `equipe` VALUES
(1,'Ibrahima Sarr','Mécanicien',NULL,1),
(2,'Moussa Gueye','Mécanicien',NULL,1),
(3,'Abdoulaye Diallo','Mécanicien',NULL,1);
/*!40000 ALTER TABLE `equipe` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `facture_items`
--

DROP TABLE IF EXISTS `facture_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `facture_items` (
  `id_item` int(11) NOT NULL AUTO_INCREMENT,
  `id_facture` int(11) DEFAULT NULL,
  `id_piece` int(11) DEFAULT NULL,
  `quantite` int(11) DEFAULT NULL,
  `prix_unitaire` decimal(15,2) DEFAULT NULL,
  `total_ligne` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id_item`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `facture_items`
--

LOCK TABLES `facture_items` WRITE;
/*!40000 ALTER TABLE `facture_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `facture_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `factures`
--

DROP TABLE IF EXISTS `factures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `factures` (
  `id_facture` int(11) NOT NULL AUTO_INCREMENT,
  `id_diagnostic` int(11) NOT NULL,
  `id_client` int(11) NOT NULL,
  `montant` decimal(10,2) NOT NULL,
  `date_facture` datetime DEFAULT current_timestamp(),
  `statut` enum('Non payée','Payée','Annulée') DEFAULT 'Non payée',
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id_facture`),
  KEY `id_diagnostic` (`id_diagnostic`),
  KEY `id_client` (`id_client`),
  CONSTRAINT `factures_ibfk_1` FOREIGN KEY (`id_diagnostic`) REFERENCES `diagnostics` (`id_diagnostic`),
  CONSTRAINT `factures_ibfk_2` FOREIGN KEY (`id_client`) REFERENCES `clients` (`id_client`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `factures`
--

LOCK TABLES `factures` WRITE;
/*!40000 ALTER TABLE `factures` DISABLE KEYS */;
/*!40000 ALTER TABLE `factures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `factures_pieces`
--

DROP TABLE IF EXISTS `factures_pieces`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `factures_pieces` (
  `id_facture` int(11) NOT NULL AUTO_INCREMENT,
  `id_client` int(11) DEFAULT NULL,
  `total_vente` int(11) DEFAULT NULL,
  `date_facture` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id_facture`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `factures_pieces`
--

LOCK TABLES `factures_pieces` WRITE;
/*!40000 ALTER TABLE `factures_pieces` DISABLE KEYS */;
/*!40000 ALTER TABLE `factures_pieces` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fiches_intervention`
--

DROP TABLE IF EXISTS `fiches_intervention`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fiches_intervention` (
  `id_fiche` int(11) NOT NULL AUTO_INCREMENT,
  `id_vehicule` int(11) DEFAULT NULL,
  `id_mec_1` int(11) DEFAULT NULL,
  `id_mec_2` int(11) DEFAULT NULL,
  `description_panne` text DEFAULT NULL,
  `diagnostic_technique` text DEFAULT NULL,
  `complexite` enum('Faible','Moyenne','Haute') DEFAULT 'Moyenne',
  `cout_main_doeuvre` decimal(15,2) DEFAULT NULL,
  `statut` enum('En cours','Terminé') DEFAULT 'En cours',
  `date_entree` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_fiche`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fiches_intervention`
--

LOCK TABLES `fiches_intervention` WRITE;
/*!40000 ALTER TABLE `fiches_intervention` DISABLE KEYS */;
INSERT INTO `fiches_intervention` VALUES
(1,1,2,NULL,'Révision 150k','Vidange + filtres + Check suspensions','Faible',25000.00,'Terminé','2026-04-01 00:00:00'),
(2,3,2,NULL,'Injecteurs grippés','Nettoyage ultrasons et calibrage','Haute',120000.00,'Terminé','2026-04-02 00:00:00'),
(3,2,3,NULL,'Court-circuit Phares','Faisceau endommagé par rongeurs','Moyenne',45000.00,'Terminé','2026-04-03 00:00:00'),
(4,4,2,NULL,'Freinage inefficace','Remplacement disques et plaquettes','Moyenne',65000.00,'En cours','2026-04-05 00:00:00'),
(5,7,3,NULL,'Check Électronique','Passage valise diag - OK','Faible',20000.00,'Terminé','2026-04-06 00:00:00'),
(6,1,1,NULL,'Surchauffe Moteur','Remplacement joint de culasse et purge circuit','Moyenne',150000.00,'Terminé','2026-04-01 00:00:00'),
(7,2,2,NULL,'Témoin ABS allumé','Capteur de roue arrière gauche défectueux','Moyenne',35000.00,'Terminé','2026-04-02 00:00:00'),
(8,3,1,NULL,'Bruit train avant','Remplacement des triangles et rotules','Moyenne',55000.00,'Terminé','2026-04-02 00:00:00'),
(9,5,3,NULL,'Révision simple','Vidange moteur + filtre climatisation','Moyenne',15000.00,'Terminé','2026-04-03 00:00:00'),
(10,7,4,NULL,'Panne batterie hybride','Équilibrage des cellules de batterie','Moyenne',250000.00,'Terminé','2026-04-04 00:00:00'),
(11,1,2,NULL,'Problème Climatisation','Recharge gaz et détection fuite','Moyenne',40000.00,'En cours','2026-04-06 00:00:00'),
(12,2,4,NULL,NULL,NULL,'Moyenne',NULL,'En cours','2026-04-07 12:41:31'),
(13,2,4,NULL,NULL,'Test démarrage ','Moyenne',2500.00,'En cours','2026-04-09 02:04:34'),
(14,4,4,NULL,NULL,NULL,'Moyenne',NULL,'En cours','2026-04-09 03:05:36');
/*!40000 ALTER TABLE `fiches_intervention` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `immobilisations`
--

DROP TABLE IF EXISTS `immobilisations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `immobilisations` (
  `id_immo` int(11) NOT NULL AUTO_INCREMENT,
  `nom_materiel` varchar(150) DEFAULT NULL,
  `date_achat` date DEFAULT NULL,
  `cout_acquisition` decimal(15,2) DEFAULT NULL,
  `duree_vie_ans` int(11) DEFAULT NULL,
  `etat` enum('Neuf','Bon','Maintenance','HS') DEFAULT 'Neuf',
  PRIMARY KEY (`id_immo`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `immobilisations`
--

LOCK TABLES `immobilisations` WRITE;
/*!40000 ALTER TABLE `immobilisations` DISABLE KEYS */;
INSERT INTO `immobilisations` VALUES
(1,'Karcher Haute Pression K7','2026-01-15',450000.00,3,'Neuf'),
(2,'Pont Élévateur 4T','2025-12-01',2500000.00,10,'Bon');
/*!40000 ALTER TABLE `immobilisations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `interventions`
--

DROP TABLE IF EXISTS `interventions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `interventions` (
  `id_intervention` int(11) NOT NULL AUTO_INCREMENT,
  `id_vehicule` int(11) DEFAULT NULL,
  `description_panne` text DEFAULT NULL,
  `main_doeuvre` decimal(10,2) DEFAULT 0.00,
  `statut` varchar(50) DEFAULT 'Terminé',
  `date_reparation` timestamp NULL DEFAULT current_timestamp(),
  `km_entree` int(11) DEFAULT NULL,
  `id_mecanicien` int(11) DEFAULT NULL,
  `immatriculation` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_intervention`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `interventions`
--

LOCK TABLES `interventions` WRITE;
/*!40000 ALTER TABLE `interventions` DISABLE KEYS */;
INSERT INTO `interventions` VALUES
(1,NULL,'Révision complète Toyota',25000.00,'Terminé','2026-04-05 12:42:45',NULL,NULL,NULL),
(2,NULL,'Changement Freins',15000.00,'Terminé','2026-04-05 12:42:45',NULL,NULL,NULL),
(3,NULL,'Bruit train \n--- TRAVAUX FAITS ---\n',150000.00,'Terminé','2026-04-09 16:53:13',15000,1,'DK11'),
(4,NULL,'Train bruit \n--- TRAVAUX FAITS ---\n',25000.00,'Terminé','2026-04-09 20:35:47',12000,1,'Dk33'),
(5,NULL,'Surchauffe moteur et sifflement turbo',0.00,'En cours','2026-04-09 22:33:50',155000,1,'DK-1010-A'),
(6,NULL,'Vidange simple effectuée',15000.00,'Terminé','2026-04-09 22:33:50',154000,1,'DK-1010-A');
/*!40000 ALTER TABLE `interventions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lavage_operations`
--

DROP TABLE IF EXISTS `lavage_operations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lavage_operations` (
  `id_lavage` int(11) NOT NULL AUTO_INCREMENT,
  `id_vehicule` int(11) DEFAULT NULL,
  `id_tarif` int(11) DEFAULT NULL,
  `agent_affecte` varchar(100) DEFAULT NULL,
  `heure_entree` datetime DEFAULT current_timestamp(),
  `heure_sortie` datetime DEFAULT NULL,
  `statut` enum('En attente','En cours','Terminé') DEFAULT 'En attente',
  `montant_encaisse` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id_lavage`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lavage_operations`
--

LOCK TABLES `lavage_operations` WRITE;
/*!40000 ALTER TABLE `lavage_operations` DISABLE KEYS */;
INSERT INTO `lavage_operations` VALUES
(1,NULL,1,'Modou','2026-04-05 12:31:35',NULL,'Terminé',3000.00),
(2,NULL,2,'Ibra','2026-04-05 12:31:35',NULL,'Terminé',7000.00),
(3,NULL,2,'Modou','2026-04-05 12:31:35',NULL,'Terminé',7000.00);
/*!40000 ALTER TABLE `lavage_operations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lavage_tarifs`
--

DROP TABLE IF EXISTS `lavage_tarifs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lavage_tarifs` (
  `id_tarif` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(100) DEFAULT NULL,
  `prix_client` decimal(10,2) DEFAULT NULL,
  `cout_produits_estime` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id_tarif`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lavage_tarifs`
--

LOCK TABLES `lavage_tarifs` WRITE;
/*!40000 ALTER TABLE `lavage_tarifs` DISABLE KEYS */;
INSERT INTO `lavage_tarifs` VALUES
(1,'Simple (Extérieur)',3000.00,500.00),
(2,'Complet (Int/Ext)',7000.00,1200.00),
(3,'Lavage Moteur',5000.00,800.00),
(4,'Lustrage Pro',15000.00,3500.00),
(5,'Simple',3000.00,500.00),
(6,'Complet',7000.00,1500.00),
(7,'Moteur',5000.00,1000.00);
/*!40000 ALTER TABLE `lavage_tarifs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lavage_transactions`
--

DROP TABLE IF EXISTS `lavage_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lavage_transactions` (
  `id_lavage` int(11) NOT NULL AUTO_INCREMENT,
  `immatriculation` varchar(20) DEFAULT NULL,
  `type_lavage` varchar(50) DEFAULT NULL,
  `montant` int(11) DEFAULT NULL,
  `date_lavage` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id_lavage`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lavage_transactions`
--

LOCK TABLES `lavage_transactions` WRITE;
/*!40000 ALTER TABLE `lavage_transactions` DISABLE KEYS */;
INSERT INTO `lavage_transactions` VALUES
(1,'DK-1234-A','Complet',7000,'2026-04-01 09:00:00'),
(2,'TH-5678-B','Simple',3000,'2026-04-01 10:30:00'),
(3,'DK-7788-BD','Moteur+Chassis',10000,'2026-04-02 14:00:00'),
(4,'DK-0001-ZG','Poids Lourd',15000,'2026-04-03 08:00:00'),
(5,'AD-001-PR','Complet VIP',12000,'2026-04-04 16:00:00'),
(6,'DK-5544-AS','Simple',3000,'2026-04-05 11:00:00'),
(7,'DK-1234-A','Simple',3000,'2026-04-06 17:00:00');
/*!40000 ALTER TABLE `lavage_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mecaniciens`
--

DROP TABLE IF EXISTS `mecaniciens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mecaniciens` (
  `id_mecanicien` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `telephone` varchar(20) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `adresse` text DEFAULT NULL,
  `specialite` varchar(100) DEFAULT NULL,
  `salaire_horaire` decimal(10,2) NOT NULL,
  `date_embauche` date DEFAULT NULL,
  `actif` tinyint(1) DEFAULT 1,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id_mecanicien`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mecaniciens`
--

LOCK TABLES `mecaniciens` WRITE;
/*!40000 ALTER TABLE `mecaniciens` DISABLE KEYS */;
INSERT INTO `mecaniciens` VALUES
(1,'Sarr','Omar','770000001','omar.sarr@example.com','Dakar, Grand Yoff','Moteur',5000.00,'2020-01-15',1,'Expert en moteurs diesel'),
(2,'Ba','Modou','770000002','modou.ba@example.com','Pikine, Niayes','Freins',4500.00,'2019-05-20',1,'Spécialiste ABS'),
(3,'Diouf','Moustapha','770000003','moustapha.diouf@example.com','Dakar, Mermoz','Électronique',5500.00,'2021-03-10',1,'Diagnostic électronique'),
(4,'Diallo','Moussa','771234567',NULL,NULL,'Diagnostic Électronique',5000.00,NULL,1,NULL),
(5,'Sow','Abdoulaye','789876543',NULL,NULL,'Mécanique Diesel',4500.00,NULL,1,NULL);
/*!40000 ALTER TABLE `mecaniciens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modules_formation`
--

DROP TABLE IF EXISTS `modules_formation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `modules_formation` (
  `id_formation` int(11) NOT NULL AUTO_INCREMENT,
  `titre_formation` varchar(100) DEFAULT NULL,
  `domaine` enum('Mécanique','Électronique','Injection','Hydraulique') NOT NULL,
  `description` text DEFAULT NULL,
  `seuil_alerte` int(11) DEFAULT 60,
  PRIMARY KEY (`id_formation`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modules_formation`
--

LOCK TABLES `modules_formation` WRITE;
/*!40000 ALTER TABLE `modules_formation` DISABLE KEYS */;
INSERT INTO `modules_formation` VALUES
(1,'Diagnostic Scanner Avancé','Électronique','Maîtrise des valises de diagnostic pour pannes intermittentes.',60),
(2,'Maintenance Systèmes Injection Diesel','Injection','Optimisation de la consommation et réduction des fumées.',60),
(3,'Réfection Moteurs Turbo','Mécanique','Techniques de rénovation complète des moteurs suralimentés.',60);
/*!40000 ALTER TABLE `modules_formation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notes_performance`
--

DROP TABLE IF EXISTS `notes_performance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notes_performance` (
  `id_note` int(11) NOT NULL AUTO_INCREMENT,
  `id_personnel` int(11) DEFAULT NULL,
  `mois_annee` varchar(7) DEFAULT NULL,
  `note_technique` int(11) DEFAULT NULL,
  `note_assiduite` int(11) DEFAULT NULL,
  `commentaires` text DEFAULT NULL,
  `date_notation` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_note`),
  UNIQUE KEY `id_personnel` (`id_personnel`,`mois_annee`),
  CONSTRAINT `notes_performance_ibfk_1` FOREIGN KEY (`id_personnel`) REFERENCES `personnel` (`id_personnel`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notes_performance`
--

LOCK TABLES `notes_performance` WRITE;
/*!40000 ALTER TABLE `notes_performance` DISABLE KEYS */;
/*!40000 ALTER TABLE `notes_performance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personnel`
--

DROP TABLE IF EXISTS `personnel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `personnel` (
  `id_personnel` int(11) NOT NULL AUTO_INCREMENT,
  `code_interne` varchar(20) DEFAULT NULL,
  `nom_complet` varchar(100) DEFAULT NULL,
  `role` varchar(100) DEFAULT NULL,
  `salaire_base` decimal(15,2) DEFAULT NULL,
  `note_performance` decimal(3,2) DEFAULT 5.00,
  `nombre_interventions` int(11) DEFAULT 0,
  `assiduite` int(11) DEFAULT 100,
  `date_embauche` date DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `specialite` varchar(50) DEFAULT NULL,
  `salaire_horaire` int(11) DEFAULT 0,
  PRIMARY KEY (`id_personnel`),
  UNIQUE KEY `code_interne` (`code_interne`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personnel`
--

LOCK TABLES `personnel` WRITE;
/*!40000 ALTER TABLE `personnel` DISABLE KEYS */;
INSERT INTO `personnel` VALUES
(1,'OMEGA-2026-0007','Mecano Test','Mécanicien',NULL,5.00,0,100,NULL,NULL,NULL,0),
(4,'OMEGA-2026-0001','Ibrahima Sarr','Mécanicien Senior',NULL,5.00,0,100,'2025-01-10','771002030','Moteur',0),
(5,'OMEGA-2026-0005','Moussa Gueye','Électricien Auto',NULL,5.00,0,100,'2025-03-15','772003040','Électronique',0),
(6,'OMEGA-2026-0006','Abdoulaye Diallo','Mécanicien Jnr',NULL,5.00,0,100,'2026-01-05','773004050','Trains roulants',0);
/*!40000 ALTER TABLE `personnel` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER before_insert_personnel
BEFORE INSERT ON personnel
FOR EACH ROW
BEGIN
    DECLARE v_id INT;
    
    SELECT COALESCE(MAX(id_personnel), 0) + 1 INTO v_id FROM personnel;
    SET NEW.code_interne = CONCAT('OMEGA-', YEAR(CURDATE()), '-', LPAD(v_id, 4, '0'));
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `pieces_detachees`
--

DROP TABLE IF EXISTS `pieces_detachees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pieces_detachees` (
  `id_piece` int(11) NOT NULL AUTO_INCREMENT,
  `nom_piece` varchar(255) NOT NULL,
  `prix_vente` int(11) NOT NULL,
  `stock_actuel` int(11) DEFAULT 0,
  `categorie` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_piece`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pieces_detachees`
--

LOCK TABLES `pieces_detachees` WRITE;
/*!40000 ALTER TABLE `pieces_detachees` DISABLE KEYS */;
INSERT INTO `pieces_detachees` VALUES
(1,'Filtre à huile Toyota',5500,20,NULL),
(2,'Filtre à air Diesel',8500,13,NULL),
(3,'Plaquettes de frein Avant',18000,10,NULL),
(4,'Filtre à huile Toyota',4500,9,NULL),
(5,'Filtre à essence',3500,5,NULL),
(6,'Filtre à air Diesel',8000,12,NULL),
(7,'Plaquettes de frein',15000,8,NULL);
/*!40000 ALTER TABLE `pieces_detachees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pieces_utilisees`
--

DROP TABLE IF EXISTS `pieces_utilisees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pieces_utilisees` (
  `id_utilisation` int(11) NOT NULL AUTO_INCREMENT,
  `id_fiche` int(11) DEFAULT NULL,
  `id_piece` int(11) DEFAULT NULL,
  `quantite` int(11) DEFAULT NULL,
  `prix_unitaire` int(11) DEFAULT NULL,
  `prix_total` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_utilisation`),
  KEY `id_fiche` (`id_fiche`),
  CONSTRAINT `pieces_utilisees_ibfk_1` FOREIGN KEY (`id_fiche`) REFERENCES `fiches_intervention` (`id_fiche`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pieces_utilisees`
--

LOCK TABLES `pieces_utilisees` WRITE;
/*!40000 ALTER TABLE `pieces_utilisees` DISABLE KEYS */;
/*!40000 ALTER TABLE `pieces_utilisees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plan_renovation`
--

DROP TABLE IF EXISTS `plan_renovation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `plan_renovation` (
  `id_plan` int(11) NOT NULL AUTO_INCREMENT,
  `id_personnel` int(11) DEFAULT NULL,
  `id_formation` int(11) DEFAULT NULL,
  `date_suggestion` timestamp NULL DEFAULT current_timestamp(),
  `statut` enum('Suggéré','En cours','Validé') DEFAULT 'Suggéré',
  PRIMARY KEY (`id_plan`),
  KEY `id_personnel` (`id_personnel`),
  KEY `id_formation` (`id_formation`),
  CONSTRAINT `plan_renovation_ibfk_1` FOREIGN KEY (`id_personnel`) REFERENCES `personnel` (`id_personnel`),
  CONSTRAINT `plan_renovation_ibfk_2` FOREIGN KEY (`id_formation`) REFERENCES `modules_formation` (`id_formation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plan_renovation`
--

LOCK TABLES `plan_renovation` WRITE;
/*!40000 ALTER TABLE `plan_renovation` DISABLE KEYS */;
/*!40000 ALTER TABLE `plan_renovation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prestations`
--

DROP TABLE IF EXISTS `prestations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `prestations` (
  `id_prestation` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(100) DEFAULT NULL,
  `tarif_mo` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_prestation`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prestations`
--

LOCK TABLES `prestations` WRITE;
/*!40000 ALTER TABLE `prestations` DISABLE KEYS */;
INSERT INTO `prestations` VALUES
(1,'Vidange Simple',5000),
(2,'Révision Complète',25000),
(3,'Freinage',12000);
/*!40000 ALTER TABLE `prestations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `specialites`
--

DROP TABLE IF EXISTS `specialites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `specialites` (
  `id_spec` int(11) NOT NULL AUTO_INCREMENT,
  `nom_specialite` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_spec`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `specialites`
--

LOCK TABLES `specialites` WRITE;
/*!40000 ALTER TABLE `specialites` DISABLE KEYS */;
INSERT INTO `specialites` VALUES
(1,'Électronique'),
(2,'Moteur Diesel'),
(3,'Boîte Auto'),
(4,'Climatisation');
/*!40000 ALTER TABLE `specialites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `types_reparation`
--

DROP TABLE IF EXISTS `types_reparation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `types_reparation` (
  `id_type` int(11) NOT NULL AUTO_INCREMENT,
  `libelle_reparation` varchar(100) DEFAULT NULL,
  `tarif_main_oeuvre` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_type`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `types_reparation`
--

LOCK TABLES `types_reparation` WRITE;
/*!40000 ALTER TABLE `types_reparation` DISABLE KEYS */;
INSERT INTO `types_reparation` VALUES
(1,'Vidange Simple',5000),
(2,'Révision 150k',25000),
(3,'Changement Freins',10000),
(4,'Vidange moteur + Filtre',5000),
(5,'Révision Système Freinage',15000),
(6,'Diagnostic Électronique OBD',10000),
(7,'Remplacement Amortisseurs (Paire)',25000),
(8,'Réfection Moteur complète',150000);
/*!40000 ALTER TABLE `types_reparation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vehicules`
--

DROP TABLE IF EXISTS `vehicules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `vehicules` (
  `id_vehicule` int(11) NOT NULL AUTO_INCREMENT,
  `immatriculation` varchar(20) NOT NULL,
  `marque` varchar(100) NOT NULL,
  `modele` varchar(100) NOT NULL,
  `annee` int(11) DEFAULT NULL,
  `id_client` int(11) DEFAULT NULL,
  `date_creation` datetime DEFAULT current_timestamp(),
  `statut_presence` enum('Atelier','Lavage','Sorti') DEFAULT 'Atelier',
  `date_livraison` datetime DEFAULT NULL,
  `dernier_km` int(11) DEFAULT 0,
  `prochain_rappel_km` int(11) DEFAULT 0,
  `telephone_client` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_vehicule`),
  KEY `id_client` (`id_client`),
  CONSTRAINT `vehicules_ibfk_1` FOREIGN KEY (`id_client`) REFERENCES `clients` (`id_client`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vehicules`
--

LOCK TABLES `vehicules` WRITE;
/*!40000 ALTER TABLE `vehicules` DISABLE KEYS */;
INSERT INTO `vehicules` VALUES
(2,'DK45','Toyota ','Hilux ',NULL,1,'2026-04-07 12:41:31','Atelier',NULL,12500,17500,NULL),
(3,'DK5 X','A préciser','A préciser',NULL,2,'2026-04-08 23:17:30','Atelier',NULL,0,0,NULL),
(4,'','Inconnue','Inconnu',NULL,NULL,'2026-04-09 03:05:36','Atelier',NULL,12500,0,NULL);
/*!40000 ALTER TABLE `vehicules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vente_details`
--

DROP TABLE IF EXISTS `vente_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `vente_details` (
  `id_detail` int(11) NOT NULL AUTO_INCREMENT,
  `id_vente` int(11) DEFAULT NULL,
  `id_piece` int(11) DEFAULT NULL,
  `quantite` int(11) DEFAULT NULL,
  `prix_unitaire` int(11) DEFAULT NULL,
  `sous_total` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_detail`),
  KEY `id_vente` (`id_vente`),
  CONSTRAINT `vente_details_ibfk_1` FOREIGN KEY (`id_vente`) REFERENCES `ventes` (`id_vente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vente_details`
--

LOCK TABLES `vente_details` WRITE;
/*!40000 ALTER TABLE `vente_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `vente_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ventes`
--

DROP TABLE IF EXISTS `ventes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ventes` (
  `id_vente` int(11) NOT NULL AUTO_INCREMENT,
  `date_vente` datetime DEFAULT NULL,
  `total_ht` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_vente`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ventes`
--

LOCK TABLES `ventes` WRITE;
/*!40000 ALTER TABLE `ventes` DISABLE KEYS */;
INSERT INTO `ventes` VALUES
(1,'2026-04-09 04:16:18',21500);
/*!40000 ALTER TABLE `ventes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-22 16:35:58
